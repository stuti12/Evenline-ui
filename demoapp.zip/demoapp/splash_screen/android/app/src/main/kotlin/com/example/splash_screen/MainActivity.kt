package com.example.splash_screen

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
