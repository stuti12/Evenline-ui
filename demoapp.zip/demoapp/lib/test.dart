void main() async {
  List<int> numbers = [1, 2, 1, 3, 3, 5, 4, 5];

  var seenint = Set<String>();
  List<int> uniquenum =
      numbers.where((numone) => seenint.add(numone.toString())).toList();
  print(uniquenum);

  List<String> countries = [
    "Nepal",
    "Nepal",
    "USA",
    "Canada",
    "Canada",
    "China",
    "Russia",
  ];

  var seen = Set<String>();
  List<String> uniquelist =
      countries.where((country) => seen.add(country)).toList();
  print(uniquelist);

  var list = [1, 2, 3, 4, 4, 24, 6, 9, 6];
  var unique = list.toSet().toList();
  print(unique);

  Set<int> set = {1, 2, 3, 4, 5, 6};
  Set<int> set2 = {1, 3, 5, 6};
  Set<int> set3 = {5, 6};
  print(set.intersection(set2).intersection(set3));

  var stream = countStream(10);
  var sum = await sumStream(stream);
  print(sum);
}

Future<int> sumStream(Stream<int> stream) async {
  var sum = 0;
  await for (final value in stream) {
    sum += value;
  }
  return sum;
}

Stream<int> countStream(int to) async* {
  for (int i = 1; i <= to; i++) {
    yield i;
  }
}
