void main() {
  List<int> array = [1, 2, 3, 4];
  List<int> array2 = [];

  array.asMap().forEach((key, value) => {print(key)});

  for (int i in array) {
    for (int temp in array) {
      var k = i - 1;
      var j = i + 1;
      if (k != i) {
        j = (j) * k;

        //  print(j);
      }
    }
  }
}
