import 'package:flutter/material.dart';

void main() => runApp(const ChipDemoApp());

class ChipDemoApp extends StatelessWidget {
  const ChipDemoApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    const appTitle = 'Flutter Chip Demo';

    return MaterialApp(
      title: appTitle,
      home: Scaffold(
        appBar: AppBar(
          title: const Text(appTitle),
          leading: IconButton(
            icon: const Icon(Icons.arrow_back),
            onPressed: () {
              Navigator.of(context, rootNavigator: false).pop(context);
            },
          ),
          centerTitle: true,
        ),
        body: Column(children: [
          Chip(
            elevation: 20,
            padding: const EdgeInsets.all(8),
            backgroundColor: Colors.greenAccent[400],
            shadowColor: Colors.black,
            avatar: const CircleAvatar(
              backgroundImage: NetworkImage(
                  "https://picsum.photos/250?image=11"), //NetwordImage
            ),
            //CircleAvatar
            label: const Text(
              'Stuti Bhavsar',
              style: TextStyle(fontSize: 20, color: Colors.white),
            ), //Text
          ),
          Chip(
            elevation: 20,
            padding: const EdgeInsets.all(8),
            backgroundColor: Colors.greenAccent[400],
            shadowColor: Colors.black,
            avatar: const CircleAvatar(
              backgroundImage: NetworkImage(
                  "https://picsum.photos/250?image=11"), //NetwordImage
            ),
            //CircleAvatar
            label: const Text(
              'Nidhi',
              style: TextStyle(fontSize: 20, color: Colors.white),
            ), //Text
          ),
          Chip(
            elevation: 20,
            padding: const EdgeInsets.all(8),
            backgroundColor: Colors.greenAccent[400],
            shadowColor: Colors.black,
            avatar: const CircleAvatar(
              backgroundImage: NetworkImage(
                  "https://picsum.photos/250?image=13"), //NetwordImage
            ),
            //CircleAvatar
            label: const Text(
              'Abcdefgh',
              style: TextStyle(fontSize: 20, color: Colors.white),
            ), //Text
          ),
        ]
            //Chip
            ),
      ),
    );
  }
}
