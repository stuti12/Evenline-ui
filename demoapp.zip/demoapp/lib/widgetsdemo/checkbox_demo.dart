import 'package:flutter/material.dart';

void main() {
  runApp(const MaterialApp(
    home: MyCheckboxDemoApp(),
  ));
}

class MyCheckboxDemoApp extends StatefulWidget {
  const MyCheckboxDemoApp({Key? key}) : super(key: key);

  @override
  _CheckboxPageState createState() => _CheckboxPageState();
}

class _CheckboxPageState extends State<MyCheckboxDemoApp> {
  bool valuefirst = false;
  bool valuesecond = false;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
          appBar: AppBar(
            title: const Text('Flutter Checkbox Example'),
            leading: IconButton(
              icon: const Icon(Icons.arrow_back),
              onPressed: () {
                Navigator.of(context, rootNavigator: true).pop(context);
              },
            ),
            centerTitle: true,
          ),
          body: Container(
            constraints: const BoxConstraints(
                maxHeight: double.infinity, maxWidth: double.infinity),
            padding: const EdgeInsets.all(10.0),
            child: Column(
              children: <Widget>[
                const SizedBox(
                  width: 10.0,
                ),
                const Text(
                  'CheckBox Example',
                  style: TextStyle(fontSize: 16.0),
                ),
                CheckboxListTile(
                  secondary: const Icon(Icons.alarm),
                  title: const Text('Alarm Ring 5:00 am'),
                  subtitle: const Text('Ring After 12hr'),
                  value: this.valuefirst,
                  onChanged: (bool? value) {
                    setState(() {
                      valuefirst = value!;
                    });
                  },
                ),
                CheckboxListTile(
                  secondary: const Icon(Icons.alarm),
                  title: const Text('Alarm Ring 4:40 am'),
                  subtitle: const Text('Ring After 12hr'),
                  value: valuesecond,
                  onChanged: (bool? value) {
                    setState(() {
                      valuesecond = value!;
                    });
                  },
                )
              ],
            ),
          )),
    );
  }
}
