import 'package:flutter/material.dart';

void main() {
  runApp(const MyRowColumnDemoApp());
}

class MyRowColumnDemoApp extends StatelessWidget {
  const MyRowColumnDemoApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
        debugShowCheckedModeBanner: false, home: MyRowColumnPage());
  }
}

class MyRowColumnPage extends StatefulWidget {
  const MyRowColumnPage({Key? key}) : super(key: key);

  @override
  _MyRowColumnPageState createState() => _MyRowColumnPageState();
}

class _MyRowColumnPageState extends State<MyRowColumnPage> {
  final textStyles = const TextStyle(fontSize: 20, fontWeight: FontWeight.bold);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Flutter Row Column Example"),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.of(context, rootNavigator: true).pop(context);
          },
        ),
        centerTitle: true,
      ),
      body: Container(
        transform: Matrix4.rotationX(0.4),
        margin: const EdgeInsets.all(4.0),
        decoration: const BoxDecoration(
            color: Colors.pink,
            shape: BoxShape.rectangle,
            boxShadow: [
              BoxShadow(color: Colors.black, offset: Offset(6.0, 6.0))
            ]),
        padding: const EdgeInsets.all(6.0),
        child: Container(
          color: Colors.lightBlueAccent,
          height: 840,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            verticalDirection: VerticalDirection.down,
            children: [
              Container(
                padding: EdgeInsets.all(8.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    const CircleAvatar(
                      backgroundImage: NetworkImage(
                          "https://www.clipartmax.com/png/middle/277-2772135_female-user-icon-download-female-person-icon.png"),
                      radius: 20,
                    ),
                    const SizedBox(width: 8),
                    Column(
                      children: const [
                        Text(
                          "Stuti Bhavsar",
                          style: TextStyle(
                              fontFamily: 'Lato-Font', fontSize: 19.0),
                        ),
                        Text(
                          "Android Developer",
                          style:
                              TextStyle(fontFamily: 'Lato-Font', fontSize: 14),
                        ),
                      ],
                    )
                  ],
                ),
              ),
              Container(
                  padding: const EdgeInsets.all(5),
                  width: double.infinity,
                  child: Image.network(
                    "https://picsum.photos/250?image=15",
                    height: 100,
                    fit: BoxFit.fitWidth,
                  )),
              Container(
                  padding: const EdgeInsets.all(5),
                  width: double.infinity,
                  child: Image.asset(
                    'assets/laptop.png',
                    //    color: const Color.fromRGBO(40, 44, 155, 0.1),
                    height: 300,
                    fit: BoxFit.fitWidth,
                  )),
              Container(
                padding: EdgeInsets.all(8.0),
                child: const Text(
                    "Such a beautiful architecture, you must visit atleast once in your life"),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Row(
                    children: const [Icon(Icons.thumb_up), Text("Like")],
                  ),
                  Row(
                    children: const [Icon(Icons.comment), Text("Comment")],
                  ),
                  Row(
                    children: const [Icon(Icons.share), Text("Share")],
                  )
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
