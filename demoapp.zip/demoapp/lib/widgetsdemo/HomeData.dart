import 'dart:convert';

List<Home> postFromJson(String str) =>
    List<Home>.from(json.decode(str).map((x) => Home.fromJson(x)));

class Home {
  int? code;
  int? status;
  Data? data;

  Home({this.code, this.status, this.data});

  Home.fromJson(Map<String, dynamic> json) {
    code = json['code'];
    status = json['status'];
    data = json['data'] != null ? new Data.fromJson(json['data']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['code'] = this.code;
    data['status'] = this.status;
    if (this.data != null) {
      data['data'] = this.data!.toJson();
    }
    return data;
  }
}

class Data {
  int? count;
  List<Rows>? rows;

  Data({this.count, this.rows});

  Data.fromJson(Map<String, dynamic> json) {
    count = json['count'];
    if (json['rows'] != null) {
      rows = <Rows>[];
      json['rows'].forEach((v) {
        rows!.add(new Rows.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['count'] = this.count;
    if (this.rows != null) {
      data['rows'] = this.rows!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Rows {
  int? id;
  int? userId;
  String? tripName;
  String? tripPostType;
  String? createdAt;
  String? startDate;
  String? endDate;
  String? updatedAt;
  bool? isDeleted;
  bool? isExpired;
  String? tripDetails;
  int? maxPeopleJoin;
  int? noOfLikes;
  int? noOfComments;
  String? lat;
  String? long;
  Null? tripAddress;
  String? city;
  String? state;
  String? country;
  List<MediaId>? mediaId;
  UserDetailsForTrip? userDetailsForTrip;
  List<Null>? userTripLikes;
  List<Null>? tripFavoriteId;

  Rows(
      {this.id,
      this.userId,
      this.tripName,
      this.tripPostType,
      this.createdAt,
      this.startDate,
      this.endDate,
      this.updatedAt,
      this.isDeleted,
      this.isExpired,
      this.tripDetails,
      this.maxPeopleJoin,
      this.noOfLikes,
      this.noOfComments,
      this.lat,
      this.long,
      this.tripAddress,
      this.city,
      this.state,
      this.country,
      this.mediaId,
      this.userDetailsForTrip,
      this.userTripLikes,
      this.tripFavoriteId});

  Rows.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    userId = json['user_id'];
    tripName = json['trip_name'];
    tripPostType = json['trip_post_type'];
    createdAt = json['createdAt'];
    startDate = json['start_date'];
    endDate = json['end_date'];
    updatedAt = json['updatedAt'];
    isDeleted = json['is_deleted'];
    isExpired = json['is_expired'];
    tripDetails = json['trip_details'];
    maxPeopleJoin = json['max_people_join'];
    noOfLikes = json['no_of_likes'];
    noOfComments = json['no_of_comments'];
    lat = json['lat'];
    long = json['long'];
    tripAddress = json['trip_address'];
    city = json['city'];
    state = json['state'];
    country = json['country'];
    if (json['mediaId'] != null) {
      mediaId = <MediaId>[];
      json['mediaId'].forEach((v) {
        mediaId!.add(new MediaId.fromJson(v));
      });
    }
    userDetailsForTrip = json['userDetailsForTrip'] != null
        ? UserDetailsForTrip.fromJson(json['userDetailsForTrip'])
        : null;
    if (json['user_trip_likes'] != null) {
      userTripLikes = <Null>[];
      json['user_trip_likes'].forEach((v) {
        userTripLikes!.add(null);
      });
    }
    if (json['tripFavoriteId'] != null) {
      tripFavoriteId = <Null>[];
      json['tripFavoriteId'].forEach((v) {
        tripFavoriteId!.add(null);
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['user_id'] = this.userId;
    data['trip_name'] = this.tripName;
    data['trip_post_type'] = this.tripPostType;
    data['createdAt'] = this.createdAt;
    data['start_date'] = this.startDate;
    data['end_date'] = this.endDate;
    data['updatedAt'] = this.updatedAt;
    data['is_deleted'] = this.isDeleted;
    data['is_expired'] = this.isExpired;
    data['trip_details'] = this.tripDetails;
    data['max_people_join'] = this.maxPeopleJoin;
    data['no_of_likes'] = this.noOfLikes;
    data['no_of_comments'] = this.noOfComments;
    data['lat'] = this.lat;
    data['long'] = this.long;
    data['trip_address'] = this.tripAddress;
    data['city'] = this.city;
    data['state'] = this.state;
    data['country'] = this.country;
    if (this.mediaId != null) {
      data['mediaId'] = this.mediaId!.map((v) => v.toJson()).toList();
    }
    if (this.userDetailsForTrip != null) {
      data['userDetailsForTrip'] = userDetailsForTrip!.toJson();
    }
    if (this.userTripLikes != null) {
      /* data['user_trip_likes'] =
          this.userTripLikes!.map((v) => v?.toJson()).toList();*/
    }
    if (this.tripFavoriteId != null) {
      /*   data['tripFavoriteId'] =
          this.tripFavoriteId!.map((v) => v?.toJson()).toList();*/
    }
    return data;
  }
}

class MediaId {
  int? id;
  int? userTripId;
  String? mediaUrl;
  String? mediaType;
  String? createdAt;
  String? updatedAt;
  bool? isDeleted;

  MediaId(
      {this.id,
      this.userTripId,
      this.mediaUrl,
      this.mediaType,
      this.createdAt,
      this.updatedAt,
      this.isDeleted});

  MediaId.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    userTripId = json['user_trip_id'];
    mediaUrl = json['media_url'];
    mediaType = json['media_type'];
    createdAt = json['createdAt'];
    updatedAt = json['updatedAt'];
    isDeleted = json['is_deleted'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['user_trip_id'] = this.userTripId;
    data['media_url'] = this.mediaUrl;
    data['media_type'] = this.mediaType;
    data['createdAt'] = this.createdAt;
    data['updatedAt'] = this.updatedAt;
    data['is_deleted'] = this.isDeleted;
    return data;
  }
}

class UserDetailsForTrip {
  String? firstName;
  String? lastName;
  String? profileImage;

  UserDetailsForTrip({this.firstName, this.lastName, this.profileImage});

  UserDetailsForTrip.fromJson(Map<String, dynamic> json) {
    firstName = json['first_name'];
    lastName = json['last_name'];
    profileImage = json['profile_image'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['first_name'] = this.firstName;
    data['last_name'] = this.lastName;
    data['profile_image'] = this.profileImage;
    return data;
  }
}
