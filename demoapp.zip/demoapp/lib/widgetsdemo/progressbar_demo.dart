import 'dart:async';

import 'package:flutter/material.dart';

void main() => runApp(const MyProgressbarDemoApp());

class MyProgressbarDemoApp extends StatelessWidget {
  const MyProgressbarDemoApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      debugShowCheckedModeBanner: false,
      home: CircularProgressIndicatorApp(),
    );
  }
}

class CircularProgressIndicatorApp extends StatefulWidget {
  const CircularProgressIndicatorApp({Key? key}) : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return CircularProgressIndicatorAppState();
  }
}

class CircularProgressIndicatorAppState
    extends State<CircularProgressIndicatorApp> {
  bool _loading = false;
  late double _progressValue = 0.0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Flutter Progressbar Demo'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.of(context, rootNavigator: true).pop(context);
          },
        ),
      ),
      body: Center(
          child: Container(
        padding: EdgeInsets.all(10.0),
        child: _loading
            ? Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  CircularProgressIndicator(
                    strokeWidth: 10,
                    backgroundColor: Colors.yellow,
                    value: _progressValue,
                    valueColor: const AlwaysStoppedAnimation<Color>(Colors.red),
                  ),
                  Text('${(_progressValue * 100).round()}%'),
                ],
              )
            : const Text(
                "Press button for downloading",
                style: TextStyle(fontSize: 25),
              ),
      )),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          setState(() {
            _loading = !_loading;
            updateProgress();
          });
        },
      ),
    );
  }

  void updateProgress() {
    const oneSec = Duration(seconds: 1);
    Timer.periodic(oneSec, (Timer t) {
      setState(() {
        _progressValue += 0.1;
        if (_progressValue.toStringAsFixed(1) == '1.0') {
          _loading = false;
          t.cancel();
          return;
        }
      });
    });
  }
}
