import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

void main() {
  runApp(const FormValidation());
}

class FormValidation extends StatelessWidget {
  const FormValidation({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        FocusScope.of(context).requestFocus(FocusNode());
      },
      child: MaterialApp(
          debugShowCheckedModeBanner: false,
          title: 'Flutter Demo',
          theme: ThemeData(
            primarySwatch: Colors.blue,
          ),
          home: Scaffold(
            appBar: AppBar(
              title: const Text('Flutter Demo'),
              leading: IconButton(
                icon: const Icon(Icons.arrow_back),
                onPressed: () {
                  Navigator.of(context, rootNavigator: true).pop(context);
                },
              ),
              centerTitle: true,
            ),
            body: const FormPage(
              title: 'Form',
            ),
          )),
    );
  }
}

class FormPage extends StatefulWidget {
  const FormPage({Key? key, required String title}) : super(key: key);

  @override
  State<StatefulWidget> createState() => _MyFormPageState();
}

class _MyFormPageState extends State<FormPage> {
  final _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return Form(
      key: _formKey,
      child: SingleChildScrollView(
          child: Container(
              padding: const EdgeInsets.all(10.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  TextFormField(
                    decoration: const InputDecoration(
                        icon: Icon(Icons.person),
                        hintText: 'Enter Name',
                        labelText: 'Name'),
                    validator: (value) {
                      if (value?.isEmpty ?? true) {
                        return 'Please Enter text';
                      }
                      return null;
                    },
                  ),
                  TextFormField(
                    keyboardType: TextInputType.phone,
                    maxLength: 10,
                    inputFormatters: <TextInputFormatter>[
                      FilteringTextInputFormatter.allow(RegExp(r'[0-9]')),
                      FilteringTextInputFormatter.digitsOnly
                    ],
                    decoration: const InputDecoration(
                      icon: Icon(
                        Icons.phone, /* color: Colors.black*/
                      ),
                      hintText: 'Enter Phone number',
                      labelText: 'Contact Number',
                    ),
                    validator: (value) {
                      if (value?.isEmpty ?? true) {
                        return 'Please Enter Phone number';
                      } else if (value?.length != 10) {
                        return 'Please Enter Valid phoneNumber';
                      } else {
                        return null;
                      }
                    },
                  ),
                  TextFormField(
                    keyboardType: TextInputType.datetime,
                    decoration: const InputDecoration(
                        icon: Icon(Icons.calendar_month),
                        hintText: 'Enter Date of Birth',
                        labelText: 'DOB'),
                    validator: (value) {
                      if (value?.isEmpty ?? true) {
                        return 'Please Enter Date of birth';
                      }
                      return null;
                    },
                  ),
                  Container(
                    padding: const EdgeInsets.only(
                        left: 15.0, top: 40.0, right: 15.0),
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () {
                        if (_formKey.currentState!.validate()) {
                          ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(
                                  content: Text('Data is Processing')));
                        }
                      },
                      style: ElevatedButton.styleFrom(primary: Colors.green),
                      child: const Text('Submit'),
                    ),
                  ),
                ],
              ))),
    );
  }
}
