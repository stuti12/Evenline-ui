import 'package:flutter/material.dart';

void main() => runApp(const SilverAppBarExample());

class SilverAppBarExample extends StatelessWidget {
  const SilverAppBarExample({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        body: CustomScrollView(
          slivers: <Widget>[
            SliverAppBar(
              leading: IconButton(
                  icon: const Icon(Icons.filter_1),
                  onPressed: () {
                    // Do something
                  }),
              expandedHeight: 220.0,
              toolbarHeight: 40,
              pinned: true,
              floating: false,
              stretch: false,
              backgroundColor: Colors.pink,
              flexibleSpace: FlexibleSpaceBar(
                  centerTitle: true,
                  title: const Text('Title',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 16.0,
                      )),
                  background: Image.network(
                    'https://images.pexels.com/photos/443356/pexels-photo-443356.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940',
                    fit: BoxFit.cover,
                  )),
              bottom: PreferredSize(
                  preferredSize: Size.fromHeight(10),
                  child: Container(
                    width: double.infinity,
                    decoration: const BoxDecoration(
                        borderRadius: BorderRadius.only(
                            topRight: Radius.circular(40),
                            topLeft: Radius.circular(40)),
                        color: Colors.white),
                    child: Text(''),
                  )),
            ),
            SliverList(delegate: SliverChildListDelegate(_buildList(50))),
          ],
        ),
      ),
    );
  }

  List<Widget> _buildList(int count) {
    List<Widget> listItems = [];

    for (int i = 0; i < count; i++) {
      listItems.add(Padding(
          padding: const EdgeInsets.all(20.0),
          child:
              Text('Item ${i.toString()}', style: TextStyle(fontSize: 25.0))));
    }

    return listItems;
  }
}
