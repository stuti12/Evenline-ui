import 'package:flutter/material.dart';

void main() {
  runApp(const MyTableViewDemoApp());
}

class MyTableViewDemoApp extends StatefulWidget {
  const MyTableViewDemoApp({Key? key}) : super(key: key);

  @override
  _TableExample createState() => _TableExample();
}

class _TableExample extends State<MyTableViewDemoApp> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
          appBar: AppBar(
            title: const Text('Flutter Table Example'),
            leading: IconButton(
              icon: const Icon(Icons.arrow_back),
              onPressed: () {
                Navigator.of(context, rootNavigator: true).pop(context);
              },
            ),
          ),
          body: Center(
              child: Column(children: <Widget>[
            Container(
              margin: const EdgeInsets.all(20),
              child: Table(
                defaultColumnWidth: const FixedColumnWidth(120.0),
                border: TableBorder.all(
                    color: Colors.black, style: BorderStyle.solid, width: 2),
                children: [
                  TableRow(children: [
                    Column(children: const [
                      Text('Website', style: TextStyle(fontSize: 20.0))
                    ]),
                    Column(children: const [
                      Text('Tutorial', style: TextStyle(fontSize: 20.0))
                    ]),
                    Column(children: const [
                      Text('Review', style: TextStyle(fontSize: 20.0))
                    ]),
                  ]),
                  TableRow(children: [
                    Column(children: const [Text('Learning')]),
                    Column(children: const [Text('Flutter')]),
                    Column(children: const [Text('5*')]),
                  ]),
                  TableRow(children: [
                    Column(children: const [Text('Learning')]),
                    Column(children: const [Text('Firebase')]),
                    Column(children: const [Text('5*')]),
                  ]),
                  TableRow(children: [
                    Column(children: const [Text('Learning')]),
                    Column(children: const [Text('ReactJS')]),
                    Column(children: const [Text('5*')]),
                  ]),
                  TableRow(children: [
                    Column(children: const [Text('Learning')]),
                    Column(children: const [Text('Android')]),
                    Column(children: const [Text('5*')]),
                  ]),
                  TableRow(children: [
                    Column(children: const [Text('Learning')]),
                    Column(children: const [Text('IOS')]),
                    Column(children: const [Text('5*')]),
                  ]),
                  TableRow(children: [
                    Column(children: const [Text('Learning')]),
                    Column(children: const [Text('Dart')]),
                    Column(children: const [Text('5*')]),
                  ]),
                ],
              ),
            ),
          ]))),
    );
  }
}
