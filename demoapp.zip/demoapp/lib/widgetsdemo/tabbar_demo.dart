import 'package:flutter/material.dart';

void main() {
  runApp(const TabbarDemoApp());
}

class TabbarDemoApp extends StatelessWidget {
  const TabbarDemoApp({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          primarySwatch: Colors.blue,
        ),
        home: const DefaultTabController(
            length: 2,
            child: MyTabbarDemoPage(title: 'Flutter Demo Alert Dialog Page')));
  }
}

class MyTabbarDemoPage extends StatefulWidget {
  const MyTabbarDemoPage({Key? key, required this.title}) : super(key: key);
  final String title;

  @override
  State<StatefulWidget> createState() => _TabbarDemoState();
}

class _TabbarDemoState extends State<MyTabbarDemoPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Flutter tabbar Example'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.of(context, rootNavigator: true).pop(context);
          },
        ),
        centerTitle: true,
        bottom: const TabBar(tabs: [
          Tab(icon: Icon(Icons.contacts), text: "Tab 1"),
          Tab(
            icon: Icon(Icons.camera),
            text: "Tab 2",
          )
        ]),
      ),
      body: TabBarView(
        children: [const FirstScreen(), SecondScreen()],
      ),
    );
  }
}

class FirstScreen extends StatelessWidget {
  const FirstScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return const Center(
        child: Padding(
            padding: EdgeInsets.all(10),
            child: Text(
              'It is a contact tab, which is responsible for displaying the contacts stored in your mobile',
              style: TextStyle(fontSize: 22.0, fontFamily: 'Times New Roman'),
            )));
  }
}

class SecondScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return const Center(
        child: Padding(
      padding: EdgeInsets.all(10),
      child: Text(
        'It is a second(camera) tab, which is responsible for taking pictures from your mobile.',
        style: TextStyle(fontSize: 25.0),
      ),
    ));
  }
}
