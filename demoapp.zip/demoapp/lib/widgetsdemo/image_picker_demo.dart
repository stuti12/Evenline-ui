import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';

void main() {
  runApp(const ImagePickerDemo());
}

class ImagePickerDemo extends StatefulWidget {
  const ImagePickerDemo({Key? key}) : super(key: key);

  @override
  State<ImagePickerDemo> createState() => _ImagePickerDemoState();
}

class _ImagePickerDemoState extends State<ImagePickerDemo> {
  File? image;
  final ImagePicker imgpicker = ImagePicker();
  List<XFile>? imagefiles = [];
  File? _video;

  void selectImages() async {
    final List<XFile>? selectedImages = await imgpicker.pickMultiImage();
    if (selectedImages!.isNotEmpty) {
      imagefiles!.addAll(selectedImages);
    }
    setState(() {});
  }

  // List<String> list = [];
  Future pickImage() async {
    try {
      final image = await ImagePicker().pickImage(source: ImageSource.gallery);
      if (image == null) return;
      final imageTemp = File(image.path);
      setState(() => this.image = imageTemp);
    } on PlatformException catch (e) {
      if (kDebugMode) {
        print(e);
      }
    }
  }

  Future pickImageCamera() async {
    try {
      final image = await ImagePicker().pickImage(source: ImageSource.camera);
      if (image == null) return;
      final imageTemp = File(image.path);
      setState(() => this.image = imageTemp);
    } on PlatformException {}
  }

  openImages() async {
    try {
      var pickedfiles = await imgpicker.pickMultiImage();
      //you can use ImageCourse.camera for Camera capture
      if (pickedfiles != null) {
        imagefiles = pickedfiles;
        setState(() {});
      } else {
        if (kDebugMode) {
          print("No image is selected.");
        }
      }
    } catch (e) {
      if (kDebugMode) {
        print("error while picking file.");
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
          body: Center(
              child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: MaterialButton(
              minWidth: double.infinity,
              color: Colors.red,
              onPressed: () {
                pickImage();
              },
              child: const Text('Pick image from Gallery'),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: MaterialButton(
              minWidth: double.infinity,
              color: Colors.red,
              onPressed: () {},
              child: const Text('Pick image from Camera'),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: MaterialButton(
              minWidth: double.infinity,
              color: Colors.red,
              onPressed: () {
                selectImages();
              },
              child: const Text('Multiple image'),
            ),
          ),
          const SizedBox(
            height: 20.0,
          ),
          image != null
              ? Image.file(
                  image!,
                  height: 500,
                )
              : const Text('No image selected'),
          Expanded(
              child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: GridView.builder(
                itemCount: imagefiles!.length,
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 3),
                itemBuilder: (BuildContext context, int index) {
                  return Image.file(File(imagefiles![index].path),
                      fit: BoxFit.cover);
                }),
          )),
        ],
      ))),
    );
  }
}
