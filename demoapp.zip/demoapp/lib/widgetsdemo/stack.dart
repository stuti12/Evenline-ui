import 'package:flutter/material.dart';

void main() {
  runApp(const MyStackPage());
}

class MyStackPage extends StatelessWidget {
  const MyStackPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const MyStack(title: 'Flutter Demo Home Page'),
    );
  }
}

class MyStack extends StatefulWidget {
  const MyStack({Key? key, required this.title}) : super(key: key);
  final String title;

  @override
  State<MyStack> createState() => _MyHomeNavPageState();
}

class _MyHomeNavPageState extends State<MyStack> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Flutter Example'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.of(context, rootNavigator: true).pop(context);
          },
        ),
        centerTitle: true,
      ),
      body: Center(
        /*child: IndexedStack(
          index: 0,
          children: <Widget>[
            Container(
              height: 300,
              width: 400,
              color: Colors.green,
              child: const Center(
                child: Text(
                  'First Widget',
                  style: TextStyle(color: Colors.white, fontSize: 20),
                ),
              ),
            ),
            Container(
              height: 250,
              width: 250,
              color: Colors.blue,
              child: const Center(
                child: Text(
                  'Second Widget',
                  style: TextStyle(color: Colors.white, fontSize: 20),
                ),
              ),
            ),
          ],
        ),*/
        child: Stack(
          clipBehavior: Clip.none,
          fit: StackFit.passthrough,
          children: <Widget>[
            // Max Size Widget
            Container(
              height: 300,
              width: 350,
              color: Colors.green,
              child: Container(
                alignment: Alignment.topCenter,
                margin: const EdgeInsets.symmetric(vertical: 20),
                child: const Text(
                  'Top Widget: Green',
                  style: TextStyle(color: Colors.white, fontSize: 20),
                ),
              ),
            ),
            Positioned(
              top: 90,
              right: 100,
              child: Container(
                height: 100,
                width: 150,
                color: Colors.blue,
                child: const Center(
                  child: Text(
                    'Middle Widget',
                    style: TextStyle(color: Colors.white, fontSize: 20),
                  ),
                ),
              ),
            ),
            Positioned(
                top: 190,
                left: 20,
                child: Container(
                  height: 100,
                  width: 150,
                  color: Colors.orange,
                  child: const Center(
                    child: Text(
                      'Bottom Widget',
                      style: TextStyle(color: Colors.white, fontSize: 20),
                    ),
                  ),
                )),
          ],
        ),
      ),
    );
  }
}
