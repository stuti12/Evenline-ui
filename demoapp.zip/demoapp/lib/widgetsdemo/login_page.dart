import 'package:flutter/material.dart';

void main() {
  runApp(const LoginPage());
}

class LoginPage extends StatelessWidget {
  const LoginPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
        onTap: () {
          FocusScope.of(context).requestFocus(FocusNode());
        },
        child: MaterialApp(
          debugShowCheckedModeBanner: false,
          theme: ThemeData(
            primarySwatch: Colors.blue,
          ),
          home: const NextLoginPage(title: 'Flutter Demo Login Widgets Page'),
        ));
  }
}

class NextLoginPage extends StatefulWidget {
  const NextLoginPage({Key? key, required String title}) : super(key: key);

  @override
  State<StatefulWidget> createState() => _MyLoginPageState();
}

class _MyLoginPageState extends State<NextLoginPage> {
  int _counter = 0;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Flutter Login Example'),
          centerTitle: true,
        ),
        body: Container(
          padding: const EdgeInsets.all(5),
          child: SingleChildScrollView(
            child: Column(
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.all(10.0),
                  child: Text(
                    'Login:$_counter',
                    style: const TextStyle(fontFamily: 'Times New Roman'),
                  ),
                ),
                const Padding(
                  padding: EdgeInsets.all(15),
                  child: TextField(
                    decoration: InputDecoration(
                      border: OutlineInputBorder(),
                      labelText: 'User Name',
                      hintText: 'Enter Your Name',
                    ),
                  ),
                ),
                const Padding(
                  padding: EdgeInsets.all(15),
                  child: TextField(
                    obscureText: true,
                    decoration: InputDecoration(
                      border: OutlineInputBorder(),
                      labelText: 'Password',
                      hintText: 'Enter Password',
                    ),
                  ),
                ),
                Padding(
                    padding: const EdgeInsets.all(15),
                    child: SizedBox(
                        width: double.infinity,
                        child: ElevatedButton(
                          onPressed: () {
                            ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(
                                    content: Text('Data is Processing')));
                            Navigator.of(context, rootNavigator: true)
                                .pop(context);
                          },
                          child: const Text('Sign In'),
                        ))),
                SizedBox(
                  child: FadeInImage.assetNetwork(
                      placeholder: 'assets/loading.gif',
                      height: 100,
                      width: 100,
                      image: 'https://picsum.photos/250?image=9'),
                ),
                const Text(
                  'Dont Have Account? Sign up',
                  style: TextStyle(
                      color: Colors.black,
                      fontSize: 16,
                      fontWeight: FontWeight.w400),
                  textAlign: TextAlign.center,
                )
              ],
            ),
          ),
        ),

        //setState Called
        floatingActionButton: FloatingActionButton(
          onPressed: () => setState(() {
            _counter += 2;
          }),
          tooltip: 'Increment Counter',
          child: const Text("Login"),
        ),
        floatingActionButtonLocation: FloatingActionButtonLocation.endDocked,
        drawer: Drawer(
          elevation: 20.0,
          child: Column(
            children: const <Widget>[
              UserAccountsDrawerHeader(
                accountName: Text("stuti"),
                accountEmail: Text("stutibhavsar@gmail.com"),
                currentAccountPicture: CircleAvatar(
                  backgroundColor: Colors.yellow,
                  child: Text("abc"),
                ),
              ),
              ListTile(
                title: Text("Inbox"),
                leading: Icon(Icons.mail),
              ),
              Divider(
                height: 0.1,
              ),
              ListTile(
                title: Text("Primary"),
                leading: Icon(Icons.inbox),
              ),
              ListTile(
                title: Text("Social"),
                leading: Icon(Icons.people),
              ),
              ListTile(
                title: Text("Promotions"),
                leading: Icon(Icons.local_offer),
              )
            ],
          ),
        ),
      ),
    );
  }
}
