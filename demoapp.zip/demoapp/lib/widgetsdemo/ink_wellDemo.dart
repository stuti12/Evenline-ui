import 'package:flutter/material.dart';

void main() {
  runApp(const MyInkWellDemoApp());
}

class MyInkWellDemoApp extends StatelessWidget {
  const MyInkWellDemoApp({Key? key}) : super(key: key);

// This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: MyInkWellPage(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class MyInkWellPage extends StatefulWidget {
  @override
  _MyInkWellPageState createState() => _MyInkWellPageState();
}

class _MyInkWellPageState extends State<MyInkWellPage> {
  String inkwell = '';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('InkWell Widget'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.of(context, rootNavigator: true).pop(context);
          },
        ),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Material(
              color: Colors.white.withOpacity(0.0),
              child: InkWell(
                onTap: () {
                  setState(() {
                    inkwell = 'Inkwell Tapped';
                  });
                },
                onLongPress: () {
                  setState(() {
                    inkwell = 'InkWell Long Pressed';
                  });
                },
                child: Ink(
                  child: const SizedBox(
                      width: 120,
                      height: 70,
                      child: Center(
                          child: Text(
                        'Inkwell',
                        textScaleFactor: 2,
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ))),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Text(
                inkwell,
                textScaleFactor: 2,
              ),
            )
          ],
        ),
      ),
    );
  }
}
