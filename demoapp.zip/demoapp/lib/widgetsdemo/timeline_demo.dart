import 'dart:math';

import 'package:flutter/material.dart';

void main() {
  runApp(const MyTimelineApp());
}

TextStyle style = const TextStyle(color: Colors.white);

class MyTimelineApp extends StatelessWidget {
  const MyTimelineApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Timeline',
      theme: ThemeData(
        primaryColor: Constants.kPurpleColor,
      ),
      home: TimelineComponent(title: 'Timeline'),
    );
  }
}

class TimelineComponent extends StatelessWidget {
  TimelineComponent({Key? key, this.title}) : super(key: key);

  final String? title;

  final List<Events> listOfEvents = [
    Events(
      eventName: "General",
    ),
    Events(eventName: "Squat"),
    Events(eventName: "Bench Press"),
    Events(eventName: "Deadlift"),
  ];

  final List<Color> listOfColors = [
    Constants.kPurpleColor,
    Constants.kGreenColor,
    Constants.kRedColor
  ];
  int tick = 0;

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    Random random = Random();
    return Scaffold(
      drawer: const Drawer(),
      appBar: AppBar(title: Text(this.title!), actions: [
        Padding(
          padding: const EdgeInsets.fromLTRB(0, 10, 10, 0),
          child: Stack(
            children: [
              CircleAvatar(
                backgroundColor: Colors.blue.shade200,
                child: const Text('PH'),
              ),
              Positioned(
                right: 0,
                top: 0,
                child: Container(
                  padding: const EdgeInsets.all(1),
                  decoration: BoxDecoration(
                    color: Colors.red,
                    borderRadius: BorderRadius.circular(6),
                  ),
                  constraints: const BoxConstraints(
                    minWidth: 12,
                    minHeight: 12,
                  ),
                ),
              )
            ],
          ),
        ),
      ]),
      body: Column(
        children: [
          /* Flexible(
            child: ListView.builder(
                shrinkWrap: true,
                itemCount: listOfEvents.length,
                itemBuilder: (context, i) {
                  return Stack(
                    children: [
                      Padding(
                        padding: const EdgeInsets.all(40),
                        child: Row(
                          children: [
                            SizedBox(width: size.width * 0.1),
                            SizedBox(
                              child: Row(
                                children: [
                                  Text(listOfEvents[i].eventName),
                                ],
                              ),
                            )
                          ],
                        ),
                      ),
                      Positioned(
                        left: 50,
                        child:  Container(
                          height: size.height * 0.7,
                          width: 1.0,
                          color: Colors.redAccent,
                        ),
                      ),
                      Positioned(
                        bottom: 5,
                        child: Padding(
                          padding: const EdgeInsets.all(40.0),
                          child: Container(
                            height: 20.0,
                            width: 20.0,
                            decoration:  BoxDecoration(
                              color: listOfColors[random.nextInt(3)],
                              borderRadius: BorderRadius.circular(20),
                            ),
                          ),
                        ),
                      ),
                    ],
                  );
                }),
          ),*/
          _ScreenProgress(),
        ],
      ),
    );
  }
}

class Events {
  final String eventName;

  Events({required this.eventName});
}

class Constants {
  static const kPurpleColor = Color(0xFFED1F24);
  static const kRedColor = Color(0xFFED1F37);
  static const kGreenColor = Color(0xFFED1F37);
}

class _ScreenProgress extends StatefulWidget {
  @override
  State<StatefulWidget> createState() => ScreenProgress(ticks: 1);
}

class ScreenProgress extends State<_ScreenProgress> {
  int ticks = 0;

  ScreenProgress({required this.ticks});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Row(
          children: <Widget>[
            const Padding(
              padding: EdgeInsets.only(left: 6.0),
              child: Text('General'),
            ),
            spacer(),
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 26.0),
              child: Text('Squat'),
            ),
            spacer(),
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 20.0),
              child: Text('Bench Press'),
            ),
            spacer(),
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 18.0),
              child: Text('Deadlift'),
            ),
          ],
        ),
        Row(
          children: <Widget>[
            tick1(),
            spacer(),
            line(),
            spacer(),
            tick2(),
            spacer(),
            line(),
            spacer(),
            tick3(),
            spacer(),
            line(),
            spacer(),
            tick4(),
          ],
        ),
        Visibility(
          visible: false,
          child: ElevatedButton(
              onPressed: () {
                ticks++;
                setState(() {
                  ScreenProgress(ticks: ticks);
                });
              },
              child: Text('update')),
        )
      ],
    );
  }

  Widget tick(bool isChecked) {
    return isChecked
        ? const Icon(
            Icons.circle_sharp,
            color: Colors.redAccent,
          )
        : Icon(
            Icons.circle,
            color: Colors.black,
          );
  }

  Widget tick1() {
    return ticks > 0 ? tick(true) : tick(false);
  }

  Widget tick2() {
    return ticks > 1 ? tick(true) : tick(false);
  }

  Widget tick3() {
    return this.ticks > 2 ? tick(true) : tick(false);
  }

  Widget tick4() {
    return this.ticks > 3 ? tick(true) : tick(false);
  }

  Widget spacer() {
    return Container(
      width: 5.0,
    );
  }

  Widget line() {
    return Container(
      color: Colors.grey,
      height: 5.0,
      width: 70.0,
    );
  }
}
