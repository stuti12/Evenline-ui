import 'dart:convert';

import 'package:get/get.dart';
import 'package:get/get_state_manager/src/simple/get_controllers.dart';
import 'package:http/http.dart' as http;

import '../../utils/constants.dart';
import '../constants/shared_preference.dart';
import 'HomeData.dart';

class TripsController extends GetxController {
  Home home = Home();
  Home homeLocal = Home();
  var isLike = false.obs;
  var like = 0.obs;

  var isDataLoading = true.obs;

  @override
  void onInit() {
    super.onInit();
    getTripsApi();
  }

  @override
  void onClose() {
    super.onClose();
  }

  void increment() {
    like.value++;
  }

  getTripsApi() async {
    try {
      isDataLoading(true);
      var token = PrefService.getUsername();
      http.Response response = await http.get(
          Uri.parse("${Constants.baseUrl}/api/v1/user/get-all-trips"),
          headers: {"language": "en", "Authorization": "Bearer $token"});
      if (response.statusCode == 200) {
        print("Trips response${json.decode(response.body)}");
        var result = json.decode(response.body);
        home = Home.fromJson(result);
        print('home data length${home?.data?.rows?.length}');
      } else {}
    } catch (e) {
      print('Error while getting data is $e');
    } finally {
      isDataLoading(false);
    }
  }
}
