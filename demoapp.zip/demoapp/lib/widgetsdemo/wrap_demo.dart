import 'package:flutter/material.dart';

void main() => runApp(const MyWrapWidgetDemoApp());

class MyWrapWidgetDemoApp extends StatelessWidget {
  const MyWrapWidgetDemoApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        theme: ThemeData(primarySwatch: Colors.blue),
        debugShowCheckedModeBanner: false,
        home: const WrapWidget());
  }
}

class WrapWidget extends StatelessWidget {
  const WrapWidget({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Wrap Widget Example"),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.of(context, rootNavigator: true).pop(context);
          },
        ),
      ),
      body: Wrap(
        direction: Axis.horizontal,
        spacing: 5.0,
        alignment: WrapAlignment.center,
        verticalDirection: VerticalDirection.up,
        runSpacing: 8.0,
        textDirection: TextDirection.rtl,
        children: <Widget>[
          Container(
              color: Colors.blue,
              width: 100,
              height: 100,
              child: const Center(
                  child: Text(
                "W1",
                textScaleFactor: 2.5,
              ))),
          Container(
              color: Colors.red,
              width: 100,
              height: 100,
              child: const Center(
                  child: Text(
                "W2",
                textScaleFactor: 2.5,
              ))),
          Container(
              color: Colors.teal,
              width: 100,
              height: 100,
              child: const Center(
                  child: Text(
                "W3",
                textScaleFactor: 2.5,
              ))),
          Container(
              color: Colors.indigo,
              width: 100,
              height: 100,
              child: const Center(
                  child: Text(
                "W4",
                textScaleFactor: 2.5,
              ))),
          Container(
              color: Colors.orange,
              width: 100,
              height: 100,
              child: const Center(
                  child: Text(
                "W5",
                textScaleFactor: 2.5,
              ))),
          Container(
              color: Colors.orange,
              width: 100,
              height: 100,
              child: const Center(
                  child: Text(
                "W6",
                textScaleFactor: 2.5,
              ))),
          Container(
              color: Colors.orange,
              width: 100,
              height: 100,
              child: const Center(
                  child: Text(
                "W7",
                textScaleFactor: 2.5,
              ))),
        ],
      ),
    );
  }
}
