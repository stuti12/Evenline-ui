import 'package:demoapp/sharedpref/routes.dart';
import 'package:flutter/material.dart';

import '../constants/shared_preference.dart';

class HomeView extends StatelessWidget {
  final PrefService _prefService = PrefService();

  @override
  Widget build(BuildContext context) {
    final todo = ModalRoute.of(context)?.settings.arguments as String;
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: Text("Home"),
      ),
      body: Center(
        child: Column(
          children: [
            Text("Welcome $todo"),
            ElevatedButton(
                onPressed: () async {
                  await _prefService.removeCache("email").whenComplete(() {
                    Navigator.of(context).pushNamed(LoginRoute);
                  });
                },
                child: Text("Log out"))
          ],
        ),
      ),
    );
  }
}
