import 'package:demoapp/sharedpref/splash.dart';

import 'dashboard.dart';
import 'login.dart';

const String SplashRoute = "/splash";
const String HomeRoute = "/home";
const String LoginRoute = "/login";

final routes = {
  SplashRoute: (context) => SplashView(),
  HomeRoute: (context) => HomeView(),
  LoginRoute: (context) => LoginView()
};
