import 'dart:ui';

class Strings {
  static const String welcomeMessageText = "Welcome";
  static const String welcomeSubtitleText = 'Sign in to continue!';
  static const String emailText = 'Email';
  static const String enterEmailText = 'Enter Your Email';
  static const String passwordText = 'Password';
  static const String enterPasswordText = 'Enter Your Password';

  static const String createAccountText = 'Create Account';
  static const String signUpSubtitle = ' Sign Up to get started!';
  static const String confirmPasswordText = 'Confirm Password';
  static const String enterCPasswordText = 'Enter Confirm Password';
  static const String alreadyHaveAccText = 'Already have an account?';

  static const String signInText = 'SIGN IN';
  static const String signUpText = 'Sign Up';
  static const String forgetText = 'Forgot Password?';
  static const String loginSuccessText = 'Login Successful';
  static const String loginFail = 'Login Fail';

  static const String dontHaveAccountText = 'Dont Have Account?';

  static const String forgetPasswordText = 'Forgot Password';
  static const String forgetSubTitleText =
      'Enter your email address to reset your password.';
  static const String passwordSentText = 'Password Sent to Email';
  static const String rememberPasswordText = 'Remember Password';
  static const String nextText = 'NEXT';

  static const String verificationText = 'Verification';
  static const String emailVerifyText = 'Email verification via OTP';
  static const String verificationSubTitleText =
      'We have sent you an OTP on your registered email address “john........12@gmail.com”.';
  static const String verifyText = 'VERIFY';

  static const String resetPasswordText = 'Reset Password';
  static const String resetPasswordSubtitleText =
      'Enter you new password to access your account.';
  static const String submitText = 'SUBMIT';

  static const String passwordResetText = 'Password reset Successfully';

  static const String createProfileText = 'Create Profile';
  static const String userNameText = 'Username';
  static const String firstNameText = 'First Name';
  static const String lastNameText = 'Last Name';
  static const String dateOfBirthText = 'Date of Birth';
  static const String squatMaxText = 'Squat Max (kg)';
  static const String benchPressMax = 'Bench Press Max (kg)';
  static const String deadliftText = 'Deadlift Max (kg)';
  static const String weightText = 'Weight (kg)';
  static const String heightText = 'Height (kg)';
  static const String selectYourGoalText = 'Select Your Goal';
  static const String trainingExperienceText = 'Training Experience';
  static const String getStrongText = 'Get Stronger';
  static const String buildText = 'Build Muscle';
  static const String powerBuildingText = 'Power Building';
  static const String recompositionText = 'Recomposition';
  static const String lessThan1Text = 'Less than 1 year';
  static const String oneTwoYearsText = '1-2 years';
  static const String threefiveText = '3-5 years';

  static const String myProgramsText = 'My Programs';

  static const String trainingText = 'Training';
  static const String programsText = 'Programs';
  static const String communityText = 'Community';
  static const String videoText = 'Video Library';
  static const String profileText = 'Profile';

  static const colorGrey = Color(0xFF1D1D1D);
  static const colorLightGrey = Color(0xFF979797);
  static const colorPrimaryGrey = Color(0xFF252525);
  static const colorBottom = Color(0xFF1F1F1F);
  static const colorBottomItem = Color(0xFF575555);
}
