import 'package:shared_preferences/shared_preferences.dart';

class PrefService {
  static late SharedPreferences _preferences;

  static Future init() async =>
      _preferences = await SharedPreferences.getInstance();

  Future createCache(String password) async {
    SharedPreferences _preferences = await SharedPreferences.getInstance();
    _preferences.setString("email", password);
  }

  Future readCache(String password) async {
    SharedPreferences _preferences = await SharedPreferences.getInstance();
    var cache = _preferences.getString("email");
    return cache;
  }

  Future removeCache(String password) async {
    SharedPreferences _preferences = await SharedPreferences.getInstance();
    _preferences.remove("email");
  }

  static Future setUsername(String token) async =>
      await _preferences.setString("token", token);

  static String getUsername() => _preferences.getString("token") ?? " ";

  static void removeUsername() => _preferences.remove("token");
}
