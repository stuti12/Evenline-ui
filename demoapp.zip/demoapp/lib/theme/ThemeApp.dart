import 'package:flutter/material.dart';

import '../theme/ThemeBuilder.dart';
import 'Detail.dart';

void main() => runApp(const MyThemeApp());

class MyThemeApp extends StatelessWidget {
  const MyThemeApp({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return ThemeBuilder(
      defaultBrightness: Brightness.dark,
      builder: (context, _brightness) {
        return MaterialApp(
          title: 'Flutter Demo',
          theme: ThemeData(primarySwatch: Colors.blue, brightness: _brightness),
          home: MyThemeHomePage(title: 'Flutter Theme Demo'),
        );
      },
    );
  }
}

class MyThemeHomePage extends StatefulWidget {
  MyThemeHomePage({Key? key, required this.title}) : super(key: key);
  final String title;

  @override
  _MyThemeHomePageState createState() => _MyThemeHomePageState();
}

class _MyThemeHomePageState extends State<MyThemeHomePage> {
  int _counter = 0;

  void _incrementCounter() {
    ThemeBuilder.of(context)?.changeTheme();
    setState(() {
      _counter++;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => const DetailPage()));
              },
              child: Text('Go to Detail'),
            ),
            const Text(
              'You have pushed the button this many times:',
            ),
            Text(
              '$_counter',
              style: Theme.of(context).textTheme.labelLarge,
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _incrementCounter,
        tooltip: 'Increment',
        child: const Icon(Icons.change_circle_outlined),
      ),
    );
  }
}
