import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';


class CustomWidgets {
  static Widget textField(
      {bool? obscureText = false,
        bool isNumber = false,
        int? length,
        Color? cursorColors,
        Color? fillColor,
        EdgeInsets? contentPadding,
        final FormFieldValidator? validator,
        TextInputAction? textInputAction,
        TextInputType? keyboardType,
        String? hint,
        TextStyle? hintstyle,
        TextEditingController? controller,
        Widget? suffixIcon,
        InputDecoration? decoration,
        GestureTapCallback? onTap,
        int lines = 1}) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.symmetric(vertical: 2),
      child: TextFormField(
        onTap: onTap,
        style: const TextStyle(
            color: Colors.black, fontFamily: 'Museo Sans'),
        textInputAction: textInputAction,
        validator: validator,
        maxLines: lines,
        cursorColor: cursorColors,
        controller: controller,
        maxLength: length,
        inputFormatters: [
          LengthLimitingTextInputFormatter(length),
        ],
        obscureText: obscureText ?? false,
        keyboardType: keyboardType ?? TextInputType.name,
        decoration: decoration ?? InputDecoration(
          suffixIcon: suffixIcon,
          hintText: hint,
          hintStyle: hintstyle ??
              TextStyle(
                  fontFamily: 'Museo Sans',
                  color: Colors.black,
                  fontSize: 16.sp,
                  fontWeight: FontWeight.w500),
          counterText: '',
          contentPadding: contentPadding ?? const EdgeInsets.only(left: 24,top: 16,bottom: 16),
          filled: true,
          fillColor: fillColor ?? Colors.white54,
          enabledBorder: const OutlineInputBorder(
              borderSide: BorderSide(color: Colors.white54),
              borderRadius: BorderRadius.all(Radius.circular(26.0))),
          errorBorder: const OutlineInputBorder(
              borderSide: BorderSide(color: Colors.white54),
              borderRadius: BorderRadius.all(Radius.circular(26.0))),
          focusedBorder: const OutlineInputBorder(
              borderSide: BorderSide(color: Colors.white54, width: 1.5),
              borderRadius: BorderRadius.all(Radius.circular(26.0))),
        ),
      ),
    );
  }
}