import 'package:demoapp/list/basic_list_demo.dart';
import 'package:demoapp/list/grid_builder.dart';
import 'package:demoapp/list/gridlist_demo.dart';
import 'package:demoapp/list/horizontal_list_demo.dart';
import 'package:demoapp/list/list_builder_demo.dart';
import 'package:demoapp/list/long_list_demo.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(const ListDemoApp());
}

class ListDemoApp extends StatelessWidget {
  const ListDemoApp({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const MyListDemoPage(title: 'Flutter Demo Home Page'),
    );
  }
}

class MyListDemoPage extends StatefulWidget {
  const MyListDemoPage({Key? key, required this.title}) : super(key: key);
  final String title;

  @override
  State<MyListDemoPage> createState() => _MyListDemoPageState();
}

class _MyListDemoPageState extends State<MyListDemoPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Flutter Example'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.of(context, rootNavigator: true).pop(context);
          },
        ),
        centerTitle: true,
      ),
      body: Center(
        child: Column(
          children: <Widget>[
            Padding(
              padding: const EdgeInsets.only(
                  left: 15.0, right: 15.0, top: 5.0, bottom: 5.0),
              child: SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => const BasicListDemoApp()));
                    },
                    style: ElevatedButton.styleFrom(primary: Colors.green),
                    child: const Text('Basic List'),
                  )),
            ),
            Padding(
              padding: const EdgeInsets.only(
                  left: 15.0, right: 15.0, top: 5.0, bottom: 5.0),
              child: SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) =>
                                  const LongListDemoApp(products: [
                                    'Item1',
                                    'Item1',
                                    'Item1',
                                    'Item1',
                                    'Item1',
                                    'Item1',
                                    'Item1',
                                    'Item1',
                                    'Item1',
                                    'Item1',
                                    'Item1'
                                  ])));
                    },
                    style: ElevatedButton.styleFrom(primary: Colors.orange),
                    child: const Text('Long List'),
                  )),
            ),
            Padding(
                padding: const EdgeInsets.only(
                    left: 15.0, right: 15.0, top: 5.0, bottom: 5.0),
                child: SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => GridListDemoApp()));
                      },
                      style: ElevatedButton.styleFrom(primary: Colors.brown),
                      child: const Text('Grid List(Grid View)'),
                    ))),
            Padding(
                padding: const EdgeInsets.only(
                    left: 15.0, right: 15.0, top: 5.0, bottom: 5.0),
                child: SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) =>
                                    const HorizontalListDemoApp()));
                      },
                      child: const Text('Horizontal List'),
                    ))),
            Padding(
                padding: const EdgeInsets.only(
                    left: 15.0, right: 15.0, top: 5.0, bottom: 5.0),
                child: SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) =>
                                    const MyListBuilderApp()));
                      },
                      style:
                          ElevatedButton.styleFrom(primary: Colors.greenAccent),
                      child: const Text('List Builder'),
                    ))),
            Padding(
                padding: const EdgeInsets.only(
                    left: 15.0, right: 15.0, top: 5.0, bottom: 5.0),
                child: SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => MyGridBuilderApp()));
                      },
                      style: ElevatedButton.styleFrom(primary: Colors.brown),
                      child: const Text('Grid Builder'),
                    ))),
          ],
        ),
      ),
    );
  }
}
