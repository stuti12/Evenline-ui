import 'package:flutter/material.dart';

void main() {
  runApp(LongListDemoApp(
    products: List<String>.generate(500, (i) => "Product List: $i"),
  ));
}

class LongListDemoApp extends StatelessWidget {
  final List<String> products;

  const LongListDemoApp({Key? key, required this.products}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    const appTitle = 'Flutter Long List Demo';

    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: appTitle,
      home: Scaffold(
        appBar: AppBar(
          title: Text(appTitle),
          leading: IconButton(
            icon: const Icon(Icons.arrow_back),
            onPressed: () {
              Navigator.of(context, rootNavigator: false).pop(context);
            },
          ),
          centerTitle: true,
        ),
        body: ListView.builder(
          itemCount: products.length,
          itemBuilder: (context, index) {
            return ListTile(
              title: Text(products[index]),
            );
          },
        ),
      ),
    );
  }
}
