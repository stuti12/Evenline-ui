import 'package:flutter/material.dart';

void main() => runApp(const HorizontalListDemoApp());

class HorizontalListDemoApp extends StatelessWidget {
  const HorizontalListDemoApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    const title = 'Flutter Horizontal Demo List';

    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        appBar: AppBar(
          title: const Text(title),
          leading: IconButton(
            icon: const Icon(Icons.arrow_back),
            onPressed: () {
              Navigator.of(context, rootNavigator: false).pop(context);
            },
          ),
          centerTitle: true,
        ),
        body: Container(
          height: double.infinity,
          margin: const EdgeInsets.symmetric(vertical: 25.0),
          child: ListView(
            scrollDirection: Axis.horizontal,
            children: <Widget>[
              Container(
                constraints:
                    const BoxConstraints(maxHeight: double.minPositive),
                width: 150.0,
                color: Colors.blue,
                child: Stack(
                  children: const <Widget>[
                    ListTile(
                      leading: Icon(Icons.home),
                      title: Text('Home'),
                    ),
                  ],
                ),
              ),
              Container(
                width: 150.0,
                color: Colors.green,
                child: Stack(
                  children: const <Widget>[
                    ListTile(
                      leading: Icon(Icons.camera_alt),
                      title: Text('Camera'),
                    ),
                  ],
                ),
              ),
              Container(
                width: 150.0,
                color: Colors.yellow,
                child: Stack(
                  children: const <Widget>[
                    ListTile(
                      leading: Icon(Icons.phone),
                      title: Text('Phone'),
                    ),
                  ],
                ),
              ),
              Container(
                width: 150.0,
                color: Colors.red,
                child: Stack(
                  children: const <Widget>[
                    ListTile(
                      leading: Icon(Icons.map),
                      title: Text('Map'),
                    ),
                  ],
                ),
              ),
              Container(
                width: 150.0,
                color: Colors.orange,
                child: Stack(
                  children: const <Widget>[
                    ListTile(
                      leading: Icon(Icons.settings),
                      title: Text('Setting'),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
