import 'package:demoapp/ToDoDataPasingDemo.dart';
import 'package:demoapp/api/dio/presentation/dio_api_home.dart';
import 'package:demoapp/api/getx/getx_api_home.dart';
import 'package:demoapp/api/retrofit/retrofit_demo.dart';
import 'package:demoapp/changenotifier/change_notifier.dart';
import 'package:demoapp/custom/CustomButtonDemoApp.dart';
import 'package:demoapp/firebase/firebase_demo.dart';
import 'package:demoapp/firebase/firebase_messaging.dart';
import 'package:demoapp/googlemaps/google_map_demo.dart';
import 'package:demoapp/list/expandable_list_demo.dart';
import 'package:demoapp/list/list_demo.dart';
import 'package:demoapp/sharedpref/login.dart';
import 'package:demoapp/socialmedia/facebook.dart';
import 'package:demoapp/socialmedia/google_sign_in.dart';
import 'package:demoapp/sqflite/sqflite_demo.dart';
import 'package:demoapp/state/state_management.dart';
import 'package:demoapp/stream//stream_provider.dart';
import 'package:demoapp/theme/ThemeApp.dart';
import 'package:demoapp/widgetsdemo/WillPopScopeDemo.dart';
import 'package:demoapp/widgetsdemo/alert_dialog_demo.dart';
import 'package:demoapp/widgetsdemo/bottom_navigation.dart';
import 'package:demoapp/widgetsdemo/bottom_sheet_demo.dart';
import 'package:demoapp/widgetsdemo/card_demo.dart';
import 'package:demoapp/widgetsdemo/checkbox_demo.dart';
import 'package:demoapp/widgetsdemo/chip_demo.dart';
import 'package:demoapp/widgetsdemo/expanded_widget_demo.dart';
import 'package:demoapp/widgetsdemo/flexible_demo.dart';
import 'package:demoapp/widgetsdemo/form_validation.dart';
import 'package:demoapp/widgetsdemo/image_picker_demo.dart';
import 'package:demoapp/widgetsdemo/ink_wellDemo.dart';
import 'package:demoapp/widgetsdemo/login_page.dart';
import 'package:demoapp/widgetsdemo/otp.dart';
import 'package:demoapp/widgetsdemo/progressbar_demo.dart';
import 'package:demoapp/widgetsdemo/pulltorefresh_demo.dart';
import 'package:demoapp/widgetsdemo/radiobutton_demo.dart';
import 'package:demoapp/widgetsdemo/ratingbar_demo.dart';
import 'package:demoapp/widgetsdemo/row_column_demo.dart';
import 'package:demoapp/widgetsdemo/searchbar_demo.dart';
import 'package:demoapp/widgetsdemo/stack.dart';
import 'package:demoapp/widgetsdemo/stepper_demo.dart';
import 'package:demoapp/widgetsdemo/tabbar_demo.dart';
import 'package:demoapp/widgetsdemo/tableview_demo.dart';
import 'package:demoapp/widgetsdemo/tic_tac_toe.dart';
import 'package:demoapp/widgetsdemo/timeline_demo.dart';
import 'package:demoapp/widgetsdemo/toggle_switch.dart';
import 'package:demoapp/widgetsdemo/wrap_demo.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'api/core_login/app_widget.dart';
import 'api/getx/createupdatepatch/create_api.dart';
import 'api/http/http_api_demo.dart';
import 'api/pagination/pagination_demo-dataget.dart';
import 'changenotifier/change_course.dart';
import 'firebase/local_notification_demo.dart';
import 'multilanguage/multi_lang_demo.dart';
import 'mvvm/mvvm_demo.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
        debugShowCheckedModeBanner: false,
        home: MyHomePage(
          title: 'Demo',
        ));
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({Key? key, required this.title}) : super(key: key);
  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Flutter Example'),
      ),
      body: Center(
        child: SingleChildScrollView(
          child: Column(
            children: <Widget>[
              Padding(
                padding:
                    const EdgeInsets.only(left: 15.0, right: 15.0, top: 10.0),
                child: SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) =>
                                    const MyInkWellDemoApp()));
                      },
                      style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.green),
                      child: const Text('InkWell Demo'),
                    )),
              ),
              Padding(
                padding:
                    const EdgeInsets.only(left: 15.0, right: 15.0, top: 10.0),
                child: SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) =>
                                    const MyStepperDemoApp()));
                      },
                      style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.green),
                      child: const Text('Stepper Demo'),
                    )),
              ),
              Padding(
                padding:
                const EdgeInsets.only(left: 15.0, right: 15.0, top: 5.0),
                child: SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => const MyStateApp()));
                      },
                      child: const Text('State Management Demo'),
                    )),
              ),
              Padding(
                padding:
                    const EdgeInsets.only(left: 15.0, right: 15.0, top: 5.0),
                child: SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) =>
                                    const MyRowColumnDemoApp()));
                      },
                      child: const Text('Row & Column Demo'),
                    )),
              ),
              Container(
                width: double.infinity,
                padding:
                    const EdgeInsets.symmetric(horizontal: 15.0, vertical: 5.0),
                child: ElevatedButton(
                  onPressed: () {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) =>
                                const MyExpandedWidgetDemoApp()));
                  },
                  child: const Text('Expanded Widget Demo'),
                ),
              ),
              Container(
                width: double.infinity,
                padding:
                    const EdgeInsets.symmetric(horizontal: 15.0, vertical: 5.0),
                child: ElevatedButton(
                  onPressed: () {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => const MyTableViewDemoApp()));
                  },
                  child: const Text('Table Demo'),
                ),
              ),
              Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(
                      horizontal: 15.0, vertical: 5.0),
                  child: ElevatedButton(
                    onPressed: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => const MyStackPage()));
                    },
                    child: const Text('Stack'),
                  )),
              Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(
                      horizontal: 15.0, vertical: 5.0),
                  child: ElevatedButton(
                    onPressed: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => const LoginPage()));
                    },
                    style:
                        ElevatedButton.styleFrom(backgroundColor: Colors.blue),
                    child: const Text('Sign In'),
                  )),
              Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(
                      horizontal: 15.0, vertical: 5.0),
                  child: ElevatedButton(
                    onPressed: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => const FormValidation()));
                    },
                    child: const Text('Form Validation'),
                  )),
              Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(
                      horizontal: 15.0, vertical: 5.0),
                  child: ElevatedButton(
                    onPressed: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => const AlertDialogApp()));
                    },
                    child: const Text('Alert Dialog'),
                  )),
              Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(
                      horizontal: 15.0, vertical: 5.0),
                  child: ElevatedButton(
                    onPressed: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) =>
                                  const MyBottomSheetDemoApp()));
                    },
                    child: const Text('BottomSheet'),
                  )),
              Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(
                      horizontal: 15.0, vertical: 5.0),
                  child: ElevatedButton(
                    onPressed: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => const CardDemoApp()));
                    },
                    child: const Text('Card'),
                  )),
              Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(
                      horizontal: 15.0, vertical: 5.0),
                  child: ElevatedButton(
                    onPressed: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => const MyCheckboxDemoApp()));
                    },
                    child: const Text('Checkbox Demo'),
                  )),
              Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: 15.0, vertical: 5.0),
                child: SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) =>
                                    const MyRadioButtonDemoApp()));
                      },
                      child: const Text('RadioButton Demo'),
                    )),
              ),
              Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: 15.0, vertical: 5.0),
                child: SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => const ChipDemoApp()));
                      },
                      child: const Text('Chip Demo'),
                    )),
              ),
              Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: 15.0, vertical: 5.0),
                child: SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) =>
                                    const MyPullToRefreshDemoApp()));
                      },
                      child: const Text('Pull To Refresh Demo'),
                    )),
              ),
              Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: 15.0, vertical: 5.0),
                child: SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) =>
                                    const MyProgressbarDemoApp()));
                      },
                      child: const Text('Progressbar Demo'),
                    )),
              ),
              Padding(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 15.0, vertical: 5.0),
                  child: SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        onPressed: () {
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) =>
                                      const MyWrapWidgetDemoApp()));
                        },
                        child: const Text('Wrap Widget Demo'),
                      ))),
              Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: 15.0, vertical: 5.0),
                child: SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => const TabbarDemoApp()));
                      },
                      child: const Text('Tabbar Demo'),
                    )),
              ),
              Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: 15.0, vertical: 5.0),
                child: SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => const BottomNav()));
                      },
                      child: const Text('Bottom Navigation'),
                    )),
              ),
              Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: 15.0, vertical: 5.0),
                child: SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => const ListDemoApp()));
                      },
                      child: const Text('List Demo'),
                    )),
              ),
              Padding(
                padding:
                    const EdgeInsets.only(left: 15.0, right: 15.0, top: 5.0),
                child: SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => const AnimeApp()));
                      },
                      child: const Text('Searchbar Demo'),
                    )),
              ),
              Padding(
                padding:
                    const EdgeInsets.only(left: 15.0, right: 15.0, top: 5.0),
                child: SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => const RatingbarDemo()));
                      },
                      child: const Text('Ratingbar Demo'),
                    )),
              ),
              Padding(
                padding:
                    const EdgeInsets.only(left: 15.0, right: 15.0, top: 5.0),
                child: SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => const MyThemeApp()));
                      },
                      child: const Text('Theme Demo'),
                    )),
              ),
              Padding(
                padding:
                    const EdgeInsets.only(left: 15.0, right: 15.0, top: 5.0),
                child: SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) =>
                                    const MyWillPopScopeDemoApp()));
                      },
                      child: const Text('Will popscope Demo'),
                    )),
              ),
              Padding(
                padding:
                    const EdgeInsets.only(left: 15.0, right: 15.0, top: 5.0),
                child: SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => TodosScreen(
                                    todos: List.generate(
                                        20,
                                        (i) => Todo(
                                              'Todo $i',
                                              'A description of what needs to be done for Todo $i',
                                            )))));
                      },
                      child: const Text('DataPassing Demo'),
                    )),
              ),
              Padding(
                padding:
                    const EdgeInsets.only(left: 15.0, right: 15.0, top: 5.0),
                child: SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => const MyStreamApp()));
                      },
                      child: const Text('StreamProvider Demo'),
                    )),
              ),
              Padding(
                padding:
                    const EdgeInsets.only(left: 15.0, right: 15.0, top: 5.0),
                child: SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => ChangeNotifierProvider(
                                      create: (_) => ChangeCourse(),
                                      child: const ChangeNotifierDemo(),
                                    )));
                      },
                      child: const Text('Change Notifier Demo'),
                    )),
              ),
              Padding(
                padding:
                    const EdgeInsets.only(left: 15.0, right: 15.0, top: 5.0),
                child: SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) =>
                                    const MyCustomButtonApp()));
                      },
                      child: const Text('Custom Button Demo'),
                    )),
              ),
              Padding(
                padding:
                    const EdgeInsets.only(left: 15.0, right: 15.0, top: 5.0),
                child: SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) =>
                                    const MyExpandableListApp()));
                      },
                      child: const Text('Expandable List Demo'),
                    )),
              ),
              Padding(
                padding:
                    const EdgeInsets.only(left: 15.0, right: 15.0, top: 5.0),
                child: SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => const MySwitchApp()));
                      },
                      child: const Text('Switch Demo'),
                    )),
              ),
             /* Padding(
                padding:
                    const EdgeInsets.only(left: 15.0, right: 15.0, top: 5.0),
                child: SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => LoginView()));
                      },
                      child: const Text('SharedPreference Session Demo'),
                    )),
              ),*/
              Padding(
                padding:
                    const EdgeInsets.only(left: 15.0, right: 15.0, top: 5.0),
                child: SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => const MyGoogleMapApp()));
                      },
                      child: const Text('Google Maps Demo'),
                    )),
              ),
              Padding(
                padding:
                    const EdgeInsets.only(left: 15.0, right: 15.0, top: 5.0),
                child: SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) =>
                                    const GoogleSignInScreen()));
                      },
                      child: const Text('Google Signin Demo'),
                    )),
              ),
              Padding(
                padding:
                    const EdgeInsets.only(left: 15.0, right: 15.0, top: 5.0),
                child: SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => const FacebookSignIn()));
                      },
                      child: const Text('Facebook Signin Demo'),
                    )),
              ),
              Padding(
                padding:
                    const EdgeInsets.only(left: 15.0, right: 15.0, top: 5.0),
                child: SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => const MySqfliteApp()));
                      },
                      child: const Text('Sqflite Demo'),
                    )),
              ),
              Padding(
                padding:
                    const EdgeInsets.only(left: 15.0, right: 15.0, top: 5.0),
                child: SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => MyMultiLangApp()));
                      },
                      child: const Text('Multi Language Demo'),
                    )),
              ),
              Padding(
                padding:
                    const EdgeInsets.only(left: 15.0, right: 15.0, top: 5.0),
                child: SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => const MyTimelineApp()));
                      },
                      child: const Text('Timeline Demo'),
                    )),
              ),
              Padding(
                padding:
                    const EdgeInsets.only(left: 15.0, right: 15.0, top: 5.0),
                child: SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => MyOtpApp()));
                      },
                      child: const Text('Show hide Demo'),
                    )),
              ),
              Padding(
                padding:
                    const EdgeInsets.only(left: 15.0, right: 15.0, top: 5.0),
                child: SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => MyGameApp()));
                      },
                      child: const Text('Tictactoe Demo'),
                    )),
              ),
              Padding(
                padding:
                    const EdgeInsets.only(left: 15.0, right: 15.0, top: 5.0),
                child: SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => MyPageViewDemoApp()));
                      },
                      child: const Text('Page View Demo'),
                    )),
              ),
              Container(
                padding:
                    const EdgeInsets.only(left: 15.0, right: 15.0, top: 5.0),
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () {
                    Navigator.push(context,
                        MaterialPageRoute(builder: (context) => MyMvvmApp()));
                  },
                  child: const Text('Mvvm View Demo'),
                ),
              ),
              Container(
                  padding:
                      const EdgeInsets.only(left: 15.0, right: 15.0, top: 5.0),
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => const FirebaseHomePage()));
                    },
                    child: const Text('Firebase Demo'),
                  )),
              Container(
                padding:
                    const EdgeInsets.only(left: 15.0, right: 15.0, top: 5.0),
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => MyFirebaseApp()));
                  },
                  child: const Text('Firebase messaging Notification Demo'),
                ),
              ),
              Container(
                padding:
                    const EdgeInsets.only(left: 15.0, right: 15.0, top: 5.0),
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => const HomeNotification()));
                  },
                  child: const Text('Local Notification Demo'),
                ),
              ),
              Padding(
                padding:
                    const EdgeInsets.only(left: 15.0, right: 15.0, top: 5.0),
                child: SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => const ImagePickerDemo()));
                      },
                      child: const Text('Image Picker Demo'),
                    )),
              ),



              Padding(
                padding:
                    const EdgeInsets.only(left: 15.0, right: 15.0, top: 5.0),
                child: SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => const ApiCallDemo()));
                      },
                      child: const Text('Http API Call Demo'),
                    )),
              ),
              Padding(
                padding:
                    const EdgeInsets.only(left: 15.0, right: 15.0, top: 5.0),
                child: SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) =>
                                    const DioDemoApiHomePage()));
                      },
                      child: const Text('Dio API Call Demo'),
                    )),
              ),
              Padding(
                padding:
                    const EdgeInsets.only(left: 15.0, right: 15.0, top: 5.0),
                child: SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => AppWidget()));
                      },
                      child: const Text('Login API Call Demo'),
                    )),
              ),
              Padding(
                padding:
                    const EdgeInsets.only(left: 15.0, right: 15.0, top: 5.0),
                child: SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) =>
                                    const GetXApiHomeScreen()));
                      },
                      child: const Text('Getx API Call Demo'),
                    )),
              ),
              Padding(
                padding:
                    const EdgeInsets.only(left: 15.0, right: 15.0, top: 5.0),
                child: SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => CreateApiCall()));
                      },
                      child: const Text('Create API Call Demo'),
                    )),
              ),
              Container(
                padding:
                    const EdgeInsets.only(left: 15.0, right: 15.0, top: 5.0),
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => PaginationUsersListScreen()));
                  },
                  child: const Text('Pagination API Call Demo'),
                ),
              ),
              Container(
                padding:
                    const EdgeInsets.only(left: 15.0, right: 15.0, top: 5.0),
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => MyRetrofitApp()));
                  },
                  child: const Text('Retrofit API Call Demo'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
