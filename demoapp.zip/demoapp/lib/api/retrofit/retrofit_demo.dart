import 'package:demoapp/api/retrofit/model.dart';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';

import 'api_client.dart';

void main() {
  runApp(const MyRetrofitApp());
}

class MyRetrofitApp extends StatelessWidget {
  const MyRetrofitApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: Home(),
    );
  }
}

class Home extends StatefulWidget {
  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {
  bool pressed = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: const Text("Retrofit Implementation - Flutter"),
      ),
      body: pressed
          ? _buildBody(context)
          : Center(
              child: ElevatedButton(
                  child: const Text(
                    "Fetch Users",
                    style: TextStyle(color: Colors.white, fontSize: 18),
                  ),
                  onPressed: () => {
                        setState(() {
                          pressed = true;
                        })
                      }),
            ),
    );
  }
}

FutureBuilder<UserModelApi> _buildBody(BuildContext context) {
  final client = ApiRequest(Dio(BaseOptions(contentType: "application/json")),
      baseUrl: 'https://reqres.in/api/');
  return FutureBuilder<UserModelApi>(
    future: client.getUsers(),
    builder: (context, snapshot) {
      /* print('snapshot.error ${snapshot.error}');*/
      if (snapshot.connectionState == ConnectionState.done) {
        final posts = snapshot.data;
        if (posts != null) {
          return _buildPosts(context, posts);
        } else {
          return Center(
            child: Container(),
          );
        }
      } else {
        return const Center(
          child: CircularProgressIndicator(),
        );
      }
    },
  );
}

Widget _buildPosts(BuildContext context, UserModelApi posts) {
  return ListView.builder(
    itemBuilder: (context, index) {
      return Card(
        child: InkWell(
          onTap: () {
            Navigator.push(
                context,
                MaterialPageRoute(
                    settings: RouteSettings(arguments: posts.data?[index]),
                    builder: (context) => const SingleUser()));
          },
          child: ListTile(
            leading: CircleAvatar(
              radius: 40,
              backgroundImage: NetworkImage(
                (posts.data?[index].avatar ?? "null"),
              ),
            ),
            title: Text(
              posts.data?[index].firstName ?? "null",
              style: const TextStyle(fontSize: 20),
            ),
            subtitle: Text(posts.data?[index].email ?? "null"),
          ),
        ),
      );
    },
    itemCount: posts.data?.length,
  );
}

class SingleUser extends StatefulWidget {
  const SingleUser({Key? key}) : super(key: key);

  @override
  State<SingleUser> createState() => _SingleUserState();
}

class _SingleUserState extends State<SingleUser> {
  @override
  Widget build(BuildContext context) {
    final todo = ModalRoute.of(context)?.settings.arguments as Data;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Pagination single User Page'),
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const SizedBox(
            height: 10,
          ),
          Container(
              margin: const EdgeInsets.only(left: 20, right: 20),
              padding: const EdgeInsets.only(left: 20),
              width: MediaQuery.of(context).size.width,
              decoration: BoxDecoration(
                  color: Colors.white, borderRadius: BorderRadius.circular(20)),
              child: Column(
                children: [
                  CircleAvatar(
                    radius: 60,
                    backgroundImage: NetworkImage(
                      todo.avatar ?? "null",
                    ),
                  ),
                  const SizedBox(
                    width: 30,
                  ),
                  Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        todo.firstName ?? "null",
                        style:
                            const TextStyle(color: Colors.black, fontSize: 18),
                      ),
                      Text(todo.email ?? "null",
                          style: const TextStyle(
                              color: Colors.black, fontSize: 18)),
                    ],
                  ),
                ],
              )),
          const SizedBox(
            height: 10,
          )
        ],
      ),
    );
  }
}
