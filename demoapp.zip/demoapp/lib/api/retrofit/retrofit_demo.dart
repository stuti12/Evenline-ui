import 'package:demoapp/api/retrofit/model/auto_model.dart';
import 'package:demoapp/api/retrofit/single_user.dart';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';

import 'service/api_client.dart';

void main() {
  runApp(const MyRetrofitApp());
}

class MyRetrofitApp extends StatelessWidget {
  const MyRetrofitApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: Home(),
    );
  }
}

class Home extends StatefulWidget {
  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {
  bool pressed = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: const Text("Retrofit Implementation - Flutter"),
      ),
      body: pressed
          ? _buildBody(context)
          : Center(
              child: ElevatedButton(
                  child: const Text(
                    "Fetch Users",
                    style: TextStyle(color: Colors.white, fontSize: 18),
                  ),
                  onPressed: () => {
                        setState(() {
                          pressed = true;
                        })
                      }),
            ),
    );
  }
}

FutureBuilder<Welcome> _buildBody(BuildContext context) {
  final client = ApiRequest(Dio(BaseOptions(contentType: "application/json")),
      baseUrl: 'https://reqres.in/api/');
  return FutureBuilder<Welcome>(
    future: client.getUsers(),
    builder: (context, snapshot) {
      /* print('snapshot.error ${snapshot.error}');*/
      if (snapshot.connectionState == ConnectionState.done) {
        final posts = snapshot.data;
        if (posts != null) {
          return _buildPosts(context, posts);
        } else {
          return Center(
            child: Container(),
          );
        }
      } else {
        return const Center(
          child: CircularProgressIndicator(),
        );
      }
    },
  );
}

Widget _buildPosts(BuildContext context, Welcome posts) {
  return ListView.builder(
    itemBuilder: (context, index) {
      return Card(
        child: InkWell(
          onTap: () {
            Navigator.push(
                context,
                MaterialPageRoute(
                    settings: RouteSettings(arguments: posts.data?[index]),
                    builder: (context) => const SingleUser()));
          },
          child: ListTile(
            leading: CircleAvatar(
              radius: 40,
              backgroundImage: NetworkImage(
                (posts.data?[index].avatar ?? "null"),
              ),
            ),
            title: Text(
              posts.data?[index].firstName ?? "null",
              style: const TextStyle(fontSize: 20),
            ),
            subtitle: Text(posts.data?[index].email ?? "null"),
          ),
        ),
      );
    },
    itemCount: posts.data?.length,
  );
}


