import 'package:demoapp/api/retrofit/model/auto_model.dart';
import 'package:dio/dio.dart';
import 'package:retrofit/http.dart';

part 'api_client.g.dart';

class Constants {
  static const String baseUrl = 'https://reqres.in/api';
}

@RestApi(baseUrl: Constants.baseUrl)
abstract class ApiRequest {
  factory ApiRequest(Dio dio, {required String baseUrl}) = _ApiRequest;

  @GET("/users")
  Future<Welcome> getUsers();
}
