import 'package:demoapp/api/pagination/model/model.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../getx/services/api_get_data.dart';

class SingleUser extends StatefulWidget {
  const SingleUser({Key? key}) : super(key: key);

  @override
  State<SingleUser> createState() => _SingleUserState();
}

class _SingleUserState extends State<SingleUser> {
  DataController dataController = Get.put(DataController());

  @override
  Widget build(BuildContext context) {
    final todo = ModalRoute.of(context)?.settings.arguments as UserDetails;

    return Scaffold(
      appBar: AppBar(
        title: Text('Pagination single User Page'),
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const SizedBox(
            height: 10,
          ),
          Container(
              margin: const EdgeInsets.only(left: 20, right: 20),
              padding: const EdgeInsets.only(left: 20),
              width: MediaQuery.of(context).size.width,
              decoration: BoxDecoration(
                  color: Colors.white, borderRadius: BorderRadius.circular(20)),
              child: Column(
                children: [
                  CircleAvatar(
                    radius: 60,
                    backgroundImage: NetworkImage(
                      todo.avatar ?? "null",
                    ),
                  ),
                  const SizedBox(
                    width: 30,
                  ),
                  Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        todo.firstName ?? "null",
                        style: TextStyle(color: Colors.black, fontSize: 18),
                      ),
                      Text(todo.email ?? "null",
                          style: TextStyle(color: Colors.black, fontSize: 18)),
                    ],
                  ),
                ],
              )),
          const SizedBox(
            height: 10,
          )
        ],
      ),
    );
  }
}
