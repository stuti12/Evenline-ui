import 'package:get/get.dart';


class PagingController extends GetxController{
  var isLoading = false.obs;
  var stop = false.obs;
  var page = 0.obs;
  var valueKey = 0.obs;
  RxList<dynamic> userDetails = [].obs;
}