import 'package:demoapp/api/pagination/single_user.dart';
import 'package:flutter/material.dart';
import 'package:visibility_detector/visibility_detector.dart';

import 'const/api.dart';
import 'model/model.dart';

class PaginationUsersListScreen extends StatefulWidget {
  @override
  _PaginationUsersListScreenState createState() =>
      _PaginationUsersListScreenState();
}

class _PaginationUsersListScreenState extends State<PaginationUsersListScreen> {
  List<UserDetails> userDetails = [];
  int page = 0;
  int valueKey = 0;
  final GlobalKey<RefreshIndicatorState> _refreshIndicatorKey =
      GlobalKey<RefreshIndicatorState>();
  bool isLoading = false;
  bool stop = false;

  getUsers() async {
    //first check for internet connectivity
    if (await ApiManager.checkInternet()) {
      //show progress
      if (mounted) {
        setState(() {
          isLoading = true;
        });
      }

      page = page + 1;
      var request = <String, dynamic>{};
      request["page"] = page.toString();

      //convert json response to class
      UsersResponse response = UsersResponse.fromJson(
        await ApiManager(context).getCall(
          url: AppStrings.USERS,
          request: request,
        ),
      );

      //hide progress
      if (mounted) {
        setState(() {
          isLoading = false;
        });
      }

      if (response != null) {
        if (response.data!.isNotEmpty) {
          if (mounted) {
            setState(() {
              //add paginated list data in list
              userDetails.addAll(response.data as List<UserDetails>);
            });
          }
        } else {
          noDataLogic(page);
        }
      } else {
        noDataLogic(page);
      }
    } else {
      //if no internet connectivity available then show apecific message
      Utility.showToast("No Internet Connection");
    }
  }

  noDataLogic(int pagenum) {
    //show empty view
    if (mounted) {
      setState(() {
        page = pagenum - 1;
        stop = true;
      });
    }
  }

  refresh() {
    //to refresh page
    if (mounted) {
      setState(() {
        valueKey = valueKey + 1;
        page = 0;
        userDetails.clear();
        stop = false;
      });
    }
    getUsers();
  }

  @override
  void initState() {
    super.initState();
    getUsers();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: const Text(
          "Pagination",
          style: TextStyle(
            fontWeight: FontWeight.w500,
            fontSize: 18,
          ),
        ),
      ),
      body: body(),
    );
  }

  Widget body() {
    return Stack(
      children: <Widget>[
        RefreshIndicator(
          key: _refreshIndicatorKey,
          onRefresh: () async {
            refresh();
          },
          child: !isLoading && userDetails.isEmpty
              /*
                i have shown empty view in list view because refresh indicator will not work if there is no list.
              */
              ? ListView(
                  physics: const AlwaysScrollableScrollPhysics(),
                  children: <Widget>[
                    SizedBox(
                      width: MediaQuery.of(context).size.width,
                      height: MediaQuery.of(context).size.height -
                          ((AppBar().preferredSize.height * 2) + 30),
                      child: Utility.emptyView("No Users"),
                    ),
                  ],
                )
              : ListView.builder(
                  physics: const AlwaysScrollableScrollPhysics(),
                  padding: const EdgeInsets.only(
                    bottom: 12,
                  ),
                  itemCount: userDetails.length,
                  itemBuilder: (BuildContext context, int index) {
                    return Column(
                      children: <Widget>[
                        (userDetails.length - 1) == index
                            ? VisibilityDetector(
                                key: Key(index.toString()),
                                child: itemView(index),
                                onVisibilityChanged: (visibilityInfo) {
                                  if (!stop) {
                                    getUsers();
                                  }
                                },
                              )
                            : itemView(index)
                      ],
                    );
                  },
                ),
        ),
        //show progress
        isLoading ? Utility.progress(context) : Container()
      ],
    );
  }

  Widget itemView(int index) {
    //users item view
    return InkWell(
        onTap: () {
          //go to single details with data passing
          Navigator.push(
              context,
              MaterialPageRoute(
                  settings: RouteSettings(arguments: userDetails[index]),
                  builder: (context) => const SingleUser()));
        },
        child: UserItemView(userDetails: userDetails[index]));
  }
}

class UserItemView extends StatelessWidget {
  UserDetails userDetails;

  UserItemView({
    required this.userDetails,
  });

  @override
  Widget build(BuildContext context) {
    String name = userDetails.firstName == null
        ? ""
        : "${userDetails.firstName} ${userDetails.lastName}";

    return ListTile(
        leading: SizedBox(
          width: 70,
          height: 80,
          child: CircleAvatar(
            radius: 80,
            backgroundImage: NetworkImage(
              userDetails.avatar ?? "not found",
            ),
          ),
        ),
        title: Text(
          name,
          style: TextStyle(
              color: AppColors.blackColor,
              fontWeight: FontWeight.bold,
              fontSize: 20),
        ),
        subtitle: Text(
          userDetails.email == null ? "" : userDetails.email ?? "null",
          style: const TextStyle(
            color: Colors.grey,
            fontSize: 16,
          ),
        ));
  }
}
