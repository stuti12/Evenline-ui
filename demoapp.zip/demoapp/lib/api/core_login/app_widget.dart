import 'package:demoapp/api/core_login/services/login/login_service.dart';
import 'package:demoapp/api/core_login/views/home/home_view.dart';
import 'package:demoapp/api/core_login/views/login/login_view.dart';
import 'package:flutter/material.dart';

import 'models/user_model.dart';

class AppWidget extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: FutureBuilder(
        future: LoginService().getUser(),
        builder: (context, snapshot) {
          switch (snapshot.connectionState) {
            case ConnectionState.waiting:
              return const Center(
                child: CircularProgressIndicator(
                  valueColor: AlwaysStoppedAnimation<Color>(Colors.black),
                  strokeWidth: 3.0,
                ),
              );
            case ConnectionState.none:
              return LoginView();
            default:
              if (snapshot.data != null) {
                return HomeView(user: snapshot.data! as UserModel);
              } else {
                return LoginView();
              }
          }
        },
      ),
      routes: {
        '/login': (_) => LoginView(),
      },
    );
  }
}
