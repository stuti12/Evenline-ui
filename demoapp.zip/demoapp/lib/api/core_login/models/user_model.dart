class UserModel {
  final String email;
  final String token;

  UserModel({required this.email, required this.token});
}
