import 'package:demoapp/api/getx/services/api_get_data.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../dio/modal/user_model.dart';
import 'getx_api_home.dart';


class SingleUser extends StatelessWidget {
  const SingleUser({Key? key,required this.data}) : super(key: key);
  final Data data;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const SizedBox(
            height: 10,
          ),
          Container(
              margin: const EdgeInsets.only(left: 20, right: 20),
              padding: const EdgeInsets.only(left: 20),
              width: MediaQuery.of(context).size.width,
              decoration: BoxDecoration(
                  color: Colors.white, borderRadius: BorderRadius.circular(20)),
              child: Column(
                children: [
                  CircleAvatar(
                    radius: 60,
                    backgroundImage: NetworkImage(data.avatar??""),
                  ),
                  const SizedBox(
                    width: 30,
                  ),
                  Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        data.firstName.toString() + "  " + data.lastName.toString(),
                        style: TextStyle(color: Colors.black, fontSize: 18),
                      ),
                      Text(data.email??"",
                          style: TextStyle(color: Colors.black, fontSize: 18)),
                    ],
                  ),
                ],
              )),
          const SizedBox(
            height: 10,
          )
        ],
      ),
    );
  }
}
