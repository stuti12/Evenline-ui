import 'package:demoapp/api/getx/model/create_model.dart';
import 'package:demoapp/api/getx/services/api_call_interface.dart';
import 'package:flutter/material.dart';

class CreateApiCall extends StatefulWidget {
  @override
  _CreateApiCallState createState() => _CreateApiCallState();
}

class _CreateApiCallState extends State<CreateApiCall> {
  final ApiCallService _apiService = ApiCallService();
  final _nameController = TextEditingController();
  final _jobController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        centerTitle: true,
        title: const Text('Create Update PUT Patch Api'),
      ),
      body: Center(
          child: GestureDetector(
        onTap: () {
          FocusScope.of(context).requestFocus(FocusNode());
        },
        child: SingleChildScrollView(
          child: Container(
            margin: const EdgeInsets.symmetric(horizontal: 20),
            child: Column(
              children: <Widget>[
                Card(
                  borderOnForeground: true,
                  shadowColor: Colors.black,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(15),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(20),
                    child: Column(
                      children: <Widget>[
                        TextField(
                          keyboardType: TextInputType.name,
                          controller: _nameController,
                          decoration: const InputDecoration(hintText: 'Name'),
                          textInputAction: TextInputAction.next,
                        ),
                        TextField(
                          keyboardType: TextInputType.name,
                          controller: _jobController,
                          decoration: InputDecoration(hintText: 'Job'),
                          textInputAction: TextInputAction.done,
                        ),
                        const SizedBox(
                          height: 30,
                        ),
                        ElevatedButton(
                          child: const Text('Create'),
                          onPressed: () async {
                            if (_nameController.text.isNotEmpty &&
                                _jobController.text.isNotEmpty) {
                              CreateUserApi? user = await _apiService.create(
                                  _nameController.text, _jobController.text);
                              if (user != null) {
                                ScaffoldMessenger.of(context)
                                    .showSnackBar(SnackBar(
                                  duration: const Duration(seconds: 3),
                                  content: Text(
                                      "Name: ${user.name} + job ${user.job} + createdDate: ${user.createdAt} id: ${user.id} "),
                                ));
                              } else {
                                ScaffoldMessenger.of(context).showSnackBar(
                                  const SnackBar(
                                    duration: Duration(seconds: 3),
                                    content:
                                        Text('email or password incorrect'),
                                  ),
                                );
                                return;
                              }
                            }
                          },
                        ),
                        ElevatedButton(
                          child: const Text('Update'),
                          onPressed: () async {
                            if (_nameController.text.isNotEmpty &&
                                _jobController.text.isNotEmpty) {
                              UpdateUserApi? user = await _apiService.update(
                                  _nameController.text, _jobController.text);
                              if (user != null) {
                                ScaffoldMessenger.of(context)
                                    .showSnackBar(SnackBar(
                                  duration: Duration(seconds: 3),
                                  content: Text(
                                      "Name: ${user.name} + job ${user.job} + updatedDate: ${user.updatedAt} "),
                                ));
                              } else {
                                ScaffoldMessenger.of(context).showSnackBar(
                                  const SnackBar(
                                    duration: Duration(seconds: 3),
                                    content:
                                        Text('email or password incorrect'),
                                  ),
                                );
                                return;
                              }
                            }
                          },
                        ),
                        ElevatedButton(
                          child: const Text('Delete'),
                          onPressed: () async {
                            DeleteUserApi? user = await _apiService.delete("6");
                            if (user != null) {
                              ScaffoldMessenger.of(context)
                                  .showSnackBar(const SnackBar(
                                duration: Duration(seconds: 3),
                                content: Text("Deleted "),
                              ));
                            }
                          },
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      )),
    );
  }
}
