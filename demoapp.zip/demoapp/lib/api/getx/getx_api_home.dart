import 'package:demoapp/api/getx/single_user.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';

import '../dio/modal/user_model.dart';
import 'services/api_get_data.dart';

class GetXApiHomeScreen extends StatefulWidget {
  const GetXApiHomeScreen({Key? key}) : super(key: key);

  @override
  State<GetXApiHomeScreen> createState() => _GetXApiHomeScreenState();
}

class TodoData {
  final String avatar;
  final String firstName;
  final String lastName;
  final String email;

  const TodoData(this.avatar, this.firstName, this.lastName, this.email);
}

class _GetXApiHomeScreenState extends State<GetXApiHomeScreen> {
  DataController dataController = Get.put(DataController());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Rest API Using GetX',
        ),
        centerTitle: true,
      ),
      body: Obx(() => dataController.isDataLoading.value
          ? const Center(child: CircularProgressIndicator())
          : ListView.builder(
              itemCount: dataController.user_model?.data?.length,
              itemBuilder: (context, index) {
                return userView(index);
              })),
    );
  }

  Widget userView(int index) {
    final TodoData todos = TodoData(
        dataController.user_model?.data?[index].avatar ?? 'assets/',
        dataController.user_model?.data?[index].firstName ?? "not found",
        dataController.user_model?.data?[index].lastName ?? "not found",
        dataController.user_model?.data?[index].email ?? "not found");

    return InkWell(
      onTap: () {
        print(dataController.user_model?.data?[index].firstName!);
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) =>  SingleUser(data:dataController.user_model?.data?[index] as Data),

          ),
        );
      },
      child: Column(
        children: [
          const SizedBox(
            height: 10,
          ),
          Container(
              margin: const EdgeInsets.only(left: 20, right: 20),
              padding: const EdgeInsets.only(left: 20),
              height: 80,
              decoration: BoxDecoration(
                  color: Colors.white, borderRadius: BorderRadius.circular(20)),
              child: Row(
                children: [
                  CircleAvatar(
                    radius: 35,
                    backgroundImage: NetworkImage(
                        dataController.user_model?.data?[index].avatar ??
                            'assets/'),
                  ),
                  const SizedBox(
                    width: 30,
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        dataController.user_model?.data?[index].firstName
                                ?.toUpperCase() ??
                            "Not found",
                        style:
                            const TextStyle(color: Colors.black, fontSize: 18),
                      ),
                      Text(
                          dataController.user_model?.data?[index].lastName ??
                              "Not found",
                          style: const TextStyle(
                              color: Colors.black, fontSize: 18)),
                      Text(
                          dataController.user_model?.data?[index].email ??
                              "not found",
                          style: const TextStyle(
                              color: Colors.black, fontSize: 18)),
                    ],
                  ),
                ],
              )),
          const SizedBox(
            height: 10,
          )
        ],
      ),
    );
  }
}
