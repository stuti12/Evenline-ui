import 'dart:convert';

import 'package:http/http.dart' as http;

import '../model/create_model.dart';

class Constants {
  static const baseUrl = 'https://reqres.in/api/users';
}

class ApiCallService {
  @override
  Future<CreateUserApi?> create(String name, String job) async {
    CreateUserApi createUserApi =
        CreateUserApi(name: "", id: "", job: "", createdAt: "");
    final api = Uri.parse(Constants.baseUrl);
    final data = {
      "id": createUserApi.id,
      "job": job,
      "name": name,
      "createdAt": createUserApi.createdAt
    };
    // final dio = Dio();
    http.Response response;
    response = await http.post(api, body: data);
    if (response.statusCode == 201) {
      final body = json.decode(response.body);
      print(body);
      return CreateUserApi(
          name: name, job: job, createdAt: body['createdAt'], id: body['id']);
    } else {
      return null;
    }
  }

  @override
  Future<UpdateUserApi?> update(String name, String job) async {
    UpdateUserApi updateUserApi =
        UpdateUserApi(name: "", job: "", updatedAt: "");
    final api = Uri.parse('${Constants.baseUrl}/2');
    final data = {
      "job": job,
      "name": name,
      "updatedAt": updateUserApi.updatedAt
    };
    // final dio = Dio();
    http.Response response;
    response = await http.patch(api, body: data);
    if (response.statusCode == 200) {
      final body = json.decode(response.body);
      print(body);
      return UpdateUserApi(name: name, job: job, updatedAt: body['updatedAt']);
    } else {
      return null;
    }
  }

  @override
  Future<DeleteUserApi?> delete(String id) async {
    final api = Uri.parse('${Constants.baseUrl}/2');
    final data = {"id": id};
    // final dio = Dio();
    http.Response response;
    response = await http.delete(api, body: data);
    if (response.statusCode == 204) {
      /*    SharedPreferences storage = await SharedPreferences.getInstance();
     final body = json.decode("Response ${response.statusCode.toString()}");
      print("succesfully deleted");
      print(body);
      await storage.setString('id', body['id']);*/
      return DeleteUserApi(id: id);
    } else {
      return null;
    }
  }
}
