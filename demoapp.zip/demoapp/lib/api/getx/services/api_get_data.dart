import 'dart:convert';

import 'package:demoapp/api/dio/modal/user_model.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;

import '../model/user.dart';

class HomeScreenBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<DataController>(
      () => DataController(),
    );
  }
}

class DataController extends GetxController {
  UserModelApi? user_model;

  var isDataLoading = false.obs;

  @override
  Future<void> onInit() async {
    super.onInit();
    getApi();
  }

  @override
  Future<void> onReady() async {
    super.onReady();
  }

  @override
  void onClose() {}

  getApi() async {
    try {
      isDataLoading(true);
      http.Response response =
          await http.get(Uri.parse('https://reqres.in/api/users?page=1'));
      if (response.statusCode == 200) {
        var result = jsonDecode(response.body);

        user_model = UserModelApi.fromJson(result);
      } else {}
    } catch (e) {
      print('Error while getting data is $e');
    } finally {
      isDataLoading(false);
    }
  }
}
