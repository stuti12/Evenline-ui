class CreateUserRequest {
  String? name;
  String? job;

  CreateUserRequest({this.name, this.job});

  CreateUserRequest.fromJson(Map<String, dynamic> json) {
    name = json['name'];
    job = json['job'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['name'] = this.name;
    data['job'] = this.job;
    return data;
  }
}

class CreateUserApi {
  String? name;
  String? job;
  String? id;
  String? createdAt;

  CreateUserApi({this.name, this.job, this.id, this.createdAt});

  CreateUserApi.fromJson(Map<String, dynamic> json) {
    name = json['name'];
    job = json['job'];
    id = json['id'];
    createdAt = json['createdAt'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['name'] = name;
    data['job'] = this.job;
    data['id'] = this.id;
    data['createdAt'] = createdAt;
    return data;
  }
}

class UpdateUserApi {
  String? name;
  String? job;
  String? updatedAt;

  UpdateUserApi({this.name, this.job, this.updatedAt});

  UpdateUserApi.fromJson(Map<String, dynamic> json) {
    name = json['name'];
    job = json['job'];
    updatedAt = json['updatedAt'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['name'] = name;
    data['job'] = this.job;
    data['updatedAt'] = updatedAt;
    return data;
  }
}

class DeleteUserApi {
  String? id;

  DeleteUserApi({this.id});
}
