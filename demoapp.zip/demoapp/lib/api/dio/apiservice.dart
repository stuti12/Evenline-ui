import 'package:dio/dio.dart';

import 'modal/model.dart';

class ApiConstants {
  static String baseUrl = 'https://reqres.in/';
  static String usersEndpoint = 'api/users?page=2';
}

class HttpResponse {
  bool status;
  String errMessage;
  dynamic json;
  dynamic totalRecords;
  bool failDueToToken;

  HttpResponse(
      {required this.status,
      required this.errMessage,
      this.json,
      this.totalRecords,
      this.failDueToToken = false});
}

class DioClient {
  final Dio _dio = Dio();

  Future<dynamic> getRequest(String apiType,
      {Map<String, String>? params, String? urlParam}) async {
    print("09/09 apiType + '$apiType'");

    final response = await _dio.get(apiType);
    return response.data;
  }

  final _baseUrl = 'https://reqres.in/api';

  Future<User> getUser({required String id}) async {
    // Perform GET request to the endpoint "/users/<id>"
    Response userData = await _dio.get(_baseUrl + '/users/$id');

    print('User Info: ${userData.data}');

    // Parsing the raw JSON data to the User class
    User user = User.fromJson(userData.data);

    return user;
  }
}
