import 'package:dio/dio.dart';

import 'core/constants.dart';

class ApiConstants {
  static String baseUrl = 'https://reqres.in/';
  static String usersEndpoint = 'api/users?page=2';
}


