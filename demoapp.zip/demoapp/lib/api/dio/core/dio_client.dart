import 'package:dio/dio.dart';

import '../modal/user_model.dart';

class ApiConst {
  ApiConst._();

  static const String baseUrl = "https://reqres.in/api/";
  static const String path = "users?page";
}

class ApiClient {
  Future getData(String path) async {
    try {
      final resonse =
          await Dio(BaseOptions(baseUrl: ApiConst.baseUrl)).get(path);
      return resonse.data;
    } on DioError catch (e) {
      throw Exception(e.message);
    }
  }
}


