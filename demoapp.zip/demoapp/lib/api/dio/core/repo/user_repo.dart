
import '../../modal/user_model.dart';
import '../dio_client.dart';

class UserRepository {
  Future<List<UserModel>> getUser() async {
    try {
      final result = await ApiClient().getData(ApiConst.path);
      final List data = result["data"];
      return data.map((e) => UserModel.fromJson(e)).toList();
    } catch (e) {
      throw Exception(e);
    }
  }
}