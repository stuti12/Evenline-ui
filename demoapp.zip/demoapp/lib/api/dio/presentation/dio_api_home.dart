import 'package:flutter/material.dart';
import 'package:shimmer/shimmer.dart';

import '../core/dio_client.dart';
import '../core/repo/user_repo.dart';
import '../modal/user_model.dart';

class DioDemoApiHomePage extends StatelessWidget {
  const DioDemoApiHomePage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Fetch API with Dio")),
      body: FutureBuilder<List<UserModel>>(
        future: UserRepository().getUser(),
        builder: (context, snapshot) {
          if (snapshot.hasData) {
            return ListView.builder(
                itemCount: snapshot.data?.length,
                itemBuilder: (context, index) {
                  final value = snapshot.data![index];

                  return ListTile(
                    leading: CircleAvatar(
                      backgroundImage: NetworkImage(value.avatar),
                    ),
                    title: Text(value.firstname + value.lastname),
                    subtitle: Text(value.email),
                  );
                });
          } else {
            return Shimmer.fromColors(
                baseColor: Colors.grey[400] ?? Colors.grey,
                highlightColor: Colors.grey[300] ?? Colors.grey,
                child: Container()
            );
          }
        },
      ),
    );
  }
}
