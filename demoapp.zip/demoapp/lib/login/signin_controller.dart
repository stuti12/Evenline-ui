import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';
import 'package:get/get_state_manager/src/simple/get_controllers.dart';

class LoginController extends GetxController {
  final GlobalKey<FormState> loginKey = GlobalKey<FormState>();

  // late TextEditingController emailController,passwordController;
  TextEditingController passwordController = TextEditingController();
  TextEditingController emailController = TextEditingController();
  var email = '';
  var pswd = '';
  var isPasswordHidden = true.obs;

  @override
  void onInit() {
    super.onInit();
  }

  @override
  void onClose() {
    super.onClose();
    emailController.dispose();
    passwordController.dispose();
  }

  String? validateEmail(String value) {
    if (value == null) {
      return 'please Enter email';
    }

    if (!GetUtils.isEmail(value)) {
      return "Please enter valid Email";
    }
    return null;
  }

  String? validatePassword(String value) {
    if (value.length < 6) {
      return "Please enter valid Password";
    }
    return null;
  }

  bool checkLogin() {
    final isValid = loginKey.currentState!.validate();
    if (!isValid) {
      return false;
    }
    Get.snackbar("title", "login success");

    loginKey.currentState?.save();
    return true;
  }

  void setData(String email, String pswd) {
    email = emailController.text;
    pswd = passwordController.text;
  }
}