
import 'package:demoapp/login/signin_controller.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:get/get_state_manager/src/rx_flutter/rx_obx_widget.dart';

import '../custom/custom_button.dart';
import '../custom/custom_textfield.dart';


class CustomLogin extends StatefulWidget {
  const CustomLogin({Key? key}) : super(key: key);

  @override
  State<CustomLogin> createState() => _CustomLoginState();
}

class _CustomLoginState extends State<CustomLogin> {
  LoginController controller = Get.put(LoginController());
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(children: [
        Expanded(
          child: SingleChildScrollView(
            child: Container(
              padding: EdgeInsets.only(left: 20.h, top: 50.h, right: 20.h),
              width: double.infinity,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [

                  Form(
                      autovalidateMode: AutovalidateMode.onUserInteraction,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          SizedBox(
                            height: 20.h,
                          ),
                          CustomWidgets.textField(
                            textInputAction: TextInputAction.next,
                            keyboardType: TextInputType.emailAddress,
                            controller: controller.emailController,
                            hint: 'Email',
                          ),
                          SizedBox(
                            height: 15.h,
                          ),

                          Obx(
                                () => CustomWidgets.textField(
                              suffixIcon: IconButton(
                                onPressed: () {
                                  controller.isPasswordHidden.value =
                                  !controller.isPasswordHidden.value;
                                },
                                icon: Icon(
                                  controller.isPasswordHidden.value
                                      ? Icons.visibility
                                      : Icons.visibility_off,
                                ),
                                color: Colors.grey,
                              ),
                              controller: controller.passwordController,
                              obscureText:
                              controller.isPasswordHidden.value,
                              textInputAction: TextInputAction.done,
                              keyboardType: TextInputType.visiblePassword,
                              hint: 'Password',
                            ),
                          ),
                          SizedBox(
                            height: 16.h,
                          ),

                          //forget password
                          Align(
                            alignment: Alignment.topRight,
                            child: Padding(
                              padding: EdgeInsets.all(20.h),
                              child: InkWell(
                                onTap: () {

                                },
                                child: RichText(
                                  text: TextSpan(
                                      text: 'Forgot Password',
                                      style: TextStyle(
                                          fontFamily: 'Museo Sans',
                                          fontWeight: FontWeight.w400,
                                          fontSize: ScreenUtil().setSp(16),
                                          color: Colors.black12),
                                      children: <TextSpan>[
                                        TextSpan(
                                          recognizer: TapGestureRecognizer()
                                            ..onTap = () => {

                                            },
                                        ),
                                      ]),
                                ),
                              ),
                            ),
                          ),
                          SizedBox(
                            height: 16.h,
                          ),
                         CustomButton(onTap: (){},title: 'Login',),
                          Padding(
                            padding: EdgeInsets.all(20.h),
                            child: Text(
                             'continue',
                              style: TextStyle(
                                  fontFamily: 'Museo Sans',
                                  fontWeight: FontWeight.w400,
                                  fontSize: ScreenUtil().setSp(16),
                                  color: Colors.black12),
                              textAlign: TextAlign.right,
                            ),
                          ),

                          //social login

                        ],
                      ))
                ],
              ),
            ),
          ),
        ),
        Padding(
          padding: EdgeInsets.only(bottom: 8.h),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              RichText(
                text: TextSpan(
                    text: 'Not member',
                    style: TextStyle(
                        fontFamily: 'Museo Sans',
                        fontSize: ScreenUtil().setSp(14),
                        color: Colors.black12),
                    children: <TextSpan>[
                      TextSpan(
                        recognizer: TapGestureRecognizer()
                          ..onTap = () => {

                          },
                        text: 'Sign Up',
                        style: TextStyle(
                            fontFamily: 'Museo Sans Bold',
                            fontWeight: FontWeight.bold,
                            fontSize: ScreenUtil().setSp(14),
                            color: Colors.black12),
                      ),
                    ]),
              ),
            ],
          ),
        ),
      ],),
    );
  }
}
