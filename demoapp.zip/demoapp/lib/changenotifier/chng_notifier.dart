import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

void main() => runApp(ChangeNotifierProvider(
      create: (_) => Favourites(),
      child: ChangeNotifierApp(),
    ));

class ChangeNotifierApp extends StatefulWidget {
  const ChangeNotifierApp({Key? key}) : super(key: key);

  @override
  State<ChangeNotifierApp> createState() => _ChangeNotifierAppState();
}

class _ChangeNotifierAppState extends State<ChangeNotifierApp> {
  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [Provider(create: (_) => Favourites())],
      child: MaterialApp(
        home: Scaffold(
          appBar: AppBar(
            title:
                Text('My favourite' + Provider.of<Favourites>(context).fruit),
          ),
          body: Column(
            children: [
              FruitButton(fruit: 'Apple'),
              FruitButton(fruit: 'Mango'),
              FruitButton(fruit: 'Strawberry')
            ],
          ),
        ),
      ),
    );
  }
}

class FruitButton extends StatelessWidget {
  final String fruit;

  FruitButton({required this.fruit});

  @override
  Widget build(BuildContext context) {
    return ElevatedButton(
        onPressed: () {
          Provider.of<Favourites>(context, listen: false).changeFruit(fruit);
        },
        child: Text(fruit));
  }
}

class Favourites extends ChangeNotifier {
  String fruit = 'unknown';

  void changeFruit(String newFruit) {
    fruit = newFruit;
    notifyListeners();
  }
}
