import 'package:demoapp/changenotifier/change_course.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class MyCourses extends StatelessWidget {
  final String course;

  const MyCourses({Key? key, required this.course}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        Provider.of<ChangeCourse>(context, listen: false)
            .changeSubjects(course);
      },
      child: Container(
        margin: const EdgeInsets.only(top: 30, left: 20, right: 20),
        width: double.maxFinite,
        height: 70,
        decoration: BoxDecoration(
            color: Colors.red, borderRadius: BorderRadius.circular(10)),
        child: Center(
          child: Text(
            course,
            style: TextStyle(color: Colors.white),
          ),
        ),
      ),
    );
  }
}
