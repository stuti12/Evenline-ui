import 'package:demoapp/changenotifier/change_course.dart';
import 'package:demoapp/changenotifier/my_courses.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

void main() {
  runApp(ChangeNotifierProvider(
    create: (_) => ChangeCourse(),
    child: const ChangeNotifierDemo(),
  ));
}

class ChangeNotifierDemo extends StatefulWidget {
  const ChangeNotifierDemo({Key? key}) : super(key: key);

  @override
  _ChangeNotifierDemoState createState() => _ChangeNotifierDemoState();
}

class _ChangeNotifierDemoState extends State<ChangeNotifierDemo> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        debugShowCheckedModeBanner: false,
        home: Scaffold(
          body: Column(
            children: [
              Container(
                margin: EdgeInsets.only(top: 30, left: 20, right: 20),
                width: double.maxFinite,
                height: 70,
                decoration: BoxDecoration(
                    color: Colors.red, borderRadius: BorderRadius.circular(10)),
                child: Center(
                  child: Text(
                    'We are Learning' +
                        Provider.of<ChangeCourse>(context).subject,
                    style: TextStyle(color: Colors.white),
                  ),
                ),
              ),
              MyCourses(course: 'Android'),
              MyCourses(course: 'iOS'),
              MyCourses(course: 'Flutter')
            ],
          ),
        ));
  }
}
