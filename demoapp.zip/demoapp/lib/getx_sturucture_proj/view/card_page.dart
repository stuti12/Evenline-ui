import 'package:demoapp/getx_sturucture_proj/models/prod.dart';
import 'package:demoapp/getx_sturucture_proj/view/product_controller.dart';
import 'package:demoapp/getx_sturucture_proj/view/producttile.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class CartPage extends StatelessWidget {

  final ProductController productController = Get.put(ProductController());
  @override
  Widget build(BuildContext context) {

    return Scaffold(
      body:
     ListView.builder(
          itemBuilder: (context, index) {
            return ProductTile(productController.productList[index]);
          }),
    );
  }
}
