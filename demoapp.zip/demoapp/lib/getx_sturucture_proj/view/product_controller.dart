import 'package:get/get.dart';

import '../models/prod.dart';
import '../services/remote.dart';

class ProductController extends GetxController {
  var isLoading = true.obs;
  var isListbtnPressed = false.obs;
  var productList = <Product>[].obs;

  @override
  void onInit() {
    fetchProducts();
    super.onInit();
  }

  void fetchProducts() async {
    try {
      isLoading(true);
      var products = await RemoteServices.fetchProducts();
      if (products != null) {
        productList.value = products;
      }
    } finally {
      isLoading(false);
    }
  }
}