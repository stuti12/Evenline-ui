
import 'package:demoapp/getx_sturucture_proj/view/card_page.dart';
import 'package:demoapp/getx_sturucture_proj/view/product_controller.dart';
import 'package:demoapp/getx_sturucture_proj/view/producttile.dart';
import 'package:flutter/material.dart';
import 'package:flutter_staggered_grid_view/flutter_staggered_grid_view.dart';
import 'package:get/get.dart';

import '../models/prod.dart';

class GetXProjectHomePage extends StatelessWidget {
  final ProductController productController = Get.put(ProductController());

  @override
  Widget build(BuildContext context) {
    Product product = Product();
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.grey,
        elevation: 0,
        actions: [
          IconButton(
            icon: const Icon(
              Icons.shopping_cart,
            ),
            onPressed: () {

            },
          )
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                const Expanded(
                  child: Text(
                    'ShopX',
                    style: TextStyle(
                        fontFamily: 'avenir',
                        fontSize: 32,
                        fontWeight: FontWeight.w900),
                  ),
                ),
                IconButton(
                    icon: const Icon(Icons.view_list_rounded),
                    onPressed: () {
                      productController.isListbtnPressed.value = true;
                    }),
                IconButton(
                    icon: const Icon(Icons.grid_view),
                    onPressed: () {
                      productController.isListbtnPressed.value = false;
                    }),
              ],
            ),
          ),
          Expanded(
            child: Obx(() {
              if (productController.isLoading.value) {
                return const Center(child: CircularProgressIndicator());
              } else {
                if (productController.isListbtnPressed.value) {
                  return ListView.builder(
                      itemCount: productController.productList.length,
                      itemBuilder: (context, index) {
                        return InkWell(onTap: (){
                        },
                          child: ProductTile(
                              productController.productList[index]),
                        );
                      });
                }

                return StaggeredGridView.countBuilder(
                  crossAxisCount: 2,
                  itemCount: productController.productList.length,
                  crossAxisSpacing: 16,
                  mainAxisSpacing: 16,
                  itemBuilder: (context, index) {
                    return InkWell(onTap: (){
                   /*   Navigator.push(
                          context,
                          MaterialPageRoute(
                            settings: RouteSettings(arguments: productController.productList[index]),
                          builder: (context) => CartPage()));*/
                    },
                        child: ProductTile(productController.productList[index]));
                  },
                  staggeredTileBuilder: (index) => const StaggeredTile.fit(1),
                );
              }
            }),
          )
        ],
      ),
    );
  }
}
