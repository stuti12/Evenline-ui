import 'dart:convert';

import 'package:get/get.dart';

class Product {
  Product({
      this.id,
      this.brand,
      this.name, 
      this.price, 
      this.priceSign, 
      this.currency, 
      this.imageLink, 
      this.productLink, 
      this.websiteLink, 
      this.description, 
      this.rating, 
      this.category, 
      this.productType, 
      this.tagList,
      this.createdAt, 
      this.updatedAt, 
      this.productApiUrl, 
      this.apiFeaturedImage, 
      this.productColors,});
  var isFavorite = false.obs;
  Product.fromJson(dynamic json) {
    id = json['id'];
    brand = json['brand'];
    name = json['name'];
    price = json['price'];
    priceSign = json['price_sign'];
    currency = json['currency'];
    imageLink = json['image_link'];
    productLink = json['product_link'];
    websiteLink = json['website_link'];
    description = json['description'];
    rating = json['rating'];
    category = json['category'];
    productType = json['product_type'];
    if (json['tag_list'] != null) {
      tagList = [];
      json['tag_list'].forEach((v) {
        tagList?.add(json['tag_list']);
      });
    }
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
    productApiUrl = json['product_api_url'];
    apiFeaturedImage = json['api_featured_image'];
    if (json['product_colors'] != null) {
      productColors = [];
      json['product_colors'].forEach((v) {
        productColors?.add(json['product_colors']);
      });
    }
  }
  int? id;
  String? brand;
  String? name;
  String? price;
  dynamic priceSign;
  dynamic currency;
  String? productLink;
  String? websiteLink;
  String? imageLink;
  String? description;
  double? rating;
  dynamic category;
  String? productType;
  List<dynamic>? tagList;
  String? createdAt;
  String? updatedAt;
  String? productApiUrl;
  String? apiFeaturedImage;
  List<dynamic>? productColors;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['id'] = id;
    map['brand'] = brand;
    map['name'] = name;
    map['price'] = price;
    map['price_sign'] = priceSign;
    map['currency'] = currency;
    map['image_link'] = imageLink;
    map['product_link'] = productLink;
    map['website_link'] = websiteLink;
    map['description'] = description;
    map['rating'] = rating;
    map['category'] = category;
    map['product_type'] = productType;
    if (tagList != null) {
      map['tag_list'] = tagList;
    }
    map['created_at'] = createdAt;
    map['updated_at'] = updatedAt;
    map['product_api_url'] = productApiUrl;
    map['api_featured_image'] = apiFeaturedImage;
    if (productColors != null) {
      map['product_colors'] = productColors?.map((v) => v.toJson()).toList();
    }
    return map;
  }

}
enum Brand { MAYBELLINE }

final brandValues = EnumValues({"maybelline": Brand.MAYBELLINE});
class ProductColor {
  ProductColor({
     this.hexValue,
     this.colourName,
  });

  String? hexValue;
  String? colourName;

  factory ProductColor.fromJson(Map<String, dynamic> json) => ProductColor(
    hexValue: json["hex_value"],
    colourName: json["colour_name"],
  );

  Map<String, dynamic> toJson() => {
    "hex_value": hexValue,
    "colour_name": colourName ?? null,
  };
}

class EnumValues<T> {
  Map<String, T> map;
  Map<T, String>? reverseMap;

  EnumValues(this.map);

  Map<T, String>? get reverse {
    reverseMap ??= map.map((k, v) =>  MapEntry(v, k));
    return reverseMap;
  }
}

List<Product> prodFromJson(String str) =>
    List<Product>.from(json.decode(str).map((x) => Product.fromJson(x)));

String prodToJson(List<Product> data) =>
    json.encode(List<dynamic>.from(data.map((x) => x.toJson())));