import 'dart:collection';
import 'dart:io';
import 'dart:math';

void main() {
  int num1 = 11;
  int num2 = 2;
  var add = num2 + num1;
  var subt = num1 - num2;
  print("Addition $add");
  print("subtraction $subt");
  print(num2 is String);

  bool c = num1 > 10 && num2 < 10;
  print(c);

  //arrow operator
  perimeterOfRectangle(46, 46);

  // Creating child class object
  Sub sub = Sub();
  sub.printInfo();

  //static
  Student std1 = Student(); // Creating instances of student class
  Student.stdBranch = "Computer Science";

  std1.stdName = "Ben Cutting";
  std1.rollNum = 90013;
  std1.showStdInfo();

  print("Enter your name?");
  // Reading name of the Geek
  String? name = stdin.readLineSync();

  // Printing the name
  print("Hello, $name! \nWelcome to Flutter!!");

  print("Enter your favourite number:");
  int? n = int.parse(stdin.readLineSync()!);
  print("Your favourite number is $n");

  //collections
  var oddList = [1, 3, 5, 7, 9];
  print('\nList\n$oddList');
  oddList.addAll([11, 13, 14]);
  print(oddList);

  var list1 = ["Smith", "Peter", "Handscomb", "Devansh", "Cruise"];
  print("Iterating the List Element");
  list1.addAll(["stuti"]);
  list1.forEach((item) {
    print("${list1.indexOf(item)}: $item");
  });

  List<String> stringData = ["abc"];
  stringData.addAll(["abc", "fff"]);
  print(stringData);

  /* var numbers = list.filled(5,0);
  numbers.add('dfdf');
  numbers.add('value');
  print(numbers);
*/

  var listMax = [100, 45, 7, 23];

  var smallFold = listMax.fold(listMax[0], min);
  var join = listMax.join();

  var large =
      listMax.reduce((value, element) => value > element ? value : element);
  print("\nSmallest value in the list : $smallFold");
  print("Smallest value in the list : $large");
  print('join$join');

  Map names = {};
  names[0] = 'Stuti';
  names[1] = 'bhavsar';
  print('\nMap:');
  print(names);

  Queue<String> namesQueue = Queue<String>();
  namesQueue.add('dff');
  namesQueue.add('nsreh');
  print('\nQueue: $namesQueue');

  List<String> geekList = ["Geeks", "For", "Geeks"];

  Queue<String> geekQueue = Queue<String>.from(geekList);
  print('\nQueue from List: $geekQueue');

  geekQueue.forEach(print);

  //set
  Set printSet = Set();
  printSet.addAll([9, 1, 2, 3, 4, 5, 6, 1, 1, 9]);
  Set printSet2 = Set();
  printSet2.addAll([2, 5, 9, 1]);

  // Looping over the set
  print('\nSet');
  for (var value in printSet) {
    print(value);
  }
  print('\nUnion set');
  print(printSet.union(printSet2));
  print('\nIntersection');
  print(printSet.intersection(printSet2));

  print('\nEnum');
  for (MyData data in MyData.values) {
    print('$data');
  }

  var listNumbers = [1, 2, 3, 4, 5];
  print('\nfor loop');
  for (int i in listNumbers) {
    print(i);
  }
  listNumbers.forEach((var num) => print(num));

  Geek1:
  for (int i = 0; i < 3; i++) {
    if (i < 2) {
      print("You are inside the loop");
      continue Geek1;
    }
    print("You are still inside the loop");
  }

  //functions with param
  void function1(int g1, [var g2]) {
    print("g1 is $g1");
    print("g2 is $g2");
  }

  void function2(int g1, {var g2, var g3}) {
    print("g1 is $g1");
    print("g2 is $g2");
    print("g3 is $g3");
  }

  print("\nCalling the function with optional parameter:");
  function1(01);
  print("\nCalling the function with Optional Named parameter:");
  function2(01, g3: 12);

  //recursion
  int fibonacci(int n) {
    // This is recursive function as it calls itself
    return n < 2 ? n : (fibonacci(n - 1) + fibonacci(n - 2));
  }

  //anonymous- closure-lamda
  var list = ["James", "Patrick", "Mathew", "Tom"];
  print("\nExample of anonymous function");
  list.forEach((item) {
    print('${list.indexOf(item)}: $item');
  });

  var fibonaci = 20;
  print('\nRecursion');
  print('fibonacci($fibonaci) = ${fibonacci(fibonaci)}');

  //lexical closure
  var data1 = printData(1);
  var data2 = printData(10);
  print('\nLexical Closure');
  print(data1(4));
  print(data2(7));

  //const
  var value1 = assign();
  var value2 = assign();
  print('\nConst keyword $value1');
  print(value1 == value2);

  print('\nString Functions');
  String gfg = "Stuti1For2Stutis3is4the5best6computer7science8website.";

  print('Split string');
  print(gfg.split(RegExp(r"[0-9]")));

  List<String> stringDemo = ['one', 'two', 'three', 'four'];

  // Sorting string by comparing the length
  stringDemo.sort((a, b) => a.length.compareTo(b.length));
  stringDemo.sort();
  print('\nsorting$stringDemo');
  print('sort string list with its length$stringDemo');

  //string
}

void perimeterOfRectangle(int length, int breadth) {
  var perimeter = 2 * (length + breadth);
  print('The perimeter of rectangle is $perimeter');
}

assign() => const [1, 2];

// Creating Parent class
class Super {
  String name = "Flutter";
}

// Creating child class
class Sub extends Super {
  void printInfo() {
    String name = "demo";
    print('\nthis keyword\n$name');
    print(this.name);
  }
}

Function printData(num add) {
  return (num i) => add + i;
}

class Student {
  static String stdBranch = ""; // Declaring static variable
  late String stdName;
  late int rollNum;

  showStdInfo() {
    print("\nStatic keyword\nStudent's name is: ${stdName}");
    print("Student's salary is: $rollNum");
    print("Student's branch name is: ${stdBranch}");
  }
}

enum MyData { stuti, bhavsar }
