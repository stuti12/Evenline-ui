import 'dart:async';
import 'dart:math';

import 'package:flutter/material.dart';

void main() => runApp(MyStreamApp());

class MyStreamApp extends StatefulWidget {
  const MyStreamApp({Key? key}) : super(key: key);

  @override
  State<MyStreamApp> createState() => _MyStreamAppState();
}

class _MyStreamAppState extends State<MyStreamApp> {
  StreamController<double> controller = StreamController<double>.broadcast();
  late StreamSubscription<double> streamSubscription;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        body: Center(
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              MaterialButton(
                child: Text('Subscribe'),
                onPressed: () {
                  //stream the controller manage
                  getDelayedRandomValue().listen((value) {
                    print('value from manual stream ${value}');
                  });
                },
                color: Colors.grey,
              ),
              MaterialButton(
                  child: Text('Emit Value'),
                  color: Colors.blue,
                  onPressed: () {
                    controller.add(12);
                  }),
              MaterialButton(
                  child: Text('Unsubscribe'),
                  color: Colors.red[300],
                  onPressed: () {
                    streamSubscription.cancel();
                  })
            ],
          ),
        ),
      ),
    );
  }

  Stream<double> getDelayedRandomValue() async* {
    var random = Random();
    while (true) {
      await Future.delayed(Duration(seconds: 1));
      yield random.nextDouble();
    }
  }
}
