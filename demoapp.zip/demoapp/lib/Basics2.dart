import 'dart:io';

void main() async {
  DemoClass demoClass = DemoClass();
  print("Inheritance");

  ConsolePrinter cp = ConsolePrinter();
  cp.print_data();

  print('\nInterface');
  MainClass mainClass = MainClass();
  mainClass.printData();
  mainClass.printData2();
  mainClass.printData3();

  DemoClassAbstract demoClassAbstract = DemoClassAbstract();
  demoClassAbstract.write();
  demoClass.setName = "Flutter Demo";

  print("Welcome to ${demoClass.getName}");

  var input = CallableClass();
  var input2 = input('Stuti ', 'Bhavsar ', 'Tutorial ');
  print('\nCallable function \n$input2');

  var second = Second();
  second.firstFunc();
  second.number();

  var now = DateTime.now();
  print('\n$now');

  var y2k = DateTime(2000);
  y2k = DateTime.parse('2000-01-01T00:00:00Z');
  print(y2k);

  var list = <int>[];
  list.add(1000);
  list.add(2000);
//  printInts(list);

  print('\nDart print Even number reverse');
  generator(10).forEach(print);

  print('\nException Handling');
  int number1 = 12;
  int number2 = 0;
  int res;
  try {
    res = number1 ~/ number2;
  } on UnsupportedError {
    print('Cannot divide by zero');
  } finally {
    print('finally block');
  }

  try {
    withdraw(-1);
  } catch (e) {
    print(e.toString());
  } finally {
    print('Ending requested operation.....');
  }

  for (int i = 1; i <= 5; i++) {
    for (int j = 1; j <= i; j++) {
      stdout.write('*');
    }
    stdout.write('\n');
  }

  MultiOperation mp = sum;
  print("\nDart typedef Example");

  mp(20, 10);
  mp = sub;
  mp(30, 20);

  //Extention
  print('\nExtention func');
  print('42'.parseInt());

  //Future
  print('\nFuture keyword');
  fetchUserOrder();
  print('Fetching user order...');

  countSeconds(4);
  await printOrderMessage();

  await printOrderMessageError();
}

Iterable generator(int number) sync* {
  int geek = number;
  while (geek >= 0) {
    // Checking for even number
    if (geek % 2 == 0) {
      // 'yield' suspends
      // the function
      yield geek;
    }

    geek--;
  }
}

class Printer {
  void print_data() {
    print("__________Printing Data__________");
  }
}

class ConsolePrinter implements Printer {
  void print_data() {
    print("__________Printing to Console__________");
  }
}

class AmtException implements Exception {
  String errMsg() => 'Amount should be greater than zero';
}

void withdraw(int amt) {
  if (amt <= 0) {
    throw AmtException();
  }
}

class DemoClass {
  late String geekName;

  String get getName {
    return geekName;
  }

  set setName(String name) {
    geekName = name;
  }
}

abstract class DemoAbstract {
  void write();
}

class DemoClassAbstract extends DemoAbstract {
  @override
  void write() {
    print("\nAbstract class Demo");
    print("Write method");
  }
}

class CallableClass {
  // Defining call method which create the class callable
  String call(String a, String b, String c) => 'Welcome to $a$b$c!';
}

mixin FirstMixim {
  void firstFunc() {
    print('hello');
  }
}

mixin SecondMixim {
  void number() {
    print(10);
  }
}

class Second with FirstMixim, SecondMixim {
  @override
  void firstFunc() {
    print('\nwith keyword mixim');
    print('can override if needed');
  }
}

//interface define with class but implement keyword used
class DemoOne {
  void printData() {
    print('Hello world');
  }
}

class DemoTwo {
  void printData2() {
    print('Hello world 2');
  }
}

class DemoThree {
  void printData3() {
    print('Hello world 3');
  }
}

class MainClass implements DemoOne, DemoThree, DemoTwo {
  @override
  void printData() {
    print('Hello Class One');
  }

  @override
  void printData2() {
    print('Hello Class Two');
  }

  @override
  void printData3() {
    print('Hello Class Three');
  }
}

typedef MultiOperation(int num1, int num2); // typedef function signature
sum(int n1, int n2) {
  print("Sum of the two number:${n1 + n2}");
}

sub(int n1, int n2) {
  print("Subtraction of the two number:${n1 - n2}");
}

extension NumberParsing on String {
  int parseInt() {
    return int.parse(this);
  }
// ···
}

Future<void> fetchUserOrder() {
  // Imagine that this function is fetching user info from another service or database.
  return Future.delayed(const Duration(seconds: 2), () => print('Large Latte'));
}

Future<void> printOrderMessage() async {
  print('Awaiting user order...');
  var order = await fetchUserOrders();
  print('Your order is: $order');
}

Future<String> fetchUserOrders() {
  // Imagine that this function is more complex and slow.
  return Future.delayed(const Duration(seconds: 4), () => 'Large Latte');
}

void countSeconds(int s) {
  for (var i = 1; i <= s; i++) {
    Future.delayed(Duration(seconds: i), () => print(i));
  }
}

Future<void> printOrderMessageError() async {
  try {
    print('\nFuture keyword with error');
    print('Awaiting user order...');
    var order = await fetchUserOrderError();
    print(order);
  } catch (err) {
    print('Caught error: $err');
  }
}

Future<String> fetchUserOrderError() {
  // Imagine that this function is more complex.
  var str = Future.delayed(
      const Duration(seconds: 4), () => throw 'Cannot locate user order');
  return str;
}
