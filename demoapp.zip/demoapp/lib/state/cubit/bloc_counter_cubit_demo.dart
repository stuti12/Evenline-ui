import 'package:flutter/material.dart';

import '../bloc_management/counter_page.dart';

class CounterApp extends MaterialApp {
  /// {@macro counter_app}
  const CounterApp({super.key}) : super(home: const CounterPage());
}
