
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../api/pagination/const/api.dart';
import 'sign_in_bloc.dart';
import '../bloc_management/bloc_event/sign_in_event.dart';
import '../bloc_management/bloc_state/sign_in_state.dart';

class LoginScreenBloc extends StatefulWidget {
  const LoginScreenBloc({Key? key}) : super(key: key);

  @override
  State<LoginScreenBloc> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreenBloc> {
  TextEditingController emailController = TextEditingController();

  TextEditingController passwordController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: ListView(
          physics: const BouncingScrollPhysics(
              parent: AlwaysScrollableScrollPhysics()),
          children: [
            BlocBuilder<SignInBloc, SignInState>(builder: (context, state) {
              if (state is SignInErrorState) {
                return Text(state.errorMessage,
                    style: const TextStyle(color: Colors.red));
              } else {
                return Container();
              }
            }),
            const SizedBox(
              height: 200.0,
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: TextField(
                keyboardType: TextInputType.emailAddress,
                /*keyboardType: const TextInputType.numberWithOptions(
                    signed: true,
                       inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                    decimal: true),*/
                textInputAction: TextInputAction.next,
                controller: emailController,
                decoration: const InputDecoration(hintText: 'Email Address'),
                onChanged: (val) {
                  BlocProvider.of<SignInBloc>(context).add(
                      SignInTextChangeEvent(
                          emailController.text, passwordController.text));
                },
              ),
            ),
            const SizedBox(
              height: 10.0,
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: TextField(
                  keyboardType: TextInputType.visiblePassword,
                  controller: passwordController,
                  textInputAction: TextInputAction.done,
                  decoration: const InputDecoration(hintText: 'Email Password'),
                  obscureText: true,
                  onChanged: (val) {
                    BlocProvider.of<SignInBloc>(context).add(
                        SignInTextChangeEvent(
                            emailController.text, passwordController.text));
                  }),
            ),
            const SizedBox(
              height: 10.0,
            ),
            BlocBuilder<SignInBloc, SignInState>(builder: (context, state) {
              if (state is SignInLoadingState) {
                return const Center(child: CircularProgressIndicator());
              }
              return ElevatedButton(
                  onPressed: () {
                    if (state is SignInValidState) {
                      Utility.showToast(
                          "Data Submitted Username:${emailController.text} + Password:${passwordController.text}");

                      BlocProvider.of<SignInBloc>(context).add(
                          SignInSubmittedEvent(
                              emailController.text, passwordController.text));
                    }
                  },
                  child: const Text('Submit'));
            }),
          ],
        ),
      ),
    );
  }
}
