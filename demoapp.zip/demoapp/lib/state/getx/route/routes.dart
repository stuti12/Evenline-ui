import 'package:get/get_navigation/src/routes/get_route.dart';

import '../binding/home.dart';
import '../view/home_view.dart';

class AppPages {
  static const INITIAL = Routes.HOME;

  static final routes = [
    GetPage(
      name: _Paths.HOME,
      page: () => GetXHomeView(),
      binding: HomeBinding(),
    ),
  ];
}

abstract class Routes {
  static const HOME = _Paths.HOME;
}

abstract class _Paths {
  static const HOME = '/home';
}
