import 'package:flutter/material.dart';

class CountProvider extends InheritedWidget {
  final Widget child;
  final Counter counter;

  CountProvider({Key? key, required this.child, required this.counter})
      : super(key: key, child: child);

  static CountProvider of(BuildContext context) {
    return (context.dependOnInheritedWidgetOfExactType<CountProvider>()
        as CountProvider);
  }

  @override
  bool updateShouldNotify(CountProvider oldWidget) {
    return true;
  }
}

class Counter {
  int count;

  Counter(this.count);

  increment() {
    count++;
  }
}

void main() {
  runApp(MyInheritedApp());
}

class MyInheritedApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: CountProvider(
        counter: Counter(0),
        child: MyHomePage(
          title: 'fgg',
        ),
      ),
    );
  }
}

class MyHomePage extends StatefulWidget {
  MyHomePage({Key? key, required this.title}) : super(key: key);
  final String title;

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  var counterProvider;

  void _incrementCounter() {
    setState(() {
      counterProvider.counter.increment();
    });
  }

  @override
  Widget build(BuildContext context) {
    counterProvider = CountProvider.of(context);
    return Scaffold(
      appBar: AppBar(
        title: Text('Flutter Inherited Widget'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Text(
              'You have pushed the button this many times:',
            ),
            Text(
              '${counterProvider.counter.count}',
              style: Theme.of(context).textTheme.headline1,
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _incrementCounter,
        tooltip: 'Increment',
        child: Icon(Icons.add),
      ),
    );
  }
}
