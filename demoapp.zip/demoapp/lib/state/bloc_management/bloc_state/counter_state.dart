class CounterInitial {
  int counterValue;

  CounterInitial({
    required this.counterValue,
  });
}
