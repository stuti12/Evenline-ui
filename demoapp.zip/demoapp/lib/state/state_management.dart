import 'package:demoapp/state/getx/view/home_view.dart';
import 'package:demoapp/state/bloc/login_screen_bloc.dart';
import 'package:demoapp/state/login_screen_provider.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';

import 'bloc/sign_in_bloc.dart';
import 'cubit/bloc_counter_cubit_demo.dart';
import 'bloc_management/counter_observer.dart';
import 'getx/route/routes.dart';
import 'getx/getx_demo.dart';

Future<void> main() async {
  Bloc.observer = CounterObserver();
  runApp(const MyStateApp());
}

class MyStateApp extends StatelessWidget {
  const MyStateApp({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
        debugShowCheckedModeBanner: false, home: MyStateManagementPage());
  }
}

class MyStateManagementPage extends StatefulWidget {
  const MyStateManagementPage({Key? key}) : super(key: key);

  @override
  State<MyStateManagementPage> createState() => _MyStateManagementPageState();
}

class _MyStateManagementPageState extends State<MyStateManagementPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Flutter State Management Example'),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: <Widget>[
            Padding(
              padding:
                  const EdgeInsets.only(left: 15.0, right: 15.0, top: 10.0),
              child: SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => const CounterApp()));
                    },
                    style: ElevatedButton.styleFrom(primary: Colors.blue),
                    child: const Text('Bloc Demo'),
                  )),
            ),
            Padding(
              padding:
                  const EdgeInsets.only(left: 15.0, right: 15.0, top: 10.0),
              child: SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => const MyGetXDemoApp()));
                    },
                    child: const Text('GetX Demo'),
                  )),
            ),
            Padding(
              padding:
                  const EdgeInsets.only(left: 15.0, right: 15.0, top: 10.0),
              child: SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => GetMaterialApp(
                              title: "Application",
                              initialRoute: AppPages.INITIAL,
                              getPages: AppPages.routes,
                              debugShowCheckedModeBanner: false,
                            ),
                          ));
                    },
                    child: const Text('GetX login Demo'),
                  )),
            ),
            Padding(
              padding:
                  const EdgeInsets.only(left: 15.0, right: 15.0, top: 10.0),
              child: SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => BlocProvider(
                                  create: (context) => SignInBloc(),
                                  child: const LoginScreenBloc())));
                    },
                    style: ElevatedButton.styleFrom(primary: Colors.blue),
                    child: const Text('Login Screen Bloc Demo'),
                  )),
            ),
            Padding(
              padding:
                  const EdgeInsets.only(left: 15.0, right: 15.0, top: 10.0),
              child: SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => ChangeNotifierProvider(
                                    create: (_) => SignupValidation(),
                                    child: const SignupProvider(),
                                  )));
                    },
                    child: const Text('Login Screen Provider Demo'),
                  )),
            ),
            Padding(
              padding:
                  const EdgeInsets.only(left: 15.0, right: 15.0, top: 10.0),
              child: SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => GetXHomeView()));
                    },
                    child: const Text('Login Screen Getx Demo'),
                  )),
            ),
            Padding(
              padding:
                  const EdgeInsets.only(left: 15.0, right: 15.0, top: 10.0),
              child: SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => const CounterApp()));
                    },
                    child: const Text('Bloc Cubit Demo'),
                  )),
            ),
          ],
        ),
      ),
    );
  }
}
