import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../api/pagination/const/api.dart';

class SignupProvider extends StatelessWidget {
  const SignupProvider({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final validationService = Provider.of<SignupValidation>(context);
    return ChangeNotifierProvider(
      create: (context) => SignupValidation(),
      child: Scaffold(
        appBar: AppBar(
          title: Text('Signup'),
        ),
        body: Padding(
          padding: const EdgeInsets.all(8.0),
          child: ListView(
            children: <Widget>[
              TextField(
                decoration: InputDecoration(
                  labelText: "First Name",
                  errorText: validationService.firstName.error,
                ),
                onChanged: (String value) {
                  validationService.changeFirstName(value);
                },
              ),
              TextField(
                decoration: InputDecoration(
                  labelText: "Last Name",
                  errorText: validationService.lastName.error,
                ),
                onChanged: (String value) {
                  validationService.changeLastName(value);
                },
              ),
              TextField(
                decoration: InputDecoration(
                    labelText: "DOB",
                    errorText: validationService.dob.error,
                    hintText: "yyyy-mm-dd"),
                onChanged: (String value) {
                  validationService.changeDOB(value);
                },
              ),
              ElevatedButton(
                child: Text('Submit'),
                onPressed: (!validationService.isValid)
                    ? null
                    : validationService.submitData,
              )
            ],
          ),
        ),
      ),
    );
  }
}

class SignupValidation with ChangeNotifier {
  ValidationItem _firstName = ValidationItem(null, null);
  ValidationItem _lastName = ValidationItem(null, null);
  ValidationItem _dob = ValidationItem(null, null);

  //Getters
  ValidationItem get firstName => _firstName;

  ValidationItem get lastName => _lastName;

  ValidationItem get dob => _dob;

  bool get isValid {
    if (_lastName.value != null &&
        _firstName.value != null &&
        dob.value != null) {
      return true;
    } else {
      return false;
    }
  }

  //Setters
  void changeFirstName(String value) {
    if (value.length >= 3) {
      _firstName = ValidationItem(value, "");
    } else {
      _firstName = ValidationItem("", "Must be at least 3 characters");
    }
    notifyListeners();
  }

  void changeLastName(String value) {
    if (value.length >= 3) {
      _lastName = ValidationItem(value, null);
    } else {
      _lastName = ValidationItem(null, "Must be at least 3 characters");
    }
    notifyListeners();
  }

  void changeDOB(String value) {
    try {
      DateTime.parse(value);
      _dob = ValidationItem(value, "");
    } catch (error) {
      _dob = ValidationItem("", "Invalid Format, Use yyyy-mm-dd format");
    }
    notifyListeners();
  }

  void submitData() {
    Utility.showToast("Data Submitted");
    print(
        "FirstName: ${firstName.value}, LastName: ${lastName.value}, ${DateTime.parse(dob.value as String)}");
  }
}

class ValidationItem {
  final String? value;
  final String? error;

  ValidationItem(this.value, this.error);
}
