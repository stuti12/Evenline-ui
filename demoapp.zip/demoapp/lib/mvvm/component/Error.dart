import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../user_list/model/user_list.dart';


class AppError extends StatelessWidget {
  final String errortxt;
  AppError({required this.errortxt});

  @override
  Widget build(BuildContext context) {
    return Visibility(
      visible: null != errortxt && errortxt.isNotEmpty,
      child: Container(
        alignment: Alignment.center,
        child: Text(
          errortxt,
          style: TextStyle(
            color: Colors.red,
            fontSize: 18.0,
          ),
        ),
      ),
    );
  }
}

class AppLoading extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Container(
        padding: const EdgeInsets.all(20.0),
        child: CupertinoActivityIndicator(),
      ),
    );
  }
}

class AppTitle extends StatelessWidget {
  final String text;
  AppTitle({this.text = ''});

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Text(
        text,
        style: TextStyle(fontSize: 20.0, fontWeight: FontWeight.bold),
      ),
    );
  }
}

class UserListRow extends StatelessWidget {
  final UserModel userModel;
  final VoidCallback? onTap;
  UserListRow({required this.userModel,  this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Container(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            AppTitle(text: userModel.name??"not found"),
            Text(
              userModel.email??"notfound",
              style: TextStyle(color: Colors.black),
            ),
          ],
        ),
      ),
    );
  }
}