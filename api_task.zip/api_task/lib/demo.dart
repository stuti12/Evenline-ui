import 'package:flutter/material.dart';

class AvatarListScreen extends StatefulWidget {
  @override
  _AvatarListScreenState createState() => _AvatarListScreenState();
}

class _AvatarListScreenState extends State<AvatarListScreen> {
  int numberOfVisibleAvatars = 3;
  List<String> avatarUrls = [
   'https://picsum.photos/250?image=15',
   'https://picsum.photos/250?image=15',
   'https://picsum.photos/250?image=15',
   'https://picsum.photos/250?image=15',
   'https://picsum.photos/250?image=15',
   'https://picsum.photos/250?image=15',
   'https://picsum.photos/250?image=15',
   'https://picsum.photos/250?image=15',
   'https://picsum.photos/250?image=15',
   'https://picsum.photos/250?image=15',
   'https://picsum.photos/250?image=15',
   'https://picsum.photos/250?image=15',
   'https://picsum.photos/250?image=15',
   'https://picsum.photos/250?image=15',
   'https://picsum.photos/250?image=15',
   'https://picsum.photos/250?image=15',
   'https://picsum.photos/250?image=15',
   'https://picsum.photos/250?image=15',
   'https://picsum.photos/250?image=15',
   'https://picsum.photos/250?image=15',
   'https://picsum.photos/250?image=15',
   'https://picsum.photos/250?image=15',
   'https://picsum.photos/250?image=15',
   'https://picsum.photos/250?image=15',
   'https://picsum.photos/250?image=15',
  ];

  void _loadMore() {
    setState(() {
      numberOfVisibleAvatars = (numberOfVisibleAvatars + 3).clamp(0, avatarUrls.length);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Avatar List'),
      ),
      body: ListView(
        padding: EdgeInsets.all(16),
        children: [
          Column(crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Wrap(
                spacing: -10,
                children: List.generate(
                  numberOfVisibleAvatars,
                      (index) => CircleAvatarWidget(imageUrl: avatarUrls[index]),

                ),
              ),
              Row(children: [
                if (numberOfVisibleAvatars + 1 < avatarUrls.length) Text(
                  '+: ${avatarUrls.length - numberOfVisibleAvatars}',
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontSize: 18),
                ),
                if (numberOfVisibleAvatars + 1 < avatarUrls.length)
                  ElevatedButton(
                    onPressed: _loadMore,
                    child: Text('Load More'),
                  ),
              ],)
            ],
          ),

        ],
      ),
    );
  }
}


class CircleAvatarWidget extends StatelessWidget {
  final String imageUrl;

  const CircleAvatarWidget({required this.imageUrl});

  @override
  Widget build(BuildContext context) {
    return CircleAvatar(backgroundColor: Colors.black,radius: 31,
      child: CircleAvatar(
        radius: 30,
        backgroundImage: NetworkImage(imageUrl),
      ),
    );
  }
}
