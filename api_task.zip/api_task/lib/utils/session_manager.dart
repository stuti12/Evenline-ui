import 'package:shared_preferences/shared_preferences.dart';

class SessionManager {
  final String authToken = "authToken";
  final String userId = "userId";

//set data into shared preferences like this
  Future<void> setAuthToken({required String? authToken}) async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.setString(this.authToken, authToken ?? "");
  }

//get value from shared preferences
  Future<String?> getAuthToken() async {
    final SharedPreferences pref = await SharedPreferences.getInstance();
    return pref.getString(authToken);
  }

  Future<void> setUserId({required String? userId}) async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.setString(this.userId, userId ?? "");
  }

//get value from shared preferences
  Future<String?> getUserId() async {
    final SharedPreferences pref = await SharedPreferences.getInstance();
    return pref.getString(userId);
  }

  removeKey() async {
    final SharedPreferences pref = await SharedPreferences.getInstance();
    pref.remove(authToken);
    pref.remove(userId);
  }
}
