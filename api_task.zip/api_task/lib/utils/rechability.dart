import 'dart:async';

import 'package:connectivity_plus/connectivity_plus.dart';

import '../utils/logger.dart';

class Reachability extends Object {
  final Connectivity _connectivity = Connectivity();
  StreamSubscription<ConnectivityResult>? connectivitySubscription;

  // current network status
  ConnectivityResult _connectStatus = ConnectivityResult.none;
  ConnectivityResult get connectStatus => _connectStatus;

  factory Reachability() {
    return _singleton;
  }

  static final Reachability _singleton = Reachability._internal();
  Reachability._internal() {
    connectivitySubscription =
        _connectivity.onConnectivityChanged.listen((ConnectivityResult result) {
      _connectStatus = result;
      Logger().v("ConnectionStatus :: = $_connectStatus");
      setUpConnectivity();
    });
  }

  dispose() {
    connectivitySubscription?.cancel();
  }

  // set up initial
  Future<void> setUpConnectivity() async {
    ConnectivityResult connectionStatus;

    try {
      connectionStatus = (await _connectivity.checkConnectivity());
      Logger().v("ConnectionStatus :: => $connectionStatus");
    } on Exception catch (e) {
      Logger().e(e.toString());
      connectionStatus = ConnectivityResult.none;
    }
    _connectStatus = connectionStatus;
    Logger().v("ConnectionStatus :: => $_connectStatus");
  }

  // check for network available
  Future<bool> isInterNetAvailable() async {
   await setUpConnectivity();
    Logger().v("ConnectionStatus :: => $_connectStatus");
    return (_connectStatus == ConnectivityResult.mobile) ||
        (_connectStatus == ConnectivityResult.wifi) ||  (_connectStatus == ConnectivityResult.ethernet);
  }
}
