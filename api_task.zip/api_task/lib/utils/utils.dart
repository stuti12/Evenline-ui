import 'package:api_task/utils/progress_dialog.dart';
import 'package:api_task/utils/rechability.dart';
import 'package:api_task/utils/ui_text_style.dart';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:formz/formz.dart';

import 'app_colors.dart';
import 'custom_widgets/progress_hud.dart';
import 'logger.dart';

extension ErrorMessageX on Object {
  String get message {
    if (this is DioException) {
      return (this as DioException).message ?? "Oops!! something wen wrong";
    }
    return "Oops!! something wen wrong";
  }
}


class Utils {
  factory Utils() {
    return _singleton;
  }

  static final Utils _singleton = Utils._internal();

  String get currencyPrefix => 'INR ';

  Utils._internal() {
    Logger().v("Instance created Utils");
  }

  /// Used for update page list
  static bool isLoaderShowing = false;

  static void showSnackBar(BuildContext context, String message, {int duration = 2, SnackBarAction? action}) {
    if ((message).isEmpty) {
      return;
    }

    final snackBar = SnackBar(
      content: Text(
        message,
        style: UITextStyle.getTextStyle(
          fontWeight: FontWeight.w500,
          fontSize: 14,
          color: AppColor.whiteColor,
        ),
      ),
      backgroundColor: AppColor.textColor,
      duration: Duration(seconds: duration),
      action: action,
    );

    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(snackBar);
  }

  static Future<bool> isInternetAvailable(BuildContext context, {bool isInternetMessageRequire = false}) async {
    bool isInternet =await Reachability().isInterNetAvailable();
    if (!isInternet && isInternetMessageRequire) {
     // showSnackBar(context, 'isInternetMessageRequire');
    }
    return isInternet;
  }

  static void showProgressDialog(BuildContext? context) {
    if (context != null) {
      showDialog(barrierDismissible: false, context: context, builder: (_) => const ProgressDialog());
    }
  }

  static void dismissProgressDialog(BuildContext context) {
    /// This Delay Added due to loader open or not
    if (Navigator.of(context).canPop()) {
      Navigator.of(context).pop();
    }
  }

  static void handleStatus({
    required BuildContext context,
    required FormzSubmissionStatus formStatus,
    required bool validationStatus,
    String? message,
    bool popCurrentPage = true,
    Object? popItem,
  }) {
    bool showMessage = false;

    if (validationStatus) {
      if (formStatus.isInProgress) {
        ProgressHUD.of(context)?.show();
      } else if (formStatus.isSuccess || formStatus.isFailure) {
        ProgressHUD.of(context)?.dismiss();
        showMessage = true;

        if (popCurrentPage && formStatus.isSuccess) {
          Navigator.of(context).pop(popItem);
        }
      }
    } else {
      showMessage = formStatus.isFailure;
    }

    if (showMessage && message?.isNotEmpty != false) {
      Utils.showSnackBar(context, message ?? '');
    }
  }

}