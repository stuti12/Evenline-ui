import 'dart:io';

import 'package:api_task/utils/logger.dart';
import 'package:api_task/utils/ui_text_style.dart';
import 'package:flutter/material.dart';
import 'package:chewie/chewie.dart';
import 'package:video_player/video_player.dart';

import '../app_colors.dart';

class CustomVideoPlayer extends StatefulWidget {
  final String videoPath;
  final bool isInternet;

  const CustomVideoPlayer({Key? key, required this.videoPath, required this.isInternet}) : super(key: key);

  @override
  _CustomVideoPlayerState createState() => _CustomVideoPlayerState();
}

class _CustomVideoPlayerState extends State<CustomVideoPlayer> {
  late VideoPlayerController _videoController;
  late ChewieController _chewieController;

  @override
  void initState() {
    super.initState();
    _videoController = widget.isInternet
        ? VideoPlayerController.networkUrl((Uri.parse(widget.videoPath)),
            videoPlayerOptions: VideoPlayerOptions(mixWithOthers: true, allowBackgroundPlayback: false))
        : VideoPlayerController.file((File(widget.videoPath)),
            videoPlayerOptions: VideoPlayerOptions(mixWithOthers: true, allowBackgroundPlayback: false));
    _chewieController = ChewieController(
      videoPlayerController: _videoController,
      autoInitialize: true,
      looping: false,
      autoPlay: true,
      allowMuting: true,
      showOptions: false,
      allowPlaybackSpeedChanging: false,
      errorBuilder: (context, errorMessage) {
        Logger().w('Video Error$errorMessage');
        return Center(
          child: Text(
            errorMessage,
            style: UITextStyle.regularTextStyle(color: AppColor.whiteColor),
          ),
        );
      },
    );
  }

  @override
  void dispose() {
    _videoController.dispose();
    _chewieController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          title: Text(
            'Video Player',
            style: UITextStyle.regularTextStyle(fontSize: 14),
          ),
        ),
        body: Center(
          child: Chewie(
            controller: _chewieController,
          ),
        ),
      ),
    );
  }
}
