import 'package:flutter/material.dart';

typedef ListBuilderCallBack = Widget Function(BuildContext context, int index);

class PullToRefreshListView extends StatefulWidget {
  final int itemCount;
  final bool? shrinkWrap;
  final VoidCallback onRefresh;
  final ListBuilderCallBack builder;
  final EdgeInsets padding;
  final ScrollPhysics? physics;
  final ScrollController? controller;
  final Axis? scrollDirection;
  final Widget? separator;

  const PullToRefreshListView(
      {super.key,
      required this.itemCount,
      this.shrinkWrap = false,
      required this.builder,
      required this.onRefresh,
      this.padding = const EdgeInsets.only(bottom: 5.0),
      this.controller,
      this.physics,
      this.scrollDirection,
      this.separator});

  @override
  _PullToRefreshListViewState createState() => _PullToRefreshListViewState();
}

class _PullToRefreshListViewState extends State<PullToRefreshListView> {
  @override
  Widget build(BuildContext context) {
      return Container(
        alignment: Alignment.topCenter,
        child: RefreshIndicator(
          child:
               ListView.builder(
                  shrinkWrap: widget.shrinkWrap!,
                  physics: widget.physics,
                  padding: widget.padding,
                  scrollDirection: widget.scrollDirection ?? Axis.vertical,
                  itemCount: widget.itemCount,
                  itemBuilder: widget.builder,
                  controller: widget.controller,
                ),
          onRefresh: () async {
            widget.onRefresh();
          },
        ),
      );
    }
  //}
}
