class ConstantString {
   static const appName = "Api task";
   static const videoTitle = "Video Title";
   static const videoSubTitle = "Video Subtitle";
   static const videoDescription = "Video Description";
   static const categoryName = "Category Name";
   static const loadMore = " Load More";
   static const loadLess = " Load Less";

}