import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import 'app_colors.dart';
class UITextStyle extends Object {
  static TextStyle getTextStyle(
      {Alignment? txtAlignment,
      String? fontFamily,
      double? fontSize,
      Color? color,
      FontWeight? fontWeight,
      bool isFixed = false,
      double? characterSpacing,
      double? wordSpacing,
      double? lineSpacing,
      TextDecoration? decoration}) {
    double finalFontSize = (fontSize ?? 12).toDouble();
    if (isFixed) {
      finalFontSize = finalFontSize.sp;
    }

    return TextStyle(
        fontSize: finalFontSize,
       // fontFamily: fontFamily ?? AppFont.fontRegular,
        color: color ?? AppColor.textColor,
        letterSpacing: characterSpacing,
        wordSpacing: wordSpacing,
        height: lineSpacing,
        fontWeight: fontWeight,
        decoration: decoration);
  }

  static boldTextStyle(
      {double? fontSize,
      Color? color,
      double? characterSpacing,
      double? wordSpacing,
      double? lineSpacing,
      TextDecoration? decoration}) {
    return getTextStyle(
    //  fontFamily: AppFont.fontBold,
      fontSize: fontSize ?? 14.sp,
      fontWeight: FontWeight.w600,
      color: color ?? AppColor.textColor,
      characterSpacing: characterSpacing,
      wordSpacing: wordSpacing,
      lineSpacing: lineSpacing,
      decoration: decoration,
    );
  }

  static semiBoldTextStyle(
      {double? fontSize,
      Color? color,
      double? characterSpacing,
      double? wordSpacing,
      double? lineSpacing,
      TextDecoration? decoration}) {
    return getTextStyle(
    //  fontFamily: AppFont.fontSemiBold,
      fontSize: fontSize ?? 14,
      color: color ?? AppColor.textColor,
      characterSpacing: characterSpacing,
      wordSpacing: wordSpacing,
      lineSpacing: lineSpacing,
      decoration: decoration,
    );
  }

  static mediumTextStyle(
      {double? fontSize,
      Color? color,
      double? characterSpacing,
      double? wordSpacing,
      double? lineSpacing,
      TextDecoration? decoration}) {
    return getTextStyle(
   //   fontFamily: AppFont.fontRegular,
      fontWeight: FontWeight.w500,
      fontSize: fontSize ?? 12,
      color: color ?? AppColor.textColor,
      characterSpacing: characterSpacing,
      wordSpacing: wordSpacing,
      lineSpacing: lineSpacing,
      decoration: decoration,
    );
  }

  static regularTextStyle(
      {double? fontSize,
      FontWeight? fontWeight,
      Color? color,
      double? characterSpacing,
      double? wordSpacing,
      double? lineSpacing,
      TextDecoration? decoration,
      TextAlign? txtAlignment}) {
    return getTextStyle(
    //  fontFamily: AppFont.fontRegular,
      fontSize: fontSize ?? 12,
      fontWeight: fontWeight,
      color: color ?? AppColor.textColor,
      characterSpacing: characterSpacing,
      wordSpacing: wordSpacing,
      lineSpacing: lineSpacing,
      decoration: decoration,
    );
  }

  static lightTextStyle(
      {double? fontSize,
      Color? color,
      double? characterSpacing,
      double? wordSpacing,
      double? lineSpacing,
      TextDecoration? decoration}) {
    return getTextStyle(
    //  fontFamily: AppFont.fontRegular,
      fontWeight: FontWeight.w600,
      fontSize: fontSize ?? 12,
      color: color ?? AppColor.textColor,
      characterSpacing: characterSpacing,
      wordSpacing: wordSpacing,
      lineSpacing: lineSpacing,
      decoration: decoration,
    );
  }
}

class UIHelper extends Object {
  static InputBorder? createBorder({Color? color, double? width}) {
    return UnderlineInputBorder(
      borderSide: BorderSide(
        color: color ?? AppColor.dividerColor,
        width: width ?? 1.0,
      ),
    );
  }

  static TextStyle get inputTextStyle => UITextStyle.regularTextStyle(fontSize: 22);

  static TextStyle get inputLabelStyle => UITextStyle.regularTextStyle(fontSize: 19);
}
