class AppImage {
  static const String _prefixPath = 'assets/images';
  static String icPlaceholder = '$_prefixPath/ic_placeholder.png';

}
