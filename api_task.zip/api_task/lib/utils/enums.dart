enum DownloadStatus {
  notStarted,
  downloading,
  downloaded,
  fail
}
enum DataSource {
  api, // Data fetched from the API
  file, /// Data read from the text file
}