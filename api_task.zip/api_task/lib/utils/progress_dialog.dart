import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';

import 'app_colors.dart';

class ProgressDialog extends StatelessWidget {
  const ProgressDialog({super.key});

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
        onWillPop: _onBackSpace,
        child: SpinKitRing(
          color: AppColor.hintTextColor,
          size: 40.w,
          lineWidth: 4.0,
        ));
  }

  Future<bool> _onBackSpace() async {
    return true;
  }
}
