class AppConstants {
  static const String developmentUrl = "https://mocki.io/v1/";
  static const String baseImageUrl = "http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/";
}

