import 'dart:io';

import 'package:api_task/models/users.dart';
import 'package:dio/dio.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:retrofit/http.dart';
import '../../generated/locale_keys.g.dart';
import '../../models/movies_response.dart';
import '../../utils/app_const.dart';
import 'dio_intercepter.dart';

part 'rest_client.g.dart';

@RestApi(baseUrl: AppConstants.developmentUrl)
abstract class RestClient {
  factory RestClient(Dio dio, {String baseUrl}) = _RestClient;

  @GET("7de8f2f1-3d8e-4221-9d62-fdc34606e9ea")
  Future<MoviesResponse> getMovies();

  @GET("https://reqres.in/api/users")
  Future<Users> getUsers( @Query("page") int page, @Query("per_page") int perPage);

}


extension RestClientX on RestClient {
  static RestClient instance() {
    final dio = Dio(BaseOptions(
        validateStatus: (status) {
          if (status != null &&
              ((status >= 200 && status < 300) || (status >= 400 && status < 500))) {
            return true;
          }
          return false;
        },
        receiveTimeout: const Duration(minutes: 1),
        connectTimeout: const Duration(minutes: 1)))
      ..interceptors.add(InterceptorsWrapper(onRequest: (request, handler) async {
        request.headers['content-type'] = 'application/json';
       /* SessionManager prefs = SessionManager();
        final token = await prefs.getAuthToken();
        if (token != null && token != '') {
          request.headers['Authorization'] = 'Bearer $token';
        }*/

        return handler.next(request);
      }, onError: (error, handler) async {
        if (error.type == DioExceptionType.unknown &&
            error.error != null &&
            error.error is SocketException) {
          handler.next(error.copyWith(message: LocaleKeys.msgInternetMessage.tr()));
        } else {
          handler.next(error.copyWith(message: LocaleKeys.msgSomethingWrong.tr()));
        }
      }))
      ..interceptors.add(DioInterceptor(printOnSuccess: true,));
    final restClient = RestClient(dio);
    return restClient;
  }
}
