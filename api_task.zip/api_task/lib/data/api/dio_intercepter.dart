import 'dart:convert';
import 'dart:developer';

import 'package:dio/dio.dart';

import '../../utils/logger.dart';

class DioInterceptor extends Interceptor {
  final bool? printOnSuccess;
  final bool convertFormData;

  DioInterceptor({this.printOnSuccess, this.convertFormData = true});

  @override
  void onRequest(RequestOptions options, RequestInterceptorHandler handler) {
    Logger().d("┌------------------------------------------------------------------------------");
    Logger().d('| [DIO] Request: ${options.method} ${options.uri}');
    Logger().d('| ${options.data.toString()}');
    Logger().d('| Headers:');
    options.headers.forEach((key, value) {
      Logger().d('|\t$key: $value');
    });
    Logger().d("├------------------------------------------------------------------------------");
    super.onRequest(options, handler);
  }
  @override
  void onError(DioError error, ErrorInterceptorHandler handler) {
    _renderCurlRepresentation(error.requestOptions);

    Logger().d("| [DIO] Error Type: ${error.type}");
    Logger().d("| [DIO] Error: ${error.error}: ${error.response.toString()}");
    Logger().d("└------------------------------------------------------------------------------");
    return handler.next(error); //continue
  }

  @override
  void onResponse(Response response, ResponseInterceptorHandler handler) {
    if (printOnSuccess != null && printOnSuccess == true) {
      _renderCurlRepresentation(response.requestOptions);
    }

    Logger().d("| [DIO] Response [code ${response.statusCode}]: ${response.data.toString()}");
    Logger().d("└------------------------------------------------------------------------------");
    return handler.next(response); //continue
  }

  void _renderCurlRepresentation(RequestOptions requestOptions) {
    // add a breakpoint here so all errors can break
    try {
      log(_cURLRepresentation(requestOptions));
    } catch (err) {
      log('unable to create a CURL representation of the requestOptions');
    }
  }

  String _cURLRepresentation(RequestOptions options) {
    List<String> components = ['curl -i'];
    if (options.method.toUpperCase() != 'GET') {
      components.add('-X ${options.method}');
    }

    options.headers.forEach((k, v) {
      if (k != 'Cookie') {
        components.add('-H "$k: $v"');
      }
    });

    if (options.data != null) {
      // FormData can't be JSON-serialized, so keep only their fields attributes
      if (options.data is FormData && convertFormData == true) {
        options.data = Map.fromEntries(options.data.fields);
      }

      final data = json.encode(options.data).replaceAll('"', '\\"');
      components.add('-d "$data"');
    }

    components.add('"${options.uri.toString()}"');

    return components.join(' \\\n\t');
  }
}