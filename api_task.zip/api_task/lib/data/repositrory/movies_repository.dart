import 'dart:core';

import 'package:api_task/models/movies_response.dart';

import '../api/rest_client.dart';

class MoviesRepository {
  late RestClient _restClient;
  MoviesRepository() {
    _restClient = RestClientX.instance();
  }
  Future<MoviesResponse> getMovies() => _restClient.getMovies();
}
