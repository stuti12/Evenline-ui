import 'dart:core';

import 'package:api_task/models/movies_response.dart';
import 'package:api_task/models/users.dart';

import '../api/rest_client.dart';

class MoviesRepository {
  late RestClient _restClient;
  MoviesRepository() {
    _restClient = RestClientX.instance();
  }
  Future<MoviesResponse> getMovies() => _restClient.getMovies();
  Future<Users> getUsers(int page,int perPage) => _restClient.getUsers(page,perPage);
}
