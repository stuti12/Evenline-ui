import 'package:freezed_annotation/freezed_annotation.dart';
import 'dart:convert';

import '../utils/enums.dart';

part 'movies_response.freezed.dart';
part 'movies_response.g.dart';

MoviesResponse moviesResponseFromMap(String str) => MoviesResponse.fromJson(json.decode(str));

String moviesResponseToMap(MoviesResponse data) => json.encode(data.toJson());

@freezed
class MoviesResponse with _$MoviesResponse {
  const factory MoviesResponse({
    List<Category>? categories,
  }) = _MoviesResponse;

  factory MoviesResponse.fromJson(Map<String, dynamic> json) => _$MoviesResponseFromJson(json);
}

@freezed
class Category with _$Category {
  const factory Category({
    String? name,
    List<Video>? videos,
  }) = _Category;

  factory Category.fromJson(Map<String, dynamic> json) => _$CategoryFromJson(json);
}

@freezed
class Video with _$Video {
  const factory Video({
    String? description,
    List<String>? sources,
    String? subtitle,
    String? thumb,
    String? title,
    DownloadStatus? downloadStatus,
    String? downloadedFilePath,
    bool? isDownloadComplete
  }) = _Video;

  factory Video.fromJson(Map<String, dynamic> json) => _$VideoFromJson(json);
}


