// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'movies_response.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$_MoviesResponse _$$_MoviesResponseFromJson(Map<String, dynamic> json) =>
    _$_MoviesResponse(
      categories: (json['categories'] as List<dynamic>?)
          ?.map((e) => Category.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$$_MoviesResponseToJson(_$_MoviesResponse instance) =>
    <String, dynamic>{
      'categories': instance.categories,
    };

_$_Category _$$_CategoryFromJson(Map<String, dynamic> json) => _$_Category(
      name: json['name'] as String?,
      videos: (json['videos'] as List<dynamic>?)
          ?.map((e) => Video.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$$_CategoryToJson(_$_Category instance) =>
    <String, dynamic>{
      'name': instance.name,
      'videos': instance.videos,
    };

_$_Video _$$_VideoFromJson(Map<String, dynamic> json) => _$_Video(
      description: json['description'] as String?,
      sources:
          (json['sources'] as List<dynamic>?)?.map((e) => e as String).toList(),
      subtitle: json['subtitle'] as String?,
      thumb: json['thumb'] as String?,
      title: json['title'] as String?,
      downloadStatus:
          $enumDecodeNullable(_$DownloadStatusEnumMap, json['downloadStatus']),
      downloadedFilePath: json['downloadedFilePath'] as String?,
    );

Map<String, dynamic> _$$_VideoToJson(_$_Video instance) => <String, dynamic>{
      'description': instance.description,
      'sources': instance.sources,
      'subtitle': instance.subtitle,
      'thumb': instance.thumb,
      'title': instance.title,
      'downloadStatus': _$DownloadStatusEnumMap[instance.downloadStatus],
      'downloadedFilePath': instance.downloadedFilePath,
    };

const _$DownloadStatusEnumMap = {
  DownloadStatus.notStarted: 'notStarted',
  DownloadStatus.downloading: 'downloading',
  DownloadStatus.downloaded: 'downloaded',
  DownloadStatus.fail: 'fail',
};
