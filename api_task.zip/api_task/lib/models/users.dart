import 'package:freezed_annotation/freezed_annotation.dart';
import 'dart:convert';

part 'users.freezed.dart';
part 'users.g.dart';

Users usersFromMap(String str) => Users.fromJson(json.decode(str));

String usersToMap(Users data) => json.encode(data.toJson());

@freezed
class Users with _$Users {
  const factory Users({
    int? page,
    int? perPage,
    int? total,
    int? totalPages,
    List<Datum>? data,
    Support? support,
  }) = _Users;

  factory Users.fromJson(Map<String, dynamic> json) => _$UsersFromJson(json);
}

@freezed
class Datum with _$Datum {
  const factory Datum({
    int? id,
    String? email,
    // ignore: non_constant_identifier_names
    String? first_name,
    // ignore: non_constant_identifier_names
    String? last_name,
    String? avatar,
  }) = _Datum;

  factory Datum.fromJson(Map<String, dynamic> json) => _$DatumFromJson(json);
}

@freezed
class Support with _$Support {
  const factory Support({
    String? url,
    String? text,
  }) = _Support;

  factory Support.fromJson(Map<String, dynamic> json) => _$SupportFromJson(json);
}
