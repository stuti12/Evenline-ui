import 'package:api_task/presentation/movie_get/view/movies_page.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../cubit/loginpage_cubit.dart';

class LoginPage extends StatelessWidget {
  LoginPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.deepPurple,
        title: const Text(
          'Example',
          style: TextStyle(color: Colors.white),
        ),
      ),
      body: BlocProvider(
        create: (context) => LoginPageCubit(),
        child: BlocBuilder<LoginPageCubit, LoginPageState>(
          builder: (context, state) {
            return Padding(
              padding: const EdgeInsets.all(10.0),
              child: Column(
                children: [
                  const SizedBox(
                    height: 20,
                  ),
                  TextField(
                    onChanged: (value) => context.read<LoginPageCubit>().nameChanged(value),
                    keyboardType: TextInputType.text,
                    textInputAction: TextInputAction.next,
                    decoration: const InputDecoration(
                      labelText: 'Name',
                      hintText: 'Name',
                      border: OutlineInputBorder(),
                      labelStyle: TextStyle(fontSize: 14, color: Colors.black),
                    ),
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                  TextField(
                    onChanged: (value) => context.read<LoginPageCubit>().emailChanged(value),
                    keyboardType: TextInputType.emailAddress,
                    textInputAction: TextInputAction.next,
                    decoration: const InputDecoration(
                      border: OutlineInputBorder(),
                      labelText: 'Email',
                      hintText: 'Email',
                      labelStyle: TextStyle(fontSize: 14, color: Colors.black),
                    ),
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                  TextField(
                    onChanged: (value) => context.read<LoginPageCubit>().passwordChange(value),
                    keyboardType: TextInputType.visiblePassword,
                    textInputAction: TextInputAction.done,
                    obscureText: state.passwordVisible,
                    decoration: InputDecoration(
                      border: const OutlineInputBorder(),
                      labelText: 'Password',
                      hintText: 'Password',
                      suffixIcon: IconButton(
                        icon: state.passwordVisible
                            ? const Icon(Icons.visibility_off)
                            : const Icon(Icons.visibility),
                        onPressed: () {
                          context.read<LoginPageCubit>().togglePasswordVisibility();
                        },
                      ),
                      labelStyle: const TextStyle(
                        fontSize: 14,
                        color: Colors.black,
                      ),
                    ),
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () {
                        final loginPageCubit = context.read<LoginPageCubit>();
                        if (state.userName.isEmpty) {
                          showSnackBar(context, 'Please enter name');
                        } else if (state.userEmail.isEmpty) {
                          showSnackBar(context, 'Please enter email');
                        } else if (!loginPageCubit.checkErrorEmail(state.userEmail)) {
                          showSnackBar(context, 'Please enter a valid email');
                        } else if (state.userPassword.isEmpty) {
                          showSnackBar(context, 'Please enter password');
                        } else if (!loginPageCubit.checkErrorPassword(state.userPassword)) {
                          showSnackBar(context,
                              'Password should be 8 characters, must contain 1 uppercase letter, 1 lowercase letter, 1 number and 1 special character');
                        } else {
                          Navigator.push(
                            context,
                            MaterialPageRoute(builder: (context) => MoviesPage.instance(),),
                          );
                        }
                      },
                      child: const Text(
                        'Login',
                        style: TextStyle(
                          fontSize: 14,
                          color: Colors.deepPurple,
                        ),
                      ),
                    ),
                  )
                ],
              ),
            );
          },
        ),
      ),
    );
  }

  void showSnackBar(BuildContext context, String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        duration: const Duration(seconds: 2),
        content: Text(message),
      ),
    );
  }
}
