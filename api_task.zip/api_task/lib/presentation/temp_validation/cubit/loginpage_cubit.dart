import 'package:bloc/bloc.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

part 'loginpage_state.dart';

part 'loginpage_cubit.freezed.dart';

class LoginPageCubit extends Cubit<LoginPageState> {
  LoginPageCubit() : super(const LoginPageState());

  void nameChanged(String value) {
    emit(
      state.copyWith(
        userName: value,
      ),
    );
  }

  void emailChanged(String value) {
    emit(state.copyWith(
      userEmail: value,
    ));
  }

  void passwordChange(String value) {
    emit(state.copyWith(
      userPassword: value,
    ));
  }

  bool checkErrorEmail(String email) {
    final bool emailValid =
        RegExp(r"^[a-zA-Z0-9.a-zA-Z0-9.!#$%&'*+-/=?^_`{|}~]+@[a-zA-Z0-9]+\.[a-zA-Z]+")
            .hasMatch(email);
    return emailValid;
  }

  bool checkErrorPassword(String password) {
    final bool passwordValid =
        RegExp(r"^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,}$")
            .hasMatch(password);
    return passwordValid;
  }

  void togglePasswordVisibility() {
    emit(state.copyWith(passwordVisible: !state.passwordVisible));
  }
}
