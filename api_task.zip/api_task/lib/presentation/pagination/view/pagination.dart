import 'package:api_task/data/repositrory/movies_repository.dart';
import 'package:api_task/models/users.dart';
import 'package:api_task/presentation/pagination/cubit/pagination_page_cubit.dart';
import 'package:api_task/utils/app_colors.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:infinite_scroll_pagination/infinite_scroll_pagination.dart';

class PaginationDemo extends StatelessWidget {
  const PaginationDemo({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Pagination'),
        backgroundColor: Colors.transparent,
      ),
      body: _userList(),
    );
  }

  Widget _userList() {
    return RepositoryProvider(
      create: (context) => MoviesRepository(),
      child: BlocProvider(
        create: (context) => PaginationPageCubit(moviesRepository: context.read()),
        child: BlocBuilder<PaginationPageCubit, PaginationPageState>(
          builder: (context, state) {
            return PagedListView.separated(
              padding: EdgeInsets.only(top: 12.h, bottom: 16.h),
              pagingController: context.read<PaginationPageCubit>().pagingController,
              builderDelegate: PagedChildBuilderDelegate<Datum>(
                itemBuilder: (context, user, index) => _user(
                  user, context
                ),
                firstPageProgressIndicatorBuilder: (context) => Container(),
                noItemsFoundIndicatorBuilder: (context) => const Center(child: Text('No Data Found'),),
              ),
              separatorBuilder: (context, index) => Divider(height: 1.h,color: AppColor.dividerColor,),
            );
          },
        ),
      ),
    );
  }

  Widget _user(Datum user, BuildContext context) {
    return ListTile(
      leading: CircleAvatar(
        backgroundImage: NetworkImage(user.avatar ?? ""),
        radius: 26,
      ),
      contentPadding: const EdgeInsets.all(8),
      title: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "${user.first_name??''} ${user.last_name??''}",
            style: const TextStyle(fontSize: 18.0, color: Colors.black, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 10.0),
          Text(user.email ?? "")
        ],
      ),
    );
  }
}
