import 'package:api_task/data/repositrory/movies_repository.dart';
import 'package:api_task/models/users.dart';
import 'package:api_task/utils/utils.dart';
import 'package:bloc/bloc.dart';
import 'package:formz/formz.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:infinite_scroll_pagination/infinite_scroll_pagination.dart';

part 'pagination_page_state.dart';
part 'pagination_page_cubit.freezed.dart';

class PaginationPageCubit extends Cubit<PaginationPageState> {
  PaginationPageCubit({required MoviesRepository moviesRepository})
      : _moviesRepository = moviesRepository,
        super(const PaginationPageState()) {
    pagingController.addPageRequestListener((pageKey) {
      loadUsers(page: pageKey);
    });
  }
  final MoviesRepository _moviesRepository;
  final PagingController<int, Datum> pagingController = PagingController(firstPageKey: 1);

  Future<void> loadUsers({int page = 1, int perPage = 6}) async {
    if (page == 1) {
      emit(state.copyWith(status: FormzSubmissionStatus.inProgress));
    }
    try {
      final response = await _moviesRepository.getUsers(page, perPage);
      if (response.data != null) {
        final faqs = response.data!;
        final totalPages = response.totalPages ?? 0;
        final nextPageKey = page + 1;
        final hasMoreItems = nextPageKey <= totalPages;

        if (page == 1) {
          pagingController.itemList = [];
        }

        if (hasMoreItems) {
          pagingController.appendPage(faqs, nextPageKey);
        } else {
          pagingController.appendLastPage(faqs);
        }

        emit(state.copyWith(
          status: FormzSubmissionStatus.success,
          faqs: pagingController.itemList,
          currentPage: page,
          totalPage: totalPages,
          errorMessage: response.message,
        ));
      } else {
        emit(state.copyWith(
          status: FormzSubmissionStatus.failure,
          errorMessage: response.message,
        ));
      }
    } catch (e) {
      emit(state.copyWith(
        status: FormzSubmissionStatus.failure,
        errorMessage: e.toString(),
      ));
    }
  }
}
