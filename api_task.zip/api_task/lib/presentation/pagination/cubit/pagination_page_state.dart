part of 'pagination_page_cubit.dart';

@freezed
class PaginationPageState with _$PaginationPageState {
   const factory PaginationPageState({

    @Default([]) List<Datum>? faqs,
    @Default(0) int currentPage,
    @Default(0) int totalPage,
    @Default(0) int perPage,
    @Default(-1) int expandedIndex,
    @Default(FormzSubmissionStatus.initial) FormzSubmissionStatus status,
    @Default("") String errorMessage,
  }) = _PaginationPageState;
}
