// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'pagination_page_cubit.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

/// @nodoc
mixin _$PaginationPageState {
  List<Datum>? get faqs => throw _privateConstructorUsedError;
  int get currentPage => throw _privateConstructorUsedError;
  int get totalPage => throw _privateConstructorUsedError;
  int get perPage => throw _privateConstructorUsedError;
  int get expandedIndex => throw _privateConstructorUsedError;
  FormzSubmissionStatus get status => throw _privateConstructorUsedError;
  String get errorMessage => throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $PaginationPageStateCopyWith<PaginationPageState> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $PaginationPageStateCopyWith<$Res> {
  factory $PaginationPageStateCopyWith(
          PaginationPageState value, $Res Function(PaginationPageState) then) =
      _$PaginationPageStateCopyWithImpl<$Res, PaginationPageState>;
  @useResult
  $Res call(
      {List<Datum>? faqs,
      int currentPage,
      int totalPage,
      int perPage,
      int expandedIndex,
      FormzSubmissionStatus status,
      String errorMessage});
}

/// @nodoc
class _$PaginationPageStateCopyWithImpl<$Res, $Val extends PaginationPageState>
    implements $PaginationPageStateCopyWith<$Res> {
  _$PaginationPageStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? faqs = freezed,
    Object? currentPage = null,
    Object? totalPage = null,
    Object? perPage = null,
    Object? expandedIndex = null,
    Object? status = null,
    Object? errorMessage = null,
  }) {
    return _then(_value.copyWith(
      faqs: freezed == faqs
          ? _value.faqs
          : faqs // ignore: cast_nullable_to_non_nullable
              as List<Datum>?,
      currentPage: null == currentPage
          ? _value.currentPage
          : currentPage // ignore: cast_nullable_to_non_nullable
              as int,
      totalPage: null == totalPage
          ? _value.totalPage
          : totalPage // ignore: cast_nullable_to_non_nullable
              as int,
      perPage: null == perPage
          ? _value.perPage
          : perPage // ignore: cast_nullable_to_non_nullable
              as int,
      expandedIndex: null == expandedIndex
          ? _value.expandedIndex
          : expandedIndex // ignore: cast_nullable_to_non_nullable
              as int,
      status: null == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as FormzSubmissionStatus,
      errorMessage: null == errorMessage
          ? _value.errorMessage
          : errorMessage // ignore: cast_nullable_to_non_nullable
              as String,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$_PaginationPageStateCopyWith<$Res>
    implements $PaginationPageStateCopyWith<$Res> {
  factory _$$_PaginationPageStateCopyWith(_$_PaginationPageState value,
          $Res Function(_$_PaginationPageState) then) =
      __$$_PaginationPageStateCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {List<Datum>? faqs,
      int currentPage,
      int totalPage,
      int perPage,
      int expandedIndex,
      FormzSubmissionStatus status,
      String errorMessage});
}

/// @nodoc
class __$$_PaginationPageStateCopyWithImpl<$Res>
    extends _$PaginationPageStateCopyWithImpl<$Res, _$_PaginationPageState>
    implements _$$_PaginationPageStateCopyWith<$Res> {
  __$$_PaginationPageStateCopyWithImpl(_$_PaginationPageState _value,
      $Res Function(_$_PaginationPageState) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? faqs = freezed,
    Object? currentPage = null,
    Object? totalPage = null,
    Object? perPage = null,
    Object? expandedIndex = null,
    Object? status = null,
    Object? errorMessage = null,
  }) {
    return _then(_$_PaginationPageState(
      faqs: freezed == faqs
          ? _value._faqs
          : faqs // ignore: cast_nullable_to_non_nullable
              as List<Datum>?,
      currentPage: null == currentPage
          ? _value.currentPage
          : currentPage // ignore: cast_nullable_to_non_nullable
              as int,
      totalPage: null == totalPage
          ? _value.totalPage
          : totalPage // ignore: cast_nullable_to_non_nullable
              as int,
      perPage: null == perPage
          ? _value.perPage
          : perPage // ignore: cast_nullable_to_non_nullable
              as int,
      expandedIndex: null == expandedIndex
          ? _value.expandedIndex
          : expandedIndex // ignore: cast_nullable_to_non_nullable
              as int,
      status: null == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as FormzSubmissionStatus,
      errorMessage: null == errorMessage
          ? _value.errorMessage
          : errorMessage // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$_PaginationPageState implements _PaginationPageState {
  const _$_PaginationPageState(
      {final List<Datum>? faqs = const [],
      this.currentPage = 0,
      this.totalPage = 0,
      this.perPage = 0,
      this.expandedIndex = -1,
      this.status = FormzSubmissionStatus.initial,
      this.errorMessage = ""})
      : _faqs = faqs;

  final List<Datum>? _faqs;
  @override
  @JsonKey()
  List<Datum>? get faqs {
    final value = _faqs;
    if (value == null) return null;
    if (_faqs is EqualUnmodifiableListView) return _faqs;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  @override
  @JsonKey()
  final int currentPage;
  @override
  @JsonKey()
  final int totalPage;
  @override
  @JsonKey()
  final int perPage;
  @override
  @JsonKey()
  final int expandedIndex;
  @override
  @JsonKey()
  final FormzSubmissionStatus status;
  @override
  @JsonKey()
  final String errorMessage;

  @override
  String toString() {
    return 'PaginationPageState(faqs: $faqs, currentPage: $currentPage, totalPage: $totalPage, perPage: $perPage, expandedIndex: $expandedIndex, status: $status, errorMessage: $errorMessage)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_PaginationPageState &&
            const DeepCollectionEquality().equals(other._faqs, _faqs) &&
            (identical(other.currentPage, currentPage) ||
                other.currentPage == currentPage) &&
            (identical(other.totalPage, totalPage) ||
                other.totalPage == totalPage) &&
            (identical(other.perPage, perPage) || other.perPage == perPage) &&
            (identical(other.expandedIndex, expandedIndex) ||
                other.expandedIndex == expandedIndex) &&
            (identical(other.status, status) || other.status == status) &&
            (identical(other.errorMessage, errorMessage) ||
                other.errorMessage == errorMessage));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType,
      const DeepCollectionEquality().hash(_faqs),
      currentPage,
      totalPage,
      perPage,
      expandedIndex,
      status,
      errorMessage);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_PaginationPageStateCopyWith<_$_PaginationPageState> get copyWith =>
      __$$_PaginationPageStateCopyWithImpl<_$_PaginationPageState>(
          this, _$identity);
}

abstract class _PaginationPageState implements PaginationPageState {
  const factory _PaginationPageState(
      {final List<Datum>? faqs,
      final int currentPage,
      final int totalPage,
      final int perPage,
      final int expandedIndex,
      final FormzSubmissionStatus status,
      final String errorMessage}) = _$_PaginationPageState;

  @override
  List<Datum>? get faqs;
  @override
  int get currentPage;
  @override
  int get totalPage;
  @override
  int get perPage;
  @override
  int get expandedIndex;
  @override
  FormzSubmissionStatus get status;
  @override
  String get errorMessage;
  @override
  @JsonKey(ignore: true)
  _$$_PaginationPageStateCopyWith<_$_PaginationPageState> get copyWith =>
      throw _privateConstructorUsedError;
}
