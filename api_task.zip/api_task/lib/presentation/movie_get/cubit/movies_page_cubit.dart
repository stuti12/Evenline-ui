import 'dart:convert';
import 'dart:io';
import 'package:api_task/data/repositrory/movies_repository.dart';
import 'package:api_task/utils/logger.dart';
import 'package:api_task/utils/utils.dart';
import 'package:bloc/bloc.dart';
import 'package:dio/dio.dart';
import 'package:formz/formz.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:path_provider/path_provider.dart';
import '../../../models/movies_response.dart';
import '../../../utils/enums.dart';
import '../../../utils/rechability.dart';
import '../../../utils/string.dart';

part 'movies_page_state.dart';

part 'movies_page_cubit.freezed.dart';

class MoviesPageCubit extends Cubit<MoviesPageState> {
  MoviesPageCubit({
    required MoviesRepository moviesRepository,
  })  : _moviesRepository = moviesRepository,
        super(const MoviesPageState()) {
    checkInternet();
    // emit(state.copyWith(downloadStatus: DownloadStatus.downloading));
  }

  final MoviesRepository _moviesRepository;

  checkInternet() async {
    bool isInternet = await Reachability().isInterNetAvailable();
    if (!isInternet) {
      emit(state.copyWith(isInternetAvailable: isInternet));
      readMoviesResponseFromFile();
    } else {
      emit(state.copyWith(isInternetAvailable: isInternet));
      await fetchMovies();
    }
  }

  ///save file while offline
  Future<void> saveMoviesApiResponseToFile(MoviesResponse? response) async {
    try {
      final directory = await getApplicationDocumentsDirectory();
      final file = File('${directory.path}/api_response.txt');
      final jsonData = response;
      final jsonString = json.encode(jsonData);
      await file.writeAsString(jsonString);
      Logger().i('API response saved to file: ${file.path}');
      emit(state.copyWith(status: FormzSubmissionStatus.success, errorMessage: '', moviesResponse: response, dataSource: DataSource.file));
    } catch (e) {
      Logger().e('Error saving API response to file: $e');
      emit(state.copyWith(status: FormzSubmissionStatus.failure, errorMessage: e.message));
    }
  }

  ///read from file
  Future<void> readMoviesResponseFromFile() async {
    try {
      final directory = await getApplicationDocumentsDirectory();
      final file = File('${directory.path}/api_response.txt');
      if (file.existsSync()) {
        final jsonString = await file.readAsString();
        final jsonData = json.decode(jsonString);
        final response = MoviesResponse.fromJson(jsonData);
        /*List<Video> mappedVideos = mapVideos(response.categories);*/
        List<Video> mappedVideos = mapVideos(response.categories).map((video) {
          String? filePath = file.existsSync() ? "${directory.path}/${video.sources?.first}" : null;
          return video.copyWith(downloadedFilePath: filePath,downloadStatus: DownloadStatus.downloaded);
        }).toList();
        Logger().i('API response read from file: $response');
        emit(state.copyWith(
            status: FormzSubmissionStatus.success, dataSource: DataSource.file, moviesResponse: response, video: mappedVideos));
      } else {
        emit(state.copyWith(status: FormzSubmissionStatus.failure, errorMessage: 'Fail'));
      }
    } catch (e) {
      Logger().e('Error reading API response from file: $e');
      emit(state.copyWith(status: FormzSubmissionStatus.failure, errorMessage: e.message));
    }
  }

  ///api call
  Future<void> fetchMovies() async {
    emit(state.copyWith(status: FormzSubmissionStatus.inProgress));
    try {
      var response = await _moviesRepository.getMovies();
      if (response.categories?.isNotEmpty == true) {
        List<Video> mappedVideos = mapVideos(response.categories).map((video) {
          return video.copyWith(downloadStatus: video.downloadStatus);
        }).toList();
        emit(
          state.copyWith(
              status: FormzSubmissionStatus.success,
              errorMessage: '',
              moviesResponse: response,
              dataSource: DataSource.api,
              video: mappedVideos,
          ),
        );
        await saveMoviesApiResponseToFile(response);
      } else {
        emit(state.copyWith(status: FormzSubmissionStatus.failure, errorMessage: response.message));
      }
    } catch (e) {
      emit(state.copyWith(status: FormzSubmissionStatus.failure, errorMessage: e.message));
      Logger().e("Response Error:-> ${e.message}");
    }
  }

  /// load more functionality for description text
  void toggleShowAllText() {
    final currentShowAllText = state.isLoad;
    emit(state.copyWith(isLoad: !currentShowAllText));
  }

  ///method to fetch videos and store to state
  List<Video> mapVideos(List<Category>? categories) {
    List<Video> mappedVideos = [];
    if (categories != null) {
      for (var category in categories) {
        if (category.videos != null) {
          for (var video in category.videos!) {
            String? filePath = video.sources?.isNotEmpty ?? false ? state.thumbnail : null;
            bool fileExists = filePath != null ? File(filePath).existsSync() : false;
            DownloadStatus downloadStatus = fileExists ? DownloadStatus.downloaded : DownloadStatus.downloading;
            mappedVideos.add(
              Video(
                  title: video.title ?? ConstantString.categoryName,
                  subtitle: video.subtitle ?? ConstantString.categoryName,
                  description: video.description ?? ConstantString.categoryName,
                  thumb: video.thumb ?? ConstantString.categoryName,
                  sources: video.sources,
                  downloadStatus: downloadStatus
              ),
            );
          }
        }
      }
    }
    return mappedVideos;
  }

  ///file save to storage and not download repeatedly
  Future<void> startDownload(Video video, int index) async {
    final updatedVideo = video.copyWith(downloadStatus: video.downloadStatus);
    final List<Video> updatedVideosList = List.from(state.video);
    updatedVideosList[index] = updatedVideo;
    emit(state.copyWith(video: updatedVideosList, status: FormzSubmissionStatus.inProgress));

    final Dio dio = Dio();
    try {
      var dir = await getApplicationDocumentsDirectory();
      bool fileExists = await File("${dir.path}/${video.sources!.first}").exists();
      String filePath = "${dir.path}/${video.sources?.first}";

      ///if video already exist than return
      if (fileExists) {
        Logger().e("Video already downloaded. File path: ${"${dir.path}/${video.sources!.first}"}");
        final updatedVideo = video.copyWith(downloadStatus: DownloadStatus.downloaded,downloadedFilePath:  filePath);
        final List<Video> updatedVideosList = List.from(state.video);
        updatedVideosList[index] = updatedVideo;
        emit(state.copyWith(video: updatedVideosList, status: FormzSubmissionStatus.success,thumbnail: filePath ));
        return;
      }

      ///download file logic
      await dio.download(video.sources!.first, "${dir.path}/${video.sources!.first}", onReceiveProgress: (rec, total) {
        double progressPercentage = (rec / total) * 100;
        Logger().e("Percentage $progressPercentage");
      });

      Logger().e("Download Completed");
      final updatedVideo = video.copyWith(downloadStatus: DownloadStatus.downloaded,downloadedFilePath:  filePath,);
      /// Create a mutable copy of the list
      final List<Video> updatedVideosList = List.from(state.video);
      updatedVideosList[index] = updatedVideo;
      emit(state.copyWith(video: updatedVideosList, status: FormzSubmissionStatus.success,thumbnail: filePath));
    } catch (e) {
      Logger().e(e);
      emit(state.copyWith(errorMessage: 'Download failed.', status: FormzSubmissionStatus.failure));
    }
  }

}
