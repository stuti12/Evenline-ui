part of 'movies_page_cubit.dart';

@freezed
class MoviesPageState with _$MoviesPageState {
  const factory MoviesPageState({
    MoviesResponse? moviesResponse,
    DownloadStatus? downloadStatus,
    @Default([]) List<Video> video,
    DataSource? dataSource,
    @Default(false) bool isLoad,
    @Default(false) bool isInternetAvailable,
    @Default(FormzSubmissionStatus.initial) FormzSubmissionStatus status,
    @Default("") String errorMessage,
    @Default("") String thumbnail,
    @Default("") String directoryPath,
  }) = _MoviesPageState;
}
