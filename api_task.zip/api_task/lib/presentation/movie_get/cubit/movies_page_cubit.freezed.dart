// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'movies_page_cubit.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

/// @nodoc
mixin _$MoviesPageState {
  MoviesResponse? get moviesResponse => throw _privateConstructorUsedError;
  List<Video> get video => throw _privateConstructorUsedError;
  DataSource? get dataSource => throw _privateConstructorUsedError;
  bool get isLoad => throw _privateConstructorUsedError;
  bool get isInternetAvailable => throw _privateConstructorUsedError;
  FormzSubmissionStatus get status => throw _privateConstructorUsedError;
  FormzSubmissionStatus get downloadStatus =>
      throw _privateConstructorUsedError;
  String get errorMessage => throw _privateConstructorUsedError;
  String get thumbnail => throw _privateConstructorUsedError;
  String get directoryPath => throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $MoviesPageStateCopyWith<MoviesPageState> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $MoviesPageStateCopyWith<$Res> {
  factory $MoviesPageStateCopyWith(
          MoviesPageState value, $Res Function(MoviesPageState) then) =
      _$MoviesPageStateCopyWithImpl<$Res, MoviesPageState>;
  @useResult
  $Res call(
      {MoviesResponse? moviesResponse,
      List<Video> video,
      DataSource? dataSource,
      bool isLoad,
      bool isInternetAvailable,
      FormzSubmissionStatus status,
      FormzSubmissionStatus downloadStatus,
      String errorMessage,
      String thumbnail,
      String directoryPath});

  $MoviesResponseCopyWith<$Res>? get moviesResponse;
}

/// @nodoc
class _$MoviesPageStateCopyWithImpl<$Res, $Val extends MoviesPageState>
    implements $MoviesPageStateCopyWith<$Res> {
  _$MoviesPageStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? moviesResponse = freezed,
    Object? video = null,
    Object? dataSource = freezed,
    Object? isLoad = null,
    Object? isInternetAvailable = null,
    Object? status = null,
    Object? downloadStatus = null,
    Object? errorMessage = null,
    Object? thumbnail = null,
    Object? directoryPath = null,
  }) {
    return _then(_value.copyWith(
      moviesResponse: freezed == moviesResponse
          ? _value.moviesResponse
          : moviesResponse // ignore: cast_nullable_to_non_nullable
              as MoviesResponse?,
      video: null == video
          ? _value.video
          : video // ignore: cast_nullable_to_non_nullable
              as List<Video>,
      dataSource: freezed == dataSource
          ? _value.dataSource
          : dataSource // ignore: cast_nullable_to_non_nullable
              as DataSource?,
      isLoad: null == isLoad
          ? _value.isLoad
          : isLoad // ignore: cast_nullable_to_non_nullable
              as bool,
      isInternetAvailable: null == isInternetAvailable
          ? _value.isInternetAvailable
          : isInternetAvailable // ignore: cast_nullable_to_non_nullable
              as bool,
      status: null == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as FormzSubmissionStatus,
      downloadStatus: null == downloadStatus
          ? _value.downloadStatus
          : downloadStatus // ignore: cast_nullable_to_non_nullable
              as FormzSubmissionStatus,
      errorMessage: null == errorMessage
          ? _value.errorMessage
          : errorMessage // ignore: cast_nullable_to_non_nullable
              as String,
      thumbnail: null == thumbnail
          ? _value.thumbnail
          : thumbnail // ignore: cast_nullable_to_non_nullable
              as String,
      directoryPath: null == directoryPath
          ? _value.directoryPath
          : directoryPath // ignore: cast_nullable_to_non_nullable
              as String,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $MoviesResponseCopyWith<$Res>? get moviesResponse {
    if (_value.moviesResponse == null) {
      return null;
    }

    return $MoviesResponseCopyWith<$Res>(_value.moviesResponse!, (value) {
      return _then(_value.copyWith(moviesResponse: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$_MoviesPageStateCopyWith<$Res>
    implements $MoviesPageStateCopyWith<$Res> {
  factory _$$_MoviesPageStateCopyWith(
          _$_MoviesPageState value, $Res Function(_$_MoviesPageState) then) =
      __$$_MoviesPageStateCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {MoviesResponse? moviesResponse,
      List<Video> video,
      DataSource? dataSource,
      bool isLoad,
      bool isInternetAvailable,
      FormzSubmissionStatus status,
      FormzSubmissionStatus downloadStatus,
      String errorMessage,
      String thumbnail,
      String directoryPath});

  @override
  $MoviesResponseCopyWith<$Res>? get moviesResponse;
}

/// @nodoc
class __$$_MoviesPageStateCopyWithImpl<$Res>
    extends _$MoviesPageStateCopyWithImpl<$Res, _$_MoviesPageState>
    implements _$$_MoviesPageStateCopyWith<$Res> {
  __$$_MoviesPageStateCopyWithImpl(
      _$_MoviesPageState _value, $Res Function(_$_MoviesPageState) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? moviesResponse = freezed,
    Object? video = null,
    Object? dataSource = freezed,
    Object? isLoad = null,
    Object? isInternetAvailable = null,
    Object? status = null,
    Object? downloadStatus = null,
    Object? errorMessage = null,
    Object? thumbnail = null,
    Object? directoryPath = null,
  }) {
    return _then(_$_MoviesPageState(
      moviesResponse: freezed == moviesResponse
          ? _value.moviesResponse
          : moviesResponse // ignore: cast_nullable_to_non_nullable
              as MoviesResponse?,
      video: null == video
          ? _value._video
          : video // ignore: cast_nullable_to_non_nullable
              as List<Video>,
      dataSource: freezed == dataSource
          ? _value.dataSource
          : dataSource // ignore: cast_nullable_to_non_nullable
              as DataSource?,
      isLoad: null == isLoad
          ? _value.isLoad
          : isLoad // ignore: cast_nullable_to_non_nullable
              as bool,
      isInternetAvailable: null == isInternetAvailable
          ? _value.isInternetAvailable
          : isInternetAvailable // ignore: cast_nullable_to_non_nullable
              as bool,
      status: null == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as FormzSubmissionStatus,
      downloadStatus: null == downloadStatus
          ? _value.downloadStatus
          : downloadStatus // ignore: cast_nullable_to_non_nullable
              as FormzSubmissionStatus,
      errorMessage: null == errorMessage
          ? _value.errorMessage
          : errorMessage // ignore: cast_nullable_to_non_nullable
              as String,
      thumbnail: null == thumbnail
          ? _value.thumbnail
          : thumbnail // ignore: cast_nullable_to_non_nullable
              as String,
      directoryPath: null == directoryPath
          ? _value.directoryPath
          : directoryPath // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$_MoviesPageState implements _MoviesPageState {
  const _$_MoviesPageState(
      {this.moviesResponse,
      final List<Video> video = const [],
      this.dataSource,
      this.isLoad = false,
      this.isInternetAvailable = false,
      this.status = FormzSubmissionStatus.initial,
      this.downloadStatus = FormzSubmissionStatus.initial,
      this.errorMessage = "",
      this.thumbnail = "",
      this.directoryPath = ""})
      : _video = video;

  @override
  final MoviesResponse? moviesResponse;
  final List<Video> _video;
  @override
  @JsonKey()
  List<Video> get video {
    if (_video is EqualUnmodifiableListView) return _video;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_video);
  }

  @override
  final DataSource? dataSource;
  @override
  @JsonKey()
  final bool isLoad;
  @override
  @JsonKey()
  final bool isInternetAvailable;
  @override
  @JsonKey()
  final FormzSubmissionStatus status;
  @override
  @JsonKey()
  final FormzSubmissionStatus downloadStatus;
  @override
  @JsonKey()
  final String errorMessage;
  @override
  @JsonKey()
  final String thumbnail;
  @override
  @JsonKey()
  final String directoryPath;

  @override
  String toString() {
    return 'MoviesPageState(moviesResponse: $moviesResponse, video: $video, dataSource: $dataSource, isLoad: $isLoad, isInternetAvailable: $isInternetAvailable, status: $status, downloadStatus: $downloadStatus, errorMessage: $errorMessage, thumbnail: $thumbnail, directoryPath: $directoryPath)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_MoviesPageState &&
            (identical(other.moviesResponse, moviesResponse) ||
                other.moviesResponse == moviesResponse) &&
            const DeepCollectionEquality().equals(other._video, _video) &&
            (identical(other.dataSource, dataSource) ||
                other.dataSource == dataSource) &&
            (identical(other.isLoad, isLoad) || other.isLoad == isLoad) &&
            (identical(other.isInternetAvailable, isInternetAvailable) ||
                other.isInternetAvailable == isInternetAvailable) &&
            (identical(other.status, status) || other.status == status) &&
            (identical(other.downloadStatus, downloadStatus) ||
                other.downloadStatus == downloadStatus) &&
            (identical(other.errorMessage, errorMessage) ||
                other.errorMessage == errorMessage) &&
            (identical(other.thumbnail, thumbnail) ||
                other.thumbnail == thumbnail) &&
            (identical(other.directoryPath, directoryPath) ||
                other.directoryPath == directoryPath));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType,
      moviesResponse,
      const DeepCollectionEquality().hash(_video),
      dataSource,
      isLoad,
      isInternetAvailable,
      status,
      downloadStatus,
      errorMessage,
      thumbnail,
      directoryPath);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_MoviesPageStateCopyWith<_$_MoviesPageState> get copyWith =>
      __$$_MoviesPageStateCopyWithImpl<_$_MoviesPageState>(this, _$identity);
}

abstract class _MoviesPageState implements MoviesPageState {
  const factory _MoviesPageState(
      {final MoviesResponse? moviesResponse,
      final List<Video> video,
      final DataSource? dataSource,
      final bool isLoad,
      final bool isInternetAvailable,
      final FormzSubmissionStatus status,
      final FormzSubmissionStatus downloadStatus,
      final String errorMessage,
      final String thumbnail,
      final String directoryPath}) = _$_MoviesPageState;

  @override
  MoviesResponse? get moviesResponse;
  @override
  List<Video> get video;
  @override
  DataSource? get dataSource;
  @override
  bool get isLoad;
  @override
  bool get isInternetAvailable;
  @override
  FormzSubmissionStatus get status;
  @override
  FormzSubmissionStatus get downloadStatus;
  @override
  String get errorMessage;
  @override
  String get thumbnail;
  @override
  String get directoryPath;
  @override
  @JsonKey(ignore: true)
  _$$_MoviesPageStateCopyWith<_$_MoviesPageState> get copyWith =>
      throw _privateConstructorUsedError;
}
