import 'dart:io';

import 'package:api_task/data/repositrory/movies_repository.dart';
import 'package:api_task/presentation/movie_get/cubit/movies_page_cubit.dart';
import 'package:api_task/utils/app_colors.dart';
import 'package:api_task/utils/app_const.dart';
import 'package:api_task/utils/app_image.dart';
import 'package:api_task/utils/custom_widgets/progress_hud.dart';
import 'package:api_task/utils/custom_widgets/pull_to_refresh_list_view.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:formz/formz.dart';

import '../../../models/movies_response.dart';
import '../../../utils/custom_widgets/custom_video_player.dart';
import '../../../utils/enums.dart';
import '../../../utils/string.dart';
import '../../../utils/ui_text_style.dart';
import '../../../utils/utils.dart';

class MoviesPage extends StatelessWidget {
  const MoviesPage({super.key});

  static Widget instance() => RepositoryProvider(
        create: (context) => MoviesRepository(),
        child: BlocProvider(
          create: (context) => MoviesPageCubit(moviesRepository: context.read()),
          child: const MoviesPage(),
        ),
      );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          ConstantString.appName,
          style: UITextStyle.regularTextStyle(fontSize: 20),
        ),
        backgroundColor: AppColor.pinkColor,
        centerTitle: true,
      ),
      body: ProgressHUD(
        isShowingInitial: true,
        child: BlocListener<MoviesPageCubit, MoviesPageState>(
          listener: (context, state) {
            if (state.status.isFailure) {
              ProgressHUD.of(context)?.dismiss();
              Utils.showSnackBar(context, state.errorMessage);
            } else if (state.status.isSuccess) {
              ProgressHUD.of(context)?.dismiss();
            } else if (state.status.isInProgress) {
              ProgressHUD.of(context)?.show();
            }
          },
          listenWhen: (previous, current) => previous.status != current.status,
          child: BlocBuilder<MoviesPageCubit, MoviesPageState>(
            builder: (context, state) {
              return _MoviesItem(
                moviesResponse: state.moviesResponse,
                mappedVideos: state.video,
              );
            },
          ),
        ),
      ),
    );
  }
}

class _MoviesItem extends StatelessWidget {
  const _MoviesItem({
    required this.moviesResponse,
    required this.mappedVideos,
  });

  final MoviesResponse? moviesResponse;
  final List<Video>? mappedVideos;

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<MoviesPageCubit, MoviesPageState>(
      builder: (context, state) {
        const int maxCharacters = 100;
        bool showAllText = state.isLoad;

        return PullToRefreshListView(
          itemCount: moviesResponse?.categories?.length ?? 0,
          padding: EdgeInsets.symmetric(horizontal: 12.w),
          builder: (context, index) {
            final category = moviesResponse?.categories?[index];
            final videos = state.video;
            return Theme(
              data: Theme.of(context).copyWith(dividerColor: Colors.transparent),
              child: ExpansionTile(
                title: Text(
                  category?.name ?? ConstantString.categoryName,
                  style: UITextStyle.regularTextStyle(
                    fontWeight: FontWeight.w500,
                    fontSize: 16,
                  ),
                ),
                children: [
                  ListView.builder(
                    itemCount: state.video.length,
                    shrinkWrap: true,
                    physics: const ScrollPhysics(),
                    itemBuilder: (context, index) {
                      String? displayText = showAllText
                          ? state.video[index].description
                          : (state.video[index].description!.length > maxCharacters
                              ? state.video[index].description?.substring(0, maxCharacters)
                              : state.video[index].description);
                      return ListTile(
                        contentPadding: EdgeInsets.zero,
                        title: Text(
                          videos[index].title ?? ConstantString.videoTitle,
                          style: UITextStyle.regularTextStyle(
                            fontSize: 18,
                            color: AppColor.blackColor,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        subtitle: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              videos[index].subtitle ?? ConstantString.videoSubTitle,
                              style: UITextStyle.regularTextStyle(
                                fontSize: 14,
                              ),
                            ),
                            SizedBox(
                              height: 10.h,
                            ),
                            state.video[index].description != null
                                ? RichText(
                                    text: TextSpan(
                                      children: [
                                        TextSpan(
                                          text: displayText,
                                          style: UITextStyle.regularTextStyle(
                                            fontWeight: FontWeight.w400,
                                            fontSize: 16,
                                            color: AppColor.blackColor,
                                          ),
                                        ),
                                        if (state.video[index].description!.length > maxCharacters)
                                          WidgetSpan(
                                            alignment: PlaceholderAlignment.middle,
                                            child: GestureDetector(
                                              child: Text(
                                                showAllText ? ConstantString.loadLess : ConstantString.loadMore,
                                                style: UITextStyle.regularTextStyle(
                                                  fontWeight: FontWeight.w700,
                                                  fontSize: 15,
                                                  color: AppColor.blackColor,
                                                ),
                                              ),
                                              onTap: () {
                                                context.read<MoviesPageCubit>().toggleShowAllText();
                                              },
                                            ),
                                          ),
                                      ],
                                    ),
                                  )
                                : Container(),
                          ],
                        ),
                        leading: videos[index].thumb != null
                            ? SizedBox(
                                width: 120, height: 100, child: _buildImageWidget(context: context, video: videos[index], index: index))
                            : Container(),
                        onTap: () {},
                      );
                    },
                  )
                ],
              ),
            );
          },
          onRefresh: () async {
           await context.read<MoviesPageCubit>().checkInternet();
          },
        );
      },
    );
  }

  Widget _buildImageWidget({required BuildContext context, required Video video, required int index}) {
    return BlocBuilder<MoviesPageCubit, MoviesPageState>(
      builder: (context, state) {
        final downloadStatus = video.downloadStatus;
        IconData icon;
        if (downloadStatus == DownloadStatus.downloading && video.downloadedFilePath == null) {
          icon = Icons.download;
        } else if (downloadStatus == DownloadStatus.downloaded && video.downloadedFilePath != null) {
          icon = Icons.play_arrow;
        } else {
          icon = Icons.download;
        }
        if (state.isInternetAvailable) {
          final thumbnailUrl = '${AppConstants.baseImageUrl}${video.thumb}';
          return Stack(
            children: [
              Image.network(
                thumbnailUrl,
                fit: BoxFit.cover,
                height: 150.h,
                width: 120.h,
              ),
              Positioned(
                right: 0,
                bottom: 0,
                top: 0,
                left: 0,
                child: IconButton(
                  onPressed: () {
                    if (video.downloadStatus == DownloadStatus.downloaded) {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => CustomVideoPlayer(videoPath: video.sources?.first ?? '',isInternet: state.isInternetAvailable),
                        ),
                      );
                    } else {
                      context.read<MoviesPageCubit>().startDownload(video:video, index:index);
                    }
                  },
                  icon: Container(
                    decoration: BoxDecoration(shape: BoxShape.circle, color: AppColor.hintTextColor),
                    child: Center(
                      child: Icon(icon, color: AppColor.blackColor),
                    ),
                  ),
                ),
              ),
            ],
          );
        } else {
          final filePath = video.downloadedFilePath;
          if (filePath != null) {
            // Check if the file exists
            bool fileExists = File(filePath).existsSync();

            if (fileExists) {
              return Stack(
                children: [
                  Image.asset(
                    AppImage.icPlaceholder,
                    fit: BoxFit.cover,
                    height: 150.h,
                    width: 120.h,
                  ),
                  Positioned(
                    right: 0,
                    bottom: 0,
                    top: 0,
                    left: 0,
                    child: IconButton(
                      onPressed: () {
                        if (video.downloadStatus == DownloadStatus.downloaded) {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => CustomVideoPlayer(videoPath: filePath,isInternet: state.isInternetAvailable,),
                            ),
                          );
                        } else {
                          context.read<MoviesPageCubit>().startDownload(video:video, index:index);
                        }
                      },
                      icon: Container(
                        decoration: BoxDecoration(shape: BoxShape.circle, color: AppColor.hintTextColor),
                        child: Center(
                          child: Icon(icon, color: AppColor.blackColor),
                        ),
                      ),
                    ),
                  ),
                ],
              );
            }
          } else {
            return Container();
          }
        }
        return Image.asset(
          AppImage.icPlaceholder,
          fit: BoxFit.cover,
          height: 150.h,
          width: 120.h,
        );
      },
    );
  }

  IconData _getVideoIcon(Video video) {
    if (video.downloadStatus == DownloadStatus.downloading && video.downloadedFilePath == null) {
      return Icons.download;
    } else if (video.downloadStatus == DownloadStatus.downloaded && video.downloadedFilePath != null) {
      return Icons.play_arrow;
    } else {
      return Icons.download;
    }
  }

}
