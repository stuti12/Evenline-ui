// DO NOT EDIT. This is code generated via package:easy_localization/generate.dart

abstract class  LocaleKeys {
  static const appName = 'appName';
  static const msgSomethingWrong = 'msgSomethingWrong';
  static const msgInternetMessage = 'msgInternetMessage';

}
