package com.example.figma.home.inroomdining.viewmodel

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.figma.home.inroomdining.model.food.TabApiTitleData
import com.example.figma.interfacesApi.UserApi
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class TabFoodTitleViewModel : ViewModel() {
    var foodData: MutableLiveData<TabApiTitleData> = MutableLiveData()
    fun getfoodTitleObserver(): MutableLiveData<TabApiTitleData> {
        return foodData
    }

    fun makeFoodTitleApiCall() {
        viewModelScope.launch(Dispatchers.IO) {
            //   val data = GetHotelData(84)
            val response = UserApi.getApi()?.getHotelMealCategories(84)
            if (response?.isSuccessful == true) {
                foodData.postValue(response.body())

            }
        }
    }
}