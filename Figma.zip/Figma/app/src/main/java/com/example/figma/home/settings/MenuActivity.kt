package com.example.figma.home.settings

import android.content.Intent
import android.content.res.Configuration
import android.os.Bundle
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.figma.MyApp
import com.example.figma.R
import com.example.figma.authentication.SignupActivity
import com.example.figma.databinding.ActivityMenuBinding
import com.example.figma.home.adapter.SettingAdapter
import com.example.figma.home.dashboard.DashboardActivity
import com.example.figma.home.data.MenuData
import com.example.figma.home.settings.viewmodel.LogOutViewModel
import com.example.figma.utils.SessionManager
import com.example.figma.utils.toast

class MenuActivity : AppCompatActivity() {
    private val binding: ActivityMenuBinding by lazy {
        ActivityMenuBinding.inflate(layoutInflater)
    }
    private lateinit var adapter: SettingAdapter
    private var dataList = listOf<MenuData>()
    private val logoutViewModel: LogOutViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        setAdapter()
        setMenuData()
        setUpClickListener()
    }


    private fun setUpClickListener() {
        binding.arrowBackImageView.setOnClickListener {
            finish()
        }
      /*  binding.switchTest.setOnClickListener {
            when(resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) {
                Configuration.UI_MODE_NIGHT_YES -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
                Configuration.UI_MODE_NIGHT_NO -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
            }
        }*/
    }

    private fun setMenuData() {
        dataList = listOf(
            MenuData(R.drawable.ic_order, getString(R.string.text_request), R.drawable.ic_next),
            MenuData(
                R.drawable.ic_privacy,
                getString(R.string.text_privacypolicy),
                R.drawable.ic_next
            ),
            MenuData(R.drawable.ic_terms, getString(R.string.text_terms), R.drawable.ic_next),
            MenuData(R.drawable.ic_faq, getString(R.string.text_faq), R.drawable.ic_next),
            MenuData(R.drawable.ic_signout, getString(R.string.text_signout), R.drawable.ic_next)
        )
        adapter.submitList(dataList)
    }

    private fun initLogOutViewModel() {
        logoutViewModel.makeLogOutApiCall()
        logoutViewModel.getLogoutObserverMsg().observe(this, Observer<String> {
            if (it != null) {
                this.toast(it)
                SessionManager.clearData(MyApp.applicationContext())
                val intent = Intent(this, SignupActivity::class.java)
                startActivity(intent)
                finishAffinity()
            } else {
                this.toast("$it")
            }
        })
    }

    //Enqueue

    private fun setAdapter() {
        adapter = SettingAdapter(this) { position: Int ->
            when (position) {
                4 -> {
                    //  this.toast(getString(R.string.text_logout))
                    initLogOutViewModel()

                }
            }
        }
        binding.apply {
            rvMenu.layoutManager = LinearLayoutManager(this@MenuActivity)
            rvMenu.adapter = adapter

        }

    }
}