package com.example.figma.home.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import coil.load
import com.example.figma.R
import com.example.figma.databinding.ItemDinnerBinding
import com.example.figma.home.inroomdining.model.Meal

class InRoomDinnerAdapter(var context: Context) :
    ListAdapter<Meal, InRoomDinnerAdapter.RecycleGridViewHolder>(InRoomDinnerDifCallBack()) {
    var dataList = ArrayList<Meal>()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecycleGridViewHolder {
        val binding = ItemDinnerBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return RecycleGridViewHolder(binding)
    }

    override fun onBindViewHolder(holder: RecycleGridViewHolder, position: Int) {
        val currwntItem = getItem(position)
        holder.bind(currwntItem)
        //  notifyDataSetChanged()
    }

    class RecycleGridViewHolder(private val binding: ItemDinnerBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(dataModel: Meal) {
            binding.apply {
                textInRoomDinner.text = dataModel.name
                textInRoomSubtitle.text = dataModel.description
                textInRoomPrice.text = dataModel.unit + dataModel.price
                val url = dataModel.image
                imgInRoomDinner.load(url) {
                    placeholder(R.drawable.ic_dashboard_restaurant)
                    crossfade(true)
                }

            }
        }
    }
}

class InRoomDinnerDifCallBack : DiffUtil.ItemCallback<Meal>() {
    override fun areItemsTheSame(oldItem: Meal, newItem: Meal): Boolean {
        return oldItem.id == newItem.id
    }

    override fun areContentsTheSame(oldItem: Meal, newItem: Meal): Boolean {
        return areItemsTheSame(oldItem, newItem)
    }

}