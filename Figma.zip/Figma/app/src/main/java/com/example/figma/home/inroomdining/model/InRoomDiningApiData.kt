package com.example.figma.home.inroomdining.model


import com.google.gson.annotations.SerializedName

data class InRoomDiningApiData(
    @SerializedName("code")
    val code: Int,
    @SerializedName("data")
    val `data`: List<InRoomDiningData>,
    @SerializedName("msg")
    val msg: String,
    @SerializedName("status")
    val status: Int
)

data class GetInRoomData(
    @SerializedName("hotel_id")
    val hotelId: Int,
    @SerializedName("category_id")
    val categoryId: Int
)