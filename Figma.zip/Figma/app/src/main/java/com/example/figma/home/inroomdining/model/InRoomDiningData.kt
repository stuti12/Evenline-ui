package com.example.figma.home.inroomdining.model


import com.google.gson.annotations.SerializedName

data class InRoomDiningData(
    @SerializedName("category")
    val category: String,
    @SerializedName("category_id")
    val categoryId: Int,
    @SerializedName("category_image")
    val categoryImage: String,
    @SerializedName("meals")
    val meals: List<Meal>
)