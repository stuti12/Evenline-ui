package com.example.figma.home.frontdesk.model


import com.google.gson.annotations.SerializedName

data class ServicesData(
    @SerializedName("count")
    val count: Int,
    @SerializedName("currentPage")
    val currentPage: Int,
    @SerializedName("rows")
    val rows: List<ServiceRow>,
    @SerializedName("totalPages")
    val totalPages: Any
)