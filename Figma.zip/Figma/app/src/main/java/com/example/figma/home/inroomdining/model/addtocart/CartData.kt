package com.example.figma.home.inroomdining.model.addtocart


import com.google.gson.annotations.SerializedName

data class CartData(
    @SerializedName("id")
    val id: Int
)