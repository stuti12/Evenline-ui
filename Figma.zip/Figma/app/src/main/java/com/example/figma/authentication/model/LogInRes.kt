package com.example.figma.authentication.model


import androidx.annotation.Keep
import com.google.gson.annotations.SerializedName

@Keep
data class LogInRes(
    @SerializedName("code")
    val code: Int,
    @SerializedName("data")
    val `data`: LoginData,
    @SerializedName("msg")
    val msg: String,
    @SerializedName("status")
    val status: Int
)