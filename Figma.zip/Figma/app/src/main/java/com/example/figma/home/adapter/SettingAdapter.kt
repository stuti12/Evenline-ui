package com.example.figma.home.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.figma.databinding.ItemMenubarBinding
import com.example.figma.home.data.MenuData

class SettingAdapter(var context: Context, private val onItemClick: (position: Int) -> Unit) : ListAdapter<MenuData, SettingAdapter.RecycleGridViewHolder>(MenusDifCallBack()) {
    var dataList = emptyList<MenuData>()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecycleGridViewHolder {
        val binding = ItemMenubarBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return RecycleGridViewHolder(binding)
    }

    override fun onBindViewHolder(holder: RecycleGridViewHolder, position: Int) {
        val currwntItem = getItem(position)
        holder.bind(currwntItem, position)
    }

    internal fun setDataList(dataList: List<MenuData>) {
        this.dataList = dataList
    }

    inner class RecycleGridViewHolder(private val binding: ItemMenubarBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(dataModel: MenuData, position: Int) {
            binding.apply {
                textMenuServices.text = dataModel.title
                imgIcon.setImageResource(dataModel.icon)
                imgMenuNext.setImageResource(dataModel.image)
            }
            itemView.setOnClickListener {
                onItemClick.invoke(position)
            }
        }
    }
}

class MenusDifCallBack : DiffUtil.ItemCallback<MenuData>() {
    override fun areItemsTheSame(oldItem: MenuData, newItem: MenuData): Boolean {
        return oldItem.title == newItem.title
    }

    override fun areContentsTheSame(oldItem: MenuData, newItem: MenuData): Boolean {
        return areItemsTheSame(oldItem, newItem)
    }

}