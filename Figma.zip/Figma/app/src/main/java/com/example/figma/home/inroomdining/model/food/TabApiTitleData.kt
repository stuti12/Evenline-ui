package com.example.figma.home.inroomdining.model.food


import com.google.gson.annotations.SerializedName

data class TabApiTitleData(
    @SerializedName("code")
    val code: Int,
    @SerializedName("data")
    val `data`: List<TabData>,
    @SerializedName("msg")
    val msg: String,
    @SerializedName("status")
    val status: Int
)