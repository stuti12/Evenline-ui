package com.example.figma.home.dashboard.model


import com.google.gson.annotations.SerializedName

data class HotelData(
    @SerializedName("amenities")
    val amenities: List<String>,
    @SerializedName("check_in_datetime")
    val checkInDatetime: String,
    @SerializedName("check_out_datetime")
    val checkOutDatetime: String,
    @SerializedName("hotel_description")
    val hotelDescription: String,
    @SerializedName("hotel_id")
    val hotelId: Int,
    @SerializedName("hotel_images")
    val hotelImages: List<String>,
    @SerializedName("hotel_name")
    val hotelName: String,
    @SerializedName("hotel_title")
    val hotelTitle: Any,
    @SerializedName("id")
    val id: Int
)

data class GetHotelData(
    @SerializedName("hotel_id")
    val hotelId: Int
)


data class RecycleList(val items: ArrayList<HotelData>)