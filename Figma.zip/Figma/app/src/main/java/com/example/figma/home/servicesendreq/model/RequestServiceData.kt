package com.example.figma.home.servicesendreq.model


import com.google.gson.annotations.SerializedName

data class RequestServiceData(
    @SerializedName("code")
    val code: Int,
    @SerializedName("data")
    val `data`: RequestData,
    @SerializedName("msg")
    val msg: String,
    @SerializedName("status")
    val status: Int
)