package com.example.figma.interfacesApi

import com.example.figma.MyApp
import com.example.figma.authentication.model.LogInRequest
import com.example.figma.authentication.model.LogInRes
import com.example.figma.home.dashboard.model.hotel.CurrentStay
import com.example.figma.home.dashboard.model.service.OurMainServiceData
import com.example.figma.home.directory.model.DirectoryApiData
import com.example.figma.home.frontdesk.model.GetSubServiceData
import com.example.figma.home.frontdesk.model.SubServiceData
import com.example.figma.home.inroomdining.model.GetInRoomData
import com.example.figma.home.inroomdining.model.InRoomDiningApiData
import com.example.figma.home.inroomdining.model.addtocart.AddToCartRequestData
import com.example.figma.home.inroomdining.model.addtocart.AddToCartResponseData
import com.example.figma.home.inroomdining.model.food.TabApiTitleData
import com.example.figma.home.inroomdining.model.fooddetail.TabFoodRecycleApiData
import com.example.figma.home.servicesendreq.model.RequestData
import com.example.figma.home.servicesendreq.model.RequestServiceData
import com.example.figma.home.settings.model.LogOutApiData
import com.example.figma.utils.Constants
import com.example.figma.utils.SessionManager
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.Field
import retrofit2.http.FormUrlEncoded
import retrofit2.http.POST
import java.util.concurrent.TimeUnit


interface UserApi {
    @POST(SIGNINENDPOINTS)
    suspend fun loginUser(@Body loginRequest: LogInRequest): Response<LogInRes>

    @FormUrlEncoded
    @POST(CURRENTSTAYENDPOINT)
    suspend fun getdashboardCurrentStay(@Field("hotel_id") hotelId: Int): Response<CurrentStay>

    @POST(MAINSERVICEENDPOINT)
    suspend fun getMainServices(): Response<OurMainServiceData>

    @POST(SUBSERVICEENDPOINT)
    suspend fun getSubServices(@Body subServiceData: GetSubServiceData): Response<SubServiceData>

    @POST(SENDREQUEST)
    suspend fun getHotelService(@Body requestData: RequestData): Response<RequestServiceData>

    @FormUrlEncoded
    @POST(DIRECTORYENDPOINT)
    suspend fun getDirectory(@Field("hotel_id") hotelId: Int): Response<DirectoryApiData>

    @POST(INROOMDININGENDPOINT)
    suspend fun getDefaultCategoryMeal(@Body diningDataId: GetInRoomData): Response<InRoomDiningApiData>

    @FormUrlEncoded
    @POST(TABENDPOINT)
    suspend fun getHotelMealCategories(@Field("hotel_id") hotelId: Int): Response<TabApiTitleData>

    @POST(TABFOODDETAILENDPOINT)
    suspend fun getHotelMealByCategory(@Body diningDataId: GetInRoomData): Response<TabFoodRecycleApiData>

    @POST(LOGOUTENDPOINT)
    suspend fun logOutUser(): Response<LogOutApiData>

/*
    @POST(LOGOUTENDPOINT)
    suspend fun logOutUser(@Header ("Authorization") token: String): Call<LogOutApiData>
*/

    @POST(ADDTOCARTENDPOINT)
    suspend fun addToCart(@Body addToCartReq: AddToCartRequestData): Response<AddToCartResponseData>

    companion object {
        const val SIGNINENDPOINTS = "api/v1/customer/user/signin"
        const val CURRENTSTAYENDPOINT = "api/v1/customers/currentStay"
        const val MAINSERVICEENDPOINT = "api/v1/customer-services/ourMainServices?page=1&limits=5"
        const val SUBSERVICEENDPOINT = "api/v1/customer-services/ourSubServices"
        const val SENDREQUEST = "api/v1/customer-services/requestHotelService"
        const val DIRECTORYENDPOINT = "api/v1/customer/user/directories"
        const val INROOMDININGENDPOINT = "api/v1/customer-meals/default-category-meal"
        const val TABENDPOINT = "api/v1/customer-meals/hotel-meal-categories"
        const val TABFOODDETAILENDPOINT = "api/v1/customer-meals/hotel-meal-by-category"
        const val LOGOUTENDPOINT = "api/v1/customer/user/logout"
        const val ADDTOCARTENDPOINT = "api/v1/customer-orders/add-to-cart"
        fun getApi(): UserApi? {
            return ApiClient.client?.create(UserApi::class.java)
        }
    }
}


object ApiClient {
    var mHttpLoggingInterceptor =
        HttpLoggingInterceptor().setLevel(HttpLoggingInterceptor.Level.BODY)
            .setLevel(HttpLoggingInterceptor.Level.BODY)

    var mOkHttpClient = OkHttpClient.Builder()
        .addInterceptor(mHttpLoggingInterceptor)
        .addInterceptor(AuthInterceptor())
        .addInterceptor(mHttpLoggingInterceptor)
        .connectTimeout(30, TimeUnit.SECONDS)
        .build()

    var mRetrofit: Retrofit? = null

    val client: Retrofit?
        get() {
            if (mRetrofit == null) {
                mRetrofit = Retrofit.Builder()
                    .baseUrl(Constants.BASEURL)
                    .client(mOkHttpClient)
                    .addConverterFactory(GsonConverterFactory.create())
                    .build()
            }
            return mRetrofit
        }
}

class AuthInterceptor : Interceptor {

    override fun intercept(chain: Interceptor.Chain): okhttp3.Response {
        val builder = chain.request().newBuilder()
        val authToken = SessionManager.getToken(MyApp.applicationContext())
        if (authToken != null) {
            builder.addHeader("Authorization", "Bearer $authToken")
        }
        return chain.proceed(builder.build())
    }

}
