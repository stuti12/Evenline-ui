package com.example.figma.home.frontdesk.model


import com.google.gson.annotations.SerializedName

data class SubServiceData(
    @SerializedName("code")
    val code: Int,
    @SerializedName("data")
    val `data`: ServicesData,
    @SerializedName("msg")
    val msg: String,
    @SerializedName("status")
    val status: Int
)

data class GetSubServiceData(
    @SerializedName("hotel_id")
    val hotelId: Int,
    @SerializedName("service_id")
    val serviceId: Int?
)