package com.example.figma.home.inroomdining.model.fooddetail


import com.google.gson.annotations.SerializedName

data class TabFoodDetailData(
    @SerializedName("count")
    val count: Int,
    @SerializedName("rows")
    val rows: List<TabFoodDetailRow>
)