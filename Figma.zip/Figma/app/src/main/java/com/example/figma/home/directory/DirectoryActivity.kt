package com.example.figma.home.directory

import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.figma.databinding.ActivityDirectoryBinding
import com.example.figma.home.adapter.DirectoryAdapter
import com.example.figma.home.dashboard.DashboardActivity
import com.example.figma.home.directory.model.DirectoryApiData
import com.example.figma.home.directory.viewmodel.DirectoryViewModel
import com.example.figma.utils.SessionManager

class DirectoryActivity : AppCompatActivity() {
    private val binding: ActivityDirectoryBinding by lazy {
        ActivityDirectoryBinding.inflate(layoutInflater)
    }
    private lateinit var adapter: DirectoryAdapter
    private val directoryViewModel: DirectoryViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        initSDirectoryViewModel()

        setObserver()
        setUpClickListener()
    }

    private fun setUpClickListener() {
        binding.apply {
            arrowImageView.setOnClickListener {
                finish()
            }
        }
    }

    private fun setObserver() {
        directoryViewModel.getDirectoryObserver()
            .observe(this, Observer<DirectoryApiData> {
                if (it != null) {
                    //   homeAdapter.setDataList(it.rows)
                    adapter.submitList(it.data.rows)
                }
            })
    }

    private fun setAdapter() {
        binding.apply {
            adapter = DirectoryAdapter(this@DirectoryActivity)
            rvDirectory.layoutManager = LinearLayoutManager(this@DirectoryActivity)
            rvDirectory.adapter = adapter
        }
    }

    private fun initSDirectoryViewModel() {
        directoryViewModel.makeDirectoryApiCall()
        adapter = DirectoryAdapter(this)
        binding.rvDirectory.adapter = adapter

    }
}