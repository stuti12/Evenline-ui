package com.example.figma.home.inroomdining.model.addtocart


import com.google.gson.annotations.SerializedName

data class AddToCartRequestData(
    @SerializedName("carts")
    val carts: List<Cart>,
    @SerializedName("hotel_id")
    val hotelId: Int
)