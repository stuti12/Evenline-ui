package com.example.figma.home.inroomdining

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.figma.R
import com.example.figma.databinding.ActivityInRoomDiningBinding
import com.example.figma.home.adapter.InRoomDiningBreakfastAdapter
import com.example.figma.home.adapter.InRoomDinnerAdapter
import com.example.figma.home.adapter.InRoomLunchAdapter
import com.example.figma.home.adapter.TabFoodDetailAdapter
import com.example.figma.home.dashboard.DashboardActivity
import com.example.figma.home.inroomdining.model.InRoomDiningApiData
import com.example.figma.home.inroomdining.model.addtocart.AddToCartRequestData
import com.example.figma.home.inroomdining.model.addtocart.Cart
import com.example.figma.home.inroomdining.model.food.TabApiTitleData
import com.example.figma.home.inroomdining.model.fooddetail.TabFoodRecycleApiData
import com.example.figma.home.inroomdining.viewmodel.*
import com.example.figma.utils.toast
import com.google.android.material.tabs.TabLayout

class InRoomDiningActivity : AppCompatActivity() {

    private val binding: ActivityInRoomDiningBinding by lazy {
        ActivityInRoomDiningBinding.inflate(layoutInflater)
    }
    private lateinit var breakfastAdapter: InRoomDiningBreakfastAdapter
    private lateinit var tabFoodDetailAdapter: TabFoodDetailAdapter
    private lateinit var lunchAdapter: InRoomLunchAdapter
    private lateinit var dinnerAdapter: InRoomDinnerAdapter
    private val breakfastViewModel: InRoomBreakfastViewModel by viewModels()
    private val lunchViewModel: InRoomLunchViewModel by viewModels()
    private val dinnerViewModel: InRoomDinnerViewModel by viewModels()
    private val tabFoodTitleViewModel: TabFoodTitleViewModel by viewModels()
    private val tabFoodDetailViewModel: TabFoodDetailViewModel by viewModels()
    private val addtoCartViewModell: AddtoCartViewModel by viewModels()


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        setUpClickListener()
        setAdapter()
        setObserver()
        initBreakfastViewModel()
        initLunchViewModel()
        initDinnerViewModel()
        initTabFoodTitleViewModel()
        tabFoodDetailDataSet()
    }

    private fun setObserver() {
        addtoCartViewModell.getaddtocartObserver().observe(this, Observer<String> {
            if (it != null) {
                this.toast("$it")
            }
        })
        addtoCartViewModell.getaddtocartObserver().observe(this, Observer<String> {
            if (it != null) {
                this.toast("$it")

            }
        })

        tabFoodDetailViewModel.getmainCourseObserver()
            .observe(this, Observer<TabFoodRecycleApiData> {
                if (it != null) {
                    tabFoodDetailAdapter.submitList(it.data.rows)
                    binding.textNotFound.visibility = View.GONE
                }
            })

        tabFoodDetailViewModel.getPastaObserver().observe(this, Observer<TabFoodRecycleApiData> {
            if (it != null) {
                tabFoodDetailAdapter.submitList(it.data.rows)
                binding.textNotFound.visibility = View.VISIBLE

            }
        })

        tabFoodDetailViewModel.getStarterObserver().observe(this, Observer<TabFoodRecycleApiData> {
            if (it != null) {
                tabFoodDetailAdapter.submitList(it.data.rows)
                binding.textNotFound.visibility = View.GONE
            }

        })
        tabFoodDetailViewModel.getAppetizerObserver()
            .observe(this, Observer<TabFoodRecycleApiData> {
                if (it != null) {
                    tabFoodDetailAdapter.submitList(it.data.rows)
                    binding.textNotFound.visibility = View.GONE
                }
            })

        breakfastViewModel.getbreakfastObserver().observe(this, Observer<InRoomDiningApiData> {
            if (it != null) {
                breakfastAdapter.submitList(it.data[0].meals)
                binding.progressbar.visibility = View.GONE
            }
        })

        lunchViewModel.getLunchObserver().observe(this, Observer<InRoomDiningApiData> {
            if (it != null) {
                lunchAdapter.submitList(it.data[0].meals)
                // breakfastAdapter.submitList(it.data.rows)
            }
        })

        dinnerViewModel.getdinnerObserver().observe(this, Observer<InRoomDiningApiData> {
            if (it != null) {
                dinnerAdapter.submitList(it.data[0].meals)
                // breakfastAdapter.submitList(it.data.rows)
            }
        })

        tabFoodTitleViewModel.getfoodTitleObserver().observe(this, Observer<TabApiTitleData> {
            if (it != null) {
                binding.tabLayout.apply {
                    for (i in it.data) {
                        addTab(binding.tabLayout.newTab().setText(i.name))
                    }
                }
            } else {
                Toast.makeText(this, "Error", Toast.LENGTH_LONG).show()
            }
        })
    }

    private fun setAdapter() {
        tabFoodDetailAdapter =
            TabFoodDetailAdapter(this, object : TabFoodDetailAdapter.AdapterInterface {
                override fun buttonMinusPressed(position: Int) {
                    val mealId = tabFoodDetailAdapter.currentList[position].id
                    addtoCartViewModell.makeAddtoCartApiCall(
                        AddToCartRequestData(listOf(Cart(mealId, -1)), 84)
                    )
                }

                override fun buttonPlusPressed(position: Int) {
                    val mealId = tabFoodDetailAdapter.currentList[position].id
                    addtoCartViewModell.makeRemoveCartApiCall(
                        AddToCartRequestData(listOf(Cart(mealId, 1)), 84)
                    )
                }

            })
        binding.rvInRoomMenu.layoutManager = LinearLayoutManager(this)
        binding.rvInRoomMenu.adapter = tabFoodDetailAdapter

        breakfastAdapter = InRoomDiningBreakfastAdapter(this)
        binding.rvInRoomBreakfast.adapter = breakfastAdapter

        lunchAdapter = InRoomLunchAdapter(this)
        binding.rvInRoomLunch.adapter = lunchAdapter

        dinnerAdapter = InRoomDinnerAdapter(this)
        binding.rvInRoomDinner.adapter = dinnerAdapter

    }

    private fun tabFoodDetailDataSet() {
        binding.tabLayout.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {

            override fun onTabSelected(tab: TabLayout.Tab?) {
                when (binding.tabLayout.selectedTabPosition) {
                    0 -> {
                        initFoodDetailPastaViewModel()
                    }
                    1 -> {
                        initFoodDetailMainCourseViewModel()
                    }
                    2 -> {
                        initFoodDetailStarterViewModel()
                    }
                    3 -> {
                        initFoodDetailAppetizerViewModel()
                    }
                }
            }

            override fun onTabUnselected(tab: TabLayout.Tab?) {
            }

            override fun onTabReselected(tab: TabLayout.Tab?) {
            }

        })
    }

    private fun setUpClickListener() {
        binding.apply {
            arrowImageView.setOnClickListener {
                finish()
            }

            btnCheckOut.setOnClickListener {
                this@InRoomDiningActivity.toast(getString(R.string.text_cart))
            }

        }

    }

    private fun initFoodDetailMainCourseViewModel() {
        tabFoodDetailViewModel.makeMainCourseApiCall()

    }

    private fun initFoodDetailPastaViewModel() {
        tabFoodDetailViewModel.makePastaApiCall()

    }


    private fun initFoodDetailStarterViewModel() {
        tabFoodDetailViewModel.makeStarterApiCall()

    }

    private fun initFoodDetailAppetizerViewModel() {
        tabFoodDetailViewModel.makeAppetizerApiCall()
    }

    private fun initBreakfastViewModel() {
        breakfastViewModel.makeBreakfastApiCall()

    }

    private fun initLunchViewModel() {
        lunchViewModel.makeLunchApiCall()

    }

    private fun initDinnerViewModel() {
        dinnerViewModel.makeDinnerApiCall()

    }

    private fun initTabFoodTitleViewModel() {
        tabFoodTitleViewModel.makeFoodTitleApiCall()
    }

}