package com.example.figma.utils

class Constants {
    companion object {
        const val TWOHUNDRED = 200
        const val TWOTHOUSAND = 2000
        const val BASEURL = "https://hemrostay-api.apps.openxcell.dev/"
    }
}