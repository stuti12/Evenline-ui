package com.example.figma.home.directory.model


import com.google.gson.annotations.SerializedName

data class DirectoryData(
    @SerializedName("count")
    val count: Int,
    @SerializedName("currentPage")
    val currentPage: Int,
    @SerializedName("rows")
    val rows: List<DirectoryRow>,
    @SerializedName("totalPages")
    val totalPages: Any
)