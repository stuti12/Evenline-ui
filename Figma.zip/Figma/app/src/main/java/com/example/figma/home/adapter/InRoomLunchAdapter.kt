package com.example.figma.home.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import coil.load
import com.example.figma.R
import com.example.figma.databinding.ItemLunchBinding
import com.example.figma.home.inroomdining.model.Meal

class InRoomLunchAdapter(var context: Context) :
    ListAdapter<Meal, InRoomLunchAdapter.RecycleGridViewHolder>(InRoomLunchDifCallBack()) {
    var dataList = ArrayList<Meal>()
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecycleGridViewHolder {
        val binding =
            ItemLunchBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return RecycleGridViewHolder(binding)
    }

    override fun onBindViewHolder(holder: RecycleGridViewHolder, position: Int) {
        val currwntItem = getItem(position)
        holder.bind(currwntItem)
    }

    class RecycleGridViewHolder(private val binding: ItemLunchBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(dataModel: Meal) {
            binding.apply {
                textInRoomLunch.text = dataModel.name
                textInRoomSubtitle.text = dataModel.description
                textInRoomPrice.text = dataModel.unit + dataModel.price
                val url = dataModel.image
                imgInRoomLunch.load(url) {
                    placeholder(R.drawable.ic_dashboard_restaurant)
                    crossfade(true)
                }
            }
        }
    }

}

class InRoomLunchDifCallBack : DiffUtil.ItemCallback<Meal>() {
    override fun areItemsTheSame(oldItem: Meal, newItem: Meal): Boolean {
        return oldItem.id == newItem.id
    }

    override fun areContentsTheSame(oldItem: Meal, newItem: Meal): Boolean {
        return areItemsTheSame(oldItem, newItem)
    }

}