package com.example.figma.authentication.model

import com.google.gson.annotations.SerializedName

data class LogInRequest(
    @SerializedName("user_name")
    val email: String,
    @SerializedName("password")
    val password: String?,
    @SerializedName("role_id")
    val roleId: Int? = 3
)