package com.example.figma.home.inroomdining.model.fooddetail


import com.google.gson.annotations.SerializedName

data class TabFoodRecycleApiData(
    @SerializedName("code")
    val code: Int,
    @SerializedName("data")
    val `data`: TabFoodDetailData,
    @SerializedName("msg")
    val msg: String,
    @SerializedName("status")
    val status: Int
)