package com.example.figma.home.dashboard

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.GridLayoutManager
import coil.load
import com.example.figma.R
import com.example.figma.databinding.FragmentHomeBinding
import com.example.figma.home.adapter.HomeAdapter
import com.example.figma.home.dashboard.model.hotel.CurrentStay
import com.example.figma.home.dashboard.model.service.OurMainServiceData
import com.example.figma.home.dashboard.viewmodel.CurrentStayViewModel
import com.example.figma.home.dashboard.viewmodel.MainServiceViewModel
import com.example.figma.home.settings.MenuActivity
import com.example.figma.utils.isNetworkConnected
import com.google.android.material.snackbar.Snackbar

class HomeFragment : Fragment() {
    private lateinit var binding: FragmentHomeBinding
    private lateinit var homeAdapter: HomeAdapter
    private val modelCurrentStay: CurrentStayViewModel by viewModels()
    private val serviceViewModel: MainServiceViewModel by viewModels()

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        binding = FragmentHomeBinding.inflate(inflater, container, false)

        return binding.root

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initCurrentStayViewModel()
        initServiceViewModel()
        setObserver()
        setUpClickListener()
        setAdapter()

        binding.apply {
            swipeRefreshLayout.setOnRefreshListener {
                if (isNetworkConnected()) {
                    initCurrentStayViewModel()
                    initServiceViewModel()
                    setObserver()
                } else {
                     Snackbar.make(view, getString(R.string.internet_not_available), Snackbar.LENGTH_SHORT).show()
                    //  requireActivity().toast(getString(R.string.internet_not_available))
                }
                binding.swipeRefreshLayout.isRefreshing = false
            }
        }
    }


    private fun setObserver() {
        serviceViewModel.getCurrentStayServiceObserver()
            .observe(viewLifecycleOwner, Observer<OurMainServiceData> {
                if (it != null) {
                    //   homeAdapter.setDataList(it.rows)
                    homeAdapter.submitList(it.data.rows)
                }
            })
    }

    private fun setUpClickListener() {
        binding.apply {
            imgOpenMenu.setOnClickListener {
                val i = Intent(activity, MenuActivity::class.java)
                startActivity(i)

            }
            imgDashboardHeader.setOnClickListener {
                val i = Intent(activity, MenuActivity::class.java)
                startActivity(i)
            }
        }
    }


    private fun setAdapter() {
        binding.apply {
            homeAdapter = HomeAdapter(requireActivity())
            rvService.adapter = homeAdapter
            rvService.layoutManager = GridLayoutManager(requireActivity(), 2)

        }
    }

    private fun initCurrentStayViewModel() {
        modelCurrentStay.makeCurrentStayApiCall()
        modelCurrentStay.getRecycleObserver().observe(viewLifecycleOwner, Observer<CurrentStay> {
            if (it != null) {
                binding.textHotelName.text = it.data.hotelName
                binding.textRoomtype.text = it.data.hotelDescription
                val url = it.data.hotelImages[0]
                binding.imgRestaurant.load(url) {
                    placeholder(R.drawable.ic_dashboard_restaurant)
                    crossfade(true)
                }
            } else {
                Toast.makeText(activity, "Error", Toast.LENGTH_LONG).show()
            }
        })

    }

    private fun initServiceViewModel() {
        serviceViewModel.makeCurrentStayServiceApiCall()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        binding == null
    }
}