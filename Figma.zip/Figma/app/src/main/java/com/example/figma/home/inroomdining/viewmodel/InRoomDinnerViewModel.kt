package com.example.figma.home.inroomdining.viewmodel

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.figma.home.inroomdining.model.GetInRoomData
import com.example.figma.home.inroomdining.model.InRoomDiningApiData
import com.example.figma.interfacesApi.UserApi
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class InRoomDinnerViewModel : ViewModel() {
    var dinnerData: MutableLiveData<InRoomDiningApiData> = MutableLiveData()
    fun getdinnerObserver(): MutableLiveData<InRoomDiningApiData> {
        return dinnerData
    }

    fun makeDinnerApiCall() {
        viewModelScope.launch(Dispatchers.IO) {
            val data = GetInRoomData(84, 377)
            val response = UserApi.getApi()?.getDefaultCategoryMeal(data)
            if (response?.isSuccessful == true) {
                dinnerData.postValue(response.body())
            }

        }
    }
}