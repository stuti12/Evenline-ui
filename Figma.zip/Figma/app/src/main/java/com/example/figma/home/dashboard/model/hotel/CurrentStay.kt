package com.example.figma.home.dashboard.model.hotel


import com.example.figma.home.dashboard.model.HotelData
import com.google.gson.annotations.SerializedName

data class CurrentStay(
    @SerializedName("code")
    val code: Int,
    @SerializedName("data")
    val `data`: HotelData,
    @SerializedName("msg")
    val msg: String,
    @SerializedName("status")
    val status: Int
)