package com.example.figma.home.adapter

import android.content.Context
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import coil.load
import com.example.figma.R
import com.example.figma.databinding.ItemTabFoodMenuBinding
import com.example.figma.home.inroomdining.model.fooddetail.TabFoodDetailRow

/*class TabFoodDetailAdapter(var context: Context)*/
class TabFoodDetailAdapter(var context: Context, adapterInterface: AdapterInterface) :
    ListAdapter<TabFoodDetailRow, TabFoodDetailAdapter.RecycleGridViewHolder>(MenuDifCallBack()) {
    var dataList = emptyList<TabFoodDetailRow>()
    var adapterInterface: AdapterInterface

    interface AdapterInterface {
        fun buttonMinusPressed(position: Int)
        fun buttonPlusPressed(position: Int)
    }

    init {
        this.adapterInterface = adapterInterface
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecycleGridViewHolder {
        val binding =
            ItemTabFoodMenuBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return RecycleGridViewHolder(binding)

    }

    override fun onBindViewHolder(holder: RecycleGridViewHolder, position: Int) {
        val currwntItem = getItem(position)
        holder.bind(currwntItem, position)
    }

    inner class RecycleGridViewHolder(val binding: ItemTabFoodMenuBinding) :
        RecyclerView.ViewHolder(binding.root) {
        var quantity = 0
        fun bind(dataModel: TabFoodDetailRow, position: Int) {
            binding.apply {
                Log.d("", dataModel.image)
                imgitemMenu.load(dataModel.image) {
                    placeholder(R.drawable.ic_menu1)
                }
                textMenutitle.text = dataModel.name
                textMenuPrice.text = dataModel.unit + dataModel.price
                //textMenuPrice.text = (textMenuPrice.text.toString().toInt()*quantity).toString()
                quantityTextview.text = quantity.toString()
                btnAdd.setOnClickListener(object : View.OnClickListener {
                    override fun onClick(v: View?) {
                        adapterInterface.buttonPlusPressed(position)
                        binding.apply {
                            quantity++
                            btnAdd.visibility = android.view.View.GONE
                            decrementButton.visibility = android.view.View.VISIBLE
                            incrementButton.visibility = android.view.View.VISIBLE
                            quantityTextview.visibility = android.view.View.VISIBLE
                            //  root.context.toast("Increased")
                            quantityTextview.text = quantity.toString()

                        }
                    }
                })
                incrementButton.setOnClickListener(object : View.OnClickListener {
                    override fun onClick(v: View?) {
                        adapterInterface.buttonPlusPressed(position)
                        binding.apply {
                            quantity++
                            if (quantity == 0) {
                                btnAdd.visibility = android.view.View.VISIBLE
                                decrementButton.visibility = android.view.View.GONE
                                incrementButton.visibility = android.view.View.GONE
                                quantityTextview.visibility = android.view.View.GONE
                            }
                            //root.context.toast("Increased")
                            quantityTextview.text = quantity.toString()

                        }
                    }
                })
                decrementButton.setOnClickListener(object : View.OnClickListener {
                    override fun onClick(v: View?) {
                        adapterInterface.buttonMinusPressed(position)
                        binding.apply {
                            quantity--
                            if (quantity == 0) {
                                btnAdd.visibility = android.view.View.VISIBLE
                                decrementButton.visibility = android.view.View.GONE
                                incrementButton.visibility = android.view.View.GONE
                                quantityTextview.visibility = android.view.View.GONE
                            }
                            //  root.context.toast("Decreases")
                            quantityTextview.text = quantity.toString()

                        }
                    }
                })
            }

        }

    }
}

class MenuDifCallBack : DiffUtil.ItemCallback<TabFoodDetailRow>() {
    override fun areItemsTheSame(oldItem: TabFoodDetailRow, newItem: TabFoodDetailRow): Boolean {
        return oldItem.id == newItem.id
    }

    override fun areContentsTheSame(oldItem: TabFoodDetailRow, newItem: TabFoodDetailRow): Boolean {
        return areItemsTheSame(oldItem, newItem)
    }

}


