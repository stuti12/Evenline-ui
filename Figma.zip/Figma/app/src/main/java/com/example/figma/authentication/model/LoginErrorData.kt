package com.example.figma.authentication.model


import com.google.gson.annotations.SerializedName

data class LoginErrorData(
    @SerializedName("errors")
    val errors: Errors
)

data class LoginData(
    @SerializedName("access_token")
    val accessToken: String,
    @SerializedName("email")
    val email: String,
    @SerializedName("first_name")
    val firstName: String,
    @SerializedName("hotel_id")
    val hotelId: Int,
    @SerializedName("id")
    val id: Int,
    @SerializedName("is_deleted")
    val isDeleted: Boolean,
    @SerializedName("last_name")
    val lastName: String,
    @SerializedName("profile_image")
    val profileImage: Any,
    @SerializedName("room_no")
    val roomNo: String,
    @SerializedName("token")
    val token: String,
    @SerializedName("user")
    val user: User,
    @SerializedName("user_name")
    val userName: String
)

data class User(
    @SerializedName("current_hotel")
    val currentHotel: CurrentHotel,
    @SerializedName("hotel_id")
    val hotelId: Int,
    @SerializedName("room_no")
    val roomNo: String
)

data class CurrentHotel(
    @SerializedName("currency_symbol")
    val currencySymbol: String,
    @SerializedName("hotel_name")
    val hotelName: String
)