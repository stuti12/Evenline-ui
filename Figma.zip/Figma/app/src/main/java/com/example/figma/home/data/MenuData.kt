package com.example.figma.home.data

data class MenuData(
    var icon: Int,
    var title: String,
    var image: Int
)
