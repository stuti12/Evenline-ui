package com.example.figma.home.servicesendreq.viewmodel

import android.util.Log
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.figma.home.servicesendreq.model.RequestData
import com.example.figma.home.servicesendreq.model.RequestServiceData
import com.example.figma.interfacesApi.UserApi
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class RequestHotelServiceViewModel : ViewModel() {
    var result: MutableLiveData<Boolean> = MutableLiveData()
    var msg: MutableLiveData<String> = MutableLiveData()

    fun getRequestObserverMsg(): MutableLiveData<String> {
        return msg
    }

    fun makeServicesRequestApiCall(data: RequestData) {
        viewModelScope.launch(Dispatchers.IO) {
            val response = UserApi.getApi()?.getHotelService(data)
            if (response?.code() == 200) {
                msg.postValue(response.body()?.msg)
                Log.d("Message", "${response.body()?.msg}")
                result.postValue(true)

            }
            if (response?.code() != 200) {
                msg.postValue(response?.body()?.msg)
                result.postValue(false)
            }
        }
    }
}