package com.example.figma.home.dashboard.viewmodel

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.figma.home.dashboard.model.GetHotelData
import com.example.figma.home.dashboard.model.hotel.CurrentStay
import com.example.figma.interfacesApi.UserApi
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class CurrentStayViewModel : ViewModel() {
    var hotelData: MutableLiveData<CurrentStay> = MutableLiveData()
    fun getRecycleObserver(): MutableLiveData<CurrentStay> {
        return hotelData
    }

    fun makeCurrentStayApiCall() {
        viewModelScope.launch(Dispatchers.IO) {
            val data = GetHotelData(84)
            val response = UserApi.getApi()?.getdashboardCurrentStay(84)
            if (response?.isSuccessful == true) {
                hotelData.postValue(response.body())
            }

        }
    }
}