package com.example.figma.authentication

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.MotionEvent
import android.view.View
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import com.example.figma.R
import com.example.figma.authentication.model.BaseResponse
import com.example.figma.authentication.model.LogInRes
import com.example.figma.authentication.viewmodel.LoginViewModel
import com.example.figma.databinding.ActivitySignupBinding
import com.example.figma.home.dashboard.DashboardActivity
import com.example.figma.utils.Constants.Companion.TWOHUNDRED
import com.example.figma.utils.SessionManager
import com.example.figma.utils.hideKeyboard
import com.example.figma.utils.isNetworkConnected
import com.example.figma.utils.toast

class SignupActivity : AppCompatActivity() {
    private val binding: ActivitySignupBinding by lazy {
        ActivitySignupBinding.inflate(layoutInflater)
    }
    private val viewModel by viewModels<LoginViewModel>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        observe()
        setListener()

    }


    override fun dispatchTouchEvent(ev: MotionEvent?): Boolean {
        if (currentFocus != null) {
            binding.mainSigninView.hideKeyboard()
        }
        return super.dispatchTouchEvent(ev)
    }


    private fun observe() {

        viewModel.loginResult.observe(this) {
            when (it) {
                is BaseResponse.Loading -> {
                    showLoading()
                }

                is BaseResponse.Success -> {
                    stopLoading()
                    processLogin(it.data)
                }

                is BaseResponse.Error -> {
                    this.toast("User Not Found")
                    stopLoading()
                }
                else -> {
                    stopLoading()
                }
            }
        }

    }

    //API Call
    private fun doLogin() {
        val email = binding.etEmail.text.toString()
        val pwd = binding.etPassword.text.toString()
        if(isNetworkConnected()) {
            viewModel.loginUser(email = email, pwd = pwd, rollId = 3)
        }
        else {
            this.toast(getString(R.string.internet_not_available))
        }
    }

    private fun showLoading() {
        binding.prgbar.visibility = View.VISIBLE
    }

    private fun stopLoading() {
        binding.prgbar.visibility = View.GONE
    }

    private fun processLogin(data: LogInRes?) {
        val token: String
            if ((data != null) && (data.code == TWOHUNDRED)) {
                token = data.data.token
                SessionManager.saveAuthToken(this, token)
                Log.d("authTOken", token)
                this.toast(data.data.token)
            }
            if (data?.code == TWOHUNDRED) {
                this.toast(data.msg)
                startActivity(Intent(this@SignupActivity, DashboardActivity::class.java))
                finish()
            } else {
                data?.msg?.let { this.toast(it) }
            }
    }

    private fun validation(): Boolean {
        binding.apply {
            if (etEmail.text.isNullOrEmpty() || etPassword.text.isNullOrEmpty()) {
                etEmail.error = getString(R.string.textEmptyEmailError)
                etPassword.error = getString(R.string.textEmptypasswordError)
                return false
            }  /*if (!Patterns.EMAIL_ADDRESS.matcher(etEmail.text.toString()).matches()) {
                    etEmail.error = getString(R.string.textInvalidEmailError)
                } */
            else {
                etEmail.error = null
                etPassword.error = null
                return true
            }
        }
    }

    private fun setListener() {

        binding.apply {
            etEmail.addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(
                    s: CharSequence?, start: Int, count: Int, after: Int
                ) {
                }

                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                    if (etEmail.text.isNullOrEmpty()) {
                        etEmail.error = "Empty Email"
                    }
                    /*else if (!Patterns.EMAIL_ADDRESS.matcher(etEmail.text.toString()).matches()) {
                        etEmail.error = "invalid Email"
                    }*/ else {
                        etEmail.error = null
                    }
                }

                override fun afterTextChanged(s: Editable?) {

                }

            })

            etPassword.addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(
                    s: CharSequence?,
                    start: Int,
                    count: Int,
                    after: Int
                ) {
                }

                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                    if (etPassword.text.isNullOrEmpty()) {
                        etPassword.error = getString(R.string.textEmptypasswordError)
                    } else {
                        etPassword.error = null
                    }
                }

                override fun afterTextChanged(s: Editable?) {
                }

            })

            btnSignup.setOnClickListener {
                if (validation()) {
                    //calling api function
                    doLogin()
                }

            }
        }
    }

}

