package com.example.figma.home.settings.viewmodel

import android.util.Log
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.figma.home.settings.model.LogOutApiData
import com.example.figma.interfacesApi.UserApi
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.launch

class LogOutViewModel : ViewModel() {
    var logoutData: MutableLiveData<LogOutApiData> = MutableLiveData()
    var logoutMsg: MutableLiveData<String> = MutableLiveData()
    fun getLogoutObserver(): MutableLiveData<LogOutApiData> {
        return logoutData
    }

    fun getLogoutObserverMsg(): MutableLiveData<String> {
        return logoutMsg
    }

    fun makeLogOutApiCall() {
        viewModelScope.launch(Dispatchers.IO) {
            async {
                val response = UserApi.getApi()?.logOutUser()
                if (response?.code() == 200) {
                    //  SessionManager.clearData(MyApp.applicationContext())
                    logoutData.postValue(response.body())
                    logoutMsg.postValue(response.body()?.msg)
                    Log.d("Logout", "${response.body()?.msg}")

                }
            }
        }
    }
}