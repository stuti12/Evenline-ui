package com.example.figma.authentication.model


import com.google.gson.annotations.SerializedName

data class Errors(
    @SerializedName("password")
    val password: List<String>,
    @SerializedName("role_id")
    val roleId: List<String>,
    @SerializedName("user_name")
    val userName: List<String>
)