package com.example.figma.home.servicesendreq

import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.*
import android.widget.Button
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.lifecycle.Observer
import com.example.figma.R
import com.example.figma.databinding.ActivitySendRequestBinding
import com.example.figma.home.dashboard.DashboardActivity
import com.example.figma.home.servicesendreq.model.RequestData
import com.example.figma.home.servicesendreq.viewmodel.RequestHotelServiceViewModel
import com.example.figma.utils.hideKeyboard
import com.example.figma.utils.toast
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog

class SendRequestActivity : AppCompatActivity() {
    private val binding: ActivitySendRequestBinding by lazy {
        ActivitySendRequestBinding.inflate(layoutInflater)
    }
    private lateinit var bottomSheetBehavior: BottomSheetBehavior<ConstraintLayout>
    private val reqViewModel: RequestHotelServiceViewModel by viewModels()
    private var mainID: Int? = 0
    var serviceID: Int? = 0
    lateinit var description: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        getIntentData()
        setUpClickListener()
        setBottomSheet()
        val name = intent?.getStringExtra("title")
        val housename = intent?.getStringExtra("housetitle")
        binding.arrowImageView.setOnClickListener {
            if (name == "Front Desk") {
                finish()
            }
            if (housename == "House Keeping") {
                finish()
            }

        }

    }

    override fun dispatchTouchEvent(ev: MotionEvent?): Boolean {
        if (currentFocus != null) {
            binding.mainViewSend.hideKeyboard()
        }
        return super.dispatchTouchEvent(ev)
    }

    private fun getIntentData() {
        mainID = intent?.getIntExtra("main_service_id", 1)
        serviceID = intent?.getIntExtra("id", 63)
        description = intent?.getStringExtra("description").toString()
        val name = intent?.getStringExtra("title")
        val housename = intent?.getStringExtra("housetitle")

        binding.textReqService.text = name
        binding.textReqService.text = housename

        binding.textReqService.text = description

        binding.tvTitle.text = description
    }

    private fun setBottomSheet() {
        bottomSheetBehavior = BottomSheetBehavior.from(binding.includeBottomSheet.root)
        bottomSheetBehavior.addBottomSheetCallback(object :
            BottomSheetBehavior.BottomSheetCallback() {
            override fun onSlide(bottomSheet: View, slideOffset: Float) {
                binding.btnSend.visibility = View.GONE
            }

            override fun onStateChanged(bottomSheet: View, newState: Int) {
                if (newState == BottomSheetBehavior.STATE_COLLAPSED) {
                    binding.btnSend.visibility = View.VISIBLE
                }
                binding.includeBottomSheet.btnSendHome.setOnClickListener {
                    finish()
                }

            }
        })

    }

    private fun setObserver() {
        reqViewModel.getRequestObserverMsg().observe(this, Observer<String> {
            if (it != null) {
                this.toast("$it")
            }
        })
    }

    private fun validation(): Boolean {
        binding.apply {
            return if (etRequest.text?.toString().isNullOrEmpty()) {
                etRequest.error = getString(R.string.text_required)
                false
            } else {
                true
            }
        }
    }

    private fun setUpClickListener() {
        binding.apply {
            btnSend.setOnClickListener {
                if (validation()) {
                    reqViewModel.makeServicesRequestApiCall(RequestData("84", mainID.toString(), "", binding.etRequest.text.toString(), "", serviceID.toString(), 0))
                    if (reqViewModel.result.value == true) {
                        setObserver()
                    }
                    if (reqViewModel.result.value == false) {
                        setObserver()
                        val state = if (bottomSheetBehavior.state == BottomSheetBehavior.STATE_EXPANDED) { BottomSheetBehavior.STATE_COLLAPSED
                        } else BottomSheetBehavior.STATE_EXPANDED
                        bottomSheetBehavior.state = state
                       // setDialog()
                    }

                }
                val name = intent?.getStringExtra("title")
                val housename = intent?.getStringExtra("housetitle")
                arrowImageView.setOnClickListener {
                    if (name == "Front Desk") {
                        finish()
                    }
                    if (housename == "House Keeping") {
                        finish()
                    }

                }

            }
        }

    }
        fun setDialog() {
            val dialog = BottomSheetDialog(this)
            val view = layoutInflater.inflate(R.layout.bottom_sheet, null)
            dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
            dialog.setContentView(view)
            dialog.show()
            dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            dialog.window?.setGravity(Gravity.BOTTOM)

            val btnHome = view.findViewById<Button>(R.id.btnSendHome)
            btnHome.setOnClickListener {
                startActivity(Intent(this, DashboardActivity::class.java))
                finish()
            }
        }

}