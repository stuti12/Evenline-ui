package com.example.figma.home.inroomdining.viewmodel

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.figma.home.inroomdining.model.GetInRoomData
import com.example.figma.home.inroomdining.model.fooddetail.TabFoodRecycleApiData
import com.example.figma.interfacesApi.UserApi
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class TabFoodDetailViewModel : ViewModel() {
    var mainCourseData: MutableLiveData<TabFoodRecycleApiData> = MutableLiveData()
    var mainStarterData: MutableLiveData<TabFoodRecycleApiData> = MutableLiveData()
    var mainAppetizerData: MutableLiveData<TabFoodRecycleApiData> = MutableLiveData()
    var mainPastaData: MutableLiveData<TabFoodRecycleApiData> = MutableLiveData()

    fun getmainCourseObserver(): MutableLiveData<TabFoodRecycleApiData> {
        return mainCourseData
    }

    fun getStarterObserver(): MutableLiveData<TabFoodRecycleApiData> {
        return mainStarterData
    }

    fun getAppetizerObserver(): MutableLiveData<TabFoodRecycleApiData> {
        return mainAppetizerData
    }

    fun getPastaObserver(): MutableLiveData<TabFoodRecycleApiData> {
        return mainPastaData
    }


    fun makeMainCourseApiCall() {
        viewModelScope.launch(Dispatchers.IO) {
            val data = GetInRoomData(84, 380)
            val response = UserApi.getApi()?.getHotelMealByCategory(data)
            if (response?.isSuccessful == true) {
                mainCourseData.postValue(response.body())

            }
        }
    }

    fun makeStarterApiCall() {
        viewModelScope.launch(Dispatchers.IO) {
            val data = GetInRoomData(84, 375)
            val response = UserApi.getApi()?.getHotelMealByCategory(data)
            if (response?.isSuccessful == true) {
                mainCourseData.postValue(response.body())

            }
        }
    }

    fun makeAppetizerApiCall() {
        viewModelScope.launch(Dispatchers.IO) {
            val data = GetInRoomData(84, 379)
            val response = UserApi.getApi()?.getHotelMealByCategory(data)
            if (response?.isSuccessful == true) {
                mainCourseData.postValue(response.body())

            }
        }
    }

    fun makePastaApiCall() {
        viewModelScope.launch(Dispatchers.IO) {
            val data = GetInRoomData(84, 408)
            val response = UserApi.getApi()?.getHotelMealByCategory(data)
            if (response?.isSuccessful == true) {
                mainPastaData.postValue(response.body())
            }

        }
    }
}