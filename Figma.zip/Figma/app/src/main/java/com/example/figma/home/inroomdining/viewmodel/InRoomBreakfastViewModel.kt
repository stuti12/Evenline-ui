package com.example.figma.home.inroomdining.viewmodel

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.figma.home.inroomdining.model.GetInRoomData
import com.example.figma.home.inroomdining.model.InRoomDiningApiData
import com.example.figma.interfacesApi.UserApi
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class InRoomBreakfastViewModel : ViewModel() {
    var breakfastData: MutableLiveData<InRoomDiningApiData> = MutableLiveData()
    fun getbreakfastObserver(): MutableLiveData<InRoomDiningApiData> {
        return breakfastData
    }

    fun makeBreakfastApiCall() {
        viewModelScope.launch(Dispatchers.IO) {
            val data = GetInRoomData(84, 375)
            val response = UserApi.getApi()?.getDefaultCategoryMeal(data)
            if (response?.isSuccessful == true) {
                breakfastData.postValue(response.body())
            }

        }
    }
}