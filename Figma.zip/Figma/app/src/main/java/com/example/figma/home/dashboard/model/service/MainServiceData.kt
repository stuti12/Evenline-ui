package com.example.figma.home.dashboard.model.service


import com.google.gson.annotations.SerializedName

data class MainServiceData(
    @SerializedName("count")
    val count: Int,
    @SerializedName("currentPage")
    val currentPage: Int,
    @SerializedName("rows")
    val rows: List<HomeServiceRow>,
    @SerializedName("totalPages")
    val totalPages: Int
)