package com.example.figma.home.directory.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.example.figma.home.directory.model.DirectoryApiData
import com.example.figma.interfacesApi.UserApi
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class DirectoryViewModel(application: Application) : AndroidViewModel(application) {
    var directoryData: MutableLiveData<DirectoryApiData> = MutableLiveData()
    fun getDirectoryObserver(): MutableLiveData<DirectoryApiData> {
        return directoryData
    }

    fun makeDirectoryApiCall() {
        viewModelScope.launch(Dispatchers.IO) {
            val response = UserApi.getApi()?.getDirectory(84)
            if (response?.isSuccessful == true) {
                directoryData.postValue(response.body())

            }
        }
    }
}