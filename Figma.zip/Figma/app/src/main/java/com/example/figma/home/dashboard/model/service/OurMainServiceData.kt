package com.example.figma.home.dashboard.model.service


import com.google.gson.annotations.SerializedName

data class OurMainServiceData(
    @SerializedName("code")
    val code: Int,
    @SerializedName("data")
    val `data`: MainServiceData,
    @SerializedName("msg")
    val msg: String,
    @SerializedName("status")
    val status: Int
)