package com.example.figma.authentication.repository

import com.example.figma.authentication.model.LogInRequest
import com.example.figma.authentication.model.LogInRes
import com.example.figma.interfacesApi.UserApi
import retrofit2.Response

class UserRepository {
    suspend fun loginUser(loginRequest: LogInRequest): Response<LogInRes>? {
        return UserApi.getApi()?.loginUser(loginRequest = loginRequest)
    }
}