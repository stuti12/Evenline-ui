package com.example.figma.home.dashboard.model.service


import com.google.gson.annotations.SerializedName

data class HomeServiceRow(
    @SerializedName("id")
    val id: Int,
    @SerializedName("image")
    val image: String,
    @SerializedName("name")
    val name: String
)