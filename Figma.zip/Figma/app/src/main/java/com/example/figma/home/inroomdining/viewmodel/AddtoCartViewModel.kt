package com.example.figma.home.inroomdining.viewmodel

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.figma.home.inroomdining.model.addtocart.AddToCartRequestData
import com.example.figma.home.inroomdining.model.addtocart.AddToCartResponseData
import com.example.figma.interfacesApi.UserApi
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class AddtoCartViewModel : ViewModel() {
    var addToCartData: MutableLiveData<AddToCartResponseData> = MutableLiveData()
    var addToCartDataMessage: MutableLiveData<String> = MutableLiveData()
    fun getaddtocartObserver(): MutableLiveData<String> {
        return addToCartDataMessage
    }

    fun makeAddtoCartApiCall(itemData: AddToCartRequestData) {
        viewModelScope.launch(Dispatchers.IO) {
            val response = UserApi.getApi()?.addToCart(itemData)
            if (response?.isSuccessful == true) {
                if (response.code() == 200) {
                    addToCartDataMessage.postValue(response.body()?.msg)

                }


            }
        }
    }

    fun makeRemoveCartApiCall(itemData: AddToCartRequestData) {
        viewModelScope.launch(Dispatchers.IO) {
            val response = UserApi.getApi()?.addToCart(itemData)
            if (response?.isSuccessful == true) {
                if (response.code() == 200) {
                    addToCartDataMessage.postValue(response.body()?.msg)

                }


            }
        }
    }
}