package com.example.figma.home.dashboard.viewmodel

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.figma.home.dashboard.model.service.OurMainServiceData
import com.example.figma.interfacesApi.UserApi
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class MainServiceViewModel : ViewModel() {
    var mainServiceData: MutableLiveData<OurMainServiceData> = MutableLiveData()
    fun getCurrentStayServiceObserver(): MutableLiveData<OurMainServiceData> {
        return mainServiceData
    }

    fun makeCurrentStayServiceApiCall() {
        viewModelScope.launch(Dispatchers.IO) {
            val response = UserApi.getApi()?.getMainServices()
            mainServiceData.postValue(response?.body())


        }
    }
}