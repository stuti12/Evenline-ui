package com.example.figma.home.frontdesk

import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.figma.databinding.ActivityFrontDeskBinding
import com.example.figma.home.adapter.FrontDeskAdapter
import com.example.figma.home.dashboard.DashboardActivity
import com.example.figma.home.frontdesk.model.GetSubServiceData
import com.example.figma.home.frontdesk.model.SubServiceData
import com.example.figma.home.frontdesk.viewmodel.FrontDeskViewModel

class FrontDeskActivity : AppCompatActivity() {
    private val binding: ActivityFrontDeskBinding by lazy {
        ActivityFrontDeskBinding.inflate(layoutInflater)
    }
    private lateinit var adapter: FrontDeskAdapter
    private val frontDeskViewModel: FrontDeskViewModel by viewModels()
    private var mainID: Int? = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        getIntentData()
        initSubServiceViewModel()
        setUpClickListener()
        setObserver()

    }

    private fun getIntentData() {
        mainID = intent?.getIntExtra("main_service_id", 1)
    }

    private fun setObserver() {
        frontDeskViewModel.getFrontDeskbserver().observe(this, Observer<SubServiceData> {
            if (it != null) {
                adapter.submitList(it.data.rows)
            }
        })
    }

    private fun setUpClickListener() {
        binding.apply {
            arrowImageView.setOnClickListener {
               finish()
            }

        }

    }

    private fun initSubServiceViewModel() {
        frontDeskViewModel.makeSubServiceStayApiCall(GetSubServiceData(84,mainID))
        adapter = FrontDeskAdapter()
        binding.rvServices.layoutManager = LinearLayoutManager(this)
        binding.rvServices.adapter = adapter
    }


}