package com.example.figma.home.housekeeping.viewmodel

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.figma.home.frontdesk.model.GetSubServiceData
import com.example.figma.home.frontdesk.model.SubServiceData
import com.example.figma.interfacesApi.UserApi
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.launch

class HouseKeepingViewModel : ViewModel() {
    var serviceData: MutableLiveData<SubServiceData> = MutableLiveData()
    fun getHousekeepingbserver(): MutableLiveData<SubServiceData> {
        return serviceData
    }

    fun makeSubServiceStayApiCall(data: GetSubServiceData) {
        viewModelScope.launch(Dispatchers.IO) {
            async {
                //val data = GetSubServiceData(data)
                val response = UserApi.getApi()?.getSubServices(data)
                if (response?.isSuccessful == true) {
                    serviceData.postValue(response.body())
                }
            }
        }
    }
}