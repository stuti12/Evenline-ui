package com.example.figma.home.inroomdining.model.addtocart


import com.google.gson.annotations.SerializedName

data class AddToCartResponseData(
    @SerializedName("code")
    val code: Int,
    @SerializedName("data")
    val `data`: CartData,
    @SerializedName("msg")
    val msg: String,
    @SerializedName("status")
    val status: Int
)