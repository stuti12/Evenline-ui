package com.example.figma.home.servicesendreq.model


import com.google.gson.annotations.SerializedName

data class RequestData(
    @SerializedName("hotel_id")
    val hotelId: String,
    @SerializedName("main_service_id")
    val mainServiceId: String,
    @SerializedName("order_id")
    val orderId: String,
    @SerializedName("requested_text")
    val requestedText: String,
    @SerializedName("room_no")
    val roomNo: String,
    @SerializedName("sub_service_id")
    val subServiceId: String,
    @SerializedName("user_id")
    val userId: Int
)

data class GetRequestServiceData(
    @SerializedName("hotel_id")
    val hotelId: Int,
    @SerializedName("sub_service_id")
    val subServiceId: Int,
    @SerializedName("requested_text")
    val requestedText: String?,
    @SerializedName("main_service_id")
    val mainServiceId: Int

)