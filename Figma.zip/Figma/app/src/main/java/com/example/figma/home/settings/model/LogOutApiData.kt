package com.example.figma.home.settings.model


import com.google.gson.annotations.SerializedName

data class LogOutApiData(
    @SerializedName("code")
    val code: Int,
    @SerializedName("data")
    val `data`: Int,
    @SerializedName("msg")
    val msg: String,
    @SerializedName("status")
    val status: Int
)