package com.example.figma.home.adapter

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import coil.load
import com.example.figma.R
import com.example.figma.databinding.HomeItemBinding
import com.example.figma.home.dashboard.model.service.HomeServiceRow
import com.example.figma.home.directory.DirectoryActivity
import com.example.figma.home.frontdesk.FrontDeskActivity
import com.example.figma.home.housekeeping.HouseKeepingActivity
import com.example.figma.home.inroomdining.InRoomDiningActivity
import com.example.figma.home.servicesendreq.SendRequestActivity

/*class HomeAdapter(var context: Context, private val onItemClick: (position: Int) -> Unit)*/
class HomeAdapter(var context: Context) : ListAdapter<HomeServiceRow, HomeAdapter.RecycleGridViewHolder>(RecycleGridDifCallBack()) {
    var dataList = listOf<HomeServiceRow>()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecycleGridViewHolder {
        val binding = HomeItemBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return RecycleGridViewHolder(binding)
    }

    override fun onBindViewHolder(holder: RecycleGridViewHolder, position: Int) {
        val currwntItem = getItem(position)
        holder.bind(currwntItem, position)
        when (holder.adapterPosition) {
            0 -> {
                holder.itemView.setOnClickListener {
                    val intent = Intent(holder.itemView.context, FrontDeskActivity::class.java)
                    intent.putExtra("main_service_id",1)
                    holder.itemView.context.startActivity(intent)
                }
            }
            1 -> {
                holder.itemView.setOnClickListener {
                    val intent = Intent(holder.itemView.context, HouseKeepingActivity::class.java)
                    intent.putExtra("main_service_id",2)
                    holder.itemView.context.startActivity(intent)
                }
            }
            2 -> {
                holder.itemView.setOnClickListener {
                    val intent = Intent(holder.itemView.context, InRoomDiningActivity::class.java)
                    holder.itemView.context.startActivity(intent)
                }
            }
            3 -> {
                holder.itemView.setOnClickListener {
                    val intent = Intent(holder.itemView.context, DirectoryActivity::class.java)
                    holder.itemView.context.startActivity(intent)
                }
            }
        }

    }

    inner class RecycleGridViewHolder(private val binding: HomeItemBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(dataModel: HomeServiceRow, position: Int) {
            binding.apply {
                textHotelService.text = dataModel.name
                //imgService.setImageResource(dataModel.image)
                val url = dataModel.image
                imgService.load(url) {
                    placeholder(R.drawable.ic_dashboard)
                }
            }
            /* itemView.setOnClickListener {
                 onItemClick.invoke(position)
             }*/
        }

    }
}

class RecycleGridDifCallBack : DiffUtil.ItemCallback<HomeServiceRow>() {
    override fun areItemsTheSame(oldItem: HomeServiceRow, newItem: HomeServiceRow): Boolean {
        return oldItem.id == newItem.id
    }

    override fun areContentsTheSame(oldItem: HomeServiceRow, newItem: HomeServiceRow): Boolean {
        return areItemsTheSame(oldItem, newItem)
    }

}
