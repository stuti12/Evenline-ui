package com.example.figma.home.inroomdining.model.addtocart


import com.google.gson.annotations.SerializedName

data class Cart(
    @SerializedName("meal_id")
    val mealId: Int,
    @SerializedName("units")
    val units: Int
)