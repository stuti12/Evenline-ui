package com.example.figma.splash

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.appcompat.app.AppCompatActivity
import com.example.figma.R
import com.example.figma.authentication.SignupActivity
import com.example.figma.databinding.ActivitySplashBinding
import com.example.figma.home.dashboard.DashboardActivity
import com.example.figma.utils.Constants.Companion.TWOTHOUSAND
import com.example.figma.utils.SessionManager
import com.example.figma.utils.isNetworkConnected
import com.google.android.material.snackbar.Snackbar


class SplashActivity : AppCompatActivity() {
    private val binding: ActivitySplashBinding by lazy {
        ActivitySplashBinding.inflate(layoutInflater)
    }
        private lateinit var delay: Handler

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        displaySplashScreen()
    }

    private fun displaySplashScreen() {
        if(isNetworkConnected()) {
            delay = Handler(Looper.getMainLooper())
            delay.postDelayed({
                val token = SessionManager.getToken(this)
                if (!token.isNullOrBlank()) {
                    val intent = Intent(this, DashboardActivity::class.java)
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK)
                    startActivity(intent)
                } else {
                    val intent = Intent(this@SplashActivity, SignupActivity::class.java)
                    startActivity(intent)
                }

                finish()
            }, TWOTHOUSAND.toLong())
        } else {
            Snackbar.make(findViewById(android.R.id.content), getString(R.string.internet_not_available), Snackbar.LENGTH_INDEFINITE
            ).setAction("Retry") {
                if(isNetworkConnected()) {
                    val token = SessionManager.getToken(this)
                    if (!token.isNullOrBlank()) {
                        val intent = Intent(this, DashboardActivity::class.java)
                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK)
                        startActivity(intent)
                    } else {
                        val intent = Intent(this@SplashActivity, SignupActivity::class.java)
                        startActivity(intent)
                    }

                    finish()
                }
            }.show()
        }
    }


    override fun onResume() {
        super.onResume()
        displaySplashScreen()
    }

    override fun onPause() {
        super.onPause()
        delay = Handler(Looper.getMainLooper())
        delay.removeCallbacksAndMessages(null)
    }
}