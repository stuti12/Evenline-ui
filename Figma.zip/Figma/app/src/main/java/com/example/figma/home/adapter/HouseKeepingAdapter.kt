package com.example.figma.home.adapter

import android.content.Context
import android.content.Intent
import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.figma.databinding.ItemServicesBinding
import com.example.figma.home.frontdesk.model.ServiceRow
import com.example.figma.home.servicesendreq.SendRequestActivity

class HouseKeepingAdapter(var context: Context) :
    ListAdapter<ServiceRow, HouseKeepingAdapter.RecycleGridViewHolder>(HouseDifCallBack()) {
    private var dataList = emptyList<ServiceRow>()

    override fun onCreateViewHolder(
        parent: ViewGroup, viewType: Int
    ): RecycleGridViewHolder {
        val binding = ItemServicesBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return RecycleGridViewHolder(binding)
    }

    override fun onBindViewHolder(holder: RecycleGridViewHolder, position: Int) {
        val currwntItem = getItem(position)
        holder.bind(currwntItem)
        holder.cardRow.setOnClickListener {
            val intent = Intent(holder.itemView.context, SendRequestActivity::class.java)
            intent.putExtra("id", currwntItem.id)
            Log.d("id", currwntItem.id.toString())
            intent.putExtra("description", currwntItem.description)
            intent.putExtra("housetitle", "House Keeping")
            holder.itemView.context.startActivity(intent)
        }
    }


    class RecycleGridViewHolder(private val binding: ItemServicesBinding) :
        RecyclerView.ViewHolder(binding.root) {
        val cardRow = binding.cardRow
        fun bind(dataModel: ServiceRow) {
            binding.apply {
                textServices.text = dataModel.name
            }
        }
    }
}

class HouseDifCallBack : DiffUtil.ItemCallback<ServiceRow>() {
    override fun areItemsTheSame(oldItem: ServiceRow, newItem: ServiceRow): Boolean {
        return oldItem.id == newItem.id
    }

    override fun areContentsTheSame(oldItem: ServiceRow, newItem: ServiceRow): Boolean {
        return areItemsTheSame(oldItem, newItem)
    }

}
