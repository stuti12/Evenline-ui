package com.example.figma.home.housekeeping

import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.figma.databinding.ActivityHouseKeepingBinding
import com.example.figma.home.adapter.HouseKeepingAdapter
import com.example.figma.home.dashboard.DashboardActivity
import com.example.figma.home.frontdesk.model.GetSubServiceData
import com.example.figma.home.frontdesk.model.SubServiceData
import com.example.figma.home.housekeeping.viewmodel.HouseKeepingViewModel

class HouseKeepingActivity : AppCompatActivity() {
    private val binding: ActivityHouseKeepingBinding by lazy {
        ActivityHouseKeepingBinding.inflate(layoutInflater)
    }
    private val housekeepingViewModel: HouseKeepingViewModel by viewModels()
    private lateinit var adapter: HouseKeepingAdapter
    private var mainID: Int? = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        getIntentData()
        setAdapter()
        initSubServiceViewModel()
        setUpClickListener()
        setObserver()

    }

    private fun getIntentData() {
        mainID = intent?.getIntExtra("main_service_id", 2)
    }

    private fun setUpClickListener() {
        binding.apply {
            arrowImageView.setOnClickListener {
                finish()
            }
        }
    }

    private fun setObserver() {
        housekeepingViewModel.getHousekeepingbserver().observe(this, Observer<SubServiceData> {
                if (it != null) {
                    //   homeAdapter.setDataList(it.rows)
                    adapter.submitList(it.data.rows)
                }
            })
    }

    private fun setAdapter() {
        binding.apply {
            adapter = HouseKeepingAdapter(this@HouseKeepingActivity)
            rvServices.layoutManager = LinearLayoutManager(this@HouseKeepingActivity)
            rvServices.adapter = adapter
        }
    }

    private fun initSubServiceViewModel() {
        housekeepingViewModel.makeSubServiceStayApiCall(GetSubServiceData(84,mainID))
    }
}