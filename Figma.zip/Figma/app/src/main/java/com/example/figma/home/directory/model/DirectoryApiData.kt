package com.example.figma.home.directory.model


import com.google.gson.annotations.SerializedName

data class DirectoryApiData(
    @SerializedName("code")
    val code: Int,
    @SerializedName("data")
    val `data`: DirectoryData,
    @SerializedName("status")
    val status: Int
)