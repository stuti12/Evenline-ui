package com.example.figma.home.adapter

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.figma.databinding.ItemDirectoryBinding
import com.example.figma.home.directory.model.DirectoryRow

class DirectoryAdapter(var context: Context) :
    ListAdapter<DirectoryRow, DirectoryAdapter.RecycleGridViewHolder>(DirectoryDifCallBack()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecycleGridViewHolder {
        val binding =
            ItemDirectoryBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return RecycleGridViewHolder(binding)
    }

    override fun onBindViewHolder(holder: RecycleGridViewHolder, position: Int) {
        val currwntItem = getItem(position)
        holder.bind(currwntItem)

        //  notifyDataSetChanged()
    }

    class RecycleGridViewHolder(private val binding: ItemDirectoryBinding) :
        RecyclerView.ViewHolder(binding.root) {
        val cardRow = binding.cardDirectoryRow
        fun bind(dataModel: DirectoryRow) {
            binding.apply {
                textServicesDirectory.text = dataModel.name
                textSubtitleDirectory.text = dataModel.number
                imgNext.setOnClickListener {
                    val dialIntent = Intent(Intent.ACTION_DIAL)
                    dialIntent.data = Uri.parse("tel:" + dataModel.number)
                    binding.root.context.startActivity(dialIntent)
                }

            }
        }
    }
}

class DirectoryDifCallBack : DiffUtil.ItemCallback<DirectoryRow>() {
    override fun areItemsTheSame(oldItem: DirectoryRow, newItem: DirectoryRow): Boolean {
        return oldItem.name == newItem.name
    }

    override fun areContentsTheSame(oldItem: DirectoryRow, newItem: DirectoryRow): Boolean {
        return areItemsTheSame(oldItem, newItem)
    }

}