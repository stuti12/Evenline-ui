package com.example.figma.home.directory.model


import com.google.gson.annotations.SerializedName

data class DirectoryRow(
    @SerializedName("email")
    val email: String,
    @SerializedName("name")
    val name: String,
    @SerializedName("number")
    val number: String
)