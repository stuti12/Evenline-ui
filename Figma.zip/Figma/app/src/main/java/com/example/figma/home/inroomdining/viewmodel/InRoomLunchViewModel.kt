package com.example.figma.home.inroomdining.viewmodel

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.figma.home.inroomdining.model.GetInRoomData
import com.example.figma.home.inroomdining.model.InRoomDiningApiData
import com.example.figma.interfacesApi.UserApi
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class InRoomLunchViewModel : ViewModel() {
    var lunchData: MutableLiveData<InRoomDiningApiData> = MutableLiveData()
    fun getLunchObserver(): MutableLiveData<InRoomDiningApiData> {
        return lunchData
    }

    fun makeLunchApiCall() {
        viewModelScope.launch(Dispatchers.IO) {
            val data = GetInRoomData(84, 376)
            val response = UserApi.getApi()?.getDefaultCategoryMeal(data)
            if (response?.isSuccessful == true) {
                lunchData.postValue(response.body())
            }

        }
    }
}