package com.example.figma.home.inroomdining.model


import com.google.gson.annotations.SerializedName

data class Meal(
    @SerializedName("description")
    val description: String,
    @SerializedName("id")
    val id: Int,
    @SerializedName("image")
    val image: String,
    @SerializedName("name")
    val name: String,
    @SerializedName("preparation_time")
    val preparationTime: Int,
    @SerializedName("preparation_unit")
    val preparationUnit: String,
    @SerializedName("price")
    val price: String,
    @SerializedName("unit")
    val unit: String
)