package com.example.myapplication.paging.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.paging.PagingData
import androidx.paging.cachedIn
import com.example.myapplication.paging.data.Repository
import com.example.myapplication.paging.model.User
import kotlinx.coroutines.flow.Flow

class viewModel(val repository: Repository) : ViewModel() {

    val newsResult: Flow<PagingData<User>> = repository.getResult().cachedIn(viewModelScope)

    fun getModelNews(): Flow<PagingData<User>> {
        return newsResult
    }

}

class ViewModelFactory(private val repo: Repository) : ViewModelProvider.Factory {

    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(viewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return viewModel(repo) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")

    }


}