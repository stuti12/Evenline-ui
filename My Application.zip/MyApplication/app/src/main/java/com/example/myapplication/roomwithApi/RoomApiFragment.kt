package com.example.myapplication.roomwithApi

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.RecyclerView
import com.example.myapplication.databinding.FragmentRoomApiBinding
import com.example.myapplication.roomwithApi.adapter.MainAdapter
import com.example.myapplication.roomwithApi.viewmodel.MainFragmentViewModel


class RoomApiFragment : Fragment() {
    private val binding: FragmentRoomApiBinding by lazy {
        FragmentRoomApiBinding.inflate(layoutInflater)
    }
    lateinit var recyclerView: RecyclerView
    private val adapter by lazy { MainAdapter() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        init()
    }

    private fun init() {
        val viewModel = ViewModelProvider(this).get(MainFragmentViewModel::class.java)
        viewModel.initDatabase()
        recyclerView = binding.rvMain
        recyclerView.adapter = adapter
        // viewModel.getMoviesRetrofit()
        viewModel.myMovies.observe(viewLifecycleOwner) { list ->
            println(list)
            Log.d("list", list.size.toString())
            adapter.setList(list)
        }

    }

    override fun onDestroy() {
        super.onDestroy()
        false
    }
}