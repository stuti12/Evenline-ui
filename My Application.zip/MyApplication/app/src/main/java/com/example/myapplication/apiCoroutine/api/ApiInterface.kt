package com.example.myapplication.apiCoroutine.api

import com.example.myapplication.apiCoroutine.model.UserList
import retrofit2.Response
import retrofit2.http.GET

interface ApiInterface {
    @GET("/api/users?delay=3")
    suspend fun getAllResult(): Response<UserList>
}

