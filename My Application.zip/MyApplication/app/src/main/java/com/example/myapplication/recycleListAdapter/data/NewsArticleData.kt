package com.example.myapplication.recycleListAdapter.data

data class Blog(
    var title: String
)