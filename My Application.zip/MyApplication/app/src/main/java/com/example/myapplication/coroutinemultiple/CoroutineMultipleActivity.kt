package com.example.myapplication.coroutinemultiple

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentTransaction
import com.example.myapplication.databinding.ActivityCoroutineMultipleBinding

class CoroutineMultipleActivity : AppCompatActivity() {
    private lateinit var binding: ActivityCoroutineMultipleBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        binding = ActivityCoroutineMultipleBinding.inflate(layoutInflater)
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        setFragment()
    }

    private fun setFragment() {
        val fragment = RecycleListFragment.newInstance()
        val fragmentManager: FragmentManager = supportFragmentManager
        val fragmentTransaction: FragmentTransaction = fragmentManager.beginTransaction()
        fragmentTransaction.replace(android.R.id.content, fragment)
        fragmentTransaction.commit()
    }
}