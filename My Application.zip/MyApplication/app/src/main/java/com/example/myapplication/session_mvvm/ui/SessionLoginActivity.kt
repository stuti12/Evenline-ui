package com.example.myapplication.session_mvvm.ui

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.MotionEvent
import android.view.View
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import com.example.myapplication.apiCoroutine.view.ApiCallCoroutineActivity
import com.example.myapplication.databinding.ActivitySessionLoginBinding
import com.example.myapplication.session_mvvm.SessionManager
import com.example.myapplication.session_mvvm.models.BaseResponse
import com.example.myapplication.session_mvvm.models.LogInResponse
import com.example.myapplication.session_mvvm.viewmodel.LoginViewModel
import com.example.myapplication.utils.hideKeyboard


class SessionLoginActivity : AppCompatActivity() {
    private lateinit var binding: ActivitySessionLoginBinding
    private val viewModel by viewModels<LoginViewModel>()

    override fun onCreate(savedInstanceState: Bundle?) {
        binding = ActivitySessionLoginBinding.inflate(layoutInflater)
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        val token = SessionManager.getToken(this)
        if (!token.isNullOrBlank()) {
            navigateToHome()
        }
        observe()
        setListener()
    }

    override fun dispatchTouchEvent(ev: MotionEvent?): Boolean {
        if (currentFocus != null) {
            binding.sessionLoginView.hideKeyboard()
        }
        return super.dispatchTouchEvent(ev)
    }

    private fun observe() {
        viewModel.loginResult.observe(this) {
            when (it) {
                is BaseResponse.Loading -> {
                    showLoading()
                }

                is BaseResponse.Success -> {
                    stopLoading()
                    processLogin(it.data)
                }

                is BaseResponse.Error -> {
                    processError(it.msg)
                    stopLoading()
                }
                else -> {
                    stopLoading()
                }
            }
        }

    }

    private fun setListener() {
        val email = binding.txtInputEmail.text
        binding.txtInputEmail.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                if (email.isNullOrEmpty()) {
                    binding.txtLayEmailAdd.error = "Please Enter Emai;"
                } else {
                    binding.txtLayEmailAdd.error = null
                }
            }

            override fun afterTextChanged(s: Editable?) {
            }

        })
        binding.txtPass.addTextChangedListener(object : TextWatcher {
            val pass = binding.txtPass.text
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                if (pass.isNullOrEmpty()) {
                    binding.txtLayPassSignup.error = "Missing Password"
                } else {
                    binding.txtLayPassSignup.error = null
                }
            }

            override fun afterTextChanged(s: Editable?) {
            }

        })
        binding.btnLogin.setOnClickListener {
            val email = binding.txtInputEmail.text
            val pass = binding.txtPass.text
            if (email.isNullOrEmpty() || pass.isNullOrEmpty()) {
                binding.txtLayEmailAdd.error = "Missing Credential"
                binding.txtLayPassSignup.error = "Missing Credential"
            } else {
                binding.txtLayEmailAdd.error = null
                binding.txtLayPassSignup.error = null
            }
            doLogin()

        }

        binding.btnRegister.setOnClickListener {
            startActivity(Intent(this, SessionSignUpActivity::class.java))
            finish()
        }
    }

    private fun navigateToHome() {
        val intent = Intent(this, ApiCallCoroutineActivity::class.java)
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK)
        intent.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY)
        startActivity(intent)
        finish()
    }

    fun doLogin() {
        val email = binding.txtInputEmail.text.toString()
        val pwd = binding.txtPass.text.toString()
        viewModel.loginUser(email = email, pwd = pwd)

    }

    private fun showLoading() {
        binding.prgbar.visibility = View.VISIBLE
    }

    fun stopLoading() {
        binding.prgbar.visibility = View.GONE
    }

    private fun processLogin(data: LogInResponse?) {
        if (data != null) {
            SessionManager.saveAuthToken(this, data.token)
        }
        showToast(data?.token.toString())
    }

    private fun processError(msg: String?) {
        showToast("Error:" + msg)
    }

    private fun showToast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }
}