package com.example.myapplication.intentfilter

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.myapplication.databinding.ActivityIntentFilterBinding

class IntentFilterActivity : AppCompatActivity() {
    private lateinit var binding: ActivityIntentFilterBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        binding = ActivityIntentFilterBinding.inflate(layoutInflater)
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        setListener()
    }

    private fun setListener() {
        binding.apply {
            sendButton.setOnClickListener {
                var intent = Intent(Intent.ACTION_SEND) // intent
                intent.type = "text/plain"
                intent.putExtra(Intent.EXTRA_EMAIL, "niranjantest@gmail.com")
                intent.putExtra(Intent.EXTRA_SUBJECT, "This is a dummy message")
                intent.putExtra(Intent.EXTRA_TEXT, "Dummy test message")
                startActivity(intent)
            }
            buttonView.setOnClickListener {
                var intent = Intent(Intent.ACTION_VIEW)
                startActivity(intent)
            }
        }
    }
}