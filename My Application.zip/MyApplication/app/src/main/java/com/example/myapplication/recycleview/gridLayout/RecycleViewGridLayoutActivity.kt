package com.example.myapplication.recycleview.gridLayout

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import com.example.myapplication.R
import com.example.myapplication.databinding.ActivityRecycleViewGridLayoutBinding

class RecycleViewGridLayoutActivity : AppCompatActivity() {
    private lateinit var binding: ActivityRecycleViewGridLayoutBinding
    private lateinit var photoAdapter: RecycleGridAdapter
    private var dataList = listOf<DataModel>()

    override fun onCreate(savedInstanceState: Bundle?) {
        binding = ActivityRecycleViewGridLayoutBinding.inflate(layoutInflater)
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        setAdapter()
    }

    private fun setAdapter() {
        binding.apply {
            photoAdapter = RecycleGridAdapter(this@RecycleViewGridLayoutActivity)
            rvGrid.layoutManager = GridLayoutManager(this@RecycleViewGridLayoutActivity, 2)
            rvGrid.adapter = photoAdapter
            // dataList = GridDataSet.list
            dataList = listOf(
                DataModel(
                    getString(R.string.titleOne),
                    getString(R.string.newsDataTwo),
                    R.drawable.ic_check
                ),
                DataModel(
                    getString(R.string.newsDataTwo),
                    getString(R.string.newsDataSix),
                    R.drawable.ic_check
                ),
                DataModel(
                    getString(R.string.newsDataTwo),
                    getString(R.string.newsDataSix),
                    R.drawable.ic_check
                ), DataModel(
                    getString(R.string.newsDataTwo),
                    getString(R.string.newsDataSix),
                    R.drawable.ic_check
                ), DataModel(
                    getString(R.string.newsDataTwo),
                    getString(R.string.newsDataSix),
                    R.drawable.ic_check
                )
            )
            photoAdapter.submitList(dataList)

        }

    }
}