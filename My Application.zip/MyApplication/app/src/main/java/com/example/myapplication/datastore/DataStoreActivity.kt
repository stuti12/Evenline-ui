package com.example.myapplication.datastore

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.asLiveData
import androidx.lifecycle.lifecycleScope
import com.example.myapplication.databinding.ActivityDataStoreBinding
import com.example.myapplication.utils.toast
import kotlinx.android.synthetic.main.activity_data_store.*
import kotlinx.coroutines.launch

class DataStoreActivity : AppCompatActivity() {
    private lateinit var binding: ActivityDataStoreBinding
    private lateinit var userManager: UserManager
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDataStoreBinding.inflate(layoutInflater)
        setContentView(binding.root)
        userManager = UserManager(applicationContext)
        set()
        observeData()
    }

    private fun set() {
        binding.apply {
            btnSave.setOnClickListener {
                storeUser()

            }
        }
    }

    private fun storeUser() {
        val name = etName.text.toString()
        val age = etAge.text.toString().toInt()

        lifecycleScope.launch {
            userManager.storeData(age, name)
            toast("User Saved")
            binding.etAge.text?.clear()
            binding.etName.text?.clear()
        }
    }

    private fun observeData() {
        userManager.userAgeFlow.asLiveData().observe(this) { age ->
            age?.let {
                binding.textAge.text = "Age $age"
            }
        }
        userManager.userNameFlow.asLiveData().observe(this) { name ->
            name?.let {
                binding.textName.text = "Name $name"
            }
        }
    }
}