package com.example.myapplication.lifecycle

import android.app.DatePickerDialog
import android.os.Bundle
import android.util.Log
import android.view.MotionEvent
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import androidx.appcompat.app.AppCompatActivity
import com.example.myapplication.R
import com.example.myapplication.databinding.ActivityLifecycleBinding
import com.example.myapplication.utils.hideKeyboard
import com.example.myapplication.utils.toast
import kotlinx.android.synthetic.main.activity_lifecycle.*
import java.util.*


class LifecycleActivity : AppCompatActivity(), AdapterView.OnItemSelectedListener,
    View.OnClickListener {
    private lateinit var binding: ActivityLifecycleBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        binding = ActivityLifecycleBinding.inflate(layoutInflater)
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        Log.d("On Create", getString(R.string.textOnCreate))
        et_feedback_grid.setOnClickListener(this)
        binding.tvTitleGrid.text = getString(R.string.textOnCreate)
        showSpinner()
    }

    override fun onStart() {
        super.onStart()
        binding.tvTitleGrid.text = getString(R.string.textOnStart)
        this.toast(getString(R.string.textOnStart))
        Log.d("OnStart", getString(R.string.textOnStart))
    }

    override fun onPause() {
        super.onPause()
        this.toast(getString(R.string.textOnPause))
        binding.tvTitleGrid.text = getString(R.string.textOnPause)
        Log.d("OnPause", getString(R.string.textOnPause))
    }

    override fun onResume() {
        this.toast(getString(R.string.textOnResume))
        super.onResume()
        Log.d("OnResume", getString(R.string.textOnResume))
    }

    override fun onStop() {
        super.onStop()
        this.toast(getString(R.string.textOnStop))
        Log.d("OnCStop", getString(R.string.textOnStop))
    }

    override fun onDestroy() {
        super.onDestroy()
        this.toast(getString(R.string.textOnDestroy))
        Log.d("OnDestroy", getString(R.string.textOnDestroy))

    }

    private fun showSpinner() {
        title = "KotlinApp"
        val adapter = ArrayAdapter.createFromResource(
            this,
            R.array.birds,
            android.R.layout.simple_spinner_item
        )
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.spPraiseGrid.adapter = adapter
        binding.spPraiseGrid.onItemSelectedListener = this@LifecycleActivity
    }

    override fun onNothingSelected(parent: AdapterView<*>?) {
    }

    override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
        val text: String = parent?.getItemAtPosition(position).toString()
        binding.tvTitleGrid.text = text
    }

    override fun onClick(v: View?) {
        val mYear: Int
        val mMonth: Int
        val mDay: Int
        if (v == binding.etFeedbackGrid) {
            val calendar: Calendar = Calendar.getInstance();

            mYear = calendar.get(Calendar.YEAR);
            mMonth = calendar.get(Calendar.MONTH);
            mDay = calendar.get(Calendar.DAY_OF_MONTH);
            val datePickerDialog = DatePickerDialog(
                this,
                { view, year, month, dayOfMonth -> binding.etFeedbackGrid.setText(dayOfMonth.toString() + "/" + (month + 1) + "/" + year) },
                mYear,
                mMonth,
                mDay
            )
            datePickerDialog.show()
        }
    }

    override fun dispatchTouchEvent(ev: MotionEvent?): Boolean {
        if (currentFocus != null) {
            binding.viewLogin.hideKeyboard()
        }
        return super.dispatchTouchEvent(ev)
    }
}