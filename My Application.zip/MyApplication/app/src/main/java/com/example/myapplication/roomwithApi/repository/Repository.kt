package com.example.myapplication.roomwithApi.repository

import com.example.myapplication.roomwithApi.model.MovieItemModel
import com.example.myapplication.roomwithApi.room.MoviesDao

interface MoviesRepository {

    //  val allMovies: LiveData<List<MovieItemModel>>

    suspend fun insertMovie(movieItemModel: MovieItemModel, onSuccess: () -> Unit)

    suspend fun deleteMovie(movieItemModel: MovieItemModel, onSuccess: () -> Unit)

}

class MoviesRepositoryRealization(private val moviesDao: MoviesDao) : MoviesRepository {
    //override val allMovies: LiveData<List<MovieItemModel>>
    //  get() = moviesDao.getAllMovies()
    override suspend fun insertMovie(movieItemModel: MovieItemModel, onSuccess: () -> Unit) {
        //   moviesDao.insert(movieItemModel)
        //  onSuccess()
    }

    override suspend fun deleteMovie(movieItemModel: MovieItemModel, onSuccess: () -> Unit) {
        moviesDao.delete(movieItemModel)
        onSuccess()
    }

}