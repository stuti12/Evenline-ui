package com.example.myapplication.roomwithApi.viewmodel

import android.app.Application
import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.example.myapplication.roomwithApi.api.RetrofitRepository
import com.example.myapplication.roomwithApi.model.MovieItemModel
import com.example.myapplication.roomwithApi.model.MoviesModel
import com.example.myapplication.roomwithApi.room.MoviesRoomDatabase
import com.example.myapplication.utils.toast
import kotlinx.coroutines.launch


class MainFragmentViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = RetrofitRepository()

    val myMovies: MutableLiveData<List<MovieItemModel>> = MutableLiveData()
    val movies: List<MoviesModel> = emptyList()
    val context = application
    fun getMoviesRetrofit() {
        viewModelScope.launch() {
            myMovies.value = repository.getMovie().body()?.results
            val daoMovie = MoviesRoomDatabase.getInstance(context).getMovieDao()
            myMovies.value?.let { daoMovie.insert(it) }
        }
    }

    fun initDatabase() {
        if (checkForInternet(context)) {
            getMoviesRetrofit()
        } else {
            context.toast("Plz check internet")
            val daoMovie = MoviesRoomDatabase.getInstance(context).getMovieDao()
            myMovies.value = daoMovie.getAllMovies()
            Log.d("list", myMovies.value.toString())

            // REALIZATION = MoviesRepositoryRealization(daoMovie)
        }
    }

    private fun checkForInternet(context: Context): Boolean {
        val connectivityManager =
            context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val network = connectivityManager.activeNetwork ?: return false
            val activeNetwork = connectivityManager.getNetworkCapabilities(network) ?: return false
            return when {
                activeNetwork.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> true
                activeNetwork.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> true
                else -> false
            }
        } else {
            // if the android version is below M
            @Suppress("DEPRECATION") val networkInfo =
                connectivityManager.activeNetworkInfo ?: return false
            @Suppress("DEPRECATION")
            return networkInfo.isConnected
        }
    }
}