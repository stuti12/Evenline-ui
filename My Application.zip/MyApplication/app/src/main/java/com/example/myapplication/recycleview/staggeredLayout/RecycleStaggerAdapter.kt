package com.example.myapplication.recycleview.nestedRecycle

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.myapplication.databinding.RecycleviewGridBinding
import com.example.myapplication.recycleview.gridLayout.DataModel


class RecycleStaggerAdapter(var context: Context) :
    ListAdapter<DataModel, RecycleStaggerAdapter.RecycleGridViewHolder>(RecycleStaggerDifCallBack()) {
    var dataList = emptyList<DataModel>()

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): RecycleGridViewHolder {
        val binding =
            RecycleviewGridBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return RecycleGridViewHolder(binding)
    }

    override fun onBindViewHolder(holder: RecycleGridViewHolder, position: Int) {
        val currwntItem = getItem(position)
        holder.bind(currwntItem)
        //  notifyDataSetChanged()
    }

    internal fun setDataList(dataList: List<DataModel>) {
        this.dataList = dataList
    }

    class RecycleGridViewHolder(private val binding: RecycleviewGridBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(dataModel: DataModel) {
            binding.apply {
                textTitleGrid.text = dataModel.title
                textDescGrid.text = dataModel.desc
                imageGrid.setImageResource(dataModel.image)
            }
        }
    }
}

class RecycleStaggerDifCallBack : DiffUtil.ItemCallback<DataModel>() {
    override fun areItemsTheSame(oldItem: DataModel, newItem: DataModel): Boolean {
        return oldItem.title == newItem.title
    }

    override fun areContentsTheSame(oldItem: DataModel, newItem: DataModel): Boolean {
        return areItemsTheSame(oldItem, newItem)
    }

}