package com.example.myapplication.video

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.myapplication.R
import com.example.myapplication.databinding.ActivityVideoPlayBinding
import com.google.android.exoplayer2.DefaultLoadControl
import com.google.android.exoplayer2.DefaultRenderersFactory
import com.google.android.exoplayer2.ExoPlayer
import com.google.android.exoplayer2.source.ProgressiveMediaSource
import com.google.android.exoplayer2.trackselection.DefaultTrackSelector
import com.google.android.exoplayer2.upstream.DefaultDataSourceFactory
import com.google.android.exoplayer2.util.Util
import kotlinx.android.synthetic.main.activity_video_play.ep_video_view
import java.io.File


class VideoPlayActivity : AppCompatActivity() {
    private val binding: ActivityVideoPlayBinding by lazy {
        ActivityVideoPlayBinding.inflate(layoutInflater)
    }
    private lateinit var exoPlayer: ExoPlayer
    private var uri = ""

    companion object {
        fun start(context: Context, uri: String?) {
            val intent = Intent(context, VideoPlayActivity::class.java)
                .putExtra("uri", uri)
            context.startActivity(intent)
        }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)

        intent?.extras?.let {
            uri = it.getString("uri", "")
        }
        initializePlayer()
    }
    private fun initializePlayer() {

        val trackSelector = DefaultTrackSelector(this)
        val loadControl = DefaultLoadControl()
        val rendererFactory = DefaultRenderersFactory(this)

        exoPlayer = ExoPlayer.Builder(this, rendererFactory)
            .setLoadControl(loadControl)
            .setTrackSelector(trackSelector)
            .build()
    }
    private fun play(uri: Uri) {

        val userAgent = Util.getUserAgent(this, getString(R.string.app_name))
        val mediaSource = ProgressiveMediaSource
            .Factory(DefaultDataSourceFactory(this, userAgent))
            .createMediaSource(uri)

        ep_video_view.player = exoPlayer

        exoPlayer.setMediaSource(mediaSource)
        exoPlayer.playWhenReady = true
    }

    override fun onStart() {
        super.onStart()
        playVideo()
    }

    private fun playVideo() {
        val file = File(uri)
        val localUri = Uri.fromFile(file)
        play(localUri)
    }

    override fun onStop() {
        super.onStop()
        exoPlayer.stop()
        exoPlayer.release()
    }

}