package com.example.myapplication.moshi

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import coil.load
import com.example.myapplication.databinding.ItemBookmarkGridBinding
import com.example.myapplication.moshi.model.GetUserResponse


class UsersRecyclerAdapter : ListAdapter<GetUserResponse.UserX, UsersRecyclerAdapter.UserRecyclerViewHolder>(UsersDiffUtilCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): UserRecyclerViewHolder {
        val binding = ItemBookmarkGridBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return UserRecyclerViewHolder(binding)
    }

    override fun onBindViewHolder(holder: UserRecyclerViewHolder, position: Int) {
        val currentItem = getItem(position)
        holder.bind(currentItem)

    }
    class UsersDiffUtilCallback: DiffUtil.ItemCallback<GetUserResponse.UserX>(){
        override fun areItemsTheSame(
            oldItem: GetUserResponse.UserX,
            newItem: GetUserResponse.UserX
        ): Boolean {
            return oldItem == newItem
        }

        override fun areContentsTheSame(
            oldItem: GetUserResponse.UserX,
            newItem: GetUserResponse.UserX
        ): Boolean {
            return oldItem == newItem
        }

    }
    class UserRecyclerViewHolder(val binding: ItemBookmarkGridBinding): RecyclerView.ViewHolder(binding.root) {
        fun bind(dataModel: GetUserResponse.UserX) {
        binding.apply {
            imgBookmark.load(dataModel.profilePicture)
            textName.text = dataModel.firstName+dataModel.lastName
        }
        }
    }
}
