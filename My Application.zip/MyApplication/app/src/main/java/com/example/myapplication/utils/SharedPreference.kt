package com.example.myapplication.utils

import android.content.Context
import android.content.SharedPreferences


class PrefManager internal constructor(context: Context) {
    var context: Context
    fun saveLoginDetails(email: String?, password: String?) {
        val sharedPreferences: SharedPreferences =
            context.getSharedPreferences("LoginDetails", Context.MODE_PRIVATE)
        val editor = sharedPreferences.edit()
        editor.putString("Email", email)
        editor.putString("Password", password)
        editor.commit()
    }

    val email: String?
        get() {
            val sharedPreferences: SharedPreferences =
                context.getSharedPreferences("LoginDetails", Context.MODE_PRIVATE)
            return sharedPreferences.getString("Email", "")
        }
    val isUserLogedOut: Boolean
        get() {
            val sharedPreferences: SharedPreferences =
                context.getSharedPreferences("LoginDetails", Context.MODE_PRIVATE)
            val isEmailEmpty = sharedPreferences.getString("Email", "")!!.isEmpty()
            val isPasswordEmpty = sharedPreferences.getString("Password", "")!!.isEmpty()
            return isEmailEmpty || isPasswordEmpty
        }

    init {
        this.context = context
    }
}