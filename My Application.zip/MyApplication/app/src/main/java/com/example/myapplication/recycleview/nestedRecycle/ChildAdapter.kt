package com.example.myapplication.recycleview.nestedRecycle

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.myapplication.R

class ChildItemAdapter  // Constructor
internal constructor(private val ChildItemList: List<ChildItem>) :
    RecyclerView.Adapter<ChildItemAdapter.ChildViewHolder>() {
    override fun onCreateViewHolder(
        viewGroup: ViewGroup,
        i: Int
    ): ChildViewHolder {

        val view: View = LayoutInflater
            .from(viewGroup.context)
            .inflate(
                R.layout.nested_recycle_child_item,
                viewGroup, false
            )
        return ChildViewHolder(view)
    }

    override fun onBindViewHolder(
        childViewHolder: ChildViewHolder,
        position: Int
    ) {

        val childItem = ChildItemList[position]

        childViewHolder.ChildItemTitle.text = childItem.childItemTitle
    }

    override fun getItemCount(): Int {
        return ChildItemList.size
    }

    inner class ChildViewHolder(itemView: View) :
        RecyclerView.ViewHolder(itemView) {
        var ChildItemTitle: TextView

        init {
            ChildItemTitle = itemView.findViewById(
                R.id.child_item_title
            )
        }
    }
}

/*
class ChildAdapter: ListAdapter<ChildItem,ChildAdapter.ChildViewHolder>(RecycleNestedChildDiffCallBack()) {
    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): ChildViewHolder {
        val binding = NestedRecycleChildItemBinding.inflate(LayoutInflater.from(parent.context),parent,false)
        return ChildViewHolder(binding)
    }

    override fun onBindViewHolder(holder: RecyclerView.ChildViewHolder, position: Int) {

    }
    class ChildViewHolder(private val binding:NestedRecycleChildItemBinding): RecyclerView.ViewHolder(binding.root) {
        fun bind(item: ChildItem) {
            binding.apply {

            }
        }
    }
}

class RecycleNestedChildDiffCallBack: DiffUtil.ItemCallback<ChildItem> () {
    override fun areItemsTheSame(oldItem: ChildItem, newItem: ChildItem): Boolean {
        return oldItem.childItemTitle == newItem.childItemTitle
    }

    override fun areContentsTheSame(oldItem: ChildItem, newItem: ChildItem): Boolean {
        return  areItemsTheSame(oldItem, newItem)
    }

}*/
