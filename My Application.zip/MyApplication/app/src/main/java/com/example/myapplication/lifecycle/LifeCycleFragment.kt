package com.example.myapplication.lifecycle

import android.content.Context
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.example.myapplication.R
import com.example.myapplication.databinding.FragmentLifeCycleBinding
import com.example.myapplication.utils.toast
import timber.log.Timber

class LifeCycleFragment : Fragment() {
    private lateinit var binding: FragmentLifeCycleBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentLifeCycleBinding.inflate(inflater, container, false)
        requireActivity().toast(getString(R.string.textOnCreateView))
        Log.d("OnCreateView", getString(R.string.textOnCreateView))
        return binding.root
    }

    override fun onAttach(context: Context) {
        super.onAttach(context)
        requireActivity().toast(getString(R.string.textOnAttach))
        Timber.d("", "")
        Log.d("OnAttach", getString(R.string.textOnAttach))
    }


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        requireActivity().toast(getString(R.string.trextOnViewCreated))
        Log.d("OnView", getString(R.string.textOnActivityCreated))
    }

    override fun onStart() {
        super.onStart()
        requireActivity().toast(getString(R.string.textOnStart))
        Log.d("OnStart", getString(R.string.textOnStart))
    }

    override fun onResume() {
        super.onResume()
        binding.textTitleFragment.text = getString(R.string.textOnResume)
        requireActivity().toast(getString(R.string.textOnResume))
        Log.d("OnResume", getString(R.string.textOnResume))
    }

    override fun onStop() {
        super.onStop()
        requireActivity().toast(getString(R.string.textOnStop))
        Log.d("OnCStop", getString(R.string.textOnStop))
    }

    override fun onPause() {
        super.onPause()
        requireActivity().toast(getString(R.string.textOnPause))
        Log.d("OnPause", getString(R.string.textOnPause))
    }

    override fun onDestroyView() {
        super.onDestroyView()
        requireActivity().toast(getString(R.string.textOnDestroyView))
        Log.d("OnDestroy", getString(R.string.textOnDestroyView))
    }

    override fun onDestroy() {
        super.onDestroy()
        requireActivity().toast(getString(R.string.textOnDestroy))
        Log.d("OnDestroy", getString(R.string.textOnDestroy))
    }

    override fun onDetach() {
        super.onDetach()
        requireActivity().toast(getString(R.string.textOnDetach))
        Log.d("OnDetech", getString(R.string.textOnDetach))
    }

    companion object {
        @JvmStatic
        fun newInstance() = LifeCycleFragment
    }
}