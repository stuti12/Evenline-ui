package com.example.myapplication.apiMVVM.network

import com.example.myapplication.apiMVVM.model.RepositoriesList
import retrofit2.Call
import retrofit2.http.GET

interface RetroServiceInterface {

    @GET("users")
    fun getDataFromAPI(): Call<RepositoriesList>
}