package com.example.myapplication.coroutinemultiple.model

import com.google.gson.annotations.SerializedName
import kotlinx.serialization.Serializable

@Serializable
data class RecycleList(val items: ArrayList<RecycleData>)

@Serializable
data class RecycleData(
    @SerializedName("name") val name: String,
    @SerializedName("description") val description: String,
    @SerializedName("owner") val owner: Owner
)

@Serializable
data class Owner(@SerializedName("avatar_url") val avtar_url: String)
