package com.example.myapplication.dependecyinje

/*
class UserRegistrationService @Inject constructor( private val userRepo: UserRepository,
    private val emailService: EmailService
    ){
        fun registerUser(email:String,password:String) {
            userRepo.saveUser(email,password)
            emailService.send(email,"stuti@gmail.com","user registered")
    }
}

class UserRepository @Inject constructor(){
    fun saveUser(email:String,password:String) {
        Log.d("tag","User Saved")
    }
}

class EmailService @Inject constructor(){
    fun send(to:String,from:String,body:String) {
        Log.d("tag","Email Sent")
    }
}*/
