package com.example.myapplication.workmanager

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.View
import androidx.activity.result.ActivityResultLauncher
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.net.toUri
import androidx.work.*
import com.example.myapplication.databinding.ActivityWorkManagerBinding
import com.example.myapplication.utils.toast

class WorkManagerActivity : AppCompatActivity() {
    private lateinit var requestMultiplePermission: ActivityResultLauncher<Array<String>>
    lateinit var workManager: WorkManager

    private val binding: ActivityWorkManagerBinding by lazy {
        ActivityWorkManagerBinding.inflate(layoutInflater)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        workManager = WorkManager.getInstance(this)

        binding.btnStartDownload.setOnClickListener {
            startDownloadingFile()
            binding.btnOpenFile.visibility = View.GONE
        }
        if (!checkPermission(Manifest.permission.READ_EXTERNAL_STORAGE) && !checkPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(
                    Manifest.permission.READ_EXTERNAL_STORAGE,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE
                ),
                201
            )
        }
    }

    private fun checkPermission(permission: String): Boolean {
        return ContextCompat.checkSelfPermission(
            this,
            permission
        ) == PackageManager.PERMISSION_GRANTED
    }

    private fun startDownloadingFile(
    ) {
        val constraints = Constraints.Builder()
            .setRequiredNetworkType(NetworkType.CONNECTED)
            .setRequiresStorageNotLow(true)
            .setRequiresBatteryNotLow(true)
            .build()
        val data = Data.Builder()

        data.apply {
            putString(KEY_FILE_NAME, "sample.pdf")
            putString(KEY_FILE_URL, "https://www.clickdimensions.com/links/TestPDFfile.pdf")
            putString(KEY_FILE_TYPE, "PDF")
        }

        val oneTimeWorkRequest = OneTimeWorkRequest.Builder(FileDownloadWorker::class.java)
            .setConstraints(constraints)
            .setInputData(data.build())
            .build()

        workManager.enqueue(oneTimeWorkRequest)

        workManager.getWorkInfoByIdLiveData(oneTimeWorkRequest.id)
            .observe(this) { info ->
                info?.let {
                    when (it.state) {
                        WorkInfo.State.SUCCEEDED -> {
                            val uri = it.outputData.getString(KEY_FILE_URI)
                            uri?.let {
                                binding.btnOpenFile.text = "Open File"
                                binding.btnOpenFile.visibility = View.VISIBLE
                                binding.btnOpenFile.setOnClickListener {
                                    val intent = Intent(Intent.ACTION_VIEW)
                                    intent.setDataAndType(uri.toUri(), "application/pdf")
                                    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                    try {

                                        val pdf =
                                            "https://www.clickdimensions.com/links/TestPDFfile.pdf"
                                        //by loading in webview
                                        binding.webViewShow.loadUrl("https://drive.google.com/viewerng/viewer?embedded=true&url=$pdf")
                                        binding.btnOpenFile.visibility = View.GONE
                                        binding.btnStartDownload.visibility = View.GONE

                                        //by intent
                                        // startActivity(intent)
                                    } catch (e: ActivityNotFoundException) {
                                        toast("Cant open pdf")
                                    }
                                }
                            }
                        }
                        WorkInfo.State.FAILED -> {
                            binding.btnOpenFile.text = "Download in failed"
                        }
                        WorkInfo.State.RUNNING -> {
                            binding.btnOpenFile.text = "Download in progress.."
                        }
                        else -> {

                        }
                    }
                }
            }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 201) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

            } else {
                toast("Permission Denied")
            }
        }
    }

}