package com.example.myapplication.paging

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.isVisible
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import androidx.paging.LoadState
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.example.myapplication.databinding.ActivityPagingBinding
import com.example.myapplication.paging.adapter.Adapter
import com.example.myapplication.paging.adapter.NewsAdapter
import com.example.myapplication.paging.data.Repository
import com.example.myapplication.paging.network.Api
import com.example.myapplication.paging.viewmodel.ViewModelFactory
import com.example.myapplication.paging.viewmodel.viewModel
import kotlinx.android.synthetic.main.activity_paging.button
import kotlinx.android.synthetic.main.activity_paging.progressbar
import kotlinx.android.synthetic.main.activity_paging.recyclerViewPaging
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.distinctUntilChangedBy
import kotlinx.coroutines.flow.filter
import kotlinx.coroutines.launch

class PagingActivity : AppCompatActivity() , SwipeRefreshLayout.OnRefreshListener{
    lateinit var viewModel: viewModel
    private val adpt = NewsAdapter()

    private lateinit var binding: ActivityPagingBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPagingBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val ap = Api()
        val repo = Repository(ap)
        val factory = ViewModelFactory(repo)
        viewModel = ViewModelProvider(
            this,
            factory
        ).get(com.example.myapplication.paging.viewmodel.viewModel::class.java)

        initAdapter()
        loadData()

        binding.swipeRefreshLayout.setOnRefreshListener(this@PagingActivity)
        binding?.swipeRefreshLayout?.setDistanceToTriggerSync(700)
    }

    private fun loadData() {
        lifecycleScope.launch {
            viewModel.getModelNews().collectLatest { pageData ->
                adpt.submitData(pageData)

            }
        }

        lifecycleScope.launch {
            adpt.loadStateFlow
                .distinctUntilChangedBy { it.refresh }
                .filter { it.refresh is LoadState.NotLoading }
                .collect { recyclerViewPaging.scrollToPosition(0) }
        }
    }

    private fun initAdapter() {
        recyclerViewPaging.adapter = adpt.withLoadStateHeaderAndFooter(
            header = Adapter { adpt.retry() },
            footer = Adapter { adpt.retry() }
        )
        adpt.addLoadStateListener { loadState ->
            recyclerViewPaging.isVisible = loadState.source.refresh is LoadState.NotLoading
            progressbar.isVisible = loadState.source.refresh is LoadState.Loading
            button.isVisible = loadState.source.refresh is LoadState.Error
        }

    }

    override fun onRefresh() {
        loadData()
        binding.swipeRefreshLayout.isRefreshing = false
    }
}