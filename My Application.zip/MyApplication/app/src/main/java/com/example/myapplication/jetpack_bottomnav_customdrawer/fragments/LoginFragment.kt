package com.example.myapplication.jetpack_bottomnav_customdrawer.fragments

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.widget.doOnTextChanged
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.myapplication.R
import com.example.myapplication.databinding.FragmentLoginBinding

class LoginFragment : Fragment() {

    private lateinit var _binding: FragmentLoginBinding
    // val signinViewModel: LoginViewModel by viewModels()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = DataBindingUtil.inflate(inflater, R.layout.fragment_login, container, false)
        return _binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        //     observeData()
        _binding.apply {

            //  textUserName.setText(args.username)
            btnSignIn.setOnClickListener {
                if (etEmail.text.isNullOrEmpty() || etPassword.text.isNullOrEmpty()) {
                    tflayoutEmail.error = getString(R.string.requireEmailError)
                    tflayoutPassword.error = getString(R.string.requirePasswordError)
                } else {
                    tflayoutEmail.error = null
                    tflayoutPassword.error = null

                    val username = etEmail.text.toString()
                    val password = etPassword.text.toString()
                    val action = LoginFragmentDirections.actionLoginFragmentToWelcomeFragment(username, password)
                    findNavController().navigate(action)
                }

            }
            etEmail.doOnTextChanged { text, start, before, count ->
                if (etEmail.text.isNullOrEmpty()) {
                    tflayoutEmail.error = getString(R.string.requireEmailError)
                } else {
                    tflayoutEmail.error = null
                }
            }
            etPassword.doOnTextChanged { text, start, before, count ->
                if (etPassword.text.isNullOrEmpty()) {
                    tflayoutPassword.error = getString(R.string.requirePasswordError)
                } else {
                    tflayoutPassword.error = null
                }
            }

        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        false
    }
}