package com.example.myapplication.jetpack_bottomnav_customdrawer.model

import com.google.gson.annotations.SerializedName

data class LogInRequest(
    @SerializedName("email")
    val email: String,
    @SerializedName("password")
    val password: String?
)