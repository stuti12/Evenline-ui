package com.example.myapplication.session_mvvm.repository

import com.example.myapplication.session_mvvm.interfaces.UserApi
import com.example.myapplication.session_mvvm.models.LogInRequest
import com.example.myapplication.session_mvvm.models.LogInResponse
import com.example.myapplication.session_mvvm.models.SignUpRequest
import com.example.myapplication.session_mvvm.models.SignUpResponse
import retrofit2.Response

class UserRepository {
    suspend fun loginUser(loginRequest: LogInRequest): Response<LogInResponse>? {
        return UserApi.getApi()?.loginUser(loginRequest = loginRequest)
    }

    suspend fun signUpUser(loginRequest: SignUpRequest): Response<SignUpResponse>? {
        return UserApi.getApi()?.signUpUser(loginRequest = loginRequest)
    }
}