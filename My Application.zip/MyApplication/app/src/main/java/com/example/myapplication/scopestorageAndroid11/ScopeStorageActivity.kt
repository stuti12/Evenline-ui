package com.example.myapplication.scopestorageAndroid11

import android.content.ContentResolver
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.provider.Settings
import androidx.activity.result.ActivityResultCallback
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.example.myapplication.R
import com.example.myapplication.databinding.ActivityScopeStorage2Binding
import com.example.myapplication.utils.toast
import java.io.File
import java.io.OutputStream
import java.util.*

class ScopeStorageActivity : AppCompatActivity() {
    private val binding: ActivityScopeStorage2Binding by lazy {
        ActivityScopeStorage2Binding.inflate(layoutInflater)
    }
    private lateinit var resultLauncher: ActivityResultLauncher<String>
    private lateinit var permission: ActivityResultLauncher<Intent>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        setUpListener()
    }

    private fun setUpListener() {
        resultLauncher = registerForActivityResult(ActivityResultContracts.GetContent(),
            ActivityResultCallback {
                binding.imgScopeStorage.setImageURI(it)

                try {
                    if (it != null) {
                        saveImageToGallery(it)
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            })

        permission = registerForActivityResult(ActivityResultContracts.StartActivityForResult(),
            ActivityResultCallback {
                if (it.resultCode == RESULT_OK) {
                    this.toast(getString(R.string.text_permission_given))
                }
            })

        binding.btnSaveScopeStorage.setOnClickListener {
            selectFile()
        }
    }

    private fun saveImageToGallery(uri: Uri) {
        val fos: OutputStream?
        val resolver: ContentResolver = contentResolver
        val contentValues = ContentValues()
        contentValues.put(
            MediaStore.MediaColumns.DISPLAY_NAME,
            ".jpeg" + System.currentTimeMillis()
        )
        contentValues.put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
        contentValues.put(
            MediaStore.MediaColumns.RELATIVE_PATH,
            Environment.DIRECTORY_PICTURES + File.separator + "StorageFolder"
        )

        val imgUri: Uri? =
            resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues)
        fos = Objects.requireNonNull(imgUri)?.let { resolver.openOutputStream(it) }
        val source: ImageDecoder.Source = ImageDecoder.createSource(this.contentResolver, uri)
        val bitmap: Bitmap = ImageDecoder.decodeBitmap(source)

        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, fos)
        Objects.requireNonNull(fos)

        this.toast(getString(R.string.text_saved))
    }

    private fun selectFile() {
        takePermission()
        resultLauncher.launch("image/*")
    }

    private fun takePermissions() {
        if (Build.VERSION.SDK_INT == Build.VERSION_CODES.R) {
            try {
                val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION)
                intent.addCategory("android.intent.category.DEFAULT")
                intent.data = Uri.parse(String.format("package:%s", applicationContext.packageName))
                permission.launch(intent)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        } else {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(android.Manifest.permission.WRITE_EXTERNAL_STORAGE),
                101
            )
        }
    }

    private fun isPermissionGranted(): Boolean {
        return if (Build.VERSION.SDK_INT == Build.VERSION_CODES.R) {
            Environment.isExternalStorageManager()
        } else {
            val internalStoragePermission: Int = ContextCompat.checkSelfPermission(
                this,
                android.Manifest.permission.WRITE_EXTERNAL_STORAGE
            )
            internalStoragePermission == PackageManager.PERMISSION_GRANTED
        }
    }

    private fun takePermission() {
        if (isPermissionGranted()) {
            this.toast(getString(R.string.text_permission))
        } else {
            takePermissions()
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (grantResults.isNotEmpty()) {
            if (requestCode == 101) {
                val readExternalStorage: Boolean =
                    grantResults[0] == PackageManager.PERMISSION_GRANTED
                if (readExternalStorage) {
                    this.toast(getString(R.string.text_permission_android_10))
                } else {
                    takePermissions()
                }
            }
        }
    }
}