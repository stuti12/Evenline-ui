package com.example.myapplication.apiMVVM

class Constants {
    companion object {
        public const val ARG_DATA_USER_ID = "arg_data_user_id"
        public const val ARG_FIRSTNAME = "arg_firstname"
        public const val ARG_LASTNAME = "arg_lastname"
        public const val ARG_EMAIL = "arg_email"
        public const val ARG_AVATAR = "arg_avatar"
    }
}