package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.databinding.DataBindingUtil
import com.example.myapplication.apiCoroutine.view.ApiCallCoroutineActivity
import com.example.myapplication.apiMVVM.WebApiActivity
import com.example.myapplication.coroutinemultiple.CoroutineMultipleActivity
import com.example.myapplication.customWidget.CustomActivity
import com.example.myapplication.databinding.ActivityMainBinding
import com.example.myapplication.datastore.DataStoreActivity
import com.example.myapplication.designSupport.AppBarCoordinatorLayoutActivity
import com.example.myapplication.firebase.FirebaseActivity
import com.example.myapplication.firebaseNotification.FirebaseMessageActivity
import com.example.myapplication.firebaseNotification.android13.FCMNotificationActivity
import com.example.myapplication.flow.FlowActivity
import com.example.myapplication.googlesignin.GoogleSignInActivity
import com.example.myapplication.intentfilter.IntentFilterActivity
import com.example.myapplication.jetpackArg.JetpackMainActivity
import com.example.myapplication.jetpack_bottomnav_customdrawer.CustomBottomNavActivity
import com.example.myapplication.jetpack_bottomnav_customdrawer.activities.JetPackActivity
import com.example.myapplication.jobservice.JobServiceActivity
import com.example.myapplication.lifecycle.FragmentContainerActivity
import com.example.myapplication.lifecycle.LifecycleActivity
import com.example.myapplication.moshi.MoshiActivity
import com.example.myapplication.paging.PagingActivity
import com.example.myapplication.permissions.PermissionActivity
import com.example.myapplication.recycleListAdapter.RecycleListActivity
import com.example.myapplication.recycleview.CommonRecycleViewActivity
import com.example.myapplication.room_crud.RoomCrudActivity
import com.example.myapplication.roomwithApi.RoomApiActivity
import com.example.myapplication.session_mvvm.ui.SessionLoginActivity
import com.example.myapplication.tictactoe.TicTacTorActivity
import com.example.myapplication.video.VideoPlayActivity
import com.example.myapplication.viewpage_slider.ViewPagerSliderActivity
import com.example.myapplication.workmanager.WorkManagerActivity

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding

    //  private val viewModel by viewModels()
    override fun onCreate(savedInstanceState: Bundle?) {
        setTheme(R.style.Theme_MyApplication)
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_main)
        val splashScreen = installSplashScreen()
        splashScreen.apply {  }
        setData()
    }

    private fun setData() {
        // val mode = intent.getStringExtra(RecycleListActivity.name)
        binding.apply {
            btnPermission.setOnClickListener {
                val intent = Intent(this@MainActivity, PermissionActivity::class.java)
                startActivity(intent)
            }
            textMsg.text = intent.getStringExtra("name")

            btnListAdapter.setOnClickListener {
                startActivity(Intent(this@MainActivity, RecycleListActivity::class.java))
            }
            btnApi.setOnClickListener {
                startActivity(Intent(this@MainActivity, WebApiActivity::class.java))
            }
            btnLifeCycleActivity.setOnClickListener {
                startActivity(Intent(this@MainActivity, LifecycleActivity::class.java))
            }
            btnFragment.setOnClickListener {
                startActivity(Intent(this@MainActivity, FragmentContainerActivity::class.java))
            }

            btnCoroutine.setOnClickListener {
                startActivity(Intent(this@MainActivity, ApiCallCoroutineActivity::class.java))
            }
            btnJetpack.setOnClickListener {
                startActivity(Intent(this@MainActivity, JetPackActivity::class.java))
            }
            btnRecycle.setOnClickListener {
                startActivity(Intent(this@MainActivity, CommonRecycleViewActivity::class.java))
            }
            btnIntent.setOnClickListener {
                startActivity(Intent(this@MainActivity, IntentFilterActivity::class.java))
            }
            btnWorkOut.setOnClickListener {
                startActivity(Intent(this@MainActivity, WorkManagerActivity::class.java))
            }
            btnScopeStorage.setOnClickListener {
                startActivity(
                    Intent(
                        this@MainActivity,
                        com.example.myapplication.scopestorageAndroid11.ScopeStorageActivity::class.java
                    )
                )
            }
            btnJobService.setOnClickListener {
                startActivity(Intent(this@MainActivity, JobServiceActivity::class.java))
            }
            btnSession.setOnClickListener {
                startActivity(Intent(this@MainActivity, SessionLoginActivity::class.java))
            }
            btnCoroutineMultiple.setOnClickListener {
                startActivity(Intent(this@MainActivity, CoroutineMultipleActivity::class.java))
            }
            btnPaging.setOnClickListener {
                startActivity(Intent(this@MainActivity, PagingActivity::class.java))
            }
            btnGoogle.setOnClickListener {
                startActivity(Intent(this@MainActivity, GoogleSignInActivity::class.java))
            }
            btnDataStore.setOnClickListener {
                startActivity(Intent(this@MainActivity, DataStoreActivity::class.java))
            }

            btnDownload.setOnClickListener {
                startActivity(Intent(this@MainActivity, WorkManagerActivity::class.java))
            }
            btnRoomCrud.setOnClickListener {
                startActivity(Intent(this@MainActivity, RoomCrudActivity::class.java))
            }
            btnRoomWithApi.setOnClickListener {
                startActivity(Intent(this@MainActivity, RoomApiActivity::class.java))
            }
            btnFirebase.setOnClickListener {
                startActivity(Intent(this@MainActivity, FirebaseActivity::class.java))
            }
            btnFirebaseCRUD.setOnClickListener {
                startActivity(Intent(this@MainActivity, FirebaseMessageActivity::class.java))
            }
            btnCoordinator.setOnClickListener {
                startActivity(
                    Intent(
                        this@MainActivity,
                        AppBarCoordinatorLayoutActivity::class.java
                    )
                )
            }
            btnGame.setOnClickListener {
                startActivity(Intent(this@MainActivity, TicTacTorActivity::class.java))
            }
            btnMoshi.setOnClickListener {
                startActivity(Intent(this@MainActivity, MoshiActivity::class.java))
            }

            btnCustomWidget.setOnClickListener {
                startActivity(Intent(this@MainActivity, CustomActivity::class.java))
            }
            btnJetpackCompose.setOnClickListener {
                startActivity(Intent(this@MainActivity, CustomBottomNavActivity::class.java))
            }

            btnFlow.setOnClickListener {

                startActivity(Intent(this@MainActivity, FlowActivity::class.java))
            }
            btnVideo.setOnClickListener {
                startActivity(Intent(this@MainActivity, VideoPlayActivity::class.java))
            }
            btnSlider.setOnClickListener {
                startActivity(Intent(this@MainActivity, ViewPagerSliderActivity::class.java))
            }
            btnNotification.setOnClickListener {
                startActivity(Intent(this@MainActivity, FCMNotificationActivity::class.java))
            }
        }
    }

}