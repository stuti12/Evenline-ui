package com.example.myapplication.moshi

import com.example.myapplication.moshi.model.GetUserResponse
import retrofit2.Call
import retrofit2.http.GET

interface ApiService {
     @GET("https://dev.codingambitions.com/android/ecommerce/api/v1/getUsers.php/")
     fun getUsers() : Call<GetUserResponse>
}