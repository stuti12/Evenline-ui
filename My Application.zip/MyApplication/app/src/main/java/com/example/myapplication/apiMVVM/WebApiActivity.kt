package com.example.myapplication.apiMVVM

import android.annotation.SuppressLint
import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SearchView
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.DividerItemDecoration
import com.example.myapplication.R
import com.example.myapplication.apiMVVM.adapter.RecyclerViewAdapter
import com.example.myapplication.apiMVVM.model.DataUser
import com.example.myapplication.apiMVVM.viewmodel.MainActivityViewModel
import com.example.myapplication.databinding.ActivityWebApiBinding
import com.google.android.material.floatingactionbutton.FloatingActionButton
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.android.synthetic.main.activity_web_api.*
import kotlinx.android.synthetic.main.custom_toolbar.view.*

@AndroidEntryPoint
class WebApiActivity : AppCompatActivity() {

    private lateinit var recyclerViewAdapter: RecyclerViewAdapter
    private lateinit var viewModel: MainActivityViewModel
    private lateinit var binding: ActivityWebApiBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityWebApiBinding.inflate(layoutInflater)
        setContentView(binding.root)

        initRecycleView()
        initMainViewModel()

        val buttonRefreshData = findViewById<FloatingActionButton>(R.id.button_refresh_data)
        buttonRefreshData.setOnClickListener {
            Log.d("logging", "refresh Data from API")
            initRecycleView()
            initMainViewModel()
        }
        setData()
    }

    private fun initRecycleView() {
        recyclerView.apply {
           val decoration =
                DividerItemDecoration(applicationContext, DividerItemDecoration.VERTICAL)
            addItemDecoration(decoration)
            recyclerViewAdapter = RecyclerViewAdapter()
            adapter = recyclerViewAdapter
            Log.d("logging", "prepare ViewModel")
        }

    }

    @SuppressLint("NotifyDataSetChanged")
    private fun initMainViewModel() {
        viewModel = ViewModelProvider(this).get(MainActivityViewModel::class.java)
        viewModel.getAllRepositoryList().observe(this, Observer<List<DataUser>> {
            recyclerViewAdapter.setListData(it)
            recyclerViewAdapter.submitList(it)
        })
        viewModel.makeApiCall()
        Log.d("logging", "make Main ViewModel")

        // setup click listener for edit
        recyclerViewAdapter.onDataUserClickListener = {
            // log (element id) to click
            Log.d("logging", "click by " + it.id.toString())
            val firstname = it.first_name
            val lastname = it.last_name
            val email = it.email
            val avatar = it.avatar
            val intent = EditUserActivity.newIntentEditDataUser(
                this,
                it.id,
                firstname,
                lastname,
                email,
                avatar
            )
            startActivity(intent)
        }
    }

    private fun setData() {
        binding.apply {
            search.setOnQueryTextListener(object: SearchView.OnQueryTextListener{
                override fun onQueryTextSubmit(query: String?): Boolean {
                   recyclerViewAdapter.filter.filter(query)
                    return false
                }

                override fun onQueryTextChange(newText: String?): Boolean {
                    return  false
                }

            })
        }
    }
}