package com.example.myapplication.coroutinemultiple.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import coil.load
import com.example.myapplication.coroutinemultiple.model.RecycleData
import com.example.myapplication.databinding.RecyclerListRowBinding

class RecyclerViewAdapter(var context: Context) :
    ListAdapter<RecycleData, RecyclerViewAdapter.MyViewHolder>(ListDiffUserCallBack()) {
    private var items = ArrayList<RecycleData>()
    fun setUpdated(items: ArrayList<RecycleData>) {
        this.items = items
        // notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val binding =
            RecyclerListRowBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return MyViewHolder(binding)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        holder.bind(context, items[position])
    }

    class MyViewHolder(binding: RecyclerListRowBinding) : RecyclerView.ViewHolder(binding.root) {
        private val img = binding.imageCoroutine
        private val tvtitle = binding.textTitleGrid
        private val tvdesc = binding.textDescGrid
        fun bind(context: Context, data: RecycleData) {
            tvtitle.text = data.name
            tvdesc.text = data.description
            val url = data.owner.avtar_url
            //img.loadImage(url)
            img.load(url)
        }
    }

}

class ListDiffUserCallBack : DiffUtil.ItemCallback<RecycleData>() {
    override fun areItemsTheSame(oldItem: RecycleData, newItem: RecycleData): Boolean {
        return oldItem.name == newItem.name
    }

    override fun areContentsTheSame(oldItem: RecycleData, newItem: RecycleData): Boolean {
        return areItemsTheSame(oldItem, newItem)
    }

}

