package com.example.myapplication.apiCoroutine.view

import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.StaggeredGridLayoutManager
import com.example.myapplication.apiCoroutine.adapter.UserListAdapter
import com.example.myapplication.apiCoroutine.viewmodel.ListViewModel
import com.example.myapplication.databinding.ActivityApiCallCoroutineBinding
import kotlinx.android.synthetic.main.activity_api_call_coroutine.*

class ApiCallCoroutineActivity : AppCompatActivity() {
    private lateinit var binding: ActivityApiCallCoroutineBinding
    lateinit var viewModel: ListViewModel
    private val userListAdapter = UserListAdapter(arrayListOf())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityApiCallCoroutineBinding.inflate(layoutInflater)
        setContentView(binding.root)
        viewModel = ViewModelProvider(this)[ListViewModel::class.java]
        viewModel.refresh()
        rvUsersList.apply {
            layoutManager = LinearLayoutManager(context)
            adapter = userListAdapter
        }
        rvUsersList2.apply {
            layoutManager = StaggeredGridLayoutManager(2, StaggeredGridLayoutManager.VERTICAL)
            adapter = userListAdapter
        }
        observeViewModel()
    }

    private fun observeViewModel() {
        viewModel.users.observe(this, Observer { countries ->
            countries?.let {
                rvUsersList.visibility = View.VISIBLE
                userListAdapter.updateCountries(it)

                rvUsersList2.visibility = View.VISIBLE
            }
        })
        viewModel.usersLoadError.observe(this, Observer { isError ->
            listError.visibility = if (isError == "") View.GONE else View.VISIBLE
        })
        viewModel.loading.observe(this, Observer { isLoading ->
            isLoading?.let {
                loadingView.visibility = if (it) View.VISIBLE else View.GONE
                if (it) {
                    listError.visibility = View.GONE
                    rvUsersList.visibility = View.GONE
                    rvUsersList2.visibility = View.GONE
                }
            }
        })
    }
}