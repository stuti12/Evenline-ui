package com.example.myapplication.apiCoroutine.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import coil.load
import com.example.myapplication.R
import com.example.myapplication.apiCoroutine.model.User
import com.example.myapplication.databinding.UserItemCardCoroutineBinding

class UserListAdapter(var users: ArrayList<User>) :
    ListAdapter<User, UserListAdapter.UserViewHolder>(DiffUtilCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, p1: Int): UserViewHolder {
        val binding =
            UserItemCardCoroutineBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return UserViewHolder(binding)
    }

    override fun getItemCount() = users.size
    override fun onBindViewHolder(holder: UserViewHolder, position: Int) {
        holder.bind(users[position])
    }

    //private function for data set
    fun updateCountries(newUsers: List<User>) {
        users.clear()
        users.addAll(newUsers)
        notifyDataSetChanged()
    }

    //Inner class
    class UserViewHolder(val binding: UserItemCardCoroutineBinding) : RecyclerView.ViewHolder(binding.root) {
        private val imageView = binding.userAvatarImageView
        private val userName = binding.userFirstNameTextView
        private val userEmail = binding.userEmailTextView
        fun bind(user: User) {
            binding.recyclerData = user
            userName.text = user.first_name + " " + user.last_name
            userEmail.text = user.email
            imageView.load(user.avatar)

        }
    }
}

class DiffUtilCallback : DiffUtil.ItemCallback<User>() {
    override fun areItemsTheSame(oldItem: User, newItem: User): Boolean {
        return oldItem.id == newItem.id
    }

    override fun areContentsTheSame(oldItem: User, newItem: User): Boolean {
        return areItemsTheSame(oldItem, newItem)
    }

}

