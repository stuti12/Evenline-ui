package com.example.myapplication.paging.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.paging.PagingDataAdapter
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import coil.load
import com.example.myapplication.databinding.ItemPagingBinding
import com.example.myapplication.paging.model.User
import kotlinx.android.synthetic.main.item_paging.view.*

class NewsAdapter : PagingDataAdapter<User, RecyclerView.ViewHolder>(REPO_COMPORATOR) {

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val news = getItem(position)
        if (news != null) {
            (holder as NewsViewHolder).bind(news)
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return NewsViewHolder.create(parent)
    }

    class NewsViewHolder(private val binding: ItemPagingBinding) :
        RecyclerView.ViewHolder(binding.root) {
        private val news: User? = null

        fun bind(news: User?) {
            if (news == null) {

            } else {
                showData(news)
            }
        }

        private fun showData(news: User) {
            itemView.tvName.text = news.first_name + news.last_name
            itemView.tvMail.text = news.email
            itemView.ivPhoto.load(news.avatar)

        }

        companion object {
            fun create(parent: ViewGroup): NewsViewHolder {
                val binding =
                    ItemPagingBinding.inflate(LayoutInflater.from(parent.context), parent, false)
                return NewsViewHolder(binding)
            }
        }
    }

    companion object {
        private val REPO_COMPORATOR = object : DiffUtil.ItemCallback<User>() {
            override fun areItemsTheSame(oldItem: User, newItem: User): Boolean {
                return oldItem.id == newItem.id
            }

            override fun areContentsTheSame(oldItem: User, newItem: User): Boolean {
                return oldItem == newItem
            }

        }
    }

}