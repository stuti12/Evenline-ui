package com.example.myapplication.recycleview.gridLayout

import android.content.res.Resources
import com.example.myapplication.R

data class DataModel(
    var title: String,
    var desc: String,
    var image: Int
)

class GridDataSet {
    companion object {
        val list = listOf(
            DataModel(
                Resources.getSystem().getString(R.string.tittleone),
                Resources.getSystem().getString(R.string.newsDataFive),
                R.drawable.ic_check
            ),
            DataModel(
                Resources.getSystem().getString(R.string.tittleone),
                Resources.getSystem().getString(R.string.newsDataFive),
                R.drawable.ic_check
            ),
            DataModel(
                Resources.getSystem().getString(R.string.tittleone),
                Resources.getSystem().getString(R.string.newsDataFive),
                R.drawable.ic_check
            )
        )
    }
}