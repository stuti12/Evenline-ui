package com.example.myapplication.splash

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.appcompat.app.AppCompatActivity
import com.example.myapplication.MainActivity
import com.example.myapplication.session_mvvm.ui.SessionLoginActivity

class SplashActivity : AppCompatActivity() {
    private lateinit var delay: Handler
    private var sharedPreferences = "kotlinPreference"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val sharedPreference = getSharedPreferences("kotlinPreference", Context.MODE_PRIVATE)
        sharedPreference.getString("username", "stuti")
        if (sharedPreference.getBoolean("isLogin", true)) {
            startActivity(Intent(this@SplashActivity, MainActivity::class.java))
        } else {
            startActivity(Intent(this@SplashActivity, SessionLoginActivity::class.java))
        }
        finish()
    }

    private fun displaySplashScreen() {
        delay = Handler(Looper.getMainLooper())
        delay.postDelayed({

            /*   val intent = Intent(this@SplashActivity, MainActivity::class.java)
               startActivity(intent)*/
            finish()
        }, 1800)

    }

    override fun onPause() {
        super.onPause()
        delay.removeCallbacksAndMessages(null)
    }
}