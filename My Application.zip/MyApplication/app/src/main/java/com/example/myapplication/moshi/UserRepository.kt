package com.example.myapplication.moshi

import com.example.myapplication.moshi.model.GetUserResponse
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class UserRepository {
    val apiService by lazy {
        ApiClient.apiService
    }

      suspend fun getUsers(): ArrayList<GetUserResponse.UserX> {
          return withContext(Dispatchers.IO){
              val response = apiService.getUsers().execute()
              response.body()?.users?: arrayListOf()
          }
      }
}