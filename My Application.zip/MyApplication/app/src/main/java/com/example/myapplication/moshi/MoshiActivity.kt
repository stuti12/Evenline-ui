package com.example.myapplication.moshi

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.example.myapplication.databinding.ActivityMoshiBinding

class MoshiActivity : AppCompatActivity() {
    private val binding: ActivityMoshiBinding by lazy {
        ActivityMoshiBinding.inflate(layoutInflater)
    }

      lateinit var viewModel: UsersViewModel
       private val adapter: UsersRecyclerAdapter = UsersRecyclerAdapter()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
           viewModel = ViewModelProvider(this)[UsersViewModel::class.java]
           binding.rvMoshi.adapter = adapter
            viewModel.getUsers()
    }
}