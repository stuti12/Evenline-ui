package com.example.myapplication.permissions

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.location.*
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.provider.Settings
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.example.myapplication.BuildConfig
import com.example.myapplication.databinding.ActivityPermissionBinding
import com.example.myapplication.utils.ONE
import com.example.myapplication.utils.THREE
import com.example.myapplication.utils.TWO
import com.example.myapplication.utils.toast
import kotlinx.android.synthetic.main.activity_permission.*
import java.io.File
import java.io.IOException
import java.util.*


@Suppress("DEPRECATION")
class PermissionActivity : AppCompatActivity(), LocationListener {
    private val binding: ActivityPermissionBinding by lazy {
        ActivityPermissionBinding.inflate(
            layoutInflater
        )
    }
    private lateinit var locationManager: LocationManager
    private val locationPermissionCode = 2

    @RequiresApi(Build.VERSION_CODES.M)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        setCamera()
        setGallery()
        getUpdate()
    }

    private fun setGallery() {
        btnGallery.setOnClickListener {
            if (checkPermission(Manifest.permission.READ_EXTERNAL_STORAGE)) {
                imageChooser()
            } else {
                if (shouldShowRequestPermissionRationale(Manifest.permission.READ_EXTERNAL_STORAGE)) {
                    showDialog("Need storage permission to Access pdf and Gallery. Please provide permission to access your pdf.")
                } else {
                    ActivityCompat.requestPermissions(
                        this, arrayOf(
                            Manifest.permission.READ_EXTERNAL_STORAGE
                        ),
                        ONE
                    )
                }
            }
        }
    }

    @RequiresApi(Build.VERSION_CODES.M)
    private fun setCamera() {
        btnAudio.setOnClickListener {
            if (checkPermission(Manifest.permission.RECORD_AUDIO)) {
                createAudioFile(this,"demo")
            } else {
                if (shouldShowRequestPermissionRationale(Manifest.permission.RECORD_AUDIO)) {
                    showDialog("Need Audio permission to Access audio. Please provide permission to access your audio.")
                } else {
                    ActivityCompat.requestPermissions(
                        this,
                        arrayOf(
                            Manifest.permission.RECORD_AUDIO
                        ),
                        TWO
                    )
                }
            }
        }
    }

    private fun showDialog(string: String) {
        AlertDialog.Builder(this)
            .setMessage(string)
            .setPositiveButton("OK") { dialogInterface, i ->
                dialogInterface.dismiss()
                //Open Settings
                startActivity(
                    Intent(
                        Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                        Uri.parse("package:" + BuildConfig.APPLICATION_ID)
                    )
                )
            }
            .setNegativeButton("Cancel") { dialogInterface, i ->
                dialogInterface.dismiss()
            }
            .create()
            .show()
    }

    fun imageChooser() {
        //Other Way for Open Image
        val intent = Intent(Intent.ACTION_GET_CONTENT, MediaStore.Images.Media.INTERNAL_CONTENT_URI)
        intent.type = "image/*"
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true)
        resultLauncher.launch(intent)
        /*val intent2 = Intent("android.media.action.IMAGE_CAPTURE")
        resultCameraLauncher.launch(intent2)*/
    }

    private var resultLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                result.data?.let {
                    val image = it.data
                    mImageView.setImageURI(image)
                }
            } else {
                Toast.makeText(this, "Picture not found", Toast.LENGTH_LONG).show()
            }
        }


    @Throws(IOException::class)
    private fun createAudioFile(context: Context, audioName: String): File? {
        val storageDir: File? = context.getExternalFilesDir(Environment.DIRECTORY_PODCASTS)
        if (shouldShowRequestPermissionRationale(Manifest.permission.RECORD_AUDIO)) {
            showDialog("Need Audio permission to Access Location. Please provide permission to access audio.")
        } else {
            ActivityCompat.requestPermissions(
                this, arrayOf(
                    Manifest.permission.RECORD_AUDIO
                ),
                TWO
            )
        }
        return File.createTempFile(
            audioName,  /* prefix */
            ".3gp",  /* suffix */
            storageDir /* directory */
        )
    }

    private var resultCameraLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                val intent = result.data
                val bitmap = intent?.extras?.get("data") as Bitmap
                mImageView.setImageBitmap(bitmap)
            } else {
                toast("Picture not found")
            }
        }

    private fun checkPermission(vararg permission: String): Boolean = permission.all {
        ContextCompat.checkSelfPermission(
            this,
            it
        ) == PackageManager.PERMISSION_GRANTED
    }

    private fun getLocation() {
        locationManager = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        if ((ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED)
        ) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
                locationPermissionCode
            )
        }
        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 5000, 5f, this)

    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (grantResults.isEmpty() || grantResults[0] != PackageManager.PERMISSION_GRANTED) {
            toast("Permission Denied")
        } else {
            Toast.makeText(this, "Permission granted", Toast.LENGTH_SHORT).show()
            when (requestCode) {
                ONE -> {
                    if (permissions[0] == Manifest.permission.READ_EXTERNAL_STORAGE) {
                        imageChooser()
                    }
                }
                TWO -> {
                    if (permissions[0] == Manifest.permission.RECORD_AUDIO) {
                        createAudioFile(this,"demo")
                    }
                }
                THREE -> {
                    if (permissions[0] == Manifest.permission.ACCESS_FINE_LOCATION) {
                        getUpdate()
                    }
                }
            }

        }
        if (requestCode == locationPermissionCode) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                this.toast("Permission Granted")
            } else {
                this.toast("Permission Denied")
            }
        }
    }

    override fun onLocationChanged(location: Location) {
        val addresses: List<Address>
        val geocoder: Geocoder = Geocoder(this, Locale.getDefault())

        addresses = geocoder.getFromLocation(
            location.latitude,
            location.longitude,
            1
        ) // Here 1 represent max location result to returned, by documents it recommended 1 to 5


        val address: String =
            addresses[0].getAddressLine(0) // If any additional address line present than only, check with max available address lines by getMaxAddressLineIndex()

        binding.textLocation.text =
            "Latitude: " + location.latitude + " , Longitude: " + location.longitude + "\n" + "Address:" + address
    }

    private fun getUpdate() {
        binding.btnLocation.setOnClickListener {
            if (checkPermission(Manifest.permission.ACCESS_FINE_LOCATION) && checkPermission(
                    Manifest.permission.ACCESS_COARSE_LOCATION
                )
            ) {
                getLocation()
            } else {
                if (shouldShowRequestPermissionRationale(Manifest.permission.ACCESS_FINE_LOCATION)) {
                    showDialog("Need location permission to Access Location. Please provide permission to access yourlocation.")
                } else {
                    ActivityCompat.requestPermissions(
                        this, arrayOf(
                            Manifest.permission.ACCESS_FINE_LOCATION
                        ),
                        THREE
                    )
                }
            }
        }
    }

}