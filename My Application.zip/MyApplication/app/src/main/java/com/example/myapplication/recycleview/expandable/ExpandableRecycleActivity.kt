package com.example.myapplication.recycleview.expandable

import RecycleAdapter
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.myapplication.R
import com.example.myapplication.databinding.ActivityExpandableRecycleBinding

class ExpandableRecycleActivity : AppCompatActivity() {
    private val  binding: ActivityExpandableRecycleBinding by  lazy {
        ActivityExpandableRecycleBinding.inflate(layoutInflater)
    }
    val listData : MutableList<ParentData> = ArrayList()
    val parentData: Array<String> = arrayOf("Andhra Pradesh", "Telangana", "Karnataka", "TamilNadu")
    val childDataData1: MutableList<ChildData> = mutableListOf(ChildData("Anathapur"),ChildData("Chittoor"),ChildData("Nellore"),ChildData("Guntur"))
    val childDataData2: MutableList<ChildData> = mutableListOf(ChildData("Rajanna Sircilla"), ChildData("Karimnagar"), ChildData("Siddipet"))
    val childDataData3: MutableList<ChildData> = mutableListOf(ChildData("Chennai"), ChildData("Erode"))
    val parentObj1 = ParentData(parentTitle = parentData[0], subList = childDataData1)
    val parentObj2 = ParentData(parentTitle = parentData[1], subList = childDataData2)
    val parentObj3 = ParentData(parentTitle = parentData[2], subList =  childDataData1)
    val parentObj4 = ParentData(parentTitle = parentData[1], subList = childDataData3)

     override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        listData.add(parentObj1)
        listData.add(parentObj2)
        listData.add(parentObj3)
        listData.add(parentObj4)
         val adapter: RecycleAdapter = RecycleAdapter(this,listData)

         binding.exRecycle.adapter = adapter
         binding.exRecycle.layoutManager = LinearLayoutManager(this)
      //   adapter.submitList(listData)

    }
}