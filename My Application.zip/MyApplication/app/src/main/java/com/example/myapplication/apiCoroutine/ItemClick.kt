package com.example.myapplication.apiCoroutine

import com.example.myapplication.apiCoroutine.model.UserList

interface ItemClickListener {
    fun setClickedInfo(data: UserList)
}