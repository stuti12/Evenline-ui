package com.example.myapplication.jetpack_bottomnav_customdrawer.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.example.myapplication.databinding.FragmentTermsBinding

class TermsFragment : Fragment() {

    private lateinit var _binding: FragmentTermsBinding

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentTermsBinding.inflate(inflater, container, false)

        return _binding.root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        false
    }
}