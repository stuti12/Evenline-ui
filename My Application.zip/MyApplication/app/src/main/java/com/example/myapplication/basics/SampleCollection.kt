package com.example.myapplication.basics

fun main(args: Array<String>) {
    println("Immutable List")
    val immutableList = listOf("Stuti", "Sanjana", "Nidhi")
    for (item in immutableList) {
        println(item)
    }
    println("\nMutable List")
    var mutableList = mutableListOf("Stuti", "Nidhi", "Sanjana")
    mutableList[0] = "Neha"
    // add one more element in the list
    mutableList.add("Sweta")
    for (item in mutableList) {
        println(item)
    }

    println("\nArrayList")
    var array = ArrayList<String>()
    array.add("12")
    array.add("10")
    array.add("2000")
    for (i in array)
        println("$i")
    println(array.get(2))

    array.remove("2000")
    for (i in array)
        println("After remove $i")

    println("\nImmutable Map")
    var immutableMap = mapOf(1 to "Stuti", 2 to "Nidhi", 3 to "Sanjana")
    for (key in immutableMap.keys) {
        println(immutableMap[key])
    }

    println("\nMap")
    val mutableMap1: MutableMap<Int, String> =
        mutableMapOf<Int, String>(1 to "Stuti", 4 to "Nidhi", 2 to "Sanjant", 3 to "Sweta")

    val mutableMap2: MutableMap<String, String> = mutableMapOf<String, String>()
    mutableMap2["name"] = "Stuti"
    mutableMap2["city"] = "Delhi"
    mutableMap2["department"] = "android Development"
    mutableMap2["hobby"] = "Singing"
    println(".....traverse mutableMap1........")
    for (key in mutableMap1.keys) {
        println("Key = ${key}, Value = ${mutableMap1[key]}")
    }
    println("......traverse mutableMap2.......")
    for (key in mutableMap2.keys) {
        println("Key = " + key + ", " + "Value = " + mutableMap2[key])
    }

    println("\nFlat Map")
    val ls1 = listOf("Java", "C", "C++", "Kotlin", "Python", "Go", "DotNet", "JavaScript")
    println(ls1.flatMap { it.toList() })

    println("\nMutable Map")
    val theMap = mutableMapOf("one" to 1, "two" to 2, "three" to 3, "four" to 4)
    var resultMap = theMap.filterValues { it > 2 }
    theMap["five"] = 5
    println(resultMap)
    println(theMap)

    println("\n Array")
    val arrayname = arrayOf<Int>(1, 2, 3, 4, 5)
    for (element in arrayname) {
        println(element)
    }

    println("For each loop\n")
    val book1 = Book("Kotlin Tutorial")
    val book2 = Book("Kotlin Android Tutorial", 2)
    var listB = listOf<Book>(book1, book2)

    listB.forEach {
        println("Price of book, ${it.name} is ${it.price}")
    }
}

data class Book(val name: String = "", val price: Int = 0)