package com.example.myapplication.recycleview.staggeredLayout

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.StaggeredGridLayoutManager
import com.example.myapplication.R
import com.example.myapplication.databinding.ActivityRecycleViewStaggeredLayoutBinding
import com.example.myapplication.recycleview.gridLayout.DataModel
import com.example.myapplication.recycleview.nestedRecycle.RecycleStaggerAdapter

class RecycleViewStaggeredLayoutActivity : AppCompatActivity() {
    private lateinit var binding: ActivityRecycleViewStaggeredLayoutBinding
    private lateinit var photoAdapter: RecycleStaggerAdapter
    private var dataList = listOf<DataModel>()

    override fun onCreate(savedInstanceState: Bundle?) {
        binding = ActivityRecycleViewStaggeredLayoutBinding.inflate(layoutInflater)
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        setAdapter()
    }

    private fun setAdapter() {
        binding.apply {
            photoAdapter = RecycleStaggerAdapter(this@RecycleViewStaggeredLayoutActivity)
            rvStaggered.layoutManager = StaggeredGridLayoutManager(2, LinearLayoutManager.VERTICAL)
            rvStaggered.adapter = photoAdapter
            // dataList = GridDataSet.list
            dataList = listOf(
                DataModel(
                    getString(R.string.titleOne),
                    "We will learn about Primary and Secondary Constructors in Kotlin. Unlike other object-oriented languages, Kotlin has two types of constructors. So, We will learn how to use them.",
                    R.drawable.ic_check
                ),
                DataModel(
                    getString(R.string.newsDataTwo),
                    getString(R.string.newsDataSix),
                    R.drawable.ic_check
                ),
                DataModel(
                    getString(R.string.newsDataTwo),
                    getString(R.string.newsDataSix),
                    R.drawable.ic_check
                ), DataModel(
                    getString(R.string.newsDataTwo),
                    getString(R.string.newsDataSix),
                    R.drawable.ic_check
                ), DataModel(
                    getString(R.string.newsDataTwo),
                    "We will learn about Primary and Secondary Constructors in Kotlin. Unlike other object-oriented languages, Kotlin has two types of constructors. So, We will learn how to use them.",
                    R.drawable.ic_check
                ), DataModel(
                    getString(R.string.newsDataTwo),
                    "We will learn about Primary and Secondary Constructors in Kotlin. Unlike other object-oriented languages, Kotlin has two types of constructors. So, We will learn how to use them.",
                    R.drawable.ic_check
                ), DataModel(
                    getString(R.string.newsDataTwo),
                    getString(R.string.newsDataSix),
                    R.drawable.ic_check
                ), DataModel(
                    getString(R.string.newsDataTwo),
                    getString(R.string.newsDataSix),
                    R.drawable.ic_check
                ), DataModel(
                    getString(R.string.newsDataTwo),
                    getString(R.string.newsDataSix),
                    R.drawable.ic_check
                ), DataModel(
                    getString(R.string.newsDataTwo),
                    "We will learn about Primary and Secondary Constructors in Kotlin. Unlike other object-oriented languages, Kotlin has two types of constructors. So, We will learn how to use them.",
                    R.drawable.ic_check
                ), DataModel(
                    getString(R.string.newsDataTwo),
                    "We will learn about Primary and Secondary Constructors in Kotlin. Unlike other object-oriented languages, Kotlin has two types of constructors. So, We will learn how to use them.",
                    R.drawable.ic_check
                ), DataModel(
                    getString(R.string.newsDataTwo),
                    getString(R.string.newsDataSix),
                    R.drawable.ic_check
                ), DataModel(
                    getString(R.string.newsDataTwo),
                    getString(R.string.newsDataSix),
                    R.drawable.ic_check

                )
            )
            photoAdapter.submitList(dataList)

        }

    }
}