package com.example.myapplication.jetpack_bottomnav_customdrawer.model

import com.google.gson.annotations.SerializedName

data class LogInResponse(
    @SerializedName("id")
    val id: Int,
    @SerializedName("token")
    val token: String
)

data class ErrorResponse(
    @SerializedName("error")
    val error: String
)