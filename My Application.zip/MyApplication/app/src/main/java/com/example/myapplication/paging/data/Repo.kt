package com.example.myapplication.paging.data

import androidx.paging.Pager
import androidx.paging.PagingConfig
import androidx.paging.PagingData
import com.example.myapplication.paging.model.User
import com.example.myapplication.paging.network.Api
import kotlinx.coroutines.flow.Flow

class Repository(private val ap: Api) {

    fun getResult(): Flow<PagingData<User>> {
        return Pager(config = PagingConfig(pageSize = 1, enablePlaceholders = true),
            pagingSourceFactory = { DataSource(ap) }
        ).flow
    }
}