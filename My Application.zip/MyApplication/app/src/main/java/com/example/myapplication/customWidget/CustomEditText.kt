package com.example.myapplication.customWidget

import android.content.Context
import android.util.AttributeSet
import android.view.LayoutInflater
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.FrameLayout
import androidx.annotation.DrawableRes
import com.example.myapplication.R
import com.example.myapplication.databinding.CustomEditTextBinding
import com.google.android.material.textfield.TextInputLayout
import java.util.regex.Pattern

class CustomEditText : FrameLayout {

    constructor(context: Context) : super(context) {
        initUi(context)
    }

    constructor(context: Context, attrs: AttributeSet?) : super(context, attrs) {
        initUi(context)
        attrs?.let {
            initAttrs(it)
        }
    }


    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int) : super(
        context, attrs, defStyleAttr
    ) {
        initUi(context)
        attrs?.let {
            initAttrs(it, defStyleAttr)
        }
    }

    constructor(
        context: Context, attrs: AttributeSet?, defStyleAttr: Int, defStyleRes: Int
    ) : super(context, attrs, defStyleAttr, defStyleRes) {
        initUi(context)
        attrs?.let {
            initAttrs(it, defStyleAttr, defStyleRes)
        }
    }

    var mCustomEditTextBinding: CustomEditTextBinding? = null
    private fun initUi(context: Context) {
        mCustomEditTextBinding = CustomEditTextBinding.inflate(LayoutInflater.from(context))
        val layoutParams = LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
        )
        mCustomEditTextBinding?.root?.layoutParams = layoutParams

        addView(mCustomEditTextBinding?.root)
    }

    private var validationRegex: String? = null
    private var emptyError: String? = null
    private var regexError: String? = null
    private var isRequired: Boolean? = null


    private fun initAttrs(attrs: AttributeSet, defStyleAttr: Int = 0, defStyleRes: Int = 0) {
        val customAttributes = context.obtainStyledAttributes(
            attrs, R.styleable.CustomEditText, defStyleAttr, defStyleRes
        )
        val hint = customAttributes.getString(R.styleable.CustomEditText_android_hint)
        val placeholderText = customAttributes.getString(R.styleable.CustomEditText_placeholderText)
        validationRegex = customAttributes.getString(R.styleable.CustomEditText_validationRegex)
        val inputType = customAttributes.getInt(
            R.styleable.CustomEditText_android_inputType, EditorInfo.TYPE_CLASS_TEXT
        )
        isRequired = customAttributes.getBoolean(R.styleable.CustomEditText_android_required, false)
        emptyError = customAttributes.getString(R.styleable.CustomEditText_emptyError)
        regexError = customAttributes.getString(R.styleable.CustomEditText_regexError)
        val endIconMode = customAttributes.getInt(
            R.styleable.CustomEditText_myEndIconMode, TextInputLayout.END_ICON_NONE
        )
        val imeOptions = customAttributes.getInt(
            R.styleable.CustomEditText_android_imeOptions, EditorInfo.IME_ACTION_NONE
        )

        val startText = customAttributes.getString(
            R.styleable.CustomEditText_startText
        )
        val myEndIcon = customAttributes.getResourceId(
            R.styleable.CustomEditText_myEndIcon, -1
        )
        setStartText(startText)
        setEndIcon(myEndIcon)
        // setValidation(isRequired!!, emptyError, validationRegex, regexError)
        /*if (isRequired) {
            mCustomEditTextBinding?.mtvRequired?.visible()
        }*/
        mCustomEditTextBinding?.tilLayout?.hint = hint
        mCustomEditTextBinding?.tilLayout?.endIconMode = endIconMode
        mCustomEditTextBinding?.tilLayout?.placeholderText = placeholderText
        mCustomEditTextBinding?.tiEtEditText?.inputType = inputType
        mCustomEditTextBinding?.tiEtEditText?.imeOptions = imeOptions

        customAttributes.recycle()
        // invalidate()
    }

    fun setStartText(startText: String?) {
        startText?.let {
            mCustomEditTextBinding?.mtvStart?.text = startText
            mCustomEditTextBinding?.mtvStart?.visibility = VISIBLE
        }

    }

    /*private fun setValidation(
        isRequired: Boolean, emptyError: String?, validationRegex: String?, regexError: String?
    ) {
        mCustomEditTextBinding?.tiEtEditText?.doAfterTextChanged { text ->
            if (mCustomEditTextBinding?.tiEtEditText?.hasFocus() == true) {
                if (!text.isNullOrBlank() && !validationRegex.isNullOrBlank() && !Pattern.matches(
                        validationRegex, text
                    )
                ) {
                    mCustomEditTextBinding?.tilLayout?.isErrorEnabled = true
                    mCustomEditTextBinding?.tilLayout?.error = regexError
                    mCustomEditTextBinding?.tilLayout?.setPadding(
                        mCustomEditTextBinding?.tilLayout?.paddingLeft ?: 0,
                        mCustomEditTextBinding?.tilLayout?.paddingTop ?: 0,
                        mCustomEditTextBinding?.tilLayout?.paddingRight ?: 0,
                        20
                    )
                } else if (isRequired && text.isNullOrBlank()) {
                    mCustomEditTextBinding?.tilLayout?.error = emptyError
                    mCustomEditTextBinding?.tilLayout?.isErrorEnabled = true
                    mCustomEditTextBinding?.tilLayout?.setPadding(
                        mCustomEditTextBinding?.tilLayout?.paddingLeft ?: 0,
                        mCustomEditTextBinding?.tilLayout?.paddingTop ?: 0,
                        mCustomEditTextBinding?.tilLayout?.paddingRight ?: 0,
                        20
                    )
                } else {
                    mCustomEditTextBinding?.tilLayout?.error = ""
                    mCustomEditTextBinding?.tilLayout?.isErrorEnabled = false
                    mCustomEditTextBinding?.tilLayout?.setPadding(
                        mCustomEditTextBinding?.tilLayout?.paddingLeft ?: 0,
                        mCustomEditTextBinding?.tilLayout?.paddingTop ?: 0,
                        mCustomEditTextBinding?.tilLayout?.paddingRight ?: 0,
                        0
                    )
                }
            }
        }
    }*/


    fun setEndIcon(@DrawableRes resId: Int) {
        if (resId != -1) {
            mCustomEditTextBinding?.acIvEnd?.visibility = VISIBLE
            mCustomEditTextBinding?.acIvEnd?.setImageResource(resId)
        }
    }


    fun isValid(): Boolean {
        val editTextData = (mCustomEditTextBinding?.tiEtEditText?.text ?: "").toString()
        return if (editTextData.isNotBlank() && !validationRegex.isNullOrBlank() && !Pattern.matches(
                validationRegex!!, editTextData
            )
        ) {
            false
        } else !(isRequired == true && editTextData.isBlank())
    }

    fun getEmptyError() = emptyError ?: ""
    fun getRegexError() = regexError ?: ""

}