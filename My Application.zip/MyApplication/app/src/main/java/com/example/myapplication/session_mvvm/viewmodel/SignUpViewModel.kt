package com.example.myapplication.session_mvvm.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.example.myapplication.session_mvvm.models.BaseResponse
import com.example.myapplication.session_mvvm.models.SignUpRequest
import com.example.myapplication.session_mvvm.models.SignUpResponse
import com.example.myapplication.session_mvvm.repository.UserRepository
import kotlinx.coroutines.launch


class SignUpViewModel(application: Application) : AndroidViewModel(application) {

    val userRepo = UserRepository()
    val loginResult: MutableLiveData<BaseResponse<SignUpResponse>> = MutableLiveData()

    fun signupUser(email: String, pwd: String) {

        loginResult.value = BaseResponse.Loading()
        viewModelScope.launch {
            try {

                val loginRequest = SignUpRequest(
                    password = pwd,
                    email = email
                )
                val response = userRepo.signUpUser(loginRequest = loginRequest)
                if (response?.code() == 200) {
                    loginResult.value = BaseResponse.Success(response.body())
                } else {
                    loginResult.value = BaseResponse.Error(response?.message())
                }

            } catch (ex: Exception) {
                loginResult.value = BaseResponse.Error(ex.message)
            }
        }
    }
}