package com.example.myapplication.jobservice

import android.annotation.SuppressLint
import android.app.job.JobParameters
import android.app.job.JobService
import android.util.Log
import com.example.myapplication.utils.toast

@Suppress("NAME_SHADOWING")
@SuppressLint("SpecifyJobSchedulerIdRange")
class MyJobScheduler : JobService() {
    override fun onStopJob(p0: JobParameters?): Boolean {
        applicationContext.toast("Job Cancelled")
        return false
    }

    override fun onStartJob(p0: JobParameters?): Boolean {
        var k = 0
        this.toast("Job Running")
        for (k in 0..10) {
            applicationContext.toast("Running Job $k")
            Log.v("JobScheduler", "Running Job $k")
        }
        applicationContext.toast("job Finished")
        return false
    }


}
