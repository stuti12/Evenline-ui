package com.example.myapplication

import kotlin.math.sqrt

fun main(args: Array<String>) {
    fun Circle.perimeter(): Double {
        return 2 * Math.PI * radius;
    }

    var sum = arrayOf(1, 2, 3, 4, 5, 6, 7, 8, 9, 10).sum()

    println("Builtin Function")
    println("The sum of all the elements of an array is: $sum")
    println("Square root of 9 is ${sqrt(9.0)}")
    println("Convert to Int ${"12".toIntOrNull()}")

    println("\n UserDefine Function")
    val name = "Stuti"
    val rollno = 10
    val grade = 'A'
    student(name, grade, rollno)

    println("Recursion")
    println("Factorial of 5 is: " + fact(5))

    val sumOfNumbers: (Int, Int) -> Int = { a, b -> a + b }
    println("\n Lamda function")
    val result = sumOfNumbers(3, 4)
    println("Sum of numbers$result")

    println("\nAnonamyous function")
    val resultAnnonamus = anonymous1(3, 4)
    println("Sum of annonymus function $resultAnnonamus")

    println("\nInline function")
    print("Stuti Bhavsar: ")
    higherfunc("A Computer Science portal for Kotlin", ::print)

    println("\nExtention Function")
    val newCircle = Circle(2.5);
    println("Perimeter of the circle is ${newCircle.perimeter()}")

    println("\n Scope Functions")
    val companyObject = Company().apply {
        cname = "OpenXcell"
        department = "Android"
        founder = "ABC"
    }
    println(companyObject.cname)
    println(companyObject.department)

    var letFunction: Int? = null
    letFunction?.let {
        println(it)
    }
    letFunction = 2
    letFunction?.let { println(it) }

    with(companyObject) {
        println("$cname")
    }

    val list = mutableListOf<Int>(1, 2, 3)

    list.also {
        it.add(4)
        it.remove(2)
        // more operations if needed
    }
    println(list)
}

val anonymous1 = fun(x: Int, y: Int): Int = x + y

inline fun higherfunc(str: String, mycall: (String) -> Unit) {
    // inovkes the print() by passing the string str
    mycall(str)
}

fun fact(num: Int): Long {
    return if (num == 1) num.toLong()
    else num * fact(num - 1)
}

fun student(name: String, grade: Char, roll_no: Int) {
    println("Name of the student is : $name")
    println("Grade of the student is: $grade")
    println("Roll no of the student is: $roll_no")

}

class Circle(val radius: Double) {
    // member function of class
    fun area(): Double {
        return Math.PI * radius * radius;
    }
}

class Company() {
    lateinit var cname: String
    lateinit var department: String
    lateinit var founder: String
}