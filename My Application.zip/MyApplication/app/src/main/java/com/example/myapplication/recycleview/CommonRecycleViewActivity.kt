package com.example.myapplication.recycleview

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.myapplication.databinding.ActivityCommonRecycleViewBinding
import com.example.myapplication.recycleview.expandable.ExpandableRecycleActivity
import com.example.myapplication.recycleview.gridLayout.RecycleViewGridLayoutActivity
import com.example.myapplication.recycleview.nestedRecycle.NestedRecycleViewActivity
import com.example.myapplication.recycleview.staggeredLayout.RecycleViewStaggeredLayoutActivity
import kotlinx.android.synthetic.main.activity_common_recycle_view.*

class CommonRecycleViewActivity : AppCompatActivity() {
    private lateinit var binding: ActivityCommonRecycleViewBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        binding = ActivityCommonRecycleViewBinding.inflate(layoutInflater)
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        setListener()
    }

    private fun setListener() {
        btnRecycleGridLayout.setOnClickListener {
            startActivity(
                Intent(
                    this@CommonRecycleViewActivity,
                    RecycleViewGridLayoutActivity::class.java
                )
            )
        }
        btnRecycleNested.setOnClickListener {
            startActivity(
                Intent(
                    this@CommonRecycleViewActivity,
                    NestedRecycleViewActivity::class.java
                )
            )
        }
        btnRecycleStaggered.setOnClickListener {
            startActivity(
                Intent(
                    this@CommonRecycleViewActivity,
                    RecycleViewStaggeredLayoutActivity::class.java
                )
            )
        }
        btnRecycleExpanded.setOnClickListener {
            startActivity(
                Intent(
                    this@CommonRecycleViewActivity,
                    ExpandableRecycleActivity::class.java
                )
            )
        }
    }
}