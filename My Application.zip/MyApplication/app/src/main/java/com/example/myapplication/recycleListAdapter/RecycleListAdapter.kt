package com.example.myapplication.recycleListAdapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.myapplication.R
import com.example.myapplication.recycleListAdapter.data.Blog
import kotlinx.android.synthetic.main.recycleview_list_item.view.*

class NoteRecyclerAdapter(
    val viewModel: MainViewModel,
    val arrayList: ArrayList<Blog>,
    val context: Context
) : ListAdapter<Blog, NoteRecyclerAdapter.NotesViewHolder>(DiffUtilCallback()) {
    override fun onCreateViewHolder(
        parent: ViewGroup, viewType: Int,
    ): NoteRecyclerAdapter.NotesViewHolder {
        var root = LayoutInflater.from(parent.context)
            .inflate(R.layout.recycleview_list_item, parent, false)
        return NotesViewHolder(root)
    }

    override fun onBindViewHolder(holder: NoteRecyclerAdapter.NotesViewHolder, position: Int) {
        holder.bind(arrayList.get(position))
    }

    override fun getItemCount(): Int {
        if (arrayList.size == 0) {
            Toast.makeText(context, "List is empty", Toast.LENGTH_LONG).show()
        } else {

        }
        return arrayList.size
    }

    inner class NotesViewHolder(private val binding: View) : RecyclerView.ViewHolder(binding) {
        fun bind(blog: Blog) {

            binding.title.text = blog.title
            binding.delete.setOnClickListener {
                viewModel.remove(blog)
                notifyItemRemoved(arrayList.indexOf(blog))
            }
        }

    }

}

class DiffUtilCallback : DiffUtil.ItemCallback<Blog>() {
    override fun areItemsTheSame(oldItem: Blog, newItem: Blog): Boolean {
        return oldItem.title == newItem.title
    }

    override fun areContentsTheSame(oldItem: Blog, newItem: Blog): Boolean {
        return areItemsTheSame(oldItem, newItem)
    }

}

/*
class NoteRecyclerAdapter(val viewModel: MainViewModel, val arrayList: ArrayList<Blog>, val context: Context) : ListAdapter<Blog, NoteRecyclerAdapter.NotesAdapterViewHolder>(NotificationAdapterDifCallBack()) {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): NotesAdapterViewHolder {
        val binding = RecycleviewListItemBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return NotesAdapterViewHolder(binding).also { viewHolder ->

            viewHolder.binding.root.setOnClickListener {
            }
        }
    }

    override fun onBindViewHolder(holder: NotesAdapterViewHolder, position: Int) {
        val currentItem = getItem(position)
        holder.bind(currentItem)

    }

    inner class NotesAdapterViewHolder(val binding: RecycleviewListItemBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(dataModel: Blog) {
            binding.apply {
             setData = dataModel
                title.text = dataModel.title
                delete.setOnClickListener {
                    viewModel.remove(dataModel)
                    notifyItemRemoved(arrayList.indexOf(dataModel))
                }
            }
        }

    }


}

class NotificationAdapterDifCallBack : DiffUtil.ItemCallback<Blog>() {
    override fun areItemsTheSame(oldItem: Blog, newItem: Blog): Boolean {
        return oldItem.title == newItem.title
    }

    override fun areContentsTheSame(oldItem: Blog, newItem: Blog): Boolean {
        return areItemsTheSame(oldItem, newItem)
    }

}*/
