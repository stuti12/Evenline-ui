package com.example.myapplication.recycleview.expandable

data class ChildData(val childTitle:String)