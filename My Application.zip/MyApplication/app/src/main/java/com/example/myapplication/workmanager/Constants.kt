package com.example.myapplication.workmanager

const val KEY_FILE_NAME = "file_name"
const val KEY_FILE_TYPE = "file_type"
const val KEY_FILE_URI = "file_uri"
const val KEY_FILE_URL = "file_url"

const val CHANNEL_NAME = "Download File"
const val CHANNEL_DESC = "Download file using work manager "
const val CHANNEL_ID = "channel_100"
const val NOTIFICATION_ID = 100
