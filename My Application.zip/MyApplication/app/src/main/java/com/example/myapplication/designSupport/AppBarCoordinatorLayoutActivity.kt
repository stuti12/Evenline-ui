package com.example.myapplication.designSupport

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.myapplication.databinding.ActivityAppBarCoordinatorLayoutBinding

class AppBarCoordinatorLayoutActivity : AppCompatActivity() {
    private val binding: ActivityAppBarCoordinatorLayoutBinding by lazy {
        ActivityAppBarCoordinatorLayoutBinding.inflate(layoutInflater)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        val toolbar = binding.toolbars
        setSupportActionBar(toolbar)
        if (supportActionBar != null) {
            supportActionBar?.setDisplayHomeAsUpEnabled(true)
        }
    }
}