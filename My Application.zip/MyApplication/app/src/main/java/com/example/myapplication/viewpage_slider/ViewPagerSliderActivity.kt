package com.example.myapplication.viewpage_slider

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.viewpager.widget.ViewPager
import com.example.myapplication.R
import com.example.myapplication.databinding.ActivityViewPagerSliderBinding
import com.gtappdevelopers.kotlingfgproject.ViewPagerAdapter

class ViewPagerSliderActivity : AppCompatActivity() {
    private val binding: ActivityViewPagerSliderBinding by lazy{
        ActivityViewPagerSliderBinding.inflate(layoutInflater)
    }
    lateinit var viewPager: ViewPager
    lateinit var viewPagerAdapter: ViewPagerAdapter
    lateinit var imageList: List<Int>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        viewPager = binding.idViewPager
        imageList = ArrayList<Int>()
        imageList = imageList + R.drawable.ic_camera
        imageList = imageList + R.drawable.ic_check
        imageList = imageList + R.drawable.ic_home
        imageList = imageList + R.drawable.ic_email
        imageList = imageList + R.drawable.ic_phone
        viewPagerAdapter = ViewPagerAdapter(this@ViewPagerSliderActivity, imageList)
        viewPager.adapter = viewPagerAdapter


    }
}