package com.example.myapplication.jetpack_bottomnav_customdrawer

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import androidx.navigation.NavController
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.fragment.findNavController
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.setupActionBarWithNavController
import androidx.navigation.ui.setupWithNavController
import com.example.myapplication.R
import com.example.myapplication.databinding.ActivityCustomBottomNavBinding
import kotlinx.android.synthetic.main.activity_custom_bottom_nav.bottomNavigationView
import kotlinx.android.synthetic.main.activity_custom_bottom_nav.toolbar

class CustomBottomNavActivity : AppCompatActivity() {
    private val binding: ActivityCustomBottomNavBinding by lazy {
        ActivityCustomBottomNavBinding.inflate(layoutInflater)
    }
    private lateinit var appBarConfiguration: AppBarConfiguration
    private lateinit var navController: NavController
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        bottomNavigationView.background = null
        bottomNavigationView.menu.getItem(2).isEnabled = false

        setNavigation()
    }
    private fun setNavigation() {
        binding.apply {
            setContentView(root)
            val navHostFragment =
                supportFragmentManager.findFragmentById(R.id.nav_host_fragment) as NavHostFragment
            navController = navHostFragment.findNavController()
            appBarConfiguration = AppBarConfiguration(
                setOf(R.id.homeFragment, R.id.searchFragment),

            )
            setSupportActionBar(toolbar)
            supportActionBar?.hide()

            setupActionBarWithNavController(navController,appBarConfiguration)

            bottomNavigationView.setupWithNavController(navController)

        }
    }
}