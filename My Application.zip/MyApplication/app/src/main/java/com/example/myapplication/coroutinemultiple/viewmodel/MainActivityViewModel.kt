package com.example.myapplication.coroutinemultiple.viewmodel

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.myapplication.coroutinemultiple.model.RecycleList
import com.example.myapplication.coroutinemultiple.network.RetroInstance
import com.example.myapplication.coroutinemultiple.network.RetroService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.launch

class MainActivityViewModel : ViewModel() {
    var recycleData: MutableLiveData<RecycleList>

    init {
        recycleData = MutableLiveData()
    }

    fun getRecycleObserver(): MutableLiveData<RecycleList> {
        return recycleData
    }

    fun makeApiCall() {
        viewModelScope.launch(Dispatchers.IO) {
            async {
                val retro = RetroInstance.getRetrofit().create(RetroService::class.java)
                val response = retro.getDataFromApi("ny")
                recycleData.postValue(response)
            }
            //    .await()
        }
    }
}