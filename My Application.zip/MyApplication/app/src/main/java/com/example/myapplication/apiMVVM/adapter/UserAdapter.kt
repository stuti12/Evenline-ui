package com.example.myapplication.apiMVVM.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.Filter
import android.widget.Filterable
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import coil.load
import com.example.myapplication.apiMVVM.model.DataUser
import com.example.myapplication.databinding.RecycleviewItemWebapiBinding
import java.util.*
import kotlin.collections.ArrayList

class RecyclerViewAdapter() :
    ListAdapter<DataUser, RecyclerViewAdapter.MyViewHolder>(ListDiffCallBack()), Filterable {

    var listDataUser: List<DataUser>? = null
    private lateinit var binding: RecycleviewItemWebapiBinding

    // click listener
    var onDataUserClickListener: ((DataUser) -> Unit)? = null

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        binding =
            RecycleviewItemWebapiBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return MyViewHolder(binding)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val dataUser = listDataUser?.get(position)
        holder.itemView.setOnClickListener {
            if (dataUser != null) {
                onDataUserClickListener?.invoke(dataUser)
            }

        }
        listDataUser?.get(position)?.let { holder.bind(it) }
    }

    fun setListData(listDataUser: List<DataUser>) {
        this.listDataUser = listDataUser
    }

    class MyViewHolder(private val binding: RecycleviewItemWebapiBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(dataUser: DataUser) {
            binding.apply {
                recycleData = dataUser
                txtUserName.text = dataUser.first_name
                txtUserInfo1.text = dataUser.last_name
                txtUserInfo2.text = dataUser.email
                imgAvtar.load(dataUser.avatar)

            }
        }
    }

    //Searchview
    override fun getFilter(): Filter {

        return object : Filter() {

            override fun performFiltering(constraint: CharSequence?): FilterResults {
                val resultList: ArrayList<DataUser> = arrayListOf()
                val charSearch = constraint.toString()
                if (charSearch.isEmpty()) {
                    resultList.clear()
                    listDataUser?.let { resultList.addAll(it) }

                } else {
                    for (row in listDataUser!!) {
                        if (row.first_name.lowercase(Locale.getDefault())
                                .contains(constraint.toString().lowercase(Locale.getDefault()))
                        ) {
                            resultList.add(row)
                        }
                    }
                }
                val filterResults = FilterResults()
                filterResults.values = resultList
                return filterResults
            }

            override fun publishResults(constraint: CharSequence?, results: FilterResults?) {
                setListData(results?.values as ArrayList<DataUser>)
                submitList(results?.values as ArrayList<DataUser>)
            }
        }
    }
}

class ListDiffCallBack : DiffUtil.ItemCallback<DataUser>() {
    override fun areItemsTheSame(oldItem: DataUser, newItem: DataUser): Boolean {
        return oldItem.id == newItem.id
    }

    override fun areContentsTheSame(oldItem: DataUser, newItem: DataUser): Boolean {
        return areItemsTheSame(oldItem, newItem)
    }

}