package com.example.myapplication.flow.repo

import com.example.myapplication.flow.model.CommentModel
import retrofit2.http.GET
import retrofit2.http.Path

interface ApiService {
    @GET("/comments/{id}")
    suspend fun getComment(@Path("id")id: Int): CommentModel
}