package com.example.myapplication.dependecyinje

/*
@Component
interface UserRegistrationComponent {
    fun getUserRegistrationService(): UserRegistrationService
}

class MainAct: AppCompatActivity(){
    val userRepository = UserRepository()
    val emailService =EmailService()
    val userReg = UserRegistrationService(userRepository,emailService)
}*/
