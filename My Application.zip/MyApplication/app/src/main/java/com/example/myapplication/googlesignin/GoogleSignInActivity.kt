package com.example.myapplication.googlesignin

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.example.myapplication.R
import com.example.myapplication.databinding.ActivityGoogleSignInBinding
import com.example.myapplication.firebase.FirebaseActivity
import com.example.myapplication.firebase.dao.UserDao
import com.example.myapplication.firebase.models.User
import com.example.myapplication.utils.toast
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.common.api.ApiException
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase
import kotlinx.android.synthetic.main.activity_google_sign_in.*

class GoogleSignInActivity : AppCompatActivity() {
    private lateinit var viewModel: LoginViewmodel

    private val binding: ActivityGoogleSignInBinding by lazy {
        ActivityGoogleSignInBinding.inflate(layoutInflater)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        initializeViewModel()
        binding.lifecycleOwner = this
        binding.mainViewModel = viewModel
        FirebaseApp.initializeApp(this)
        observeData()
        setData()
    }

    override fun onStart() {
        super.onStart()
        val current = Firebase.auth.currentUser
        updateUI(current)
    }

    private fun initializeViewModel() {
        val factory = ViewModelFactory(application)
        viewModel = ViewModelProvider(this, factory)[LoginViewmodel::class.java]
    }

    private fun observeData() {
        viewModel.currentUser.observe(this) {
            it?.let {
                viewModel.name.value = it.displayName

            }
        }
    }

    private fun updateUI(firebaseUser: FirebaseUser?) {
        if (firebaseUser != null) {
            val user =
                User(firebaseUser.uid, firebaseUser.displayName, firebaseUser.photoUrl.toString())
            val userDao = UserDao()
            userDao.addUser(user)
            startActivity(Intent(this@GoogleSignInActivity, FirebaseActivity::class.java))
            finish()
        } else {
            startGoogleSignR.launch(viewModel.googleSignInClient.signInIntent)
        }
    }

    private fun setData() {
        btnLogin.setOnClickListener {
            when {
                Firebase.auth.currentUser != null -> { //first check user already signing or not.
                    viewModel.name.value = Firebase.auth.currentUser?.displayName.toString()
                    toast(getString(R.string.str_sign_in))
                    startActivity(Intent(this@GoogleSignInActivity, FirebaseActivity::class.java))
                    Log.d("current", Firebase.auth.currentUser?.displayName.toString())
                }
                else -> {
                    startGoogleSignR.launch(viewModel.googleSignInClient.signInIntent)

                }
            }
        }
    }

    /*    private fun setData() {
              btnLogin.setOnClickListener { view: View? ->
                 val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                     .requestIdToken(R.string.default_web_client_id.toString())
                     .requestEmail()
                     .build()
                 val googleSignInClient = GoogleSignIn.getClient(this, gso)
                 val signInIntent = googleSignInClient.signInIntent

                 callBack.launch(signInIntent)
             }

        }*/
    /* private fun handleResult(completedTask: Task<GoogleSignInAccount>) {
         try {
             val account: GoogleSignInAccount? = completedTask.getResult(ApiException::class.java)
             if (account != null) {
                 UpdateUI(account)
             }
         } catch (e: ApiException) {
             Toast.makeText(this, e.toString(), Toast.LENGTH_SHORT).show()
         }
     }

     // this is where we update the UI after Google signin takes place
     private fun UpdateUI(account: GoogleSignInAccount) {
         val credential = GoogleAuthProvider.getCredential(account.idToken, null)
         firebaseAuth.signInWithCredential(credential).addOnCompleteListener { task ->
             if (task.isSuccessful) {
                 // SavedPreference.setEmail(this, account.email.toString())
                 //  SavedPreference.setUsername(this, account.displayName.toString())
                 val intent = Intent(this, LogOutActivity::class.java)
                 startActivity(intent)
                 finish()
             }
         }
     }

     val callBack = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
         if (it.resultCode == Activity.RESULT_OK) {
             val task: Task<GoogleSignInAccount> = GoogleSignIn.getSignedInAccountFromIntent(it.data)
             handleResult(task)
         }
     }
 */
    private val startGoogleSignR =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                val task = GoogleSignIn.getSignedInAccountFromIntent(result.data)
                try {
                    val account = task.getResult(ApiException::class.java)!!
                    account.idToken?.let { viewModel.firebaseAuthWithGoogle(it) }
                    toast(message = getString(R.string.str_sign_in))
                    startActivity(Intent(this@GoogleSignInActivity, FirebaseActivity::class.java))
                } catch (e: ApiException) {
                    toast(e.message.toString())

                }

            }
        }
}