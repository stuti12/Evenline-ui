package com.example.myapplication.flow.CommentViewModel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.myapplication.flow.model.CommentModel
import com.example.myapplication.flow.repo.CommentApiState
import com.example.myapplication.flow.repo.CommentRepository
import com.example.myapplication.flow.repo.Status
import com.example.myapplication.flow.utils.AppConfig
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch

class CommentViewModel: ViewModel() {
    private val repository = CommentRepository(AppConfig.ApiService())
    val cstate = MutableStateFlow(CommentApiState(Status.LOADING,CommentModel(),""))
    init {
        getNewComment(1)
    }

    fun getNewComment(id: Int) {
        cstate.value = CommentApiState.loading()
        viewModelScope.launch {
            repository.getComment(id).catch {
                cstate.value = CommentApiState.error(it.message.toString())
            }.collect{
                cstate.value = CommentApiState.success(it.data)
            }
        }
    }
}