package com.example.myapplication.moshi

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.myapplication.moshi.model.GetUserResponse
import kotlinx.coroutines.launch

class UsersViewModel : ViewModel() {
    private var _users = MutableLiveData<ArrayList<GetUserResponse.UserX>>()
    val users: LiveData<ArrayList<GetUserResponse.UserX>> = _users

    val userRepository by lazy {
        UserRepository()
    }

    fun getUsers() {
        viewModelScope.launch {
            var respose = userRepository.getUsers()
            _users.postValue(respose)
        }
    }
}
