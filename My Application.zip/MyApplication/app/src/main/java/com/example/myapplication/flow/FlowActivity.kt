package com.example.myapplication.flow

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.core.view.isVisible
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import com.example.myapplication.databinding.ActivityFlowBinding
import com.example.myapplication.flow.CommentViewModel.CommentViewModel
import com.example.myapplication.flow.repo.Status
import kotlinx.coroutines.launch

class FlowActivity : AppCompatActivity() {
    private val binding: ActivityFlowBinding by lazy {
        ActivityFlowBinding.inflate(layoutInflater)
    }
    private lateinit var viewModel: CommentViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        viewModel = ViewModelProvider(this).get(CommentViewModel::class.java)

        setData()
    }
    private fun setData() {
        binding.apply {
            buttonFlow.setOnClickListener {
               if(searchEditText.text.isNullOrEmpty()){
                   Toast.makeText(this@FlowActivity,"Empty Query",Toast.LENGTH_SHORT).show()
               }else{
                   viewModel.getNewComment(searchEditText.text.toString().toInt())
               }
            }
        }
        lifecycleScope.launch {
            viewModel.cstate.collect {
                when(it.status) {
                    Status.LOADING -> {
                        binding.progressBar.isVisible = true
                    }
                    Status.SUCCESS -> {
                        binding.progressBar.isVisible = false
                        binding.apply {
                            it.data.let {comment->
                                commentIdTextview.text = comment?.id.toString()
                                nameTextview.text =comment?.name
                                emailTextview.text = comment?.email
                                commentTextview.text = comment?.comment
                            }
                        }
                    }
                    Status.ERROR -> {
                        binding.progressBar.isVisible = false
                        Toast.makeText(this@FlowActivity, "${it.message}", Toast.LENGTH_SHORT).show()

                    }
                }
            }
        }
    }
}