package com.example.myapplication.googlesignin

import android.app.Application
import androidx.lifecycle.*
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase

class LoginViewmodel(app: Application) : AndroidViewModel(app) {

    private var auth: FirebaseAuth = Firebase.auth
    val currentUserName = MutableLiveData<FirebaseUser>()
    val currentUser: LiveData<FirebaseUser> = currentUserName

    val name = MutableLiveData<String>()

    private val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
        //.requestIdToken("1056600315856-7ahikbk3cct7tjdh6ht4554qdq69eq1j.apps.googleusercontent.com")
        .requestEmail()
        .requestIdToken("1056600315856-8lq8niqtpe7kph47cr1qg6fg5rb5hut7.apps.googleusercontent.com")
        .build()

    val googleSignInClient = GoogleSignIn.getClient(app, gso)

    //button click
    fun firebaseAuthWithGoogle(idToken: String) {
        val credential = GoogleAuthProvider.getCredential(idToken, null)
        auth.signInWithCredential(credential).addOnCompleteListener {
            if (it.isSuccessful) {
                currentUserName.value = auth.currentUser
            }
        }
    }

    fun logout() {
        auth.signOut()
        googleSignInClient.signOut()
        name.value = ""
    }

}

class ViewModelFactory(private val application: Application) : ViewModelProvider.Factory {

    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(LoginViewmodel::class.java)) {
            return LoginViewmodel(application) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }


}