package com.example.myapplication.customWidget

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.myapplication.databinding.ActivityCustomBinding

class CustomActivity : AppCompatActivity() {
    private val binding: ActivityCustomBinding by lazy {
        ActivityCustomBinding.inflate(layoutInflater)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
    }
}