package com.example.myapplication.jobservice

import android.app.job.JobInfo
import android.app.job.JobScheduler
import android.content.ComponentName
import android.content.Context
import android.os.Build
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.myapplication.databinding.ActivityJobServiceBinding

class JobServiceActivity : AppCompatActivity() {
    companion object {
        private const val TAG = "JobServiceActivity"
    }

    private val binding: ActivityJobServiceBinding by lazy {
        ActivityJobServiceBinding.inflate(layoutInflater)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        setListeners()
    }

    private fun setListeners() {
        binding.scheduleJobBtn.setOnClickListener {
            startJob()
        }
        binding.cancelJobBtn.setOnClickListener {
            stopJob()
        }
    }

    private fun stopJob() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            val jobScheduler = getSystemService(Context.JOB_SCHEDULER_SERVICE) as JobScheduler
            jobScheduler.cancel(1)
        }
        binding.chronometer.stop()

    }

    private fun startJob() {
        binding.chronometer.start()
        var component = ComponentName(this, MyJobScheduler::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            val jobInfo = JobInfo.Builder(1, component)
                .setMinimumLatency(5000)
                .build()

            val jobScheduler = getSystemService(Context.JOB_SCHEDULER_SERVICE) as JobScheduler
            jobScheduler.schedule(jobInfo)
        }
    }
}