package com.example.myapplication.recycleview.nestedRecycle

class ChildItem     // Constructor of the class
// to initialize the variable*
    (  // Getter and Setter method
    var childItemTitle: String
)