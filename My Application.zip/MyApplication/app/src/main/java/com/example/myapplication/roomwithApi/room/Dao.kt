package com.example.myapplication.roomwithApi.room

import androidx.room.*
import com.example.myapplication.roomwithApi.model.MovieItemModel

@Dao
interface MoviesDao {

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    fun insert(moviesItemModel: List<MovieItemModel>)

    @Delete
    fun delete(moviesItemModel: MovieItemModel)

    @Query("SELECT * from movie_table")
    fun getAllMovies(): List<MovieItemModel>

}