package com.example.myapplication.session_mvvm.ui

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.MotionEvent
import android.view.View
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import com.example.myapplication.databinding.ActivitySessionSignUpBinding
import com.example.myapplication.session_mvvm.models.BaseResponse
import com.example.myapplication.session_mvvm.models.SignUpResponse
import com.example.myapplication.session_mvvm.viewmodel.SignUpViewModel
import com.example.myapplication.utils.hideKeyboard

class SessionSignUpActivity : AppCompatActivity() {
    private val viewModel by viewModels<SignUpViewModel>()
    private lateinit var binding: ActivitySessionSignUpBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        binding = ActivitySessionSignUpBinding.inflate(layoutInflater)
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        observe()
        setListener()
    }

    override fun dispatchTouchEvent(ev: MotionEvent?): Boolean {
        if (currentFocus != null) {
            binding.sessionLoginView.hideKeyboard()
        }
        return super.dispatchTouchEvent(ev)
    }

    private fun observe() {
        val email = binding.txtInputEmail.text
        binding.txtInputEmail.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                if (email.isNullOrEmpty()) {
                    binding.txtLayEmailAdd.error = "Please Enter Emai;"
                } else {
                    binding.txtLayEmailAdd.error = null
                }
            }

            override fun afterTextChanged(s: Editable?) {
            }

        })
        binding.txtPass.addTextChangedListener(object : TextWatcher {
            val pass = binding.txtPass.text
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                if (pass.isNullOrEmpty()) {
                    binding.txtLayPassSignup.error = "Missing Password"
                } else {
                    binding.txtLayPassSignup.error = null
                }
            }

            override fun afterTextChanged(s: Editable?) {
            }

        })

        binding.btnRegister.setOnClickListener {
            doLogin()
        }
        binding.btnLogin.setOnClickListener {
            startActivity(Intent(this, SessionLoginActivity::class.java))
            finish()
        }
        viewModel.loginResult.observe(this) {
            when (it) {
                is BaseResponse.Loading -> {
                    showLoading()
                }

                is BaseResponse.Success -> {
                    stopLoading()
                    processLogin(it.data)
                }

                is BaseResponse.Error -> {
                    processError(it.msg)
                    stopLoading()
                }
                else -> {
                    stopLoading()
                }
            }
        }

    }

    private fun setListener() {
        binding.apply {
            val email = binding.txtInputEmail.text
            txtInputEmail.addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(
                    s: CharSequence?,
                    start: Int,
                    count: Int,
                    after: Int
                ) {
                }

                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                    if (email.isNullOrEmpty()) {
                        binding.txtLayEmailAdd.error = "Please Enter Emai;"
                    } else {
                        binding.txtLayEmailAdd.error = null
                    }
                }

                override fun afterTextChanged(s: Editable?) {
                }

            })
            txtPass.addTextChangedListener(object : TextWatcher {
                val pass = binding.txtPass.text
                override fun beforeTextChanged(
                    s: CharSequence?,
                    start: Int,
                    count: Int,
                    after: Int
                ) {

                }

                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                    if (pass.isNullOrEmpty()) {
                        binding.txtLayPassSignup.error = "Missing Password"
                    } else {
                        binding.txtLayPassSignup.error = null
                    }
                }

                override fun afterTextChanged(s: Editable?) {
                }

            })

            btnRegister.setOnClickListener {
                doLogin()
            }
            btnLogin.setOnClickListener {
                startActivity(Intent(this@SessionSignUpActivity, SessionLoginActivity::class.java))
                finish()
            }
        }
    }

    fun showLoading() {
        binding.prgbar.visibility = View.VISIBLE
    }

    fun processError(msg: String?) {
        showToast("Error:" + msg)
    }

    fun doLogin() {
        val email = binding.txtInputEmail.text.toString()
        val pwd = binding.txtPass.text.toString()
        viewModel.signupUser(email = email, pwd = pwd)

    }

    fun stopLoading() {
        binding.prgbar.visibility = View.GONE
    }

    fun processLogin(data: SignUpResponse?) {

        showToast("Register Successful")
    }

    fun showToast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }
}