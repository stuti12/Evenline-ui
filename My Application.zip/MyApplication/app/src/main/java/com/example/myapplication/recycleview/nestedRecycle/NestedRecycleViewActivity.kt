package com.example.myapplication.recycleview.nestedRecycle

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.myapplication.R
import com.example.myapplication.databinding.ActivityNestedRecycleViewBinding
import kotlinx.android.synthetic.main.activity_nested_recycle_view.*


class NestedRecycleViewActivity : AppCompatActivity() {
    private lateinit var binding: ActivityNestedRecycleViewBinding
    private lateinit var adapter: ParentItemAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        binding = ActivityNestedRecycleViewBinding.inflate(layoutInflater)
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        setData()
    }

    private fun setData() {

        binding.apply {
            val layoutManager = LinearLayoutManager(
                this@NestedRecycleViewActivity
            )
            rvNested.layoutManager = layoutManager
        }
        val parentItemAdapter = ParentItemAdapter(
            ParentItemList()
        )
        rvNested.adapter = parentItemAdapter
    }

    private fun ParentItemList(): List<ParentItem> {
        val itemList: MutableList<ParentItem> = ArrayList()
        val item = ParentItem(
            "Title 1",
            ChildItemList()
        )
        itemList.add(item)
        val item1 = ParentItem(
            "Title 2",
            ChildItemList()
        )
        itemList.add(item1)
        val item2 = ParentItem(
            "Title 3",
            ChildItemList()
        )
        itemList.add(item2)
        val item3 = ParentItem(
            "Title 4",
            ChildItemList()
        )
        itemList.add(item3)
        return itemList
    }

    private fun ChildItemList(): List<ChildItem> {
        val ChildItemList: MutableList<ChildItem> = ArrayList()
        ChildItemList.add(ChildItem(getString(R.string.newsDataSix)))
        ChildItemList.add(ChildItem(getString(R.string.newsDataSix)))
        ChildItemList.add(ChildItem(getString(R.string.newsDataTwo)))
        ChildItemList.add(ChildItem(getString(R.string.newsDataFour)))
        return ChildItemList
    }
}