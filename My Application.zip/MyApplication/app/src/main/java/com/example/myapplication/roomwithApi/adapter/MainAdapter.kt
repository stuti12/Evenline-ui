package com.example.myapplication.roomwithApi.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import coil.load
import com.example.myapplication.R
import com.example.myapplication.databinding.ItemRoomLayoutBinding
import com.example.myapplication.roomwithApi.MAIN
import com.example.myapplication.roomwithApi.model.MovieItemModel


class MainAdapter : RecyclerView.Adapter<MainAdapter.MyViewHolder>() {
    var listMovies = emptyList<MovieItemModel>()
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val binding = ItemRoomLayoutBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return MyViewHolder(binding)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        with(holder) {
            binding.tvTitle.text = listMovies[position].title
            binding.tvDate.text = listMovies[position].release_date
            binding.itemImg.load("https://image.tmdb.org/t/p/w185/${listMovies[position].poster_path}")

        }
    }

    override fun getItemCount(): Int {
        return listMovies.size
    }


    class MyViewHolder(val binding: ItemRoomLayoutBinding) : RecyclerView.ViewHolder(binding.root)

    fun setList(list: List<MovieItemModel>) {
        listMovies = list
        notifyDataSetChanged()
    }

}


/*
class MainAdapter : ListAdapter<MovieItemModel, MainAdapter.MyViewHolder>(DiffUtilCallbacks()) {
    var listMovies = emptyList<MovieItemModel>()
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val binding = ItemLayoutBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return MyViewHolder(binding)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        with(holder) {
            binding.tvTitle.text = listMovies[position].title
            binding.tvDate.text = listMovies[position].release_date

            Glide.with(MAIN)
                .load("https://image.tmdb.org/t/p/w185/${listMovies[position].poster_path}")
                .placeholder(R.drawable.ic_launcher_foreground)
                .into(binding.itemImg)
        }
    }

    override fun getItemCount(): Int {
        return listMovies.size
    }

    class MyViewHolder(val binding: ItemLayoutBinding) : RecyclerView.ViewHolder(binding.root)

    fun setList(list: List<MovieItemModel>) {
        listMovies = list
     //   notifyDataSetChanged()
    }

}
class DiffUtilCallbacks : DiffUtil.ItemCallback<MovieItemModel>(){
    override fun areItemsTheSame(oldItem: MovieItemModel, newItem:MovieItemModel): Boolean {
        return oldItem.title == newItem.title
    }

    override fun areContentsTheSame(oldItem: MovieItemModel, newItem: MovieItemModel): Boolean {
        return areItemsTheSame(oldItem,newItem)
    }

}*/
