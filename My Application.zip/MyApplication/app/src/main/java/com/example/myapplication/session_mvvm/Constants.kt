package com.example.myapplication.session_mvvm

class Constants {
    companion object {
        const val BASEURL = "https://reqres.in/"
        const val TYPE = "application/json"
        const val ACCEPT = "ACCEPT"
    }
}