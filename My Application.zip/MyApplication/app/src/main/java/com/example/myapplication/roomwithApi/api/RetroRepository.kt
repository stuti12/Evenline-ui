package com.example.myapplication.roomwithApi.api

import com.example.myapplication.roomwithApi.model.MoviesModel
import retrofit2.Response

class RetrofitRepository {

    suspend fun getMovie(): Response<MoviesModel> {
        return RetrofitInstance.api.getPopularMovie()
    }

}