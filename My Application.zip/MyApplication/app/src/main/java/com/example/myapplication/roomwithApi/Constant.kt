package com.example.myapplication.roomwithApi

import com.example.myapplication.roomwithApi.repository.MoviesRepositoryRealization


lateinit var MAIN: RoomApiActivity

const val BASE_URL = "https://api.themoviedb.org/"
const val IMG = "https://image.tmdb.org/t/p/w185/"

lateinit var REALIZATION: MoviesRepositoryRealization