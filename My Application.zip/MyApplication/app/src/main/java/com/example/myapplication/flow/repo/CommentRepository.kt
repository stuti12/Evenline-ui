package com.example.myapplication.flow.repo

import com.example.myapplication.flow.model.CommentModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn

class CommentRepository(private val apiService: ApiService) {
    suspend fun getComment(id: Int): Flow<CommentApiState<CommentModel>> {
        return flow {
            val comment = apiService.getComment(id)
            emit(CommentApiState.success(comment))
        }.flowOn(Dispatchers.IO)
    }
}