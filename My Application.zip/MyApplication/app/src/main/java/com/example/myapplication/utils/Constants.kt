package com.example.myapplication.utils

const val TWO = 2
const val ONE = 1
const val THREE = 3

object Constants {
    const val CHANNEL_ID_PERIOD_WORK = "PERIODIC_APP_UPDATES"
    const val CHANNEL_ID_ONE_TIME_WORK = "INSTANT_APP_UPDATES"
    const val ONETIME_WORK_DESCRIPTION = "ONETIME_WORK_DESCRIPTION"
    const val LAST_PERIODIC_TIME = "LAST_PERIODIC_TIME"
    const val BASEURL = "https://reqres.in/"
    const val USERID = "UserID"
}


fun main() {
    var array = listOf(listOf(1, 2, 3, 4, 5), listOf(1, 2, 3, 4, 5)).flatMap { it }


    println(array)
}