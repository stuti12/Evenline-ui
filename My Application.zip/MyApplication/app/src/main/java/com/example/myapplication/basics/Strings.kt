package com.example.myapplication.basics

fun main(args: Array<String>) {
    var name = "StutiBhavsar"
    var name2 = "StutiBhavsar"
    var surname = "Stuti"
    println(name.length)
    println(name.get(4))
    println(name.subSequence(2, 7))
    println(name.compareTo(surname))
    println(name === name2)
    println(name == surname)
    println(name === surname)

    val text = """Kotlin is official language  
        |announce by Google for  
        |android application development  
    """.trimMargin()
    println(text)


    val text2 = text.codePointAt(2)
    println(text2)

    println("\nFormat")
    val PI = 3.14159265358979323
    val myStr = String.format("The PI value is %.2f", PI)

    print(myStr)

    val padWithSpace = "125".padStart(12, '$')
    println("\n")
    println("'$padWithSpace'")

    val numbers: List<Int> = listOf(1, 2, 3, 4, 5, 6, 7)
    val evenNumbers = numbers.filter { it % 2 == 0 }
    val notMultiplesOf3 = numbers.filterNot { number -> number % 3 == 0 }

    println("\nEven Numbers" + evenNumbers)
    println("FilterNot" + notMultiplesOf3)

    println(text.reversed())

    val words = listOf("a", "abc", "ab", "def", "abcd")
    val byLength = words.groupBy { it.length }
    println("\n" + byLength.keys) // [1, 3, 2, 4]
    println(byLength.values) // [[a], [abc, def], [ab], [abcd]]

    val mutableByLength: MutableMap<Int, MutableList<String>> =
        words.groupByTo(mutableMapOf()) { it.length }
    println("mutableByLength == byLength is ${mutableByLength == byLength}") // true
}
