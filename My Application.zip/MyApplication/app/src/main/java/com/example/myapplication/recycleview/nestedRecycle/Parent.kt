package com.example.myapplication.recycleview.nestedRecycle


class ParentItem(
    var parentItemTitle: String,
    ChildItemList: List<ChildItem>
) {
    private var ChildItemList: List<ChildItem>
    fun getChildItemList(): List<ChildItem> {
        return ChildItemList
    }

    fun setChildItemList(
        childItemList: List<ChildItem>
    ) {
        ChildItemList = childItemList
    }

    init {
        this.ChildItemList = ChildItemList
    }
}
