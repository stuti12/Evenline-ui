package com.example.strengthstudio

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
