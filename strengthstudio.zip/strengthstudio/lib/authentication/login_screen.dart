import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:strengthstudio/constants/colors.dart';
import 'package:strengthstudio/tabbarpage/tab_bar.dart';

import '../../constants/strings.dart';
import '../../custom/custom_button.dart';
import '../../custom/text_style.dart';
import '../constants/shared_pref.dart';
import 'forget_password_screen.dart';
import 'sign_up_screen.dart';

void main() {
  runApp(const LoginScreen());
}

class LoginScreen extends StatefulWidget {
  const LoginScreen({Key? key}) : super(key: key);

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  static final _formKey = GlobalKey<FormState>();
  final PrefService _prefService = PrefService();

  static final TextEditingController _email = TextEditingController();
  static final TextEditingController _password = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
        onTap: () {
          FocusScope.of(context).requestFocus(FocusNode());
        },
        child: MaterialApp(
            debugShowCheckedModeBanner: false,
            home: Scaffold(
              resizeToAvoidBottomInset: false,
              body: Column(
                children: [
                  Expanded(
                    child: Container(
                      height: ScreenUtil().screenHeight,
                      color: AppColors.blackColor,
                      child: SingleChildScrollView(
                        child: Form(
                          key: _formKey,
                          child: Padding(
                            padding: EdgeInsets.only(
                                top: 90.h, left: 30.w, right: 30.w, bottom: 48.h),
                            child: Column(
                              children: [
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    RichText(
                                      text: TextSpan(
                                        text: Strings.welcomeMessageText,
                                        style: UITextStyle.boldTextStyle(
                                            color: Colors.white, fontSize: 30),
                                      ),
                                    ),
                                    SizedBox(height: 13.h),

                                    RichText(
                                      text: TextSpan(
                                        text: Strings.welcomeSubtitleText,
                                        style: UITextStyle.regularTextStyle(
                                            color: Colors.white, fontSize: 20),
                                      ),
                                    ),
                                    SizedBox(height: 27.h),

                                    //Email Field
                                    Container(
                                      width: double.infinity,
                                      color: AppColors.colorGrey,
                                      margin: const EdgeInsets.symmetric(
                                          horizontal: 10.0, vertical: 16.0),
                                      child: TextFormField(
                                        controller: _email,
                                        textInputAction: TextInputAction.next,
                                        style: const TextStyle(color: Colors.white,fontFamily: 'Lato'),
                                        keyboardType: TextInputType.emailAddress,
                                        cursorColor: Colors.white,
                                        decoration: InputDecoration(
                                          filled: true,
                                          labelStyle: const TextStyle(color: Colors.red),
                                          focusedBorder: const OutlineInputBorder(
                                              borderSide:
                                                  BorderSide(color: Colors.red),
                                              borderRadius: BorderRadius.all(
                                                  Radius.circular(5.0))),
                                          border: const OutlineInputBorder(
                                              borderSide:
                                                  BorderSide(color: Colors.red)),
                                          labelText: Strings.emailText,
                                          hintText: Strings.enterEmailText,
                                          hintStyle: UITextStyle.getTextStyle(
                                              color: Colors.grey),
                                        ),
                                        validator: (value) {
                                          if (value?.isEmpty ?? true) {
                                            return 'Please Enter Email';
                                          } else if (value?.isValidEmail() == false) {
                                            return 'Enter valid email';
                                          }
                                          return null;
                                        },
                                      ),
                                    ),

                                    SizedBox(height: 10.h),

                                    //password
                                    Container(
                                      width: double.infinity,
                                      color: AppColors.colorGrey,
                                      margin: const EdgeInsets.symmetric(
                                          horizontal: 10.0),
                                      child: TextFormField(
                                        controller: _password,
                                        textInputAction: TextInputAction.done,
                                        keyboardType: TextInputType.visiblePassword,
                                        style: const TextStyle(color: Colors.white,fontFamily: 'Lato'),
                                        cursorColor: Colors.white,
                                        obscureText: true,
                                        decoration:  InputDecoration(
                                          labelStyle:
                                              const TextStyle(color: AppColors.colorRed),
                                          focusedBorder: const OutlineInputBorder(
                                              borderSide: BorderSide(
                                                  color: AppColors.colorRed),
                                              borderRadius: BorderRadius.all(
                                                  Radius.circular(5.0))),
                                          border: const OutlineInputBorder(
                                              borderSide: BorderSide(
                                                  color: AppColors.colorRed)),
                                          labelText: Strings.passwordText,
                                          hintText: Strings.enterPasswordText,
                                          hintStyle: UITextStyle.getTextStyle(
                                              color: Colors.grey),
                                        ),
                                        validator: (value) {
                                          if (value?.isEmpty ?? true) {
                                            return 'Please Enter Password';
                                          }
                                          return null;
                                        },
                                      ),
                                    ),

                                    SizedBox(height: 30.h),

                                    //button
                                    Container(
                                      margin: EdgeInsets.symmetric(horizontal: 10.h),
                                      child: CustomButton(
                                          title: Strings.signInText.toUpperCase(),
                                          bgColor: AppColors.colorRed,
                                          height: 50.0,
                                          onTap: () async {
                                            _prefService
                                                .createCache(_email.text)
                                                .whenComplete(() {
                                              if (_formKey.currentState!.validate()) {
                                                ScaffoldMessenger.of(_formKey
                                                            .currentState?.context ??
                                                        context)
                                                    .showSnackBar(const SnackBar(
                                                        content: Text(Strings
                                                            .loginSuccessText)));
                                                Navigator.pushReplacement(
                                                    context,
                                                    MaterialPageRoute(
                                                        settings: RouteSettings(
                                                            arguments: _email.text),
                                                        builder: (context) =>
                                                            const TabbarPage()));
                                                _email.text = '';
                                                _password.text = '';
                                              }
                                            });
                                          }),
                                    ),
                                    SizedBox(height: 31.h),

                                    Center(
                                      child: InkWell(
                                        child: RichText(
                                          text: const TextSpan(
                                            text: Strings.forgetText,
                                            style: TextStyle(
                                                fontFamily: 'Lato',
                                                fontSize: 18.0,
                                                color: AppColors.colorLightGrey),
                                          ),
                                        ),
                                        onTap: () {
                                          Navigator.push(context, MaterialPageRoute(
                                              builder: (BuildContext context) {
                                            return const ForgetPasswordScreen();
                                          }));
                                        },
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),

                  //bottom
                  Container(
                    color: AppColors.blackColor,
                    child: Padding(
                      padding: const EdgeInsets.only(bottom: 8.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          RichText(
                            text: TextSpan(
                                text: Strings.dontHaveAccountText,
                                style: const TextStyle(
                                    fontFamily: 'Lato',
                                    fontSize: 18.0,
                                    color: AppColors.colorLightGrey),
                                children: <TextSpan>[
                                  TextSpan(
                                    recognizer: TapGestureRecognizer()
                                      ..onTap = () => {
                                        Navigator.push(
                                            context,
                                            MaterialPageRoute(
                                                builder: (context) =>
                                                const SignUpScreen()))
                                      },
                                    text: Strings.signUpText,
                                    style: const TextStyle(
                                        fontFamily: 'Lato',
                                        fontSize: 18.0,
                                        color: Colors.white),
                                  ),
                                ]),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),

            )));
  }
}

extension EmailValidator on String {
  bool isValidEmail() {
    return RegExp(
            r'^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$')
        .hasMatch(this);
  }
}
