import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:pin_code_fields/pin_code_fields.dart';
import 'package:strengthstudio/createprofile/create_profile_screen.dart';

import '../../constants/strings.dart';
import '../../custom/custom_button.dart';
import '../../custom/text_style.dart';
import '../constants/colors.dart';
import '../strengthstudio/reset_password_screen.dart';

void main() {
  runApp(const VerificationScreen(
    flag: false,
  ));
}

class VerificationScreen extends StatefulWidget {
  const VerificationScreen({required this.flag, Key? key}) : super(key: key);

  final bool flag;

  @override
  State<VerificationScreen> createState() => _VerificationScreenState();
}

class _VerificationScreenState extends State<VerificationScreen> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        backgroundColor: Colors.white,
        scaffoldBackgroundColor: AppColors.blackColor,
      ),
      home: PinCodeVerificationScreen(
          flag: widget.flag), // a random number, please don't call xD
    );
  }
}

class PinCodeVerificationScreen extends StatefulWidget {
  const PinCodeVerificationScreen({
    required this.flag,
    Key? key,
  }) : super(key: key);

  final bool flag;

  @override
  _PinCodeVerificationScreenState createState() =>
      _PinCodeVerificationScreenState();
}

class _PinCodeVerificationScreenState extends State<PinCodeVerificationScreen> {
  TextEditingController textEditingController = TextEditingController();

  // ..text = "123456";
  // ignore: close_sinks
  StreamController<ErrorAnimationType>? errorController;

  bool hasError = false;
  String currentText = "";
  final formKey = GlobalKey<FormState>();

  @override
  void initState() {
    errorController = StreamController<ErrorAnimationType>();
    super.initState();
  }

  @override
  void dispose() {
    errorController!.close();

    super.dispose();
  }

  // snackBar Widget
  snackBar(String? message) {
    return ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message!),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final todo = ModalRoute.of(context)?.settings.arguments;

    return Scaffold(
      backgroundColor: AppColors.blackColor,
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.of(context, rootNavigator: true).pop(context);
          },
        ),
        automaticallyImplyLeading: true,
        backgroundColor: AppColors.blackColor,
        title: Text(''),
        centerTitle: true,
      ),
      body: GestureDetector(
        onTap: () {
          FocusScope.of(context).requestFocus(FocusNode());
        },
        child: SizedBox(
          height: MediaQuery.of(context).size.height,
          width: MediaQuery.of(context).size.width,
          child: ListView(
            children: <Widget>[
              Padding(
                padding: const EdgeInsets.only(top: 18.0, left: 24.0),
                child: RichText(
                  text: TextSpan(
                    text: Strings.verificationText,
                    style: UITextStyle.boldTextStyle(
                      color: Colors.white,
                      fontSize: 26,
                    ),
                  ),
                ),
              ),
              SizedBox(height: 13.h),

              Padding(
                padding: const EdgeInsets.only(top: 14.0, left: 24.0),
                child: RichText(
                  text: TextSpan(
                    text: Strings.emailVerifyText,
                    style: UITextStyle.regularTextStyle(
                        color: Colors.white, fontSize: 18),
                  ),
                ),
              ),
              SizedBox(height: 13.h),

              Padding(
                padding: const EdgeInsets.only(left: 24.0),
                child: RichText(
                  text: TextSpan(
                    text: Strings.verificationSubTitleText,
                    style: UITextStyle.regularTextStyle(
                        color: Colors.white, fontSize: 16),
                  ),
                ),
              ),

              SizedBox(height: 27.h),
              Form(
                key: formKey,
                child: Padding(
                    padding:
                        EdgeInsets.symmetric(vertical: 8.0, horizontal: 50.h),
                    child: PinCodeTextField(
                      appContext: context,
                      pastedTextStyle: const TextStyle(
                        color: Strings.colorRed,
                        fontWeight: FontWeight.bold,
                      ),
                      length: 4,
                      obscureText: true,
                      obscuringCharacter: '*',
                      obscuringWidget: const FlutterLogo(
                        size: 24,
                      ),
                      blinkWhenObscuring: true,
                      animationType: AnimationType.fade,
                      validator: (v) {
                        if (v!.length < 3) {
                          return "*Please fill up all the cells properly";
                        } else {
                          return null;
                        }
                      },
                      pinTheme: PinTheme(
                          shape: PinCodeFieldShape.box,
                          borderRadius: BorderRadius.circular(5),
                          fieldHeight: 50,
                          fieldWidth: 40,
                          activeFillColor: AppColors.colorGrey,
                          inactiveFillColor: AppColors.colorGrey),
                      cursorColor: AppColors.blackColor,
                      animationDuration: const Duration(milliseconds: 300),
                      enableActiveFill: true,
                      errorAnimationController: errorController,
                      controller: textEditingController,
                      keyboardType: TextInputType.number,
                      boxShadows: const [
                        BoxShadow(
                          offset: Offset(0, 1),
                          color: Colors.black12,
                          blurRadius: 10,
                        )
                      ],
                      onCompleted: (v) {
                        debugPrint("Completed");
                      },
                      // onTap: () {
                      //   print("Pressed");
                      // },
                      onChanged: (value) {
                        debugPrint(value);
                        setState(() {
                          currentText = value;
                        });
                      },
                      beforeTextPaste: (text) {
                        debugPrint("Allowing to paste $text");
                        return true;
                      },
                    )),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 30.0),
                child: Text(
                  hasError ? "*Please fill up all the cells properly" : "",
                  style: const TextStyle(
                      color: AppColors.colorRed,
                      fontSize: 12,
                      fontWeight: FontWeight.w400),
                ),
              ),
              //button
              SizedBox(
                child: CustomButton(
                    title: Strings.verifyText,
                    bgColor: AppColors.colorRed,
                    margin: EdgeInsets.symmetric(horizontal: 40.h),
                    height: 50.0,
                    onTap: () async {
                      if (formKey.currentState!.validate()) {
                        if (widget.flag) {
                          print("todo $todo");
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (BuildContext context) =>
                                      const CreateProfileScreen()));
                        } else {
                          print("todo $todo");
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (BuildContext context) =>
                                      ResetPasswordScreen()));
                        }
                      }
                    }),
              ),
              SizedBox(
                height: 25.h,
              ),
              Align(
                alignment: Alignment.center,
                child: RichText(
                  text: const TextSpan(
                    text: Strings.resendOtpText,
                    style: TextStyle(
                        fontFamily: 'Lato', fontSize: 18.0, color: Colors.grey),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
