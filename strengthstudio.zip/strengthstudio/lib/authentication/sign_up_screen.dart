import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:strengthstudio/authentication/verification_screen.dart';

import '../../constants/strings.dart';
import '../../custom/custom_button.dart';
import '../../custom/text_style.dart';
import '../constants/colors.dart';
import 'login_screen.dart';

class SignUpScreen extends StatefulWidget {
  const SignUpScreen({Key? key}) : super(key: key);

  @override
  State<SignUpScreen> createState() => _SignUpScreenState();
}

class _SignUpScreenState extends State<SignUpScreen> {
  static final _formKey = GlobalKey<FormState>();

  static final TextEditingController _email = TextEditingController();
  static final TextEditingController _pass = TextEditingController();
  static final TextEditingController _cpass = TextEditingController();

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
        onTap: () {
          FocusScope.of(context).requestFocus(FocusNode());
        },
        child: MaterialApp(
            debugShowCheckedModeBanner: false,
            home: Scaffold(
              resizeToAvoidBottomInset: false,
              appBar: AppBar(
                backgroundColor: AppColors.blackColor,
                leading: IconButton(
                  icon: const Icon(Icons.arrow_back),
                  onPressed: () {
                    Navigator.of(context, rootNavigator: true).pop(context);
                  },
                ),
                centerTitle: true,
              ),
              body: Column(
                children: [
                  Expanded(
                    child: Container(
                      height: ScreenUtil().screenHeight,
                      color: AppColors.blackColor,
                      child: SingleChildScrollView(
                        child: Form(
                          key: _formKey,
                          child: Padding(
                            padding: EdgeInsets.only(
                                top: 20.h, left: 30.w, right: 30.w, bottom: 48.h),
                            child: Column(
                              children: [
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    RichText(
                                      text: TextSpan(
                                        text: Strings.createAccountText,
                                        style: UITextStyle.boldTextStyle(
                                            color: Colors.white, fontSize: 30),
                                      ),
                                    ),
                                    SizedBox(height: 13.h),

                                    RichText(
                                      text: TextSpan(
                                        text: Strings.signUpSubtitle,
                                        style: UITextStyle.regularTextStyle(
                                            color: Colors.white, fontSize: 18),
                                      ),
                                    ),
                                    SizedBox(height: 27.h),

                                    //Email Field
                                    Container(
                                      width: ScreenUtil().screenWidth,
                                      color: AppColors.colorGrey,
                                      margin: const EdgeInsets.symmetric(
                                          horizontal: 10.0, vertical: 16.0),
                                      child: TextFormField(
                                        controller: _email,
                                        textInputAction: TextInputAction.next,
                                        style: const TextStyle(color: Colors.white,fontFamily: 'Lato'),
                                        keyboardType: TextInputType.emailAddress,
                                        cursorColor: Colors.white,
                                        decoration:  InputDecoration(
                                          filled: true,
                                          labelStyle:
                                              const TextStyle(color: AppColors.colorRed),
                                          focusedBorder: const OutlineInputBorder(
                                              borderSide: BorderSide(
                                                  color: AppColors.colorRed),
                                              borderRadius: BorderRadius.all(
                                                  Radius.circular(5.0))),
                                          border: const OutlineInputBorder(
                                              borderSide: BorderSide(
                                                  color: AppColors.colorRed)),
                                          labelText: Strings.emailText,
                                          hintText: Strings.enterEmailText,
                                          hintStyle:  UITextStyle.getTextStyle(
                                              color: Colors.grey),
                                        ),
                                        validator: (value) {
                                          if (value?.isEmpty ?? true) {
                                            return 'Please Enter Email';
                                          }
                                          return null;
                                        },
                                      ),
                                    ),

                                    //password
                                    Container(
                                      width: ScreenUtil().screenWidth,
                                      color: AppColors.colorGrey,
                                      margin: const EdgeInsets.symmetric(
                                          horizontal: 10.0, vertical: 16.0),
                                      child: TextFormField(
                                        controller: _pass,
                                        keyboardType: TextInputType.visiblePassword,
                                        textInputAction: TextInputAction.next,
                                        style: const TextStyle(color: Colors.white,fontFamily: 'Lato'),
                                        cursorColor: Colors.white,
                                        obscureText: true,
                                        decoration:  InputDecoration(
                                          filled: true,
                                          labelStyle:
                                              const TextStyle(color: AppColors.colorRed),
                                          focusedBorder: const OutlineInputBorder(
                                              borderSide: BorderSide(
                                                  color: AppColors.colorRed),
                                              borderRadius: BorderRadius.all(
                                                  Radius.circular(5.0))),
                                          border: const OutlineInputBorder(
                                              borderSide: BorderSide(
                                                  color: AppColors.colorRed)),
                                          labelText: Strings.passwordText,
                                          hintText: Strings.enterPasswordText,
                                          hintStyle: UITextStyle.getTextStyle(
                                              color: Colors.grey),
                                        ),
                                        validator: (value) {
                                          if (value?.isEmpty ?? true) {
                                            return 'Please Enter Password';
                                          }
                                          return null;
                                        },
                                      ),
                                    ),
                                    //c password
                                    Container(
                                      width: ScreenUtil().screenWidth,
                                      color: AppColors.colorGrey,
                                      margin: const EdgeInsets.symmetric(
                                          horizontal: 10.0, vertical: 16.0),
                                      child: TextFormField(
                                        controller: _cpass,
                                        textInputAction: TextInputAction.done,
                                        style: const TextStyle(color: Colors.white,fontFamily: 'Lato'),
                                        cursorColor: Colors.white,
                                        obscureText: true,
                                        decoration: InputDecoration(
                                          filled: true,
                                          labelStyle:
                                              TextStyle(color: AppColors.colorRed),
                                          focusedBorder: const OutlineInputBorder(
                                              borderSide: BorderSide(
                                                  color: AppColors.colorRed),
                                              borderRadius: BorderRadius.all(
                                                  Radius.circular(5.0))),
                                          border: const OutlineInputBorder(
                                              borderSide: BorderSide(
                                                  color: AppColors.colorRed)),
                                          labelText: Strings.confirmPasswordText,
                                          hintText: Strings.enterCPasswordText,
                                          hintStyle: UITextStyle.getTextStyle(
                                              color: Colors.grey),
                                        ),
                                        validator: (value) {
                                          if (value?.isEmpty ?? true) {
                                            return 'Please Enter Password';
                                          }
                                          if (value != _pass.text) {
                                            return 'Not match';
                                          }
                                          return null;
                                        },
                                      ),
                                    ),

                                    SizedBox(height: 20.h),

                                    //button
                                    SizedBox(
                                      child: CustomButton(
                                          margin: EdgeInsets.symmetric(horizontal: 8.h),
                                          title: Strings.signUpText.toUpperCase(),
                                          bgColor: AppColors.colorRed,
                                          fontWeight: FontWeight.bold,
                                          height: 50.0,
                                          onTap: () {
                                            if (_formKey.currentState!.validate()) {
                                              ScaffoldMessenger.of(
                                                      _formKey.currentState!.context)
                                                  .showSnackBar(const SnackBar(
                                                      content: Text(
                                                          Strings.loginSuccessText)));
                                              Navigator.push(context,
                                                  MaterialPageRoute(builder:
                                                      (BuildContext context) {
                                                return const VerificationScreen(
                                                  flag: true,
                                                );
                                              }));
                                              _email.text = '';
                                              _pass.text = '';
                                              _cpass.text = '';
                                            }
                                          }),
                                    ),
                                  ],
                                ),

                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  //bottom part
                  Container(color: AppColors.blackColor,
                    child: Padding(
                      padding: const EdgeInsets.only(bottom: 8.0),
                      child: Align(
                        alignment: Alignment.bottomCenter,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            RichText(
                              text: TextSpan(
                                  text: Strings.alreadyHaveAccText,
                                  style: const TextStyle(
                                      fontFamily: 'Lato',
                                      fontSize: 18.0,
                                      color: AppColors.colorLightGrey),
                                  children: <TextSpan>[
                                    TextSpan(
                                      recognizer: TapGestureRecognizer()
                                        ..onTap = () => {
                                          Navigator.push(
                                              context,
                                              MaterialPageRoute(
                                                  builder: (context) =>
                                                      LoginScreen()))
                                        },
                                      text: Strings.signInText,
                                      style: UITextStyle.semiBoldTextStyle(fontSize: 18),
                                    ),
                                  ]),
                            ),
                          ],
                        ),
                      ),
                    ),
                  )

                ],
              ),

            )));
  }
}
