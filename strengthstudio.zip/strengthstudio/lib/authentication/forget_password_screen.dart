import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:strengthstudio/constants/colors.dart';

import '../../constants/strings.dart';
import '../../custom/custom_button.dart';
import '../../custom/text_style.dart';
import 'login_screen.dart';
import 'verification_screen.dart';

void main() {
  runApp(const ForgetPasswordScreen());
}

class ForgetPasswordScreen extends StatefulWidget {
  const ForgetPasswordScreen({Key? key}) : super(key: key);

  @override
  State<ForgetPasswordScreen> createState() => _ForgetPasswordScreenState();
}

class _ForgetPasswordScreenState extends State<ForgetPasswordScreen> {
  static final _formKey = GlobalKey<FormState>();

  static final TextEditingController _email = TextEditingController();

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
        onTap: () {
          FocusScope.of(context).requestFocus(FocusNode());
        },
        child: MaterialApp(
            debugShowCheckedModeBanner: false,
            home: SafeArea(
              child: Scaffold(
                resizeToAvoidBottomInset: false,
                appBar: AppBar(
                  backgroundColor: AppColors.blackColor,
                  leading: IconButton(
                    icon: const Icon(Icons.arrow_back),
                    onPressed: () {
                      Navigator.of(context, rootNavigator: true).pop(context);
                    },
                  ),
                  centerTitle: true,
                ),
                body: Column(
                  children: [
                    Expanded(
                      child: Container(
                        height: ScreenUtil().screenHeight,
                        color: AppColors.blackColor,
                        child: SingleChildScrollView(
                          child: Form(
                            key: _formKey,
                            child: Padding(
                              padding: EdgeInsets.only(
                                  top: 30.h, left: 30.w, right: 30.w, bottom: 48.h),
                              child: Column(
                                children: [
                                  Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      RichText(
                                        text: TextSpan(
                                          text: Strings.forgetPasswordText,
                                          style: UITextStyle.boldTextStyle(
                                            color: Colors.white,
                                            fontSize: 26,
                                          ),
                                        ),
                                      ),
                                      SizedBox(height: 13.h),

                                      RichText(
                                        text: TextSpan(
                                          text: Strings.forgetSubTitleText,
                                          style: UITextStyle.regularTextStyle(
                                              color: Colors.white, fontSize: 18),
                                        ),
                                      ),
                                      SizedBox(height: 27.h),

                                      //Email Field
                                      Container(
                                        width: ScreenUtil().screenWidth,
                                        color: AppColors.colorGrey,
                                        margin: const EdgeInsets.symmetric(
                                            horizontal: 10.0, vertical: 16.0),
                                        child: TextFormField(
                                          controller: _email,
                                          style: const TextStyle(color: Colors.white,fontFamily: 'Lato'),
                                          keyboardType: TextInputType.emailAddress,
                                          cursorColor: Colors.white,
                                          decoration: const InputDecoration(
                                            filled: true,
                                            labelStyle:
                                                TextStyle(color: Strings.colorRed),
                                            focusedBorder: OutlineInputBorder(
                                                borderSide:
                                                    BorderSide(color: Strings.colorRed),
                                                borderRadius: BorderRadius.all(
                                                    Radius.circular(5.0))),
                                            border: OutlineInputBorder(
                                                borderSide: BorderSide(
                                                    color: Strings.colorRed)),
                                            labelText: Strings.emailText,
                                            hintText: Strings.enterEmailText,
                                            hintStyle: TextStyle(color: Colors.grey),
                                          ),
                                          validator: (value) {
                                            if (value?.isEmpty ?? true) {
                                              return 'Please Enter Email';
                                            }
                                            return null;
                                          },
                                        ),
                                      ),

                                      SizedBox(height: 30.h),

                                      //button
                                      SizedBox(
                                        child: CustomButton(
                                          margin: EdgeInsets.symmetric(horizontal: 8.h),
                                            title: Strings.nextText,
                                            bgColor: Strings.colorRed,
                                            height: 50.0,
                                            onTap: () async {
                                              if (_formKey.currentState!.validate()) {
                                            
                                                Navigator.push(
                                                    context,
                                                    MaterialPageRoute(
                                                        builder:
                                                            (BuildContext context) {
                                                          return const VerificationScreen(
                                                            flag: false,
                                                          );
                                                        }));
                                              }
                                            }),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    
                    //bottom part
                    Align(    alignment: Alignment.bottomCenter,
                      child: Container(
                        color: AppColors.blackColor,
                        child: Padding(
                          padding: const EdgeInsets.only(bottom: 8.0),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              RichText(
                                text: TextSpan(
                                    text: Strings.rememberPasswordText,
                                    style: const TextStyle(
                                        fontFamily: 'Lato',
                                        fontSize: 18.0,
                                        color: AppColors.colorLightGrey),
                                    children: <TextSpan>[
                                      TextSpan(
                                        recognizer: TapGestureRecognizer()
                                          ..onTap = () => {
                                            Navigator.push(
                                                context,
                                                MaterialPageRoute(
                                                    builder: (context) =>
                                                    const LoginScreen()))
                                          },
                                        text: Strings.signInText,
                                        style: const TextStyle(
                                            fontFamily: 'Lato',
                                            fontSize: 18.0,
                                            color: Colors.white),
                                      ),
                                    ]),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ],
                ),

              ),
            )));
  }
}
