import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:strengthstudio/constants/colors.dart';
import 'package:strengthstudio/custom/custom_button.dart';
import 'package:strengthstudio/custom/text_style.dart';

import '../../constants/strings.dart';

class ProgramDetails extends StatefulWidget {
  const ProgramDetails({Key? key}) : super(key: key);

  @override
  State<ProgramDetails> createState() => _ProgramDetailsState();
}

class _ProgramDetailsState extends State<ProgramDetails> {
  double _rating = 2.0;

  @override
  void initState() {
    _rating = 2.0;
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
        length: 2,
        child: Scaffold(
          backgroundColor: Colors.black,
          appBar: AppBar(
            backgroundColor: Colors.black,
            title: const Text(Strings.programLibrartAppTitle),
            centerTitle: true,
          ),
          body: SingleChildScrollView(
            child: Column(
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Image.asset(
                      'assets/programbanner.png',
                      width: double.infinity,
                    ),
                    Padding(
                      padding: const EdgeInsets.all(14.0),
                      child: Text(
                        Strings.programLibraryTitleText,
                        style: UITextStyle.regularTextStyle(fontSize: 16),
                      ),
                    ),
                    Row(
                      children: [
                        const Padding(
                          padding: EdgeInsets.symmetric(horizontal: 14.0),
                          child: Text(
                            Strings.dollarText,
                            style: TextStyle(
                                fontSize: 16, color: AppColors.colorRed),
                          ),
                        ),
                        Expanded(
                          child: Align(
                            alignment: Alignment.topRight,
                            child: Row(
                              children: [
                                _ratingBar(1),
                                Text(
                                  '$_rating',
                                  style: const TextStyle(
                                      fontFamily: 'Lato',
                                      fontSize: 15,
                                      color: Colors.white),
                                )
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                    Padding(
                      padding: const EdgeInsets.only(top: 14.0, left: 14),
                      child: Text(
                        Strings.programLengthText,
                        style: UITextStyle.regularTextStyle(fontSize: 16),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 14.0),
                      child: Text(
                        Strings.overaalLiftingText,
                        style: UITextStyle.regularTextStyle(fontSize: 16),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 14.0),
                      child: Text(
                        Strings.typeText,
                        style: UITextStyle.regularTextStyle(fontSize: 16),
                      ),
                    ),

                    //tabbar
                    Padding(
                      padding: const EdgeInsets.all(4.0),
                      child: Container(
                        color: Colors.black,
                        height: 50,
                        child: AppBar(
                          backgroundColor: Colors.black,
                          bottom: const TabBar(
                            indicatorColor: Colors.white,
                            tabs: [
                              Tab(text: Strings.detailsText),
                              Tab(text: Strings.reviewText)
                            ],
                          ),
                        ),
                      ),
                    ),
                    Container(
                        decoration: const BoxDecoration(
                            border: Border(
                                top: BorderSide(
                                    color: Colors.grey, width: 0.5))),
                        height: 140,
                        child: const TabBarView(
                            children: [FirstScreen(), SecondScreen()])),
                  ],
                ),

                //footer
                Container(
                  width: double.infinity,
                  alignment: Alignment.bottomCenter,
                  color: Strings.colorPrimaryGrey,
                  height: 80,
                  child: CustomButton(
                    title: Strings.buyNowText.toUpperCase(),
                    height: 70.h,
                    bgColor: Strings.colorRed,
                    margin: const EdgeInsets.all(10),
                    onTap: () {},
                  ),
                )
              ],
            ),
          ),
        ));
  }

  Widget _ratingBar(int mode) {
    IconData? _selectedIcon;
    switch (mode) {
      case 1:
        return RatingBar.builder(
          initialRating: 2.0,
          minRating: 1,
          direction: false ? Axis.vertical : Axis.horizontal,
          allowHalfRating: true,
          unratedColor: Colors.amber.withAlpha(50),
          itemCount: 5,
          itemSize: 20.0,
          itemPadding: const EdgeInsets.symmetric(horizontal: 4.0),
          itemBuilder: (context, _) => Icon(
            _selectedIcon ?? Icons.star,
            color: Colors.white,
          ),
          onRatingUpdate: (rating) {
            setState(() {
              _rating = rating;
            });
          },
          updateOnDrag: true,
        );
      default:
        return Container();
    }
  }
}

class FirstScreen extends StatelessWidget {
  const FirstScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return const SingleChildScrollView(
      child: Padding(
          padding: EdgeInsets.all(20.0),
          child: Text(
            Strings.programDetailText,
            style: TextStyle(
                color: Colors.white, fontFamily: 'Lato', fontSize: 15.0),
          )),
    );
  }
}

class SecondScreen extends StatefulWidget {
  const SecondScreen({Key? key}) : super(key: key);

  @override
  State<StatefulWidget> createState() => _SecondScreen();
}

class _SecondScreen extends State<SecondScreen> {
  List<String> list = ['Caden'];

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(4),
      child: (list != null && list.isNotEmpty)
          ? ListView.builder(
              itemCount: list.length,
              itemBuilder: (context, index) {
                return ProgBox(
                    name: list[index],
                    image: 'assets/person.png',
                    title: Strings.noReviewAddedSubtitleText);
              })
          :

          //view when no data
          SingleChildScrollView(
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Visibility(
                    visible: true,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Text(
                            Strings.noReviewsAddedText,
                            style: UITextStyle.regularTextStyle(fontSize: 18),
                          ),
                        ),
                        const Padding(
                          padding: EdgeInsets.all(8.0),
                          child: Text(
                            Strings.noReviewAddedSubtitleText,
                            style: TextStyle(
                                fontFamily: 'Lato',
                                fontSize: 16,
                                color: Colors.grey),
                          ),
                        ),
                        CustomButton(
                          title: Strings.addYourReview,
                          bgColor: Strings.colorActionSheetButton,
                          onTap: () {
                            showModalBottomSheet<void>(
                              context: context,
                              builder: (BuildContext context) {
                                return SingleChildScrollView(
                                  child: SizedBox(
                                    child: Column(
                                      children: [
                                        Container(
                                          color: Strings.colorPrimaryGrey,
                                          width: double.infinity,
                                          padding: const EdgeInsets.only(
                                              top: 10, bottom: 5.0),
                                          child: const Text(
                                            Strings.addYourReview,
                                            style: TextStyle(
                                                fontFamily: 'Lato-Bold',
                                                fontSize: 18,
                                                color: Colors.white),
                                            textAlign: TextAlign.center,
                                          ),
                                        ),
                                        Container(
                                          color: Strings.colorPrimaryGrey,
                                          width: double.infinity,
                                          padding: const EdgeInsets.only(
                                              top: 10, bottom: 5.0),
                                          child: Center(child: _ratingBar(1)),
                                        ),
                                        Container(
                                          color: Strings.colorPrimaryGrey,
                                          width: double.infinity,
                                          padding: const EdgeInsets.only(
                                              top: 10, bottom: 5.0),
                                          child: const Padding(
                                            padding: EdgeInsets.symmetric(
                                                horizontal: 14.0),
                                            child: TextField(
                                              style: TextStyle(
                                                  color: Colors.white),
                                              maxLines: 5,
                                              cursorColor: Colors.white,
                                              decoration: InputDecoration(
                                                  border: OutlineInputBorder(),
                                                  enabledBorder:
                                                      OutlineInputBorder(
                                                    borderSide: BorderSide(
                                                        color:
                                                            Strings.colorGrey,
                                                        width: 0.0),
                                                  ),
                                                  filled: true,
                                                  fillColor: Strings.colorGrey,
                                                  hintText:
                                                      'Enter your comments here...',
                                                  hintStyle: TextStyle(
                                                      color: Colors.grey)),
                                            ),
                                          ),
                                        ),
                                        Container(
                                          color: Strings.colorPrimaryGrey,
                                          width: double.infinity,
                                          child: CustomButton(
                                            title: Strings.submitText,
                                            bgColor: Strings.colorRed,
                                            onTap: () {},
                                            margin: const EdgeInsets.symmetric(
                                                horizontal: 14.0,
                                                vertical: 4.0),
                                          ),
                                        ),
                                        Container(
                                          color: Strings.colorPrimaryGrey,
                                          width: double.infinity,
                                          child: CustomButton(
                                            title: Strings.closeText,
                                            bgColor:
                                                Strings.colorActionSheetButton,
                                            onTap: () {},
                                            margin: const EdgeInsets.symmetric(
                                                horizontal: 14.0,
                                                vertical: 4.0),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                );
                              },
                            );
                          },
                          margin: const EdgeInsets.symmetric(
                              horizontal: 10.0, vertical: 4.0),
                        ),
                      ],
                    )),
              ),
            ),
    );
  }

  Widget _ratingBar(int mode) {
    IconData? _selectedIcon;
    switch (mode) {
      case 1:
        return RatingBar.builder(
          initialRating: 2.0,
          minRating: 1,
          direction: false ? Axis.vertical : Axis.horizontal,
          allowHalfRating: true,
          unratedColor: Colors.amber.withAlpha(50),
          itemCount: 5,
          itemSize: 30.0,
          itemPadding: const EdgeInsets.symmetric(horizontal: 4.0),
          itemBuilder: (context, _) => Icon(
            _selectedIcon ?? Icons.star,
            color: Colors.white,
          ),
          onRatingUpdate: (rating) {
            /*    setState(() {
              _ratings = rating;
            });*/
          },
          updateOnDrag: true,
        );
      default:
        return Container();
    }
  }
}

class ProgBox extends StatefulWidget {
  const ProgBox(
      {Key? key, required this.name, required this.image, required this.title})
      : super(key: key);
  final String image;
  final String name;
  final String title;

  @override
  State<StatefulWidget> createState() => _ProgBox();
}

class _ProgBox extends State<ProgBox> {
  double _ratings = 2.0;

  @override
  void initState() {
    _ratings = 2.0;
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        //name row
        Row(
          children: const [
            Padding(
              padding: EdgeInsets.all(8.0),
              child: Icon(
                Icons.person_outline_rounded,
                color: Colors.white,
              ),
            ),
            Text(
              'Caden',
              style: TextStyle(color: Colors.white, fontFamily: 'Lato'),
            ),
            Expanded(
              child: Padding(
                padding: EdgeInsets.only(right: 8.0),
                child: Align(
                  alignment: Alignment.topRight,
                  child: Text(
                    Strings.verifiefOwner,
                    style: TextStyle(color: Colors.grey, fontFamily: 'Lato'),
                  ),
                ),
              ),
            )
          ],
        ),

        //ratingbar
        Row(
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 30.0),
              child: _ratingBar(1),
            ),
            Text(
              '$_ratings',
              style: const TextStyle(
                  fontFamily: 'Lato', fontSize: 15, color: Colors.white),
            ),
            const Expanded(
              child: Padding(
                  padding: EdgeInsets.only(right: 8.0),
                  child: Align(
                    alignment: Alignment.topRight,
                    child: Text(
                      Strings.datesText,
                      style: TextStyle(color: Colors.grey, fontFamily: 'Lato'),
                    ),
                  )),
            )
          ],
        ),
        const Padding(
          padding: EdgeInsets.symmetric(horizontal: 14.0),
          child: Text(
            Strings.reviewDetailText,
            style: TextStyle(
                fontFamily: 'Lato', fontSize: 15, color: Colors.white),
          ),
        ),
        const SizedBox(
          height: 5.0,
        ),
        CustomButton(
          title: Strings.addYourReview,
          bgColor: Strings.colorActionSheetButton,
          onTap: () {
            showModalBottomSheet<void>(
              context: context,
              builder: (BuildContext context) {
                return SingleChildScrollView(
                  child: SizedBox(
                    child: Column(
                      children: [
                        Container(
                          color: Strings.colorPrimaryGrey,
                          width: double.infinity,
                          padding: const EdgeInsets.only(top: 10, bottom: 5.0),
                          child: const Text(
                            Strings.addYourReview,
                            style: TextStyle(
                                fontFamily: 'Lato-Bold',
                                fontSize: 18,
                                color: Colors.white),
                            textAlign: TextAlign.center,
                          ),
                        ),
                        Container(
                          color: Strings.colorPrimaryGrey,
                          width: double.infinity,
                          padding: const EdgeInsets.only(top: 10, bottom: 5.0),
                          child: Center(child: _ratingBar(1)),
                        ),
                        Container(
                          color: Strings.colorPrimaryGrey,
                          width: double.infinity,
                          padding: const EdgeInsets.only(top: 10, bottom: 5.0),
                          child: const Padding(
                            padding: EdgeInsets.symmetric(horizontal: 14.0),
                            child: TextField(
                              style: TextStyle(color: Colors.white),
                              maxLines: 5,
                              cursorColor: Colors.white,
                              decoration: InputDecoration(
                                  border: OutlineInputBorder(),
                                  enabledBorder: OutlineInputBorder(
                                    borderSide: BorderSide(
                                        color: Strings.colorGrey, width: 0.0),
                                  ),
                                  filled: true,
                                  fillColor: Strings.colorGrey,
                                  hintText: 'Enter your comments here...',
                                  hintStyle: TextStyle(color: Colors.grey)),
                            ),
                          ),
                        ),
                        Container(
                          color: Strings.colorPrimaryGrey,
                          width: double.infinity,
                          child: CustomButton(
                            title: Strings.submitText,
                            bgColor: Strings.colorRed,
                            onTap: () {},
                            margin: const EdgeInsets.symmetric(
                                horizontal: 14.0, vertical: 4.0),
                          ),
                        ),
                        Container(
                          color: Strings.colorPrimaryGrey,
                          width: double.infinity,
                          child: CustomButton(
                            title: Strings.closeText,
                            bgColor: Strings.colorActionSheetButton,
                            onTap: () {},
                            margin: const EdgeInsets.symmetric(
                                horizontal: 14.0, vertical: 4.0),
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            );
          },
          margin: const EdgeInsets.symmetric(horizontal: 14.0, vertical: 4.0),
        ),
      ],
    );
  }

  Widget _ratingBar(int mode) {
    IconData? _selectedIcon;
    switch (mode) {
      case 1:
        return RatingBar.builder(
          initialRating: 2.0,
          minRating: 1,
          direction: false ? Axis.vertical : Axis.horizontal,
          allowHalfRating: true,
          unratedColor: Colors.amber.withAlpha(50),
          itemCount: 5,
          itemSize: 20.0,
          itemPadding: const EdgeInsets.symmetric(horizontal: 4.0),
          itemBuilder: (context, _) => Icon(
            _selectedIcon ?? Icons.star,
            color: Colors.white,
          ),
          onRatingUpdate: (rating) {
            setState(() {
              _ratings = rating;
            });
          },
          updateOnDrag: true,
        );
      default:
        return Container();
    }
  }
}
