import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:strengthstudio/constants/colors.dart';
import 'package:strengthstudio/custom/custom_program_library_search.dart';
import 'package:strengthstudio/custom/text_style.dart';
import 'package:strengthstudio/tabbarpage/programs/program_details.dart';

import '../../constants/strings.dart';
import '../../custom/custom_button.dart';

class ProgramLibrary extends StatefulWidget {
  const ProgramLibrary({Key? key}) : super(key: key);

  @override
  State<ProgramLibrary> createState() => _ProgramLibraryState();
}

class _ProgramLibraryState extends State<ProgramLibrary> {
  int _selectedIndex = 0;
  List<String> list = [
    'FILTER',
    Strings.allText,
    Strings.powerBuildingText,
    Strings.strengthText,
    Strings.hyperTrophyText,
  ];

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
          backgroundColor: AppColors.blackColor,
          appBar: AppBar(
            backgroundColor: AppColors.blackColor,
            title: const Text(Strings.programLibrartAppTitle,
                style: TextStyle(fontFamily: 'Lato')),
            leading: IconButton(
              icon: const Icon(Icons.filter_alt),
              onPressed: () {
                showModalBottomSheet<void>(
                  backgroundColor: AppColors.blackColor,
                  context: context,
                  builder: (BuildContext context) {
                    return ListView.builder(
                        itemCount: list.length,
                        itemBuilder: (BuildContext context, int index) {
                          return ListTile(
                              selectedColor: Colors.white,
                              selectedTileColor: AppColors.blackColor,
                              textColor: Colors.grey,
                              tileColor: AppColors.blackColor,
                              title: Text(list[index]),
                              selected: index == _selectedIndex,
                              onTap: () {
                                setState(() {
                                  _selectedIndex = index;
                                });
                              });
                        });
                  },
                );
              },
            ),
            centerTitle: true,
            actions: [
              IconButton(
                icon: const Icon(Icons.search),
                onPressed: () {
                  showSearch(
                      context: context,
                      delegate: CustomProgramLibrarySearchDelegate());
                },
              )
            ],
          ),
          body: const FirstScreen()),
    );
  }
}

class FirstScreen extends StatefulWidget {
  const FirstScreen({Key? key}) : super(key: key);

  @override
  State<FirstScreen> createState() => _FirstScreenState();
}

class _FirstScreenState extends State<FirstScreen> {
  @override
  Widget build(BuildContext context) {
    List<String> list = [
      Strings.programLibraryTitleText,
      Strings.programLibraryTitleText,
      Strings.programLibraryTitleText,
      Strings.programLibraryTitleText,
      Strings.programLibraryTitleText,
      Strings.programLibraryTitleText
    ];
    List<String> images = [
      'main_1.png',
      'main_1.png',
      'main_1.png',
      'main_1.png',
      'main_1.png',
      'main_1.png',
    ];
    List<String> rating = ['2.0', '3.0', '2.0', '2.0', '3.0', '2.0'];
    List<String> price = [
      Strings.dollarText,
      Strings.dollarText,
      Strings.dollarText,
      Strings.dollarText,
      Strings.dollarText,
      Strings.dollarText
    ];
    List<String> discount = [
      Strings.dollarDiscountText,
      Strings.dollarDiscountText,
      Strings.dollarDiscountText,
      Strings.dollarDiscountText,
      Strings.dollarDiscountText,
      Strings.dollarDiscountText
    ];
    return Padding(
      padding: const EdgeInsets.all(20.0),
      child: (list != null && list.isNotEmpty)
          ? InkWell(
              onTap: () {
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => const ProgramDetails()));
              },
              child: Ink(
                color: Colors.transparent,
                child: ListView.builder(
                    itemCount: list.length,
                    itemBuilder: (BuildContext context, int index) {
                      return ProgramBox(
                        name: list[index],
                        image: images[index],
                        rating: rating[index],
                        price: price[index],
                        discountPrice: discount[index],
                      );
                    }),
              ),
            )
          :
          //view when no data
          SingleChildScrollView(
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Visibility(
                    visible: true,
                    child: Column(
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(top: 100.0),
                          child: Center(
                              child: Image.asset('assets/no_library.png')),
                        ),
                        Text(
                          Strings.noProgramLibraryText,
                          style: UITextStyle.mediumTextStyle(fontSize: 20),
                          textAlign: TextAlign.center,
                        ),
                        const Padding(
                          padding: EdgeInsets.symmetric(horizontal: 28.0),
                          child: Text(
                            Strings.noProgramLibrarySubtitleText,
                            textAlign: TextAlign.center,
                            style: TextStyle(
                                fontFamily: 'Lato',
                                fontSize: 14,
                                color: Colors.grey),
                          ),
                        ),
                        CustomButton(
                            margin: const EdgeInsets.symmetric(
                                horizontal: 30.0, vertical: 10),
                            title: Strings.refreshPageText,
                            bgColor: AppColors.colorRed,
                            fontWeight: FontWeight.bold,
                            height: 45.0,
                            onTap: () {
                              //refresh page
                            }),
                      ],
                    )),
              ),
            ),
    );
  }
}

class ProgramBox extends StatefulWidget {
  ProgramBox(
      {Key? key,
      this.name,
      this.image,
      this.rating,
      this.price,
      this.discountPrice,
      this.chip})
      : super(key: key);
  String? name;
  String? image;
  String? rating;
  String? price;
  String? discountPrice;
  List<String>? chip;

  @override
  State<StatefulWidget> createState() => _ProgramBoxState();
}

class _ProgramBoxState extends State<ProgramBox> {
  List<String>? chips = [Strings.powerBuildingText, Strings.hyperTrophyText];
  double _rating = 2.0;

  @override
  void initState() {
    _rating = 2.0;
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: ScreenUtil().screenWidth,
      child: Card(
          color: Strings.colorGrey,
          child: Row(children: <Widget>[
            Padding(
              padding: const EdgeInsets.only(left: 8.0),
              child: Image.asset(
                "assets/${widget.image}",
                width: 70.h,
              ),
            ),
            Expanded(
                child: Container(
                    padding: const EdgeInsets.all(4),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Padding(
                          padding: const EdgeInsets.all(4.0),
                          child: Text(widget.name ?? "not found",
                              style: const TextStyle(
                                  color: Colors.white,
                                  fontFamily: 'Lato',
                                  fontSize: 16.0)),
                        ),
                        Row(
                          children: [
                            _ratingBar(1),
                            Text(
                              '$_rating',
                              style: const TextStyle(
                                  fontFamily: 'Lato',
                                  fontWeight: FontWeight.bold,
                                  color: Colors.white),
                            ),
                          ],
                        ),

                        //price
                        Card(
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(5.0)),
                          elevation: 10,
                          color: Strings.colorRed,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceAround,
                            children: [
                              Padding(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 4.0, vertical: 6.0),
                                child: Text(
                                  widget.price ?? "not found",
                                  style: UITextStyle.regularTextStyle(
                                      fontSize: 19, color: Colors.white),
                                ),
                              ),
                              Padding(
                                padding:
                                    const EdgeInsets.symmetric(horizontal: 4.0),
                                child: Text(widget.discountPrice ?? "not found",
                                    style: const TextStyle(
                                        color: Colors.grey,
                                        fontSize: 19,
                                        fontFamily: 'Lato',
                                        decoration:
                                            TextDecoration.lineThrough)),
                              ),
                              const Icon(
                                Icons.arrow_right_alt,
                                color: Colors.white,
                                size: 30,
                              )
                            ],
                          ),
                        ),

                        //chip
                        Row(
                          children: [
                            Padding(
                              padding: const EdgeInsets.all(2.0),
                              child: Chip(
                                elevation: 20,
                                padding: const EdgeInsets.all(4),
                                backgroundColor: Strings.colorActionSheetButton,
                                shadowColor: AppColors.blackColor,
                                //CircleAvatar
                                label: Text(
                                  chips?[0] ?? "not found",
                                  style: const TextStyle(
                                      fontSize: 12,
                                      color: Colors.white,
                                      fontFamily: 'Lato'),
                                ), //Text
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.all(4.0),
                              child: Chip(
                                elevation: 20,
                                padding: const EdgeInsets.all(4),
                                backgroundColor: Strings.colorActionSheetButton,
                                shadowColor: AppColors.blackColor,
                                //CircleAvatar
                                label: Text(
                                  chips?[1] ?? "not found",
                                  style: const TextStyle(
                                      fontFamily: 'Lato',
                                      fontSize: 12,
                                      color: Colors.white),
                                ), //Text
                              ),
                            ),
                          ],
                        ),
                      ],
                    )))
          ])),
    );
  }

  Widget _ratingBar(int mode) {
    IconData? _selectedIcon;
    switch (mode) {
      case 1:
        return RatingBar.builder(
          initialRating: 2.0,
          minRating: 1,
          direction: false ? Axis.vertical : Axis.horizontal,
          allowHalfRating: true,
          unratedColor: Colors.amber.withAlpha(50),
          itemCount: 5,
          itemSize: 20.0,
          itemPadding: const EdgeInsets.symmetric(horizontal: 4.0),
          itemBuilder: (context, _) => Icon(
            _selectedIcon ?? Icons.star,
            color: Colors.white,
          ),
          onRatingUpdate: (rating) {
            setState(() {
              _rating = rating;
            });
          },
          updateOnDrag: true,
        );
      default:
        return Container();
    }
  }
}
