import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../constants/colors.dart';
import '../../constants/strings.dart';

class Reply extends StatefulWidget {
  const Reply({Key? key}) : super(key: key);

  @override
  State<Reply> createState() => _ReplyState();
}

class _ReplyState extends State<Reply> {
  static final TextEditingController _comment = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        centerTitle: true,
        backgroundColor: Colors.black,
        title: const Text(
          'Reply',
          style: TextStyle(color: Colors.white, fontFamily: 'Lato'),
        ),
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: SizedBox(
              child: ListView.builder(
                  itemCount: 2,
                  itemBuilder: (BuildContext context, int index) {
                    return CommentBox(
                        name: 'Cadem',
                        description:
                            'You can’t go wrong with this bundle, sick programs. Thank you Jamal and SST Team',
                        image: 'person.png');
                  }),
            ),
          ),
          const Padding(
            padding: EdgeInsets.all(8.0),
            child: SizedBox(
                child: Text(
              'Reply(25)',
              style: TextStyle(
                  color: Colors.white, fontFamily: 'Lato', fontSize: 16.0),
            )),
          ),
          Expanded(
            child: ListView.builder(
                itemCount: 4,
                itemBuilder: (BuildContext context, int index) {
                  return CommentBoxReply(
                    name: 'Cadem',
                    description:
                        'You can’t go wrong with this bundle, sick programs. Thank you Jamal and SST Team',
                    image: 'person.png',
                    duration: Strings.durationText,
                  );
                }),
          ),
          Container(
            color: Strings.colorGrey,
            height: 70,
            child: Row(
              children: [
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: TextField(
                      controller: _comment,
                      decoration: const InputDecoration(
                          hintStyle:
                              TextStyle(color: Colors.grey, fontFamily: 'Lato'),
                          hintText: Strings.typeReplyText),
                      style: TextStyle(fontFamily: 'Lato', color: Colors.white),
                    ),
                  ),
                ),
                Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: CircleAvatar(
                        backgroundColor: Colors.red,
                        child: IconButton(
                            onPressed: () {},
                            icon: const Icon(
                              Icons.reply,
                              color: Colors.white,
                            ))))
              ],
            ),
          )
        ],
      ),
    );
  }
}

class CommentBox extends StatefulWidget {
  String? name;
  String? description;
  String? image;
  String? duration;

  CommentBox(
      {super.key, this.name, this.description, this.image, this.duration});

  @override
  State<StatefulWidget> createState() => _CommentBoxState();
}

class _CommentBoxState extends State<CommentBox> {
  int like = 0;
  int dislike = 0;

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Strings.colorGrey,
      padding: const EdgeInsets.all(2),
      child: Card(
          color: Strings.colorGrey,
          child: Column(
            children: [
              Row(children: <Widget>[
                Padding(
                  padding: const EdgeInsets.only(left: 8.0),
                  child: Image.asset("assets/${widget.image}"),
                ),
                Expanded(
                    child: Container(
                        padding: const EdgeInsets.all(4),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Text(widget.name ?? "",
                                  style: const TextStyle(
                                      color: Colors.white,
                                      fontFamily: 'Lato',
                                      fontSize: 16.0)),
                            ),
                            Padding(
                              padding: const EdgeInsets.only(left: 8.0),
                              child: Text(widget.description ?? "",
                                  style: const TextStyle(
                                      color: Colors.grey, fontFamily: 'Lato')),
                            ),
                          ],
                        ))),
                const Padding(
                  padding: EdgeInsets.all(8.0),
                  child: Text('1 Day',
                      style: TextStyle(color: Colors.grey, fontFamily: 'Lato')),
                ),
              ]),
              Row(
                children: [
                  Padding(
                      padding: const EdgeInsets.only(left: 36.0),
                      child: InkWell(
                        child: const Icon(
                          Icons.thumb_up_outlined,
                          color: Colors.white,
                        ),
                        onTap: () {
                          setState(() {
                            like++;
                          });
                          print('like$like');
                        },
                      )),
                  Padding(
                    padding: const EdgeInsets.only(left: 8.0),
                    child: Text(
                      like.toString(),
                      style: const TextStyle(
                          fontFamily: 'Lato', color: Colors.white),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(left: 8.0),
                    child: InkWell(
                      child: const Icon(
                        Icons.thumb_down_outlined,
                        color: Colors.white,
                      ),
                      onTap: () {
                        setState(() {
                          dislike++;
                        });
                      },
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(left: 8.0),
                    child: Text(
                      dislike.toString(),
                      style: TextStyle(fontFamily: 'Lato', color: Colors.white),
                    ),
                  )
                ],
              )
            ],
          )),
    );
  }
}

class CommentBoxReply extends StatefulWidget {
  String? name;
  String? description;
  String? image;
  String? duration;

  CommentBoxReply(
      {super.key, this.name, this.description, this.image, this.duration});

  @override
  State<StatefulWidget> createState() => _CommentBoxReplyState();
}

class _CommentBoxReplyState extends State<CommentBoxReply> {
  @override
  Widget build(BuildContext context) {
    return Container(
      color: AppColors.blackColor,
      padding: const EdgeInsets.all(2),
      child: Card(
          color: AppColors.blackColor,
          child: Column(
            children: [
              Row(children: <Widget>[
                Padding(
                  padding: const EdgeInsets.only(left: 8.0, top: 10.0),
                  child: Center(child: Image.asset("assets/${widget.image}")),
                ),
                Expanded(
                    child: Container(
                        padding: const EdgeInsets.all(4),
                        child: Text(widget.name ?? "",
                            style: const TextStyle(
                                color: Colors.white,
                                fontFamily: 'Lato',
                                fontSize: 16.0)))),
                Padding(
                  padding: const EdgeInsets.only(left: 8.0),
                  child: Text(
                    widget.duration ?? "Not found",
                    style: TextStyle(fontFamily: 'Lato', color: Colors.grey),
                  ),
                ),
              ]),
              SizedBox(
                height: 5.h,
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 40.0),
                child: Text(widget.description ?? "",
                    style: const TextStyle(
                        color: Colors.grey, fontFamily: 'Lato')),
              ),
              SizedBox(
                height: 10.h,
              )
            ],
          )),
    );
  }
}
