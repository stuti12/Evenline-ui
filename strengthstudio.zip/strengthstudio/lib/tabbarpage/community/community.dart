import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:strengthstudio/constants/colors.dart';
import 'package:strengthstudio/tabbarpage/community/community_comment.dart';
import 'package:strengthstudio/tabbarpage/community/private_video.dart';
import 'package:toggle_switch/toggle_switch.dart';

import '../../constants/strings.dart';
import '../../custom/custom_button.dart';
import '../../custom/custom_community_search.dart';

class Community extends StatefulWidget {
  const Community({Key? key}) : super(key: key);

  @override
  State<Community> createState() => _CommunityState();
}

class _CommunityState extends State<Community> {
  int _selectedIndex = 0;
  bool isSelected = true;
  List<String> list = [
    Strings.squareVarientText.toUpperCase(),
    Strings.benchPressText,
    Strings.deadLiftText,
    Strings.trainingText,
    Strings.nutritionText,
    Strings.extraText
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.blackColor,
      appBar: AppBar(
        backgroundColor: AppColors.blackColor,
        title: const Text(
          Strings.communityText,
          style: TextStyle(fontFamily: 'Lato'),
          textAlign: TextAlign.center,
        ),
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.filter_alt_outlined),
          onPressed: () {
            showModalBottomSheet<void>(
              backgroundColor: AppColors.colorPrimaryGrey,
              context: context,
              builder: (BuildContext context) {
                return Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Padding(
                          padding: const EdgeInsets.all(20.0),
                          child: Text(
                            Strings.filterText.toUpperCase(),
                            style: const TextStyle(
                                fontFamily: 'Lato',
                                color: Colors.white,
                                fontSize: 18),
                          ),
                        ),
                        Expanded(
                          child: Padding(
                            padding: const EdgeInsets.only(right: 8.0),
                            child: Align(
                              alignment: Alignment.topRight,
                              child: Text(
                                Strings.resetText.toUpperCase(),
                                style: const TextStyle(
                                    fontFamily: 'Lato',
                                    color: Colors.white,
                                    fontSize: 16),
                              ),
                            ),
                          ),
                        )
                      ],
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 20.0),
                      child: Text(
                        Strings.filterFeedType.toUpperCase(),
                        style: const TextStyle(
                            fontFamily: 'Lato',
                            color: Strings.colorRed,
                            fontSize: 18),
                      ),
                    ),
                    SizedBox(
                      height: 10.h,
                    ),
                    Padding(
                      padding: const EdgeInsets.only(left: 20.0),
                      child: ToggleSwitch(
                        minWidth: 120.0,
                        minHeight: 50.0,
                        fontSize: 16.0,
                        initialLabelIndex: 1,
                        activeBgColor: const [Strings.colorRed],
                        activeFgColor: Colors.white,
                        inactiveBgColor: Strings.colorGrey,
                        inactiveFgColor: Colors.white,
                        totalSwitches: 3,
                        labels: [
                          Strings.allText,
                          Strings.userForumText,
                          Strings.communityText
                        ],
                        onToggle: (index) {
                          print('switched to: $index');
                        },
                      ),
                    ),
                    SizedBox(
                      height: 15.h,
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 20.0),
                      child: Text(
                        Strings.filterByCategoryText.toUpperCase(),
                        style: const TextStyle(
                            fontFamily: 'Lato',
                            color: Strings.colorRed,
                            fontSize: 18),
                      ),
                    ),
                    SizedBox(
                      height: 5.h,
                    ),
                    Expanded(
                        child: ListView.builder(
                            itemCount: list.length,
                            itemBuilder: (BuildContext context, int index) {
                              return ListTile(
                                  title: Text(
                                    list[index],
                                    style: TextStyle(
                                        color: isSelected
                                            ? Colors.white
                                            : Colors.grey),
                                  ),
                                  selected: index == _selectedIndex,
                                  onTap: () {
                                    setState(() {
                                      _selectedIndex = index;
                                    });
                                  });
                            })),
                    SizedBox(height: 10.h),
                    CustomButton(
                      title: Strings.applyText.toUpperCase(),
                      onTap: () {},
                      bgColor: AppColors.colorRed,
                      margin: EdgeInsets.symmetric(horizontal: 25.h),
                    )
                  ],
                );
              },
            );
          },
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.lock),
            onPressed: () {
              Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => const PrivateVideo()));
            },
          ),
          IconButton(
            icon: const Icon(Icons.search),
            onPressed: () {
              showSearch(
                  context: context, delegate: CustomCommunitySearchDelegate());
            },
          )
        ],
      ),
      body: ListView(
        children: const [
          CommunityBox(
            name: Strings.jamelText,
            description: Strings.loreumCommunityText,
            duration: Strings.durationText,
          ),
          Padding(
            padding: EdgeInsets.symmetric(vertical: 8.0, horizontal: 16.0),
            child: Divider(
              height: 1,
              color: Colors.grey,
            ),
          ),
          CommunityBox(
            name: Strings.jamelText,
            description: Strings.loreumCommunityText,
            image: 'programbanner.png',
            duration: Strings.durationText,
          ),
          Padding(
            padding: EdgeInsets.symmetric(vertical: 8.0, horizontal: 16.0),
            child: Divider(
              height: 1,
              color: Colors.grey,
            ),
          ),
          CommunityBox(
            name: Strings.jamelText,
            description: Strings.loreumCommunityText,
            image: 'programbanner.png',
            duration: Strings.durationText,
          )
        ],
      ),
      /* ListView.builder(
        itemCount: list.length,
        itemBuilder: (BuildContext context, int index) {
          return const CommunityBox(
            image: 'programbanner.png',
            name: Strings.jamelText,
            description: Strings.loreumCommunityText,
            duration: Strings.durationText,
          );
        },
      ),*/
      floatingActionButton: FloatingActionButton(
        backgroundColor: Strings.colorRed,
        onPressed: () {
          var itemsList = [
            'Feed Type',
            'Item 1',
            'Item 3',
            'Item 4',
            'Item 5',
          ];
          String dropdownvalue = 'Feed Type';
          showModalBottomSheet<void>(
            context: context,
            builder: (BuildContext context) {
              return SingleChildScrollView(
                child: Container(
                  color: Strings.colorPrimaryGrey,
                  width: ScreenUtil().screenWidth,
                  child: Column(
                    children: [
                      SizedBox(
                        height: 20.h,
                      ),
                      Container(
                        color: Strings.colorPrimaryGrey,
                        width: double.infinity,
                        padding: const EdgeInsets.only(top: 10, bottom: 5.0),
                        child: const Text(
                          Strings.createFeed,
                          style: TextStyle(
                              fontFamily: 'Lato-Bold',
                              fontSize: 18,
                              color: Colors.white),
                          textAlign: TextAlign.center,
                        ),
                      ),
                      SizedBox(
                        height: 20.h,
                      ),
                      const Padding(
                        padding: EdgeInsets.symmetric(horizontal: 14.0),
                        child: TextField(
                          style: TextStyle(color: Colors.white),
                          maxLines: 1,
                          cursorColor: Colors.white,
                          decoration: InputDecoration(
                              border: OutlineInputBorder(),
                              enabledBorder: OutlineInputBorder(
                                borderSide: BorderSide(
                                    color: Strings.colorGrey, width: 0.0),
                              ),
                              filled: true,
                              fillColor: Strings.colorGrey,
                              hintText: Strings.feedTitleText,
                              hintStyle: TextStyle(color: Colors.grey)),
                        ),
                      ),
                      SizedBox(
                        height: 10.h,
                      ),
                      Container(
                        color: Strings.colorPrimaryGrey,
                        width: ScreenUtil().screenWidth,
                        child: const Padding(
                          padding: EdgeInsets.symmetric(horizontal: 14.0),
                          child: TextField(
                            style: TextStyle(color: Colors.white),
                            maxLines: 5,
                            cursorColor: Colors.white,
                            decoration: InputDecoration(
                                border: OutlineInputBorder(),
                                enabledBorder: OutlineInputBorder(
                                  borderSide: BorderSide(
                                      color: Strings.colorGrey, width: 0.0),
                                ),
                                filled: true,
                                fillColor: Strings.colorGrey,
                                hintText: Strings.descriptionText,
                                hintStyle: TextStyle(color: Colors.grey)),
                          ),
                        ),
                      ),

                      //dropdown
                      SizedBox(
                        height: 10.h,
                      ),
                      Container(
                        color: AppColors.colorGrey,
                        width: double.infinity,
                        margin: const EdgeInsets.symmetric(horizontal: 18.0),
                        child: Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: DropdownButtonHideUnderline(
                            child: DropdownButtonFormField(
                                dropdownColor: Strings.colorGrey,
                                icon: const Icon(
                                  Icons.arrow_drop_down,
                                  color: Colors.grey,
                                ),
                                value: dropdownvalue,
                                items: itemsList
                                    .map((e) => DropdownMenuItem(
                                        value: e, child: Text(e)))
                                    .toList(),
                                onChanged: (val) {
                                  setState(() {
                                    dropdownvalue = val as String;
                                  });
                                }),
                          ),
                        ),
                      ),
                      SizedBox(
                        height: 20.h,
                      ),
                      CustomButton(
                        title: Strings.createText,
                        bgColor: Strings.colorRed,
                        onTap: () {},
                        height: 60.h,
                        width: ScreenUtil().screenWidth,
                        margin: const EdgeInsets.symmetric(
                            horizontal: 20.0, vertical: 4.0),
                      ),
                      SizedBox(
                        height: 20.h,
                      ),
                      CustomButton(
                        width: ScreenUtil().screenWidth,
                        title: Strings.closeText,
                        height: 60.h,
                        bgColor: AppColors.colorActionSheetButton,
                        onTap: () {
                          Navigator.pop(context);
                        },
                        margin: const EdgeInsets.symmetric(
                            horizontal: 20.0, vertical: 4.0),
                      ),
                      SizedBox(
                        height: 20.h,
                      ),
                    ],
                  ),
                ),
              );
            },
          );
        },
        child: const Icon(Icons.add, color: Colors.white),
      ),
    );
  }
}

class CommunityBox extends StatefulWidget {
  const CommunityBox(
      {Key? key,
      this.name,
      this.description,
      this.image,
      this.chip,
      this.duration})
      : super(key: key);
  final String? name;
  final String? description;
  final String? image;
  final List<String>? chip;
  final String? duration;

  @override
  State<StatefulWidget> createState() => _CommunityBoxState();
}

class _CommunityBoxState extends State<CommunityBox> {
  List<String>? chips = [Strings.squatText, Strings.benchPressText];

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(2),
      width: double.infinity,
      child: Card(
          color: AppColors.blackColor,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              (widget.image != null)
                  ? Stack(
                      clipBehavior: Clip.none,
                      fit: StackFit.passthrough,
                      children: <Widget>[
                        // Max Size Widget
                        Container(
                          color: AppColors.blackColor,
                          child: Image.asset(
                            "assets/${widget.image}",
                            width: double.infinity,
                          ),
                        ),
                        Positioned(
                          top: 0,
                          bottom: 0,
                          right: 0,
                          left: 0,
                          child: SizedBox(
                            height: 100,
                            width: 150,
                            child: Center(
                                child: CircleAvatar(
                                    backgroundColor: Colors.white,
                                    child: IconButton(
                                      alignment: Alignment.centerLeft,
                                      padding: EdgeInsets.all(7.h),
                                      icon: const Icon(
                                          Icons.play_arrow_outlined,
                                          size: 30,
                                          color: Colors.grey),
                                      onPressed: () {},
                                    ))),
                          ),
                        ),
                      ],
                    )
                  :
                  //no image
                  Container(),
              Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: 16.0, vertical: 4.0),
                child: Text(
                  widget.name ?? "not found",
                  style: const TextStyle(
                      fontFamily: 'Lato', fontSize: 16, color: Colors.white),
                  textAlign: TextAlign.start,
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 15.0),
                child: Text(
                  widget.description ?? "not found",
                  style: const TextStyle(
                      fontFamily: 'Lato', fontSize: 16, color: Colors.grey),
                  textAlign: TextAlign.start,
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16.0),
                child: Row(
                  children: [
                    Padding(
                      padding: EdgeInsets.all(2.0),
                      child: Chip(
                        elevation: 20,
                        padding: const EdgeInsets.all(4),
                        backgroundColor: Strings.colorActionSheetButton,
                        shadowColor: AppColors.blackColor,
                        //CircleAvatar
                        label: Text(
                          chips?[0] ?? "not found",
                          style: const TextStyle(
                              fontFamily: 'Lato',
                              fontSize: 14,
                              color: Colors.white),
                        ), //Text
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(4.0),
                      child: Chip(
                        elevation: 20,
                        padding: const EdgeInsets.all(4),
                        backgroundColor: Strings.colorActionSheetButton,
                        shadowColor: AppColors.blackColor,
                        //CircleAvatar
                        label: Text(
                          chips?[1] ?? "not found",
                          style: const TextStyle(
                              fontFamily: 'Lato',
                              fontSize: 14,
                              color: Colors.white),
                        ), //Text
                      ),
                    ),
                  ],
                ),
              ),
              Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16.0),
                  child: Row(
                    children: [
                      IconButton(
                        icon: const Icon(
                          Icons.thumb_up_outlined,
                          color: Colors.white,
                        ),
                        onPressed: () {},
                      ),
                      const Text(
                        '1',
                        style: TextStyle(
                            fontFamily: 'Lato',
                            fontSize: 16,
                            color: Colors.grey),
                        textAlign: TextAlign.start,
                      ),
                      IconButton(
                        icon: const Icon(
                          Icons.comment_outlined,
                          color: Colors.white,
                        ),
                        onPressed: () {
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) =>
                                      const CommunityComments()));
                        },
                      ),
                      const Text(
                        '1',
                        style: TextStyle(
                            fontFamily: 'Lato',
                            fontSize: 16,
                            color: Colors.grey),
                        textAlign: TextAlign.start,
                      ),
                      const Expanded(
                        child: Align(
                          alignment: Alignment.topRight,
                          child: Text(
                            Strings.durationText,
                            style: TextStyle(
                                fontFamily: 'Lato',
                                fontSize: 16,
                                color: Colors.grey),
                            textAlign: TextAlign.start,
                          ),
                        ),
                      ),
                    ],
                  ))
            ],
          )),
    );
  }
}
