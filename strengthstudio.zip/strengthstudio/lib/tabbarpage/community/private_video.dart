import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../constants/colors.dart';
import '../../constants/strings.dart';
import '../../custom/custom_button.dart';
import '../../custom/custom_program_library_search.dart';
import 'community_comment.dart';

class PrivateVideo extends StatefulWidget {
  const PrivateVideo({Key? key}) : super(key: key);

  @override
  State<PrivateVideo> createState() => _PrivateVideoState();
}

class _PrivateVideoState extends State<PrivateVideo> {
  int _selectedIndex = 0;
  List<String> list = [
    'FILTER',
    Strings.filterFeedType,
    Strings.filterByCategoryText.toUpperCase(),
    Strings.squareVarientText.toUpperCase(),
    Strings.benchPressText,
    Strings.deadLiftText,
    Strings.trainingText,
    Strings.nutritionText,
    Strings.extraText
  ];

  File? image;

  // List<String> list = [];
  Future pickImage() async {
  /*  try {
      final image = await ImagePicker().pickImage(source: ImageSource.gallery);
      if (image == null) return;
      final imageTemp = File(image.path);
      setState(() => this.image = imageTemp);
    } on PlatformException catch (e) {
      print('failed$e');
    }*/
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.blackColor,
      appBar: AppBar(
        automaticallyImplyLeading: true,
        backgroundColor: AppColors.blackColor,
        title: const Text(
          Strings.privateVideoText,
          style: TextStyle(fontFamily: 'Lato'),
          textAlign: TextAlign.center,
        ),
        centerTitle: true,
        actions: [
          IconButton(
            icon: const Icon(Icons.search),
            onPressed: () {
              showSearch(
                  context: context,
                  delegate: CustomProgramLibrarySearchDelegate());
            },
          )
        ],
      ),
      body: ListView(
        children: const [
          CommunityBox(
            name: Strings.jamelText,
            description: Strings.loreumCommunityText,
            image: 'programbanner.png',
            duration: Strings.durationText,
          ),
          Padding(
            padding: EdgeInsets.all(8.0),
            child: Divider(
              height: 1,
              color: Colors.grey,
            ),
          ),
          CommunityBox(
            name: Strings.jamelText,
            description: Strings.loreumCommunityText,
            image: 'programbanner.png',
            duration: Strings.durationText,
          ),
          Padding(
            padding: EdgeInsets.all(8.0),
            child: Divider(
              height: 1,
              color: Colors.grey,
            ),
          ),
          CommunityBox(
            name: Strings.jamelText,
            description: Strings.loreumCommunityText,
            image: 'programbanner.png',
            duration: Strings.durationText,
          )
        ],
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: Strings.colorRed,
        onPressed: () {
          var itemsList = [
            'Feed Type',
            'Item 1',
            'Item 3',
            'Item 4',
            'Item 5',
          ];
          String dropdownvalue = 'Feed Type';
          showModalBottomSheet<void>(
            context: context,
            builder: (BuildContext context) {
              return ListView(
                children: [
                  Container(
                    color: Strings.colorPrimaryGrey,
                    child: Column(
                      children: [
                        Container(
                          color: Strings.colorPrimaryGrey,
                          width: ScreenUtil().screenWidth,
                          padding: const EdgeInsets.only(top: 10, bottom: 5.0),
                          child: Text(
                            Strings.addPrivateVideoText.toUpperCase(),
                            style: const TextStyle(
                                fontFamily: 'Lato-Bold',
                                fontSize: 18,
                                color: Colors.white),
                            textAlign: TextAlign.center,
                          ),
                        ),
                        Container(
                          color: Strings.colorPrimaryGrey,
                          width: ScreenUtil().screenWidth,
                          padding: const EdgeInsets.only(top: 10, bottom: 5.0),
                          child: const Padding(
                            padding: EdgeInsets.symmetric(horizontal: 28.0),
                            child: TextField(
                              style: TextStyle(color: Colors.white),
                              maxLines: 1,
                              cursorColor: Colors.white,
                              decoration: InputDecoration(
                                  border: OutlineInputBorder(),
                                  enabledBorder: OutlineInputBorder(
                                    borderSide: BorderSide(
                                        color: Strings.colorGrey, width: 0.0),
                                  ),
                                  filled: true,
                                  fillColor: Strings.colorGrey,
                                  hintText: Strings.feedTitleText,
                                  hintStyle: TextStyle(color: Colors.grey)),
                            ),
                          ),
                        ),
                        Container(
                          color: Strings.colorPrimaryGrey,
                          width: ScreenUtil().screenWidth,
                          padding: const EdgeInsets.only(top: 10, bottom: 5.0),
                          child: const Padding(
                            padding: EdgeInsets.symmetric(horizontal: 28.0),
                            child: TextField(
                              style: TextStyle(color: Colors.white),
                              maxLines: 5,
                              cursorColor: Colors.white,
                              decoration: InputDecoration(
                                  border: OutlineInputBorder(),
                                  enabledBorder: OutlineInputBorder(
                                    borderSide: BorderSide(
                                        color: Strings.colorGrey, width: 0.0),
                                  ),
                                  filled: true,
                                  fillColor: Strings.colorGrey,
                                  hintText: Strings.descriptionText,
                                  hintStyle: TextStyle(color: Colors.grey)),
                            ),
                          ),
                        ),
                        Container(
                          color: Strings.colorPrimaryGrey,
                          width: double.infinity,
                          padding: const EdgeInsets.only(
                              top: 10, bottom: 5.0, left: 28.0),
                          child: const Text(
                            Strings.addPhotoText,
                            style: TextStyle(
                                fontFamily: 'Lato-Bold',
                                fontSize: 18,
                                color: Colors.white),
                            textAlign: TextAlign.start,
                          ),
                        ),
                        Container(
                            width: double.infinity,
                            alignment: Alignment.topLeft,
                            color: Strings.colorPrimaryGrey,
                            child: Padding(
                              padding: const EdgeInsets.symmetric(
                                  vertical: 12.0, horizontal: 28.0),
                              child: Container(
                                  color: Strings.colorGrey,
                                  width: 100.h,
                                  child: IconButton(
                                    icon: const Icon(
                                      Icons.add,
                                      color: Colors.white,
                                    ),
                                    onPressed: () {
                                      //open gallery

                                      pickImage();
                                    },
                                  )),
                            )),
                        const SizedBox(
                          height: 20.0,
                        ),
                        /*   image != null
                         ? Image.file(
                       image!,
                       height: 500,
                     )
                         : Text('No image selected'),*/
                        SizedBox(
                          height: 20.h,
                        ),
                        CustomButton(
                          title: Strings.addText,
                          bgColor: Strings.colorRed,
                          onTap: () {},
                          height: 60.h,
                          width: ScreenUtil().screenWidth,
                          margin: EdgeInsets.symmetric(
                              horizontal: 28.h, vertical: 4.0),
                        ),
                        SizedBox(
                          height: 20.h,
                        ),
                        CustomButton(
                          title: Strings.closeText,
                          bgColor: Strings.colorActionSheetButton,
                          onTap: () {
                            Navigator.pop(context);
                          },
                          height: 60.h,
                          width: ScreenUtil().screenWidth,
                          margin: EdgeInsets.symmetric(
                              horizontal: 28.h, vertical: 4.0),
                        ),
                        SizedBox(
                          height: 20.h,
                        ),
                      ],
                    ),
                  ),
                ],
              );
            },
          );
        },
        child: const Icon(Icons.add, color: Colors.white),
      ),
    );
  }
}

class CommunityBox extends StatefulWidget {
  const CommunityBox(
      {Key? key,
      this.name,
      this.description,
      this.image,
      this.chip,
      this.duration})
      : super(key: key);
  final String? name;
  final String? description;
  final String? image;
  final List<String>? chip;
  final String? duration;

  @override
  State<StatefulWidget> createState() => _CommunityBoxState();
}

class _CommunityBoxState extends State<CommunityBox> {
  List<String>? chips = [Strings.squatText, Strings.benchPressText];

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(2),
      width: double.infinity,
      child: Card(
          color: AppColors.blackColor,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Stack(
                clipBehavior: Clip.none,
                fit: StackFit.passthrough,
                children: <Widget>[
                  // Max Size Widget
                  Container(
                    color: AppColors.blackColor,
                    child: Image.asset(
                      "assets/${widget.image}",
                      width: double.infinity,
                    ),
                  ),
                  Positioned(
                    top: 0,
                    bottom: 0,
                    right: 0,
                    left: 0,
                    child: SizedBox(
                      height: 100,
                      width: 150,
                      child: Center(
                          child: CircleAvatar(
                              backgroundColor: Colors.white,
                              child: IconButton(
                                alignment: Alignment.centerLeft,
                                padding: EdgeInsets.all(7.h),
                                icon: const Icon(Icons.play_arrow_outlined,
                                    size: 30, color: Colors.grey),
                                onPressed: () {},
                              ))),
                    ),
                  ),
                ],
              ),
              Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: 16.0, vertical: 4.0),
                child: Text(
                  widget.name ?? "not found",
                  style: const TextStyle(
                      fontFamily: 'Lato', fontSize: 16, color: Colors.white),
                  textAlign: TextAlign.start,
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 15.0),
                child: Text(
                  widget.description ?? "not found",
                  style: const TextStyle(
                      fontFamily: 'Lato', fontSize: 16, color: Colors.grey),
                  textAlign: TextAlign.start,
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16.0),
                child: Row(
                  children: [
                    Padding(
                      padding: EdgeInsets.all(2.0),
                      child: Chip(
                        elevation: 20,
                        padding: const EdgeInsets.all(4),
                        backgroundColor: Strings.colorActionSheetButton,
                        shadowColor: AppColors.blackColor,
                        //CircleAvatar
                        label: Text(
                          chips?[0] ?? "not found",
                          style: const TextStyle(
                              fontFamily: 'Lato',
                              fontSize: 14,
                              color: Colors.white),
                        ), //Text
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(4.0),
                      child: Chip(
                        elevation: 20,
                        padding: const EdgeInsets.all(4),
                        backgroundColor: Strings.colorActionSheetButton,
                        shadowColor: AppColors.blackColor,
                        //CircleAvatar
                        label: Text(
                          chips?[1] ?? "not found",
                          style: const TextStyle(
                              fontFamily: 'Lato',
                              fontSize: 14,
                              color: Colors.white),
                        ), //Text
                      ),
                    ),
                  ],
                ),
              ),
              Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16.0),
                  child: Row(
                    children: [
                      IconButton(
                        icon: const Icon(
                          Icons.thumb_up_outlined,
                          color: Colors.white,
                        ),
                        onPressed: () {},
                      ),
                      const Text(
                        '1',
                        style: TextStyle(
                            fontFamily: 'Lato',
                            fontSize: 16,
                            color: Colors.grey),
                        textAlign: TextAlign.start,
                      ),
                      IconButton(
                        icon: const Icon(
                          Icons.comment_outlined,
                          color: Colors.white,
                        ),
                        onPressed: () {
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) =>
                                      const CommunityComments()));
                        },
                      ),
                      const Text(
                        '1',
                        style: TextStyle(
                            fontFamily: 'Lato',
                            fontSize: 16,
                            color: Colors.grey),
                        textAlign: TextAlign.start,
                      ),
                      const Expanded(
                        child: Align(
                          alignment: Alignment.topRight,
                          child: Text(
                            Strings.durationText,
                            style: TextStyle(
                                fontFamily: 'Lato',
                                fontSize: 16,
                                color: Colors.grey),
                            textAlign: TextAlign.start,
                          ),
                        ),
                      ),
                    ],
                  ))
            ],
          )),
    );
  }
}
