import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:strengthstudio/tabbarpage/community/reply.dart';

import '../../constants/strings.dart';

class CommunityComments extends StatefulWidget {
  const CommunityComments({Key? key}) : super(key: key);

  @override
  State<CommunityComments> createState() => _CommunityCommentsState();
}

class _CommunityCommentsState extends State<CommunityComments> {
  static final TextEditingController _comment = TextEditingController();
  final _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      /*  appBar: AppBar(backgroundColor: Colors.black,),
    */
      body: Column(
        children: [
          Stack(
            children: [
              SizedBox(
                width: MediaQuery.of(context).size.width,
                height: 200.h,
                child: FadeInImage.assetNetwork(
                  fit: BoxFit.fill,
                  image:
                      "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ0OuN6GLFnHZYJtI3YpFt9Kf7Kxskx8viXAA&usqp=CAU",
                  placeholder: '',
                ),
              ),
              Positioned(
                  top: 0,
                  bottom: 0,
                  left: 0,
                  right: 0,
                  child: Image.asset(
                    'assets/Play.png',
                  ))
            ],
          ),
          Expanded(
            child: GestureDetector(
              onTap: () {
                Navigator.push(context,
                    MaterialPageRoute(builder: (context) => const Reply()));
              },
              child: ListView.builder(
                  itemCount: 3,
                  itemBuilder: (BuildContext context, int index) {
                    return CommentBox(
                      name: 'Cadem',
                      description:
                          'You can’t go wrong with this bundle, sick programs. Thank you Jamal and SST Team',
                      image: 'person.png',
                      duration: 'Just Now',
                    );
                  }),
            ),
          ),
          Container(
            color: Strings.colorGrey,
            height: 70,
            child: Row(
              children: [
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Form(
                      key: _formKey,
                      child: TextFormField(
                        validator: (value) {
                          if (value?.isEmpty ?? true) {
                            return 'Please Enter Value';
                          } else {
                            return null;
                          }
                        },
                        controller: _comment,
                        cursorColor: Colors.white,
                        textInputAction: TextInputAction.done,
                        decoration: const InputDecoration(
                            hintStyle: TextStyle(
                                color: Colors.grey, fontFamily: 'Lato'),
                            hintText: Strings.typeCommentText),
                        style: const TextStyle(
                            fontFamily: 'Lato', color: Colors.white),
                      ),
                    ),
                  ),
                ),
                Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: CircleAvatar(
                        backgroundColor: Colors.red,
                        child: IconButton(
                            onPressed: () {
                              if (_formKey.currentState!.validate()) {
                                Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) => const Reply()));
                                _comment.text = '';
                              }
                            },
                            icon: const Icon(
                              Icons.reply,
                              color: Colors.white,
                            ))))
              ],
            ),
          )
        ],
      ),
    );
  }
}

class CommentBox extends StatefulWidget {
  String? name;
  String? description;
  String? image;
  String? duration;

  CommentBox(
      {super.key, this.name, this.description, this.image, this.duration});

  @override
  State<StatefulWidget> createState() => _CommentBoxState();
}

class _CommentBoxState extends State<CommentBox> {
  int like = 0;
  int dislike = 0;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(2),
      child: Card(
          color: Colors.black,
          child: Column(
            children: [
              Row(children: <Widget>[
                Padding(
                  padding: const EdgeInsets.only(left: 8.0, top: 10.0),
                  child: Center(child: Image.asset("assets/${widget.image}")),
                ),
                Expanded(
                    child: Container(
                        padding: const EdgeInsets.all(4),
                        child: Text(widget.name ?? "",
                            style: const TextStyle(
                                color: Colors.white,
                                fontFamily: 'Lato',
                                fontSize: 16.0)))),
                Padding(
                  padding: const EdgeInsets.only(left: 8.0),
                  child: Text(
                    widget.duration ?? "Not found",
                    style:
                        const TextStyle(fontFamily: 'Lato', color: Colors.grey),
                  ),
                ),
              ]),
              SizedBox(
                height: 5.h,
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 40.0),
                child: Text(widget.description ?? "",
                    style: const TextStyle(
                        color: Colors.grey, fontFamily: 'Lato')),
              ),
              SizedBox(
                height: 10.h,
              ),
              Row(
                children: [
                  Padding(
                      padding: const EdgeInsets.only(left: 36.0),
                      child: InkWell(
                        child: const Icon(
                          Icons.thumb_up_outlined,
                          color: Colors.white,
                        ),
                        onTap: () {
                          setState(() {
                            like++;
                          });
                        },
                      )),
                  Padding(
                    padding: const EdgeInsets.only(left: 8.0),
                    child: Text(
                      like.toString(),
                      style: const TextStyle(
                          fontFamily: 'Lato', color: Colors.white),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(left: 8.0),
                    child: InkWell(
                      child: const Icon(
                        Icons.thumb_down_outlined,
                        color: Colors.white,
                      ),
                      onTap: () {
                        setState(() {
                          dislike++;
                        });
                      },
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(left: 8.0),
                    child: Text(
                      dislike.toString(),
                      style: const TextStyle(
                          fontFamily: 'Lato', color: Colors.white),
                    ),
                  ),
                  const Expanded(
                    child: Align(
                      alignment: Alignment.topRight,
                      child: Padding(
                        padding: EdgeInsets.only(right: 8.0),
                        child: Text(
                          Strings.reply25Text,
                          style:
                              TextStyle(fontFamily: 'Lato', color: Colors.grey),
                        ),
                      ),
                    ),
                  ),
                ],
              )
            ],
          )),
    );
  }
}
