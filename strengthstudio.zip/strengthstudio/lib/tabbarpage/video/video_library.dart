import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:strengthstudio/custom/custom_video_library_search.dart';
import 'package:strengthstudio/tabbarpage/video/video_details.dart';

import '../../constants/strings.dart';

class Video extends StatefulWidget {
  const Video({Key? key}) : super(key: key);

  @override
  State<Video> createState() => _VideoState();
}

class _VideoState extends State<Video> {
  var itemsList = [
    'Feed Type',
    'Item 1',
    'Item 3',
    'Item 4',
    'Item 5',
  ];
  String dropdownvalue = 'Feed Type';

  @override
  Widget build(BuildContext context) {
    List<String> list = [
      Strings.jamelVideoTitleText,
      Strings.jamelVideoTitleText,
      Strings.jamelVideoTitleText,
      Strings.jamelVideoTitleText,
    ];
    List<String> images = [
      'videobanner.png',
      'videobanner.png',
      'videobanner.png',
      'videobanner.png',
    ];
    List<String> description = [
      Strings.loreumCommunityText,
      Strings.loreumCommunityText,
      Strings.loreumCommunityText,
      Strings.loreumCommunityText
    ];
    return Scaffold(
        appBar: AppBar(
          automaticallyImplyLeading: false,
          backgroundColor: Colors.black,
          title: const Text(Strings.videoText,
              style: TextStyle(fontFamily: 'Lato')),
          centerTitle: true,
          actions: [
            IconButton(
              icon: const Icon(Icons.search),
              onPressed: () {
                showSearch(
                    context: context,
                    delegate: CustomVideoLibrarySearchDelegate());
              },
            )
          ],
        ),
        body: Column(
          children: [
            Container(
              color: Strings.colorPrimaryGrey,
              width: double.infinity,
              margin: const EdgeInsets.symmetric(horizontal: 20.0),
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: DropdownButtonHideUnderline(
                  child: DropdownButtonFormField(
                      dropdownColor: Strings.colorGrey,
                      icon: const Icon(
                        Icons.arrow_drop_down,
                        color: Colors.grey,
                      ),
                      value: dropdownvalue,
                      items: itemsList
                          .map(
                              (e) => DropdownMenuItem(value: e, child: Text(e)))
                          .toList(),
                      onChanged: (val) {
                        setState(() {
                          dropdownvalue = val as String;
                        });
                      }),
                ),
              ),
            ),
            Expanded(
              child: InkWell(
                  onTap: () {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => const VideoDetailsScreen()));
                  },
                  child: ListView.builder(
                      itemCount: list.length,
                      itemBuilder: (context, int index) {
                        return VideoBox(
                          name: list[index],
                          description: description[index],
                          image: images[index],
                          time: Strings.durationText,
                          duration: 'Duration: 10:15',
                        );
                      })),
            ),
          ],
        ),
        backgroundColor: Colors.black);
  }
}

class VideoBox extends StatefulWidget {
  VideoBox(
      {Key? key,
      this.name,
      this.description,
      this.image,
      this.time,
      this.duration})
      : super(key: key);
  String? name;
  String? description;
  String? image;
  String? time;
  String? duration;

  @override
  State<StatefulWidget> createState() => _VideoBoxState();
}

class _VideoBoxState extends State<VideoBox> {
  @override
  Widget build(BuildContext context) {
    return Card(
        color: Colors.black,
        child: Column(
          children: [
            Row(children: <Widget>[
              Stack(
                children: <Widget>[
                  // Max Size Widget
                  Container(
                    width: 160.h,
                    child: Image.asset(
                      'assets/${widget.image}',
                    ),
                  ),
                  Positioned(
                    top: 0,
                    bottom: 0,
                    right: 0,
                    left: 0,
                    child: SizedBox(
                      child: Center(
                          child: CircleAvatar(
                              backgroundColor: Colors.white,
                              child: IconButton(
                                alignment: Alignment.centerLeft,
                                padding: EdgeInsets.all(7.h),
                                icon: const Icon(Icons.play_arrow_outlined,
                                    size: 30, color: Colors.grey),
                                onPressed: () {
                                  Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) =>
                                              const VideoDetailsScreen()));
                                },
                              ))),
                    ),
                  ),
                ],
              ),
              Expanded(
                  child: Container(
                      padding: const EdgeInsets.all(4),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          SizedBox(
                            height: 5.h,
                          ),
                          Text(widget.name ?? "not found",
                              style: const TextStyle(
                                  color: Colors.white,
                                  fontFamily: 'Lato',
                                  fontSize: 16.0)),
                          SizedBox(
                            height: 5.h,
                          ),
                          Text(widget.description ?? "not found",
                              style: const TextStyle(
                                  color: Colors.grey, fontFamily: 'Lato')),
                          SizedBox(
                            height: 8.h,
                          ),
                          Row(
                            children: [
                              Text(widget.time ?? "Not found",
                                  style: const TextStyle(
                                      color: Colors.grey,
                                      fontFamily: 'Lato',
                                      fontSize: 14.0)),
                              Padding(
                                padding: const EdgeInsets.only(left: 20.0),
                                child: Text(widget.duration ?? "not found",
                                    style: const TextStyle(
                                        color: Colors.grey,
                                        fontFamily: 'Lato')),
                              ),
                            ],
                          )
                        ],
                      )))
            ]),
          ],
        ));
  }
}
