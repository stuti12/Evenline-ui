import 'package:flutter/material.dart';

import '../../constants/strings.dart';

class VideoDetailsScreen extends StatefulWidget {
  const VideoDetailsScreen({Key? key}) : super(key: key);

  @override
  State<VideoDetailsScreen> createState() => _VideoDetailsScreenState();
}

class _VideoDetailsScreenState extends State<VideoDetailsScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: true,
        backgroundColor: Colors.transparent,
      ),
      backgroundColor: Colors.black,
      body: Container(
        color: Colors.black,
        height: double.infinity,
        child: ListView(children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Image.asset(
                'assets/commentbanner.png',
                width: double.infinity,
              ),
              const Padding(
                padding: EdgeInsets.symmetric(horizontal: 16.0),
                child: Text(
                  Strings.durationText,
                  style: TextStyle(fontFamily: 'Lato', color: Colors.grey),
                ),
              ),
              const Padding(
                padding: EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
                child: Text(
                  Strings.jamelVideoTitleText,
                  style: TextStyle(
                      fontFamily: 'Lato', color: Colors.white, fontSize: 18),
                ),
              ),
              const Padding(
                padding: EdgeInsets.symmetric(horizontal: 16.0),
                child: Text(
                  Strings.loreumText,
                  style: TextStyle(fontFamily: 'Lato', color: Colors.grey),
                ),
              ),
            ],
          ),
        ]),
      ),
    );
  }
}
