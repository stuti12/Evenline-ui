import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../authentication/login_screen.dart';
import '../../constants/colors.dart';
import '../../constants/shared_pref.dart';
import '../../constants/strings.dart';
import '../../custom/custom_button.dart';

class Profile extends StatefulWidget {
  const Profile({Key? key}) : super(key: key);

  @override
  State<Profile> createState() => _ProfileState();
}

class _ProfileState extends State<Profile> {
  final PrefService _prefService = PrefService();

  bool viewVisible = true;
  bool isPremiumUser = true;

  void showWidget() {
    setState(() {
      viewVisible = true;
    });
  }

  void hideWidget() {
    setState(() {
      viewVisible = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          backgroundColor: AppColors.blackColor,
          automaticallyImplyLeading: false,
          centerTitle: true,
          title: const Text(
            Strings.profileText,
            style: TextStyle(fontFamily: 'Lato'),
          ),
          actions: [
            IconButton(
              icon: const Icon(Icons.settings),
              onPressed: () async {
                //logout
                await _prefService.removeCache("email").whenComplete(() {
                  Navigator.pushReplacement(
                      context,
                      MaterialPageRoute(
                          builder: (context) => const LoginScreen()));
                });
              },
            )
          ],
        ),
        body: SingleChildScrollView(
            child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Stack(children: [
                  Image.asset(
                    'assets/profile.png',
                  ),
                  (!isPremiumUser)
                      ? Visibility(
                          visible: true,
                          child: Positioned(
                            top: 14,
                            right: 0,
                            child: Padding(
                              padding: const EdgeInsets.only(left: 28.0),
                              child: Image.asset('assets/premium_icon.png'),
                            ),
                          ),
                        )
                      : Container()
                ]),
                Padding(
                  padding: const EdgeInsets.only(left: 28.0),
                  child: Image.asset('assets/profileSide.png'),
                ),
              ],
            ),
            const Padding(
              padding: EdgeInsets.all(8.0),
              child: Text(
                Strings.johnSmithText,
                style: TextStyle(
                    fontFamily: 'Lato',
                    fontSize: 18,
                    color: Colors.white,
                    fontWeight: FontWeight.bold),
              ),
            ),
            const Padding(
              padding: EdgeInsets.only(left: 8.0),
              child: Text(
                Strings.johnEmail,
                style: TextStyle(
                    fontFamily: 'Lato', fontSize: 16, color: Colors.white),
              ),
            ),
            SizedBox(
              height: 10.h,
            ),
            Padding(
                padding: const EdgeInsets.symmetric(horizontal: 50.0),
                child: (isPremiumUser)
                    ? CustomButton(
                        title: Strings.becomePremiumText,
                        bgColor: Strings.colorRed,
                        fontWeight: FontWeight.bold,
                        height: 35.0,
                        onTap: () {
                          showModalBottomSheet<void>(
                            context: context,
                            builder: (BuildContext context) {
                              return SingleChildScrollView(
                                child: Container(
                                  color: Strings.colorPrimaryGrey,
                                  width: ScreenUtil().screenWidth,
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      SizedBox(
                                        height: 10.h,
                                      ),
                                      Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        children: [
                                          Padding(
                                            padding: const EdgeInsets.all(8.0),
                                            child: Image.asset(
                                                'assets/premium.png',
                                                height: 40.h,
                                                width: 40.h),
                                          ),
                                          const Text(
                                            Strings.becomePremiumText,
                                            style: TextStyle(
                                                fontFamily: 'Lato-Bold',
                                                fontSize: 18,
                                                color: Colors.white),
                                            textAlign: TextAlign.center,
                                          ),
                                        ],
                                      ),
                                      SizedBox(
                                        height: 10.h,
                                        width: 10.h,
                                      ),
                                      const Padding(
                                        padding: EdgeInsets.only(left: 18.0),
                                        child: Text(
                                          Strings.premiumBenefitText,
                                          style: TextStyle(
                                              fontFamily: 'Lato-Bold',
                                              fontSize: 20,
                                              fontWeight: FontWeight.bold,
                                              color: AppColors.colorYellow),
                                          textAlign: TextAlign.center,
                                        ),
                                      ),
                                      Container(
                                        alignment: Alignment.topLeft,
                                        color: Strings.colorPrimaryGrey,
                                        width: double.infinity,
                                        padding: const EdgeInsets.only(
                                            top: 10, bottom: 5.0, left: 20.0),
                                        child: Row(
                                          children: [
                                            Container(
                                              width: 10,
                                              margin:
                                                  const EdgeInsets.symmetric(
                                                      horizontal: 10.0),
                                              height: 10,
                                              decoration: const BoxDecoration(
                                                  shape: BoxShape.circle,
                                                  color: AppColors.colorYellow),
                                            ),
                                            const Text(
                                              Strings.communityAccess,
                                              style: TextStyle(
                                                  fontFamily: 'Lato-Bold',
                                                  fontSize: 18,
                                                  color: Colors.white),
                                              textAlign: TextAlign.center,
                                            ),
                                          ],
                                        ),
                                      ),
                                      Container(
                                        alignment: Alignment.topLeft,
                                        color: Strings.colorPrimaryGrey,
                                        width: double.infinity,
                                        padding: const EdgeInsets.only(
                                            top: 10, bottom: 5.0, left: 20.0),
                                        child: Row(
                                          children: [
                                            Container(
                                              width: 10,
                                              margin:
                                                  const EdgeInsets.symmetric(
                                                      horizontal: 10.0),
                                              height: 10,
                                              decoration: const BoxDecoration(
                                                  shape: BoxShape.circle,
                                                  color: AppColors.colorYellow),
                                            ),
                                            const Text(
                                              Strings.privateVideoUploadText,
                                              style: TextStyle(
                                                  fontFamily: 'Lato-Bold',
                                                  fontSize: 18,
                                                  color: Colors.white),
                                              textAlign: TextAlign.center,
                                            ),
                                          ],
                                        ),
                                      ),
                                      Container(
                                        alignment: Alignment.topLeft,
                                        color: Strings.colorPrimaryGrey,
                                        width: double.infinity,
                                        padding: const EdgeInsets.only(
                                            top: 10, bottom: 5.0, left: 20.0),
                                        child: Row(
                                          children: [
                                            Container(
                                              width: 10,
                                              margin:
                                                  const EdgeInsets.symmetric(
                                                      horizontal: 10.0),
                                              height: 10,
                                              decoration: const BoxDecoration(
                                                  shape: BoxShape.circle,
                                                  color: AppColors.colorYellow),
                                            ),
                                            const Text(
                                              Strings.discountedRate,
                                              style: TextStyle(
                                                  fontFamily: 'Lato-Bold',
                                                  fontSize: 18,
                                                  color: Colors.white),
                                              textAlign: TextAlign.center,
                                            ),
                                          ],
                                        ),
                                      ),
                                      Container(
                                        alignment: Alignment.topLeft,
                                        color: Strings.colorPrimaryGrey,
                                        width: double.infinity,
                                        padding: const EdgeInsets.only(
                                            top: 10, bottom: 5.0, left: 20.0),
                                        child: Row(
                                          children: [
                                            Container(
                                              width: 10,
                                              margin:
                                                  const EdgeInsets.symmetric(
                                                      horizontal: 10.0),
                                              height: 10,
                                              decoration: const BoxDecoration(
                                                  shape: BoxShape.circle,
                                                  color: AppColors.colorYellow),
                                            ),
                                            const Text(
                                              Strings.accessText,
                                              style: TextStyle(
                                                  fontFamily: 'Lato-Bold',
                                                  fontSize: 18,
                                                  color: Colors.white),
                                              textAlign: TextAlign.center,
                                            ),
                                          ],
                                        ),
                                      ),
                                      Container(
                                        alignment: Alignment.center,
                                        color: Strings.colorPrimaryGrey,
                                        width: double.infinity,
                                        padding: const EdgeInsets.only(
                                            top: 20.0, bottom: 5.0, left: 20.0),
                                        child: const Text(
                                          Strings.priceText,
                                          style: TextStyle(
                                              fontFamily: 'Lato-Bold',
                                              fontSize: 18,
                                              fontWeight: FontWeight.bold,
                                              color: Colors.white),
                                          textAlign: TextAlign.center,
                                        ),
                                      ),
                                      Container(
                                        alignment: Alignment.center,
                                        color: Strings.colorPrimaryGrey,
                                        width: double.infinity,
                                        padding: const EdgeInsets.only(
                                            top: 10,
                                            bottom: 15.0,
                                            left: 20.0,
                                            right: 20.0),
                                        child: CustomButton(
                                            title: Strings.subscribeNow,
                                            bgColor: Strings.colorRed,
                                            fontWeight: FontWeight.bold,
                                            height: 50.0,
                                            onTap: () {
                                              setState(() {
                                                viewVisible = !viewVisible;
                                              });
                                            }),
                                      ),
                                    ],
                                  ),
                                ),
                              );
                            },
                          );
                        })
                    : CustomButton(
                        title: Strings.premiumMemberText,
                        bgColor: Strings.colorYellow,
                        fontWeight: FontWeight.bold,
                        height: 35.0,
                        onTap: () {
                          showModalBottomSheet<void>(
                            context: context,
                            builder: (BuildContext context) {
                              return SingleChildScrollView(
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    Container(
                                        color: Strings.colorPrimaryGrey,
                                        width: double.infinity,
                                        alignment: Alignment.topCenter,
                                        padding: const EdgeInsets.only(
                                            top: 10, bottom: 5.0),
                                        child:
                                            Image.asset('assets/premium.png')),
                                    Container(
                                      alignment: Alignment.topCenter,
                                      color: Strings.colorPrimaryGrey,
                                      width: double.infinity,
                                      padding: const EdgeInsets.only(
                                          top: 10, bottom: 5.0, left: 20.0),
                                      child: const Text(
                                        Strings.youArePrimeMember,
                                        style: TextStyle(
                                            fontFamily: 'Lato-Bold',
                                            fontSize: 20,
                                            fontWeight: FontWeight.bold,
                                            color: Colors.white),
                                        textAlign: TextAlign.center,
                                      ),
                                    ),
                                    Container(
                                      alignment: Alignment.center,
                                      color: Strings.colorPrimaryGrey,
                                      width: double.infinity,
                                      padding: const EdgeInsets.only(
                                          top: 26.0, bottom: 5.0, left: 20.0),
                                      child: const Text(
                                        Strings.currentPlanText,
                                        style: TextStyle(
                                            fontFamily: 'Lato-Bold',
                                            fontSize: 18,
                                            fontWeight: FontWeight.bold,
                                            color: Colors.white),
                                        textAlign: TextAlign.center,
                                      ),
                                    ),
                                    Container(
                                      alignment: Alignment.center,
                                      color: Strings.colorPrimaryGrey,
                                      width: double.infinity,
                                      padding: const EdgeInsets.only(
                                          top: 12.0, left: 20.0),
                                      child: const Text(
                                        Strings.pricePremiumText,
                                        style: TextStyle(
                                            fontFamily: 'Lato-Bold',
                                            fontSize: 24,
                                            fontWeight: FontWeight.bold,
                                            color: Colors.white),
                                        textAlign: TextAlign.center,
                                      ),
                                    ),
                                    Container(
                                      alignment: Alignment.center,
                                      color: Strings.colorPrimaryGrey,
                                      width: double.infinity,
                                      padding: const EdgeInsets.only(
                                          top: 5.0, bottom: 5.0, left: 20.0),
                                      child: const Text(
                                        Strings.validTillText,
                                        style: TextStyle(
                                            fontFamily: 'Lato-Bold',
                                            fontSize: 18,
                                            fontWeight: FontWeight.bold,
                                            color: Colors.white),
                                        textAlign: TextAlign.center,
                                      ),
                                    ),
                                  ],
                                ),
                              );
                            },
                          );
                        })),
            SizedBox(
              height: 10.h,
            ),

            //grid
            /*  GridView.count(
                shrinkWrap: true,
                crossAxisCount: 3,
                children: List.generate(choices.length, (index) {
                  return Center(
                    child: SelectCard(choice: choices[index]),
                  );
                })),*/
            Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    SelectCard(choice: choices[0]),
                    SelectCard(choice: choices[1]),
                    SelectCard(choice: choices[2]),
                  ],
                ),
                SizedBox(
                  height: 20.h,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    SelectCard(choice: choices[3]),
                    SelectCard(choice: choices[4]),
                  ],
                )
              ],
            ),
            Padding(
                padding: const EdgeInsets.symmetric(
                    vertical: 16.0, horizontal: 40.0),
                child: CustomButton(
                    title: Strings.editProfileText,
                    bgColor: Strings.colorRed,
                    fontWeight: FontWeight.bold,
                    height: 55.0,
                    onTap: () {
                      setState(() {
                        isPremiumUser = !isPremiumUser;
                      }); /* Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => const PremiumProfile()));*/
                    })),
          ],
        )),
        backgroundColor: AppColors.blackColor);
  }
}

class Choice {
  const Choice({required this.title, required this.icon});

  final String title;
  final String icon;
}

const List<Choice> choices = <Choice>[
  Choice(title: Strings.weightsText, icon: 'assets/weigth.png'),
  Choice(title: Strings.heightsText, icon: 'assets/height.png'),
  Choice(title: Strings.unitPrefText, icon: 'assets/unitPreference.png'),
  Choice(title: Strings.trainingExText, icon: 'assets/trainingExperience.png'),
  Choice(title: Strings.goalText, icon: 'assets/weightloss.png'),
];

class SelectCard extends StatelessWidget {
  final Choice choice;

  const SelectCard({super.key, required this.choice});

  @override
  Widget build(BuildContext context) {
    return Card(
        color: Colors.black,
        child: Column(children: <Widget>[
          Image.asset(choice.icon, color: Colors.white),
          SizedBox(
            height: 15.h,
          ),
          Text(
            choice.title,
            style: TextStyle(fontFamily: 'Lato', color: Colors.white),
          ),
        ]));
  }
}
