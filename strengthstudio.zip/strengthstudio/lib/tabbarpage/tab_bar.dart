import 'package:flutter/material.dart';
import 'package:strengthstudio/tabbarpage/community/community.dart';
import 'package:strengthstudio/tabbarpage/profile/profile.dart';
import 'package:strengthstudio/tabbarpage/programs/program_library.dart';
import 'package:strengthstudio/tabbarpage/training/my_programs.dart';
import 'package:strengthstudio/tabbarpage/video/video_library.dart';

import '../constants/strings.dart';
import '../custom/text_style.dart';

class TabbarPage extends StatefulWidget {
  const TabbarPage({Key? key}) : super(key: key);

  @override
  State<TabbarPage> createState() => _TabbarPageState();
}

class _TabbarPageState extends State<TabbarPage>
    with SingleTickerProviderStateMixin {
  int selectedIndex = 0;
  final _bucket = PageStorageBucket();
  final _key = GlobalKey<ScaffoldState>();
  final GlobalKey<NavigatorState> _navigatorKey = GlobalKey<NavigatorState>();
  List<Widget> pages = [
    const MyPrograms(),
    const ProgramLibrary(),
    const Community(),
    const Video(),
    const Profile(),
  ];

  void onSelected(int index) {
    setState(() {
      selectedIndex = index;
    });
    print(selectedIndex);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _key,
      body: PageStorage(
        bucket: _bucket,
        child: pages[selectedIndex],
      ),
      bottomNavigationBar: BottomNavigationBar(
          backgroundColor: Strings.colorBottom,
          items: <BottomNavigationBarItem>[
            BottomNavigationBarItem(
              icon: _getBottomBar(
                Icons.candlestick_chart_sharp,
                selectedIndex == 0,
                Strings.trainingText,
              ),
              label: "",
            ),
            BottomNavigationBarItem(
              icon: _getBottomBar(
                Icons.wrap_text,
                selectedIndex == 1,
                Strings.programsText,
              ),
              label: "",
            ),
            BottomNavigationBarItem(
              icon: _getBottomBar(
                Icons.groups_sharp,
                selectedIndex == 2,
                Strings.communityText,
              ),
              label: "",
            ),
            BottomNavigationBarItem(
              icon: _getBottomBar(
                Icons.video_camera_back,
                selectedIndex == 3,
                Strings.videoText,
              ),
              label: "",
            ),
            BottomNavigationBarItem(
              icon: _getBottomBar(
                Icons.person_outline_rounded,
                selectedIndex == 4,
                Strings.profileText,
              ),
              label: "",
            )
          ],
          type: BottomNavigationBarType.fixed,
          unselectedItemColor: Strings.colorBottomItem,
          selectedItemColor: Colors.white,
          onTap: onSelected,
          iconSize: 30,
          elevation: 5),
    );
  }
}

Widget _getBottomBar(IconData icon, bool indicator, String label) {
  return Column(
    children: <Widget>[
      Icon(icon, color: indicator ? Colors.white : Colors.grey),
      Text(
        label,
        style: UITextStyle.regularTextStyle(
            color: indicator ? Colors.white : Colors.grey, fontSize: 12),
      ),
    ],
  );
}
