import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:strengthstudio/custom/custom_my_program_search_delegate.dart';

import '../../constants/colors.dart';
import '../../constants/strings.dart';
import '../../custom/custom_button.dart';
import '../../custom/text_style.dart';
import '../../questionnary/questionnary1.dart';
import '../../strengthstudio/proglibrarydetails/prog_library_detail.dart';

class MyPrograms extends StatefulWidget {
  const MyPrograms({Key? key}) : super(key: key);

  @override
  State<MyPrograms> createState() => _MyProgramsState();
}

class _MyProgramsState extends State<MyPrograms> {
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        backgroundColor: AppColors.blackColor,
        appBar: AppBar(
            automaticallyImplyLeading: false,
            backgroundColor: AppColors.blackColor,
            title: const Text(Strings.myProgramsText,
                style: TextStyle(fontFamily: 'Lato')),
            centerTitle: true,
            actions: [
              IconButton(
                icon: const Icon(Icons.search),
                onPressed: () {
                  showSearch(
                      context: context,
                      delegate: CustomMyProgramSearchDelegate());
                },
              )
            ],
            bottom: const TabBar(
              tabs: [
                Tab(text: Strings.activatedText),
                Tab(
                  text: Strings.completedText,
                )
              ],
              indicatorColor: Colors.white,
            )),
        body: const TabBarView(
          children: [
            FirstScreen(),
            SecondScreen(),
          ],
        ),
      ),
    );
  }
}

class FirstScreen extends StatelessWidget {
  const FirstScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    List<String> list = [
      Strings.jamelText,
      Strings.theGodfatherProgramBundleText,
      Strings.sSTTsStrengthFocusedPushPullLegs,
      Strings.jamelText,
      Strings.theGodfatherProgramBundleText,
      Strings.sSTTsStrengthFocusedPushPullLegs
    ];

    List<String> images = [
      "main_1.png",
      "main_2.png",
      "main_3.png",
      "main_1.png",
      "main_2.png",
      "main_3.png"
    ];

    return Padding(
      padding: const EdgeInsets.all(20.0),
      child: (list != null && list.isNotEmpty)
          ? InkWell(
              onTap: () {
                showModalBottomSheet<void>(
                  context: context,
                  builder: (BuildContext context) {
                    return Container(
                      height: 300.h,
                      color: AppColors.colorPrimaryGrey,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Padding(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 16.0, vertical: 9.0),
                            child: _ScreenProgress(),
                          ),
                          SizedBox(
                            height: 20.h,
                          ),
                          const Text(
                            Strings.doYouWantText,
                            style: TextStyle(
                                fontFamily: 'Lato-Bold',
                                fontSize: 16,
                                color: Colors.white),
                            textAlign: TextAlign.center,
                          ),
                          SizedBox(
                            height: 20.h,
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: [
                              Expanded(
                                child: CustomButton(
                                  margin: const EdgeInsets.only(
                                      left: 20, top: 4, right: 8),
                                  title: Strings.yesText.toUpperCase(),
                                  textColor: Colors.white,
                                  onTap: () {
                                    Navigator.pop(context);

                                    showModalBottomSheet<void>(
                                      context: context,
                                      builder: (BuildContext context) {
                                        return Container(
                                          height: 303.h,
                                          color: AppColors.colorPrimaryGrey,
                                          width: ScreenUtil().screenWidth,
                                          child: Column(
                                            mainAxisAlignment:
                                                MainAxisAlignment.center,
                                            children: [
                                              Padding(
                                                padding:
                                                    const EdgeInsets.symmetric(
                                                        horizontal: 16.0),
                                                child: _ScreenProgress2(),
                                              ),
                                              CustomButton(
                                                  title: Strings.customPlanText,
                                                  onTap: () {
                                                    Navigator.pop(context);
                                                    Navigator.push(
                                                        context,
                                                        MaterialPageRoute(
                                                            builder: (context) =>
                                                                const Questionnary1()));
                                                  },
                                                  margin: const EdgeInsets.only(
                                                      top: 15.0,
                                                      left: 25.0,
                                                      right: 25.0,
                                                      bottom: 15.0),
                                                  bgColor: AppColors
                                                      .colorActionSheetButton),
                                              CustomButton(
                                                  title:
                                                      Strings.useDefaultPlanText,
                                                  onTap: () {
                                                    Navigator.pop(context);
                                                    Navigator.push(
                                                        context,
                                                        MaterialPageRoute(
                                                            builder: (context) =>
                                                                const ProgLibraryDetail()));
                                                  },
                                                  margin: const EdgeInsets.only(
                                                      top: 5.0,
                                                      left: 25.0,
                                                      right: 25.0,
                                                      bottom: 15.0),
                                                  bgColor: AppColors
                                                      .colorActionSheetButton),
                                              CustomButton(
                                                  title: Strings.closeText,
                                                  onTap: () {
                                                    Navigator.pop(context);
                                                  },
                                                  margin: const EdgeInsets.only(
                                                      top: 5.0,
                                                      left: 25.0,
                                                      right: 25.0,
                                                      bottom: 15.0),
                                                  bgColor: Strings
                                                      .colorActionSheetButton)
                                            ],
                                          ),
                                        );
                                      },
                                    );
                                  },
                                  bgColor: AppColors.colorActionSheetButton,
                                  
                                ),
                              ),
                              Expanded(
                                child: CustomButton(
                                  margin: const EdgeInsets.only(
                                      right: 25, top: 4, left: 8),
                                  title: Strings.noText.toUpperCase(),
                                  onTap: () {},
                                  bgColor: Strings.colorActionSheetButton,
                                  
                                ),
                              )
                            ],
                          ),
                          CustomButton(
                              title: Strings.closeText,
                              onTap: () {
                                Navigator.pop(context);
                              },
                              margin: const EdgeInsets.only(
                                  top: 15.0,
                                  left: 25.0,
                                  right: 25.0,
                                  bottom: 15.0),
                              bgColor: AppColors.colorActionSheetButton)
                        ],
                      ),
                    );
                  },
                );
              },
              child: /* ListView(
                children:  <Widget>[
                  ProgramBox(
                      name: list[0],
                      description: Strings.weeksText,
                      image: images[0]),
                  ProgramBox(
                      name: list[1],
                      description: Strings.weeksText,
                      image: images[1]),
                  ProgramBox(
                      name: list[2],
                      description: Strings.weeksText,
                      image: images[2]),
                  ProgramBox(
                      name: list[3],
                      description: Strings.weeksText,
                      image: images[3]),
                  ProgramBox(
                      name: list[4],
                      description: Strings.weeksText,
                      image: images[4]),
                  ProgramBox(
                      name: list[5],
                      description: Strings.weeksText,
                      image: images[5]),
                ],
              ),*/
                  ListView.builder(
                itemCount: list.length,
                itemBuilder: (BuildContext context, int index) {
                  return ProgramBox(
                    name: list[index],
                    description: Strings.weeksText,
                    image: images[index],
                  );
                },
              ))
          :
          //view when no data
          SingleChildScrollView(
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Visibility(
                    visible: true,
                    child: Column(
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(top: 100.0),
                          child: Center(
                              child: Image.asset('assets/no_program.png')),
                        ),
                        Text(
                          Strings.noActivatedPlan,
                          style: UITextStyle.mediumTextStyle(fontSize: 20),
                          textAlign: TextAlign.center,
                        ),
                        const Padding(
                          padding: EdgeInsets.symmetric(horizontal: 28.0),
                          child: Text(
                            Strings.noProgramLibrarySubtitleText,
                            textAlign: TextAlign.center,
                            style: TextStyle(
                                fontFamily: 'Lato',
                                fontSize: 14,
                                color: Colors.grey),
                          ),
                        ),
                        CustomButton(
                            margin: const EdgeInsets.symmetric(
                                horizontal: 30.0, vertical: 10),
                            title: Strings.selectaplan,
                            bgColor: AppColors.colorRed,
                            fontWeight: FontWeight.bold,
                            height: 45.0,
                            onTap: () {}),
                      ],
                    )),
              ),
            ),
    );
  }
}

class SecondScreen extends StatelessWidget {
  const SecondScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    List<String> list = [
      Strings.jamelText,
      Strings.sSTTsStrengthFocusedPushPullLegs,
      Strings.jamelText,
      Strings.sSTTsStrengthFocusedPushPullLegs,
    ];

    List<String> images = [
      'main_1.png',
      'main_3.png',
      'main_1.png',
      'main_3.png',
      'main_1.png',
      'main_1.png'
    ];

    return Padding(
      padding: const EdgeInsets.all(20.0),
      child: GestureDetector(
        onTap: () => showModalBottomSheet<void>(
          context: context,
          builder: (BuildContext context) {
            return SizedBox(
              height: 259.h,
              width: ScreenUtil().screenWidth,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    color: Strings.colorPrimaryGrey,
                    width: ScreenUtil().screenWidth,
                    alignment: Alignment.topCenter,
                    padding: const EdgeInsets.symmetric(vertical: 9.0),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 16.0),
                      child: _ScreenProgress(),
                    ),
                  ),
                  Container(
                    color: Strings.colorPrimaryGrey,
                    width: ScreenUtil().screenWidth,
                    padding: const EdgeInsets.symmetric(vertical: 9.0),
                    child: const Text(
                      'DO YOU WANT TO ADD AN ADDITIONAL DAY?',
                      style: TextStyle(
                          fontFamily: 'Lato-Bold',
                          fontSize: 16,
                          color: Colors.white),
                      textAlign: TextAlign.center,
                    ),
                  ),
                  const Divider(
                    height: 0,
                  ),
                  Container(
                    color: AppColors.colorPrimaryGrey,
                    child: Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        Expanded(
                          child: CustomButton(
                            margin: const EdgeInsets.symmetric(
                                horizontal: 30, vertical: 4),
                            title: 'Yes, ADD',
                            textColor: Colors.white,
                            onTap: () {},
                            bgColor: AppColors.colorActionSheetButton,

                          ),
                        ),
                    Expanded(
                       child: CustomButton(
                          margin: const EdgeInsets.symmetric(
                              horizontal: 20, vertical: 4),
                          title: Strings.noText,
                          onTap: () {},
                          bgColor: AppColors.colorActionSheetButton,

                        ))
                      ],
                    ),
                  ),
                  const Divider(
                    height: 0,
                    color: AppColors.colorPrimaryGrey,
                  ),
                  Container(
                    color: AppColors.colorPrimaryGrey,
                    padding: const EdgeInsets.only(
                        top: 15.0, left: 25.0, right: 25.0, bottom: 15.0),
                    child: CustomButton(
                        title: Strings.closeText,
                        onTap: () {
                          Navigator.pop(context);
                        },
                        bgColor: AppColors.colorActionSheetButton),
                  )
                ],
              ),
            );
          },
        ),
        child: (list != null && list.isNotEmpty)
            ? ListView.builder(
                itemCount: list.length,
                itemBuilder: (BuildContext context, int index) {
                  return ProgramBox(
                    name: list[index],
                    description: Strings.weeksText,
                    image: images[index],
                  );
                },
              )
            :

            //no data
            SingleChildScrollView(
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Visibility(
                      visible: true,
                      child: Column(
                        children: [
                          Padding(
                            padding: const EdgeInsets.only(top: 100.0),
                            child: Center(
                                child: Image.asset('assets/no_program.png')),
                          ),
                          Text(
                            Strings.noActivatedPlan,
                            style: UITextStyle.mediumTextStyle(fontSize: 20),
                            textAlign: TextAlign.center,
                          ),
                          const Padding(
                            padding: EdgeInsets.symmetric(horizontal: 28.0),
                            child: Text(
                              Strings.noProgramLibrarySubtitleText,
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                  fontFamily: 'Lato',
                                  fontSize: 14,
                                  color: Colors.grey),
                            ),
                          ),
                          CustomButton(
                              margin: const EdgeInsets.symmetric(
                                  horizontal: 30.0, vertical: 10),
                              title: Strings.selectaplan,
                              bgColor: AppColors.colorRed,
                              fontWeight: FontWeight.bold,
                              height: 45.0,
                              onTap: () {}),
                        ],
                      )),
                ),
              ),
      ),
    );
  }
}

class ProgramBox extends StatefulWidget {
  const ProgramBox({Key? key, this.name, this.description, this.image})
      : super(key: key);
  final String? name;
  final String? description;
  final String? image;

  @override
  State<StatefulWidget> createState() => _ProgramBoxState();
}

class _ProgramBoxState extends State<ProgramBox> {
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(2),
      child: Card(
          color: Strings.colorGrey,
          child: Row(children: <Widget>[
            Image.asset("assets/${widget.image}"),
            Expanded(
                child: Container(
                    padding: const EdgeInsets.all(10),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text(widget.name ?? "not found",
                            style: const TextStyle(
                                color: Colors.white,
                                fontFamily: 'Lato',
                                fontSize: 16.0)),
                        Text(widget.description ?? "not found",
                            style: const TextStyle(
                                color: Colors.grey, fontFamily: 'Lato')),
                      ],
                    )))
          ])),
    );
  }
}

class _ScreenProgress extends StatefulWidget {
  @override
  State<StatefulWidget> createState() => ScreenProgress(ticks: 1);
}

class ScreenProgress extends State<_ScreenProgress> {
  int ticks = 1;

  ScreenProgress({required this.ticks});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Row(
          children: <Widget>[
            const Padding(
              padding: EdgeInsets.only(left: 70.0),
              child: Text(
                Strings.daysPlannningText,
                style: TextStyle(color: Colors.white, fontFamily: 'Lato'),
              ),
            ),
            spacer(),
            const Padding(
              padding: EdgeInsets.only(left: 50.0),
              child: Text(Strings.selectPlanText,
                  style: TextStyle(color: Colors.white, fontFamily: 'Lato')),
            ),
          ],
        ),
        Row(
          children: <Widget>[
            line(),
            spacer(),
            tick1(),
            spacer(),
            line(),
            spacer(),
            tick2(),
            line()
          ],
        ),
      ],
    );
  }

  Widget tick(bool isChecked) {
    return isChecked
        ? const Icon(
            Icons.circle_sharp,
            color: Colors.redAccent,
          )
        : Icon(
            Icons.circle,
            color: AppColors.blackColor,
          );
  }

  Widget tick1() {
    return ticks > 0 ? tick(true) : tick(false);
  }

  Widget tick2() {
    return ticks > 1 ? tick(true) : tick(false);
  }

  Widget tick3() {
    return this.ticks > 2 ? tick(true) : tick(false);
  }

  Widget tick4() {
    return ticks > 3 ? tick(true) : tick(false);
  }

  Widget spacer() {
    return Container(
      width: 2.0,
    );
  }

  Widget line() {
    return Container(
      color: Colors.grey,
      height: 3.0,
      width: 100.0,
    );
  }
}

class _ScreenProgress2 extends StatefulWidget {
  @override
  State<StatefulWidget> createState() => ScreenProgress2(ticks: 2);
}

class ScreenProgress2 extends State<_ScreenProgress2> {
  int ticks = 2;

  ScreenProgress2({required this.ticks});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Row(
          children: <Widget>[
            const Padding(
              padding: EdgeInsets.only(left: 70.0),
              child: Text(
                Strings.daysPlannningText,
                style: TextStyle(color: Colors.white, fontFamily: 'Lato'),
              ),
            ),
            spacer(),
            const Padding(
              padding: EdgeInsets.only(left: 50.0),
              child: Text(Strings.selectPlanText,
                  style: TextStyle(color: Colors.white, fontFamily: 'Lato')),
            ),
          ],
        ),
        Row(
          children: <Widget>[
            line(),
            spacer(),
            tick1(),
            spacer(),
            line(),
            spacer(),
            tick2(),
            line()
          ],
        ),
      ],
    );
  }

  Widget tick(bool isChecked) {
    return isChecked
        ? const Icon(
            Icons.circle_sharp,
            color: Colors.redAccent,
          )
        : Icon(
            Icons.circle,
            color: AppColors.blackColor,
          );
  }

  Widget tick1() {
    return ticks > 0 ? tick(true) : tick(false);
  }

  Widget tick2() {
    return ticks > 1 ? tick(true) : tick(false);
  }

  Widget tick3() {
    return ticks > 2 ? tick(true) : tick(false);
  }

  Widget tick4() {
    return this.ticks > 3 ? tick(true) : tick(false);
  }

  Widget spacer() {
    return Container(
      width: 2.0,
    );
  }

  Widget line() {
    return Container(
      color: Colors.grey,
      height: 3.0,
      width: 100.0,
    );
  }
}
