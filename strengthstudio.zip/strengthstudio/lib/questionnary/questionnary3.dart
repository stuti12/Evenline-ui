import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:strengthstudio/questionnary/questionarry4.dart';

import '../constants/colors.dart';
import '../constants/strings.dart';
import '../custom/custom_button.dart';

class Questionnary3 extends StatefulWidget {
  const Questionnary3({Key? key}) : super(key: key);

  @override
  State<Questionnary3> createState() => _Questionnary3State();
}

enum SingingCharacter { stressful, average, low }

class _Questionnary3State extends State<Questionnary3> {
  SingingCharacter? _character = SingingCharacter.stressful;
  var itemsList = [
    'Feed Type',
    'Item 1',
    'Item 3',
    'Item 4',
    'Item 5',
  ];
  String dropdownvalue = 'Feed Type';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.blackColor,
      appBar: AppBar(
        backgroundColor: AppColors.blackColor,
        centerTitle: true,
        title: const Text(
          Strings.quesTitle,
          style: TextStyle(fontFamily: 'Lato', color: Colors.white),
        ),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0),
            child: _ScreenProgress(),
          ),
          Expanded(
            child: ClipRRect(
              borderRadius: const BorderRadius.only(
                  topRight: Radius.circular(30), topLeft: Radius.circular(30)),
              child: Container(
                color: Strings.colorPrimaryGrey,
                child: Padding(
                  padding: const EdgeInsets.all(10.0),
                  child: ListView(
                    children: [
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Row(
                          children: [
                            Expanded(
                              child: Container(
                                color: Strings.colorPrimaryGrey,
                                margin: const EdgeInsets.symmetric(
                                    horizontal: 20.0),
                                child: Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: DropdownButtonHideUnderline(
                                    child: DropdownButtonFormField(
                                        dropdownColor: Strings.colorGrey,
                                        icon: const Icon(
                                          Icons.arrow_drop_down,
                                          color: Colors.grey,
                                        ),
                                        value: dropdownvalue,
                                        items: itemsList
                                            .map((e) => DropdownMenuItem(
                                                value: e, child: Text(e)))
                                            .toList(),
                                        onChanged: (val) {
                                          setState(() {
                                            dropdownvalue = val as String;
                                          });
                                        }),
                                  ),
                                ),
                              ),
                            ),
                            Container(
                              width: 100.h,
                              color: Strings.colorGrey,
                              child: const TextField(
                                style: TextStyle(color: Colors.white),
                                cursorColor: Colors.white,
                                decoration: InputDecoration(
                                  hintText: '80 lbs',
                                  hintStyle: TextStyle(color: Colors.grey),
                                  focusedBorder: OutlineInputBorder(
                                      borderSide: BorderSide(color: Colors.red),
                                      borderRadius: BorderRadius.all(
                                          Radius.circular(5.0))),
                                  border: OutlineInputBorder(
                                      borderSide:
                                          BorderSide(color: Colors.red)),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      const Padding(
                        padding: EdgeInsets.symmetric(
                            horizontal: 12.0, vertical: 4.0),
                        child: Text(
                          Strings.rateQuesText,
                          style: TextStyle(
                              color: Colors.white,
                              fontFamily: 'Lato',
                              fontSize: 16),
                        ),
                      ),
                      RadioListTile<SingingCharacter>(
                        activeColor: Colors.grey,
                        title: const Text(
                          Strings.cantRecoverText,
                          style: TextStyle(
                              color: Colors.white, fontFamily: 'Lato'),
                        ),
                        value: SingingCharacter.stressful,
                        groupValue: _character,
                        onChanged: (SingingCharacter? value) {
                          setState(() {
                            _character = value;
                          });
                        },
                      ),
                      RadioListTile<SingingCharacter>(
                        activeColor: Colors.grey,
                        title: const Text(
                          Strings.averageAbilityText,
                          style: TextStyle(
                              color: Colors.white, fontFamily: 'Lato'),
                        ),
                        value: SingingCharacter.average,
                        groupValue: _character,
                        onChanged: (SingingCharacter? value) {
                          setState(() {
                            _character = value;
                          });
                        },
                      ),
                      RadioListTile<SingingCharacter>(
                        activeColor: Colors.grey,
                        title: const Text(
                          Strings.lotOfRecoverText,
                          style: TextStyle(
                              color: Colors.white, fontFamily: 'Lato'),
                        ),
                        value: SingingCharacter.low,
                        groupValue: _character,
                        onChanged: (SingingCharacter? value) {
                          setState(() {
                            _character = value;
                          });
                        },
                      ),
                      const Padding(
                        padding: EdgeInsets.symmetric(
                            vertical: 4.0, horizontal: 8.0),
                        child: Text(
                          Strings.rateQuesText,
                          style: TextStyle(
                              color: Colors.white,
                              fontFamily: 'Lato',
                              fontSize: 16),
                        ),
                      ),
                      RadioListTile<SingingCharacter>(
                        activeColor: Colors.grey,
                        title: const Text(
                          Strings.dontHaveAbilityText,
                          style: TextStyle(
                              color: Colors.white, fontFamily: 'Lato'),
                        ),
                        value: SingingCharacter.stressful,
                        groupValue: _character,
                        onChanged: (SingingCharacter? value) {
                          setState(() {
                            _character = value;
                          });
                        },
                      ),
                      RadioListTile<SingingCharacter>(
                        activeColor: Colors.grey,
                        title: const Text(
                          Strings.averageAbility,
                          style: TextStyle(
                              color: Colors.white, fontFamily: 'Lato'),
                        ),
                        value: SingingCharacter.average,
                        groupValue: _character,
                        onChanged: (SingingCharacter? value) {
                          setState(() {
                            _character = value;
                          });
                        },
                      ),
                      RadioListTile<SingingCharacter>(
                        activeColor: Colors.grey,
                        title: const Text(
                          Strings.flowLessAbilityText,
                          style: TextStyle(
                              color: Colors.white, fontFamily: 'Lato'),
                        ),
                        value: SingingCharacter.low,
                        groupValue: _character,
                        onChanged: (SingingCharacter? value) {
                          setState(() {
                            _character = value;
                          });
                        },
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
          Container(
              padding: EdgeInsets.symmetric(horizontal: 12.0, vertical: 6.0),
              width: double.infinity,
              color: Strings.colorGrey,
              height: 133.h,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: const [
                  Text(
                    Strings.ques2Guide,
                    style: TextStyle(
                        fontFamily: 'Lato', color: Colors.grey, fontSize: 12),
                  )
                ],
              )),
          Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 14.0, vertical: 8.0),
              width: double.infinity,
              color: Strings.colorPrimaryGrey,
              height: 70.h,
              child: CustomButton(
                bgColor: Strings.colorRed,
                title: Strings.nextText,
                onTap: () {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => const Questionnary4()));
                },
              )),
        ],
      ),
    );
  }
}

class _ScreenProgress extends StatefulWidget {
  @override
  State<StatefulWidget> createState() => ScreenProgress(ticks: 3);
}

class ScreenProgress extends State<_ScreenProgress> {
  int ticks = 0;

  ScreenProgress({required this.ticks});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Row(
          children: <Widget>[
            const Padding(
              padding: EdgeInsets.only(left: 6.0),
              child: Text(
                Strings.generalText,
                style: TextStyle(color: Colors.white, fontFamily: 'Lato'),
              ),
            ),
            spacer(),
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 26.0),
              child: Text(
                Strings.squatText,
                style: TextStyle(color: Colors.white, fontFamily: 'Lato'),
              ),
            ),
            spacer(),
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 20.0),
              child: Text(
                Strings.benchPressText,
                style: TextStyle(color: Colors.white, fontFamily: 'Lato'),
              ),
            ),
            spacer(),
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 18.0),
              child: Text(
                Strings.deadLiftText,
                style: TextStyle(color: Colors.white, fontFamily: 'Lato'),
              ),
            ),
          ],
        ),
        Row(
          children: <Widget>[
            tick1(),
            spacer(),
            line(),
            spacer(),
            tick2(),
            spacer(),
            line(),
            spacer(),
            tick3(),
            spacer(),
            line(),
            spacer(),
            tick4(),
          ],
        ),
        Visibility(
          visible: false,
          child: ElevatedButton(
              onPressed: () {
                ticks++;
                setState(() {
                  ScreenProgress(ticks: ticks);
                });
              },
              child: const Text('update')),
        )
      ],
    );
  }

  Widget tick(bool isChecked) {
    return isChecked
        ? const Icon(
            Icons.circle_sharp,
            color: Colors.redAccent,
          )
        : const Icon(
            Icons.circle,
            color: Colors.grey,
          );
  }

  Widget tick1() {
    return ticks > 0 ? tick(true) : tick(false);
  }

  Widget tick2() {
    return ticks > 1 ? tick(true) : tick(false);
  }

  Widget tick3() {
    return this.ticks > 2 ? tick(true) : tick(false);
  }

  Widget tick4() {
    return this.ticks > 3 ? tick(true) : tick(false);
  }

  Widget spacer() {
    return Container(
      width: 5.0,
    );
  }

  Widget line() {
    return Container(
      color: Colors.grey,
      height: 3.0,
      width: 70.0,
    );
  }
}
