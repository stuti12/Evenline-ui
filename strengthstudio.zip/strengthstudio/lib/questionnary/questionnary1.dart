import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:strengthstudio/questionnary/questionnary2.dart';

import '../constants/colors.dart';
import '../constants/strings.dart';
import '../custom/custom_button.dart';

class Questionnary1 extends StatefulWidget {
  const Questionnary1({Key? key}) : super(key: key);

  @override
  State<Questionnary1> createState() => _Questionnary1State();
}

enum SingingCharacter { stressful, average, low }

class GroupModel {
  String text;
  int index;
  bool selected;

  GroupModel({required this.text, required this.index, required this.selected});
}

class _Questionnary1State extends State<Questionnary1> {
  SingingCharacter? _character = SingingCharacter.stressful;
  var itemsList = [
    'Feed Type',
    'Item 1',
    'Item 3',
    'Item 4',
    'Item 5',
  ];
  String dropdownvalue = 'Feed Type';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.blackColor,
      appBar: AppBar(
        backgroundColor: AppColors.blackColor,
        centerTitle: true,
        title: const Text(
          Strings.quesTitle,
          style: TextStyle(fontFamily: 'Lato', color: Colors.white),
        ),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0),
            child: _ScreenProgress(),
          ),
          Expanded(
            child: ClipRRect(
              borderRadius: const BorderRadius.only(
                  topRight: Radius.circular(30), topLeft: Radius.circular(30)),
              child: Container(
                color: Strings.colorPrimaryGrey,
                child: Column(
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Padding(
                          padding: EdgeInsets.all(20.0),
                          child: Text(
                            '1. How stressful is your life outside of the GYM?',
                            style: TextStyle(
                                color: Colors.white,
                                fontFamily: 'Lato',
                                fontSize: 16),
                          ),
                        ),
                        RadioListTile<SingingCharacter>(
                          activeColor: Colors.grey,
                          title: const Text(
                            Strings.stressfulText,
                            style: TextStyle(
                                color: Colors.white, fontFamily: 'Lato'),
                          ),
                          value: SingingCharacter.stressful,
                          groupValue: _character,
                          onChanged: (SingingCharacter? value) {
                            setState(() {
                              _character = value;
                            });
                          },
                        ),
                        RadioListTile<SingingCharacter>(
                          activeColor: Colors.grey,
                          title: const Text(
                            Strings.averageText,
                            style: TextStyle(
                                color: Colors.white, fontFamily: 'Lato'),
                          ),
                          value: SingingCharacter.average,
                          groupValue: _character,
                          onChanged: (SingingCharacter? value) {
                            setState(() {
                              _character = value;
                            });
                          },
                        ),
                        RadioListTile<SingingCharacter>(
                          activeColor: Colors.grey,
                          title: const Text(
                            Strings.lowText,
                            style: TextStyle(
                                color: Colors.white, fontFamily: 'Lato'),
                          ),
                          value: SingingCharacter.low,
                          groupValue: _character,
                          onChanged: (SingingCharacter? value) {
                            setState(() {
                              _character = value;
                            });
                          },
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
          Container(
              padding: const EdgeInsets.all(14.0),
              width: double.infinity,
              color: Strings.colorGrey,
              height: 130.h,
              child: const Text(
                Strings.questionaryHas4PartText,
                style: TextStyle(fontFamily: 'Lato', color: Colors.white),
              )),
          Container(
              padding: EdgeInsets.all(14.0),
              width: double.infinity,
              color: Strings.colorPrimaryGrey,
              height: 80.h,
              child: CustomButton(
                bgColor: Strings.colorRed,
                title: Strings.nextText,
                onTap: () {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => const Questionnary2()));
                },
              )),
        ],
      ),
    );
  }
}

class _ScreenProgress extends StatefulWidget {
  @override
  State<StatefulWidget> createState() => ScreenProgress(ticks: 1);
}

class ScreenProgress extends State<_ScreenProgress> {
  int ticks = 0;

  ScreenProgress({required this.ticks});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Row(
          children: <Widget>[
            const Padding(
              padding: EdgeInsets.only(left: 6.0),
              child: Text(
                'General',
                style: TextStyle(color: Colors.white, fontFamily: 'Lato'),
              ),
            ),
            spacer(),
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 26.0),
              child: Text(
                'Squat',
                style: TextStyle(color: Colors.white, fontFamily: 'Lato'),
              ),
            ),
            spacer(),
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 20.0),
              child: Text(
                'Bench Press',
                style: TextStyle(color: Colors.white, fontFamily: 'Lato'),
              ),
            ),
            spacer(),
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 18.0),
              child: Text(
                'Deadlift',
                style: TextStyle(color: Colors.white, fontFamily: 'Lato'),
              ),
            ),
          ],
        ),
        Row(
          children: <Widget>[
            tick1(),
            spacer(),
            line(),
            spacer(),
            tick2(),
            spacer(),
            line(),
            spacer(),
            tick3(),
            spacer(),
            line(),
            spacer(),
            tick4(),
          ],
        ),
        Visibility(
          visible: false,
          child: ElevatedButton(
              onPressed: () {
                ticks++;
                setState(() {
                  ScreenProgress(ticks: ticks);
                });
              },
              child: Text('update')),
        )
      ],
    );
  }

  Widget tick(bool isChecked) {
    return isChecked
        ? const Icon(
            Icons.circle_sharp,
            color: Colors.redAccent,
          )
        : const Icon(
            Icons.circle,
            color: Colors.grey,
          );
  }

  Widget tick1() {
    return ticks > 0 ? tick(true) : tick(false);
  }

  Widget tick2() {
    return ticks > 1 ? tick(true) : tick(false);
  }

  Widget tick3() {
    return this.ticks > 2 ? tick(true) : tick(false);
  }

  Widget tick4() {
    return this.ticks > 3 ? tick(true) : tick(false);
  }

  Widget spacer() {
    return Container(
      width: 5.0,
    );
  }

  Widget line() {
    return Container(
      color: Colors.grey,
      height: 3.0,
      width: 70.0,
    );
  }
}
