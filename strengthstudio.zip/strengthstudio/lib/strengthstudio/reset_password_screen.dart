import 'package:flutter/cupertino.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../authentication/login_screen.dart';
import '../constants/colors.dart';
import '../constants/strings.dart';
import '../createprofile/create_profile_screen.dart';
import '../custom/custom_button.dart';
import '../custom/text_style.dart';

void main() {
  runApp(const ResetPasswordScreen());
}

class ResetPasswordScreen extends StatelessWidget {
  const ResetPasswordScreen({Key? key}) : super(key: key);
  static final _formKey = GlobalKey<FormState>();
  static final TextEditingController _pass = TextEditingController();

  static final TextEditingController _cpass = TextEditingController();

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
        onTap: () {
          FocusScope.of(context).requestFocus(FocusNode());
        },
        child: MaterialApp(
            debugShowCheckedModeBanner: false,
            home: Scaffold(
              appBar: AppBar(
                backgroundColor: Colors.black,
                leading: IconButton(
                  icon: const Icon(Icons.arrow_back),
                  onPressed: () {
                    Navigator.of(context, rootNavigator: false).pop(context);
                  },
                ),
                centerTitle: true,
              ),
              body: Container(
                height: double.infinity,
                color: Colors.black,
                child: SingleChildScrollView(
                  child: Form(
                    key: _formKey,
                    child: Padding(
                      padding: EdgeInsets.only(
                          top: 30.h, left: 30.w, right: 30.w, bottom: 48.h),
                      child: Column(
                        children: [
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              RichText(
                                text: TextSpan(
                                  text: Strings.resetPasswordText,
                                  style: UITextStyle.boldTextStyle(
                                    color: Colors.white,
                                    fontSize: 26,
                                  ),
                                ),
                              ),
                              SizedBox(height: 13.h),

                              RichText(
                                text: TextSpan(
                                  text: Strings.resetPasswordSubtitleText,
                                  style: UITextStyle.regularTextStyle(
                                      color: Colors.white, fontSize: 18),
                                ),
                              ),
                              //password
                              Container(
                                width: double.infinity,
                                color: AppColors.colorGrey,
                                margin: const EdgeInsets.symmetric(
                                    horizontal: 10.0, vertical: 16.0),
                                child: TextFormField(
                                  controller: _pass,
                                  textInputAction: TextInputAction.next,
                                  keyboardType: TextInputType.visiblePassword,
                                  style: const TextStyle(color: Colors.white,fontFamily: 'Lato'),
                                  cursorColor: Colors.white,
                                  obscureText: true,
                                  decoration: const InputDecoration(
                                    filled: true,
                                    labelStyle:
                                        TextStyle(color: AppColors.colorRed),
                                    focusedBorder: OutlineInputBorder(
                                        borderSide: BorderSide(
                                            color: AppColors.colorRed),
                                        borderRadius: BorderRadius.all(
                                            Radius.circular(5.0))),
                                    border: OutlineInputBorder(
                                        borderSide: BorderSide(
                                            color: AppColors.colorRed)),
                                    labelText: Strings.passwordText,
                                    hintText: Strings.enterPasswordText,
                                    hintStyle: TextStyle(
                                        color: Colors.grey,
                                        fontFamily: 'Lato'),
                                  ),
                                  validator: (value) {
                                    if (value?.isEmpty ?? true) {
                                      return 'Please Enter Password';
                                    }
                                    return null;
                                  },
                                ),
                              ),
                              //c password
                              Container(
                                width: double.infinity,
                                color: Strings.colorGrey,
                                margin: const EdgeInsets.symmetric(
                                    horizontal: 10.0, vertical: 16.0),
                                child: TextFormField(
                                  controller: _cpass,
                                  keyboardType: TextInputType.visiblePassword,
                                  textInputAction: TextInputAction.done,
                                  style: const TextStyle(color: Colors.white,fontFamily: 'Lato'),
                                  cursorColor: Colors.white,
                                  obscureText: true,
                                  decoration: const InputDecoration(
                                    filled: true,
                                    labelStyle:
                                        TextStyle(color: AppColors.colorRed),
                                    focusedBorder: OutlineInputBorder(
                                        borderSide: BorderSide(
                                            color: AppColors.colorRed),
                                        borderRadius: BorderRadius.all(
                                            Radius.circular(5.0))),
                                    border: OutlineInputBorder(
                                        borderSide: BorderSide(
                                            color: AppColors.colorRed)),
                                    labelText: Strings.confirmPasswordText,
                                    hintText: Strings.enterCPasswordText,
                                    hintStyle: TextStyle(
                                        color: Colors.grey,
                                        fontFamily: 'Lato'),
                                  ),
                                  validator: (value) {
                                    if (value?.isEmpty ?? true) {
                                      return 'Please Enter Password';
                                    }
                                    if (value != _pass.text) {
                                      return 'Not match';
                                    }
                                    return null;
                                  },
                                ),
                              ),
                              SizedBox(height: 20.h),

                              //button
                              SizedBox(
                                child: CustomButton(
                                    margin: EdgeInsets.symmetric(horizontal: 8.h),
                                    title: Strings.submitText,
                                    bgColor: AppColors.colorRed,
                                    height: 50.0,
                                    onTap: () async {
                                      if (_formKey.currentState!.validate()) {
                                        /* showModalBottomSheet<void>(context: context, builder: (BuildContext context) {return SizedBox(height: 150.h,
                                          child: Column(children: [Text()],),
                                        );});*/
                                        showActionsheet();
                                        Navigator.push(context,
                                            MaterialPageRoute(builder:
                                                (BuildContext context) {
                                          return const CreateProfileScreen();
                                        }));
                                        _pass.text = '';
                                        _cpass.text = '';
                                      }
                                    }),
                              ),
                            ],
                          ),

                        ],
                      ),
                    ),
                  ),
                ),
              ),
            )));
  }

  showActionsheet() {
    showModalBottomSheet(
      context: _formKey.currentState!.context,
      builder: (BuildContext context) => Container(
        color: AppColors.colorPrimaryGrey,
        height: 100.h,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            SizedBox(
              height: 10.h,
            ),
            Container(
              color: Strings.colorPrimaryGrey,
              child: const Text(Strings.passwordChanged,
                  style: TextStyle(
                      fontFamily: 'Lato', color: Colors.white, fontSize: 14)),
            ),
            SizedBox(
              height: 15.h,
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 36.0),
              child: Container(
                color: Strings.colorPrimaryGrey,
                child: const Text(
                  Strings.resetSheetText,
                  style: TextStyle(
                      fontFamily: 'Lato', color: Colors.white, fontSize: 15),
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}
