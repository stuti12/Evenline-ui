import 'package:expandable_text/expandable_text.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:strengthstudio/constants/colors.dart';
import 'package:strengthstudio/custom/text_style.dart';

import '../../constants/strings.dart';
import '../../custom/custom_button.dart';

class CompleteExerciseScreen extends StatefulWidget {
  const CompleteExerciseScreen({Key? key}) : super(key: key);

  @override
  State<CompleteExerciseScreen> createState() => _CompleteExerciseScreenState();
}

class _CompleteExerciseScreenState extends State<CompleteExerciseScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.black,
        appBar: AppBar(
          backgroundColor: Colors.black,
          title: Text(
            Strings.complteExTitleText,
            style: UITextStyle.regularTextStyle(fontSize: 18),
          ),
          centerTitle: true,
        ),
        body: ListView(
          children: [
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Container(
                color: AppColors.colorPrimaryGrey,
                height: 190.h,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                      padding: const EdgeInsets.symmetric(
                          vertical: 8.0, horizontal: 28.0),
                      child: Text(
                        Strings.exerciseNoteText.toUpperCase(),
                        style: UITextStyle.boldTextStyle(fontSize: 16),
                      ),
                    ),
                    const Padding(
                      padding: EdgeInsets.symmetric(horizontal: 28.0),
                      child: ExpandableText(
                        Strings.loreumText,
                        style: TextStyle(
                            color: Colors.grey,
                            fontFamily: 'Lato',
                            fontSize: 14.0),
                        linkColor: Colors.white,
                        expandText: 'show more',
                        collapseText: 'show less',
                        maxLines: 6,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Padding(
                      padding: const EdgeInsets.only(
                          top: 8.0, left: 28.0, bottom: 8.0),
                      child: Text(
                        Strings.exerciseDetailText.toUpperCase(),
                        style: UITextStyle.boldTextStyle(fontSize: 16),
                      ),
                    ),
                    Expanded(
                        child: Padding(
                      padding: const EdgeInsets.only(right: 18.0),
                      child: Align(
                          alignment: Alignment.centerRight,
                          child: Text(
                            Strings.resetText.toUpperCase(),
                            style: TextStyle(
                                fontSize: 15,
                                color: AppColors.colorRed,
                                fontFamily: 'Lato'),
                          )),
                    )),
                  ],
                ),
                getWidget(),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Divider(
                    height: 1.h,
                    color: Colors.grey,
                  ),
                ),
                getWidget(),
                getWidget(),
                getWidget(),
                Container(
                  margin:
                      EdgeInsets.symmetric(horizontal: 30.h, vertical: 10.h),
                  child: CustomButton(
                      title: Strings.completeExerciseText.toUpperCase(),
                      bgColor: Strings.colorRed,
                      height: 55.0,
                      onTap: () {}),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(
                      vertical: 8.0, horizontal: 28.0),
                  child: Text(
                    Strings.noteText.toUpperCase(),
                    style: UITextStyle.boldTextStyle(fontSize: 16),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 28.0),
                  child: Card(
                    color: AppColors.colorPrimaryGrey,
                    elevation: 10.0,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8.0),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Padding(
                          padding: EdgeInsets.only(left: 20.0, top: 5.0),
                          child: Text(
                            'Lorem Ipsum is simply dummy text of the printing and type setting industry. Lorem Ipsum has been.',
                            style: TextStyle(
                                color: Colors.grey,
                                fontFamily: 'Lato',
                                fontSize: 14.0),
                            maxLines: 2,
                          ),
                        ),
                        Container(
                          margin: EdgeInsets.only(left: 20.h, top: 28.h),
                          child: CustomButton(
                              title: Strings.saveText.toUpperCase(),
                              bgColor: Strings.colorRed,
                              height: 30.0,
                              width: 90.0,
                              onTap: () {}),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            )
          ],
        ));
  }

  Widget getWidget() {
    return Center(
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Padding(
            padding:
                const EdgeInsets.symmetric(horizontal: 18.0, vertical: 8.0),
            child: SizedBox(
                width: 125.h,
                height: 70.h,
                child: Card(
                    color: AppColors.colorGrey,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                    child: const Center(
                        child: Text(
                      '5 Rpe',
                      style: TextStyle(
                          fontSize: 14,
                          fontFamily: 'Lato',
                          color: Colors.white),
                    )))),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8.0),
            child: Card(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10.0),
              ),
              elevation: 10.0,
              color: AppColors.colorGrey,
              child: Container(
                width: 120.h,
                height: 60.h,
                child: TextFormField(
                  style: const TextStyle(color: Colors.white),
                  cursorColor: Colors.white,
                  decoration: const InputDecoration(
                    filled: true,
                    labelStyle: TextStyle(color: Colors.red),
                    focusedBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.red),
                        borderRadius: BorderRadius.all(Radius.circular(5.0))),
                    border: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.red)),
                    labelText: Strings.k80KgText,
                    hintText: Strings.k80KgText,
                    hintStyle: TextStyle(color: Colors.white),
                  ),
                  validator: (value) {
                    if (value?.isEmpty ?? true) {
                      return 'Please Enter FirstName';
                    }
                    return null;
                  },
                ),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 18.0),
            child: SizedBox(
                width: 125.h,
                height: 70.h,
                child: Card(
                    color: AppColors.colorGrey,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                    child: const Center(
                        child: Text(
                      '5 Rpe',
                      style: TextStyle(
                          fontSize: 14,
                          fontFamily: 'Lato',
                          color: Colors.white),
                    )))),
          )
        ],
      ),
    );
  }
}
