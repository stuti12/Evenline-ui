import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../constants/strings.dart';
import '../../custom/custom_button.dart';

class SelectExerciseScreen extends StatefulWidget {
  const SelectExerciseScreen({Key? key}) : super(key: key);

  @override
  State<SelectExerciseScreen> createState() => _SelectExerciseScreenState();
}

class _SelectExerciseScreenState extends State<SelectExerciseScreen> {
  int _selectedIndex = 0;
  List<String> list = [
    Strings.squareVarientText,
    Strings.highSquatText,
    Strings.pinSquatText,
    Strings.pausedSquat,
    Strings.frontSquat
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.of(context, rootNavigator: true).pop(context);
          },
        ),
        title: const Text(Strings.selectExerciseText),
        centerTitle: true,
      ),
      body: ListView.builder(
          itemCount: 5,
          itemBuilder: (BuildContext context, int index) {
            return ListTile(
                selectedColor: Colors.white,
                selectedTileColor: Colors.black,
                textColor: Colors.grey,
                tileColor: Colors.black,
                title: Text(list[index]),
                selected: index == _selectedIndex,
                onTap: () {
                  setState(() {
                    _selectedIndex = index;
                    showModalBottomSheet<void>(
                      context: context,
                      builder: (BuildContext context) {
                        return SizedBox(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Container(
                                color: Strings.colorPrimaryGrey,
                                width: double.infinity,
                                padding:
                                    const EdgeInsets.symmetric(vertical: 9.0),
                                child: const Text(
                                  Strings.areYouSureText,
                                  style: TextStyle(
                                      fontFamily: 'Lato-Bold',
                                      fontSize: 16,
                                      color: Colors.white),
                                  textAlign: TextAlign.center,
                                ),
                              ),
                              Container(
                                color: Strings.colorPrimaryGrey,
                                child: Row(
                                  children: [
                                    CustomButton(
                                      margin: const EdgeInsets.symmetric(
                                          horizontal: 15, vertical: 10),
                                      title: Strings.yesReset,
                                      textColor: Colors.white,
                                      onTap: () {},
                                      bgColor: Strings.colorActionSheetButton,
                                      width: 200.h,
                                    ),
                                    CustomButton(
                                      margin: const EdgeInsets.symmetric(
                                          horizontal: 20, vertical: 4),
                                      title: Strings.noReset,
                                      onTap: () {},
                                      bgColor: Strings.colorActionSheetButton,
                                      width: 200.h,
                                    )
                                  ],
                                ),
                              ),
                            ],
                          ),
                        );
                      },
                    );
                  });
                });
          }),
    );
  }
}

class ProgramBox extends StatelessWidget {
  const ProgramBox({
    Key? key,
    required this.name,
  }) : super(key: key);
  final String name;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 50,
      child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Text(name,
                  style: const TextStyle(fontFamily: 'Lato', fontSize: 16.0)),
            ),
          ]),
    );
  }
}
