import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:strengthstudio/constants/colors.dart';
import 'package:strengthstudio/strengthstudio/proglibrarydetails/complete_exercise.dart';

import '../../constants/strings.dart';
import '../../custom/custom_button.dart';
import 'day1_screen.dart';

class ProgLibraryDetail extends StatefulWidget {
  const ProgLibraryDetail({Key? key}) : super(key: key);

  @override
  State<ProgLibraryDetail> createState() => _ProgLibraryDetailState();
}

class _ProgLibraryDetailState extends State<ProgLibraryDetail> {
  final List<League> data = <League>[
    League(
      Strings.day1Text.toUpperCase(),
      'assets/ChartLineUp.png',
      <Club>[
        Club('assets/main_4.png', 'Squat', 'Completed'),
        Club('assets/main_4.png', 'Squat', 'Completed'),
        Club('assets/main_4.png', 'Squat', 'Pending'),
      ],
    ),
    League(
      Strings.day2Text.toUpperCase(),
      'assets/ChartLineUp.png',
      <Club>[
        Club('assets/main_2.png', 'Squat', 'Completed'),
      ],
    ),
    League(
      Strings.day3Text.toUpperCase(),
      'assets/ChartLineUp.png',
      <Club>[
        Club('assets/main_2.png', 'Squat', 'Completed'),
      ],
    ),
    League(
      Strings.day4Text.toUpperCase(),
      'assets/ChartLineUp.png',
      <Club>[
        Club('assets/main_2.png', 'Squat', 'Completed'),
      ],
    ),
    League(
      Strings.day5Text.toUpperCase(),
      'assets/ChartLineUp.png',
      <Club>[
        Club('assets/main_2.png', 'Squat', 'Completed'),
      ],
    ),
    League(
      Strings.day6Text.toUpperCase(),
      'assets/ChartLineUp.png',
      <Club>[
        Club('assets/main_2.png', 'Squat', 'Completed'),
      ],
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 4,
      child: Scaffold(
        backgroundColor: Colors.black,
        appBar: AppBar(
            backgroundColor: Colors.black,
            title: const Text(Strings.programDetailTitleText),
            actions: [
              IconButton(
                icon: const Icon(Icons.settings),
                onPressed: () {
                  showModalBottomSheet<void>(
                    context: context,
                    builder: (BuildContext context) {
                      return SizedBox(
                        height: 186,
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Container(
                              color: Strings.colorPrimaryGrey,
                              width: double.infinity,
                              padding: EdgeInsets.only(top: 10, bottom: 5.0),
                              child: const Text(
                                Strings.updatePlanText,
                                style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    fontFamily: 'Lato-Bold',
                                    fontSize: 16,
                                    color: Colors.white),
                                textAlign: TextAlign.center,
                              ),
                            ),
                            const Divider(
                              height: 0,
                            ),
                            Container(
                              color: Strings.colorPrimaryGrey,
                              width: double.infinity,
                              child: CustomButton(
                                  margin: const EdgeInsets.symmetric(
                                      horizontal: 30, vertical: 4),
                                  title: Strings.resetprogText,
                                  textColor: Colors.white,
                                  onTap: () {},
                                  bgColor: Strings.colorActionSheetButton,
                                  width: double.infinity),
                            ),
                            Container(
                                color: Strings.colorPrimaryGrey,
                                width: double.infinity,
                                child: CustomButton(
                                    margin: const EdgeInsets.symmetric(
                                        horizontal: 30, vertical: 4),
                                    title: Strings.reanswerText,
                                    onTap: () {},
                                    bgColor: Strings.colorActionSheetButton,
                                    width: double.infinity)),
                            const Divider(
                              height: 0,
                              color: Strings.colorPrimaryGrey,
                            ),
                            Container(
                              color: Strings.colorPrimaryGrey,
                              width: double.infinity,
                              child: CustomButton(
                                  margin: const EdgeInsets.symmetric(
                                      horizontal: 30, vertical: 4),
                                  title: Strings.closeText,
                                  onTap: () {
                                    Navigator.pop(context);
                                  },
                                  bgColor: Strings.colorActionSheetButton),
                            )
                          ],
                        ),
                      );
                    },
                  );
                },
              )
            ],
            bottom: const TabBar(
              tabs: [
                Tab(text: Strings.week1Text),
                Tab(text: Strings.week2Text),
                Tab(text: Strings.week3Text),
                Tab(text: 'Week 4')
              ],
              indicatorColor: Colors.white,
            )),
        body: TabBarView(children: [
          ListView.builder(
            itemBuilder: (BuildContext context, int index) =>
                MyExpandableWidget(data[index]),
            itemCount: data.length,
          ),
          ListView.builder(
            itemBuilder: (BuildContext context, int index) =>
                MyExpandableWidget(data[index]),
            itemCount: data.length,
          ),
          ListView.builder(
            itemBuilder: (BuildContext context, int index) =>
                MyExpandableWidget(data[index]),
            itemCount: data.length,
          ),
          ListView.builder(
            itemBuilder: (BuildContext context, int index) =>
                MyExpandableWidget(data[index]),
            itemCount: data.length,
          ),
        ]),
      ),
    );
  }
}

class MyExpandableWidget extends StatelessWidget {
  final League league;

  const MyExpandableWidget(this.league);

  @override
  Widget build(BuildContext context) {
    showPrograms(Club club) {
      Color getColor(String status) {
        if (club.status == 'Completed')
          return Colors.green;
        else
          return Colors.red;
      }

      return ListTile(
        tileColor: AppColors.colorActionSheetButton,
        leading: Image.asset(club.image),
        trailing: IconButton(
          icon: Icon(
            Icons.keyboard_arrow_right,
            color: Colors.white,
            size: 30.h,
          ),
          onPressed: () {
            Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) => const CompleteExerciseScreen()));
          },
        ),
        key: PageStorageKey<Club>(club),
        title: Text(
          club.clubName,
          style: const TextStyle(
              fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white),
        ),
        subtitle: Text(
          club.status,
          style: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.bold,
              color: getColor('Pending')),
        ),
      );
    }

    if (league.listClubs.isEmpty) {
      return ListTile(
        title: Image.asset('assets/ChartLineUp.png'),
        leading: Text(league.leagueName),
      );
    }
    return ExpansionTile(
      trailing: const Icon(
        Icons.expand_circle_down_outlined,
        color: Colors.white,
      ),
      collapsedIconColor: Colors.white,
      iconColor: Colors.white,
      collapsedBackgroundColor: AppColors.colorPrimaryGrey,
      backgroundColor: AppColors.colorActionSheetButton,
      key: PageStorageKey<League>(league),
      title: Row(
        children: [
          Text(league.leagueName,
              style: const TextStyle(
                  fontFamily: 'Lato',
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  color: Colors.white)),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12.0),
            child: IconButton(
              icon: Image.asset('assets/ChartLineUp.png'),
              onPressed: () {
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => const Day1Screen()));
              },
            ),
          ),
        ],
      ),
      children:
          league.listClubs.map<Widget>((club) => showPrograms(club)).toList(),
    );
  }
}

class League {
  String leagueName;
  String img;
  List<Club> listClubs;

  League(this.leagueName, this.img, this.listClubs);
}

class Club {
  String image;
  String clubName;
  String status;

  Club(this.image, this.clubName, this.status);
}
