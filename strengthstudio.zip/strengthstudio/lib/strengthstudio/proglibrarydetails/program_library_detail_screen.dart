import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:strengthstudio/strengthstudio/proglibrarydetails/day1_screen.dart';
import 'package:strengthstudio/strengthstudio/proglibrarydetails/select_exercise_screen.dart';
import 'package:strengthstudio/tabbarpage/tab_bar.dart';

import '../../constants/strings.dart';
import '../../custom/custom_button.dart';

void main() => runApp(const ProgramLibraryDetailScreen());

class MyStatefulWidget extends StatefulWidget {
  const MyStatefulWidget({Key? key}) : super(key: key);

  @override
  State<StatefulWidget> createState() => _MyStatefulWidgetState();
}

class _MyStatefulWidgetState extends State<MyStatefulWidget> {
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 4,
      child: WillPopScope(
        onWillPop: () async {
          return true;
        },
        child: Scaffold(
          backgroundColor: Colors.black,
          appBar: AppBar(
              backgroundColor: Colors.black,
              title: const Text(Strings.programDetailTitleText),
              leading: IconButton(
                icon: const Icon(Icons.arrow_back),
                onPressed: () {
                  Navigator.pushAndRemoveUntil(
                      context,
                      MaterialPageRoute(
                          builder: (context) => const TabbarPage()),
                      ModalRoute.withName("/Home"));
                },
              ),
              centerTitle: true,
              actions: [
                IconButton(
                  icon: const Icon(Icons.settings),
                  onPressed: () {
                    showModalBottomSheet<void>(
                      context: context,
                      builder: (BuildContext context) {
                        return SizedBox(
                          height: 186,
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Container(
                                color: Strings.colorPrimaryGrey,
                                width: double.infinity,
                                padding: EdgeInsets.only(top: 10, bottom: 5.0),
                                child: const Text(
                                  Strings.updatePlanText,
                                  style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontFamily: 'Lato-Bold',
                                      fontSize: 16,
                                      color: Colors.white),
                                  textAlign: TextAlign.center,
                                ),
                              ),
                              const Divider(
                                height: 0,
                              ),
                              Container(
                                color: Strings.colorPrimaryGrey,
                                width: double.infinity,
                                child: CustomButton(
                                    margin: const EdgeInsets.symmetric(
                                        horizontal: 30, vertical: 4),
                                    title: Strings.resetprogText,
                                    textColor: Colors.white,
                                    onTap: () {},
                                    bgColor: Strings.colorActionSheetButton,
                                    width: double.infinity),
                              ),
                              Container(
                                  color: Strings.colorPrimaryGrey,
                                  width: double.infinity,
                                  child: CustomButton(
                                      margin: const EdgeInsets.symmetric(
                                          horizontal: 30, vertical: 4),
                                      title: Strings.reanswerText,
                                      onTap: () {},
                                      bgColor: Strings.colorActionSheetButton,
                                      width: double.infinity)),
                              const Divider(
                                height: 0,
                                color: Strings.colorPrimaryGrey,
                              ),
                              Container(
                                color: Strings.colorPrimaryGrey,
                                width: double.infinity,
                                child: CustomButton(
                                    margin: const EdgeInsets.symmetric(
                                        horizontal: 30, vertical: 4),
                                    title: Strings.closeText,
                                    onTap: () {
                                      Navigator.pop(context);
                                    },
                                    bgColor: Strings.colorActionSheetButton),
                              )
                            ],
                          ),
                        );
                      },
                    );
                  },
                )
              ],
              bottom: const TabBar(
                tabs: [
                  Tab(text: Strings.week1Text),
                  Tab(text: Strings.week2Text),
                  Tab(text: Strings.week3Text),
                  Tab(text: 'Week 4')
                ],
                indicatorColor: Colors.white,
              )),
          body: const TabBarView(
            children: [
              FirstScreen(),
              FirstScreen(),
              FirstScreen(),
              FirstScreen()
            ],
          ),
        ),
      ),
    );
  }
}

class ProgramLibraryDetailScreen extends StatelessWidget {
  const ProgramLibraryDetailScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
        debugShowCheckedModeBanner: false, home: MyStatefulWidget());
  }
}

class FirstScreen extends StatelessWidget {
  const FirstScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(1.0),
      child: GestureDetector(
        onTap: () => {},
        child: ListView(
          children: const <Widget>[
            ProgramBox(
              chartimg: "ChartLineUp.png",
              name: Strings.day1Text,
            ),
            ProgramBox(
              chartimg: "ChartLineUp.png",
              name: Strings.day2Text,
            ),
            ProgramBox(
              chartimg: "imogi.png",
              name: Strings.day3Text,
            ),
            ProgramBox(
              chartimg: "ChartLineUp.png",
              name: Strings.day4Text,
            ),
            ProgramBox(
              chartimg: "imogi.png",
              name: "Day 5",
            ),
            ProgramBox(
              chartimg: "ChartLineUp.png",
              name: "Day 6",
            ),
          ],
        ),
      ),
    );
  }
}

class ProgramBox extends StatelessWidget {
  const ProgramBox({
    Key? key,
    required this.chartimg,
    required this.name,
  }) : super(key: key);
  final String chartimg;
  final String name;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 50,
      child: Card(
          color: Strings.colorGrey,
          child: Row(children: <Widget>[
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Text(name,
                  style: const TextStyle(
                      color: Colors.white, fontFamily: 'Lato', fontSize: 16.0)),
            ),
            Expanded(
                child: Container(
                    padding: const EdgeInsets.all(0),
                    child: Row(
                      children: [
                        Padding(
                          padding: const EdgeInsets.all(5.0),
                          child: GestureDetector(
                            child: Image.asset("assets/$chartimg"),
                            onTap: () {
                              /*  for(var i in ProgramBox[name]) {
                                 if(i == "DAY 1") {

                                 }
                               }*/
                              Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) =>
                                          const Day1Screen()));
                            },
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(left: 260),
                          child: IconButton(
                              icon: const Icon(
                                Icons.arrow_circle_down,
                                color: Colors.white,
                              ),
                              onPressed: () {
                                Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) =>
                                            const SelectExerciseScreen()));
                              }),
                        )
                      ],
                    )))
          ])),
    );
  }
}
