import 'package:expandable_text/expandable_text.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:strengthstudio/tabbarpage/programs/program_library.dart';

import '../../constants/strings.dart';

void main() => runApp(const Day1Screen());

class MyStatefulWidget extends StatefulWidget {
  const MyStatefulWidget({Key? key}) : super(key: key);

  @override
  State<StatefulWidget> createState() => _MyStatefulWidgetState();
}

class _MyStatefulWidgetState extends State<MyStatefulWidget> {
  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        return true;
      },
      child: Scaffold(
          backgroundColor: Colors.black,
          appBar: AppBar(
            backgroundColor: Colors.black,
            title: const Text('Day 1'),
            leading: IconButton(
              icon: const Icon(Icons.arrow_back),
              onPressed: () {
                Navigator.pushAndRemoveUntil(
                    context,
                    MaterialPageRoute(
                        builder: (context) => const ProgramLibrary()),
                    ModalRoute.withName("/Programs"));
              },
            ),
            centerTitle: true,
          ),
          body: const FirstScreen()),
    );
  }
}

class Day1Screen extends StatelessWidget {
  const Day1Screen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
        debugShowCheckedModeBanner: false, home: MyStatefulWidget());
  }
}

class FirstScreen extends StatelessWidget {
  static final _formKey = GlobalKey<ScaffoldState>();

  const FirstScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ListView(
      children: const <Widget>[
        ProgramBox(
            name: Strings.lowBarText,
            rpe: Strings.reposText,
            lbs: Strings.lbsText,
            rep: Strings.rpesText,
            note: Strings.noteText,
            loreum: Strings.loreumText),
        ProgramBox(
            name: Strings.benchPressText,
            rpe: Strings.reposText,
            lbs: Strings.lbsText,
            rep: Strings.rpesText,
            note: Strings.noteText,
            loreum: Strings.loreumText),
        ProgramBox(
            name: Strings.deadLiftText,
            rpe: Strings.reposText,
            lbs: Strings.lbsText,
            rep: Strings.rpesText,
            note: Strings.noteText,
            loreum: Strings.loreumText),
      ],
    );
/*    ListView.builder(itemCount: 3,itemBuilder: (_,index)=>ProgramBox(name: Strings.deadLiftText,
        rpe: Strings.reposText,
        lbs: Strings.lbsText,
        rep: Strings.rpesText,
        note: Strings.noteText,
        loreum: Strings.loreumText));*/
  }
}

class ProgramBox extends StatefulWidget {
  const ProgramBox(
      {Key? key,
      required this.name,
      required this.rpe,
      required this.lbs,
      required this.rep,
      required this.note,
      required this.loreum})
      : super(key: key);
  final String? name;
  final String? rpe;
  final String? lbs;
  final String? rep;
  final String? note;
  final String? loreum;

  @override
  State<StatefulWidget> createState() => _ProgramBoxState();
}

class _ProgramBoxState extends State<ProgramBox> {
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(0),
      height: 220.h,
      child: Card(
          color: Colors.black,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                  child: Container(
                      padding: const EdgeInsets.all(1),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Padding(
                            padding:
                                const EdgeInsets.symmetric(horizontal: 8.0),
                            child: Text(widget.name ?? "not found",
                                style: const TextStyle(
                                    color: Colors.white,
                                    fontFamily: 'Lato',
                                    fontSize: 16.0)),
                          ),
                          Padding(
                            padding:
                                const EdgeInsets.symmetric(horizontal: 8.0),
                            child: Text(widget.rpe ?? "not found",
                                style: const TextStyle(
                                    color: Colors.white, fontFamily: 'Lato')),
                          ),
                          Padding(
                            padding:
                                const EdgeInsets.symmetric(horizontal: 8.0),
                            child: Text(widget.lbs ?? "not found",
                                style: const TextStyle(
                                    color: Colors.white, fontFamily: 'Lato')),
                          ),
                          Padding(
                            padding:
                                const EdgeInsets.symmetric(horizontal: 8.0),
                            child: Text(widget.rep ?? "not found",
                                style: const TextStyle(
                                    color: Colors.white, fontFamily: 'Lato')),
                          ),
                        ],
                      ))),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8.0),
                child: Text(widget.note ?? "not found",
                    style: const TextStyle(
                      color: Colors.white,
                      fontFamily: 'Lato',
                      fontSize: 15,
                    )),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8.0),
                child: ExpandableText(
                  widget.loreum ?? "not found",
                  style:
                      const TextStyle(color: Colors.grey, fontFamily: 'Lato'),
                  linkColor: Colors.white,
                  expandText: 'show more',
                  collapseText: 'show less',
                  maxLines: 2,
                ),
              ),
            ],
          )),
    );
  }
}
