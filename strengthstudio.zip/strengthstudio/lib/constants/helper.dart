import 'package:flutter/material.dart';
import 'package:strengthstudio/constants/strings.dart';

/*void main() {
  runApp(ScreenStepper());
}*/

class ScreenStepper extends StatefulWidget {
  @override
  State<StatefulWidget> createState() => _ScreenProgressState(ticks: 1);
}

class _ScreenProgressState extends State<ScreenStepper> {
  int ticks = 2;

  _ScreenProgressState({required this.ticks});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Row(
          children: <Widget>[
            const Padding(
              padding: EdgeInsets.only(left: 20.0),
              child: Text(
                Strings.personalInfoText,
                style: TextStyle(color: Colors.white, fontFamily: 'Lato'),
              ),
            ),
            spacer(),
            const Padding(
              padding: EdgeInsets.only(left: 20.0),
              child: Text(Strings.recordsText,
                  style: TextStyle(color: Colors.white, fontFamily: 'Lato')),
            ),
            spacer(),
            const Padding(
              padding: EdgeInsets.only(left: 20.0),
              child: Text(Strings.goalsText,
                  style: TextStyle(color: Colors.white, fontFamily: 'Lato')),
            ),
          ],
        ),
        Row(
          children: <Widget>[
            line(),
            spacer(),
            tick1(),
            spacer(),
            line(),
            spacer(),
            tick2(),
            line(),
            tick3(),
            spacer(),
            line()
          ],
        ),
      ],
    );
  }

  Widget tick(bool isChecked) {
    return isChecked
        ? const Icon(
            Icons.circle_sharp,
            color: Colors.redAccent,
          )
        : Icon(
            Icons.circle,
            color: Colors.grey,
          );
  }

  Widget tick1() {
    return ticks > 0 ? tick(true) : tick(false);
  }

  Widget tick2() {
    return ticks > 1 ? tick(true) : tick(false);
  }

  Widget tick3() {
    return this.ticks > 2 ? tick(true) : tick(false);
  }

  Widget tick4() {
    return this.ticks > 3 ? tick(true) : tick(false);
  }

  Widget spacer() {
    return Container(
      width: 2.0,
    );
  }

  Widget line() {
    return Container(
      color: Colors.grey,
      height: 3.0,
      width: 70.0,
    );
  }
}

class ScreenStepper2 extends StatefulWidget {
  @override
  State<StatefulWidget> createState() => _ScreenProgressState2(ticks: 2);
}

class _ScreenProgressState2 extends State<ScreenStepper2> {
  int ticks = 2;

  _ScreenProgressState2({required this.ticks});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Row(
          children: <Widget>[
            const Padding(
              padding: EdgeInsets.only(left: 20.0),
              child: Text(
                Strings.personalInfoText,
                style: TextStyle(color: Colors.white, fontFamily: 'Lato'),
              ),
            ),
            spacer(),
            const Padding(
              padding: EdgeInsets.only(left: 20.0),
              child: Text(Strings.recordsText,
                  style: TextStyle(color: Colors.white, fontFamily: 'Lato')),
            ),
            spacer(),
            const Padding(
              padding: EdgeInsets.only(left: 20.0),
              child: Text(Strings.goalsText,
                  style: TextStyle(color: Colors.white, fontFamily: 'Lato')),
            ),
          ],
        ),
        Row(
          children: <Widget>[
            line(),
            spacer(),
            tick1(),
            spacer(),
            line(),
            spacer(),
            tick2(),
            line(),
            tick3(),
            spacer(),
            line()
          ],
        ),
      ],
    );
  }

  Widget tick(bool isChecked) {
    return isChecked
        ? const Icon(
            Icons.circle_sharp,
            color: Colors.redAccent,
          )
        : Icon(
            Icons.circle,
            color: Colors.grey,
          );
  }

  Widget tick1() {
    return ticks > 0 ? tick(true) : tick(false);
  }

  Widget tick2() {
    return ticks > 1 ? tick(true) : tick(false);
  }

  Widget tick3() {
    return this.ticks > 2 ? tick(true) : tick(false);
  }

  Widget tick4() {
    return this.ticks > 3 ? tick(true) : tick(false);
  }

  Widget spacer() {
    return Container(
      width: 2.0,
    );
  }

  Widget line() {
    return Container(
      color: Colors.grey,
      height: 3.0,
      width: 70.0,
    );
  }
}

class ScreenStepper3 extends StatefulWidget {
  @override
  State<StatefulWidget> createState() => _ScreenProgressState3(ticks: 3);
}

class _ScreenProgressState3 extends State<ScreenStepper3> {
  int ticks = 2;

  _ScreenProgressState3({required this.ticks});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Row(
          children: <Widget>[
            const Padding(
              padding: EdgeInsets.only(left: 20.0),
              child: Text(
                Strings.personalInfoText,
                style: TextStyle(color: Colors.white, fontFamily: 'Lato'),
              ),
            ),
            spacer(),
            const Padding(
              padding: EdgeInsets.only(left: 20.0),
              child: Text(Strings.recordsText,
                  style: TextStyle(color: Colors.white, fontFamily: 'Lato')),
            ),
            spacer(),
            const Padding(
              padding: EdgeInsets.only(left: 20.0),
              child: Text(Strings.goalsText,
                  style: TextStyle(color: Colors.white, fontFamily: 'Lato')),
            ),
          ],
        ),
        Row(
          children: <Widget>[
            line(),
            spacer(),
            tick1(),
            spacer(),
            line(),
            spacer(),
            tick2(),
            line(),
            tick3(),
            spacer(),
            line()
          ],
        ),
      ],
    );
  }

  Widget tick(bool isChecked) {
    return isChecked
        ? const Icon(
            Icons.circle_sharp,
            color: Colors.redAccent,
          )
        : Icon(
            Icons.circle,
            color: Colors.grey,
          );
  }

  Widget tick1() {
    return ticks > 0 ? tick(true) : tick(false);
  }

  Widget tick2() {
    return ticks > 1 ? tick(true) : tick(false);
  }

  Widget tick3() {
    return this.ticks > 2 ? tick(true) : tick(false);
  }

  Widget tick4() {
    return this.ticks > 3 ? tick(true) : tick(false);
  }

  Widget spacer() {
    return Container(
      width: 2.0,
    );
  }

  Widget line() {
    return Container(
      color: Colors.grey,
      height: 3.0,
      width: 70.0,
    );
  }
}
