import 'dart:ui';

import 'package:flutter/material.dart';

class AppColors extends Object {
  static const colorGrey = Color(0xFF1D1D1D);
  static const colorLightGrey = Color(0xFF979797);
  static const colorPrimaryGrey = Color(0xFF252525);
  static const colorBottom = Color(0xFF1F1F1F);
  static const colorBottomItem = Color(0xFF575555);
  static const colorActionSheetButton = Color(0xFF696969);
  static const colorRed = Color(0xFFED1F24);
  static const colorYellow = Color(0xFFFFD600);
  static const colorGreen = Color(0xFF27AE60);
  static Color whiteColor = Colors.white;
  static Color blackColor = Colors.black;
}
