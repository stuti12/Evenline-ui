import 'dart:ui';

class Strings {
  //login
  static const String welcomeMessageText = "Welcome,";
  static const String welcomeSubtitleText = 'Sign in to continue!';
  static const String emailText = 'Email';
  static const String enterEmailText = 'Enter Your Email';
  static const String passwordText = 'Password';
  static const String enterPasswordText = 'Enter Your Password';

  //signup
  static const String createAccountText = 'Create Account';
  static const String signUpSubtitle = ' Sign Up to get started!';
  static const String confirmPasswordText = 'Confirm Password';
  static const String enterCPasswordText = 'Enter Confirm Password';
  static const String alreadyHaveAccText = 'Already have an account? ';
  static const String signUpText = 'Sign Up';

  static const String signInText = 'Sign In';
  static const String signUpBtnText = 'SIGN UP';
  static const String forgetText = 'Forgot Password?';
  static const String loginSuccessText = 'Login Successful';
  static const String loginFail = 'Login Fail';

  static const String dontHaveAccountText = 'Dont Have Account? ';

  static const String forgetPasswordText = 'Forgot Password';
  static const String forgetSubTitleText =
      'Enter your email address to reset your password.';
  static const String passwordSentText = 'Password Sent to Email';
  static const String rememberPasswordText = 'Remember Password? ';
  static const String nextText = 'NEXT';

  //verification
  static const String verificationText = 'Verification';
  static const String emailVerifyText = 'Email verification via OTP';
  static const String verificationSubTitleText =
      'We have sent you an OTP on your registered email address “john........12@gmail.com”.';
  static const String verifyText = 'VERIFY';
  static const String resendOtpText = 'Resend OTP';

  //reset password
  static const String resetPasswordText = 'Reset Password';
  static const String resetPasswordSubtitleText =
      'Enter you new password to access your account.';
  static const String passwordChanged = 'Password Changed';
  static const String resetSheetText =
      'Your password is reset, let’s  login access you account.';
  static const String submitText = 'SUBMIT';

  static const String passwordResetText = 'Password reset Successfully';

  //create profile
  static const String personalInfoText = 'Personal Info';
  static const String recordsText = 'Records & Metrics';
  static const String goalsText = 'Goals & Training';
  static const String recordText = 'Records';
  static const String metricesText = 'Metrics';
  static const String unitPreferenceText = 'unit Preference';
  static const String metricText = 'Metric';
  static const String imperialText = 'Imperial';
  static const String createProfileText = 'Create Profile';
  static const String userNameText = 'Username';
  static const String firstNameText = 'First Name';
  static const String lastNameText = 'Last Name';
  static const String dateOfBirthText = 'Date of Birth';
  static const String squatMaxText = 'Squat Max (kg)';
  static const String benchPressMax = 'Bench Press Max (kg)';
  static const String deadliftText = 'Deadlift Max (kg)';
  static const String weightText = 'Weight (kg)';
  static const String heightText = 'Height (kg)';
  static const String selectYourGoalText = 'Select Your Goal';
  static const String trainingExperienceText = 'Training Experience';
  static const String getStrongText = 'Get Stronger';
  static const String buildText = 'Build Muscle';
  static const String powerBuildingText = 'Power Building';
  static const String recompositionText = 'Recomposition';
  static const String lessThan1Text = 'Less than 1 year';
  static const String oneTwoYearsText = '1-2 years';
  static const String threefiveText = '3-5 years';

  //myprogram
  static const String activatedText = 'Activated';
  static const String completedText = 'Completed';
  static const String myProgramsText = 'My Programs';

  static const String trainingText = 'Training';
  static const String programsText = 'Programs';
  static const String communityText = 'Community';
  static const String videoText = 'Video Library';
  static const String profileText = 'Profile';

  static const String jamelText = 'Jamal Browner’s 12 Week Intermediate Vol. 4';
  static const String weeksText = '12 weeks';
  static const String theGodfatherProgramBundleText =
      "The Godfather Program Bundle (LIMITED)";
  static const String sSTTsStrengthFocusedPushPullLegs =
      'SSTT’s Strength Focused Push Pull Legs';

  static const String noActivatedPlan = 'No Activated Plan';
  static const String selectaplan = 'SELECT  PLAN';

  //prog_library
  static const String noProgramLibraryText = 'No Program Library Available';
  static const String noProgramLibrarySubtitleText =
      'Lorem Ipsum is simply dummy text of the printing and typesetting industry.';
  static const String refreshPageText = 'REFRESH PAGE';

  static const String daysPlannningText = 'Days Planning';
  static const String selectPlanText = 'Select a Plan';

  static const String doYouWantText = 'DO YOU WANT TO ADD AN ADDITIONAL DAY?';
  static const String customPlanText = 'CUSTOMIZED PLAN';
  static const String useDefaultPlanText = 'USE CHANGE PLAN';
  static const String yesText = 'YES, ADD';

  static const String noText = 'NO, Dont Add';
  static const String closeText = 'CLOSE';

  static const String programDetailTitleText = 'Jamal Browner’s 12 Week';

  //prog-library_detail
  static const String week1Text = 'Week 1';
  static const String week2Text = 'Week 2';
  static const String week3Text = 'Week 3';
  static const String day1Text = 'Day 1';
  static const String day2Text = 'Day 2';
  static const String day3Text = 'Day 3';
  static const String day4Text = 'Day 4';
  static const String day5Text = 'Day 5';
  static const String day6Text = 'Day 6';

  static const String workoutText = 'Workout Overview';
  static const String dateText = '04/20/22 3:02 am';
  static const String lowBarText = 'Low Bar Back Squat';
  static const String reposText = '5 reps \n5 reps \n5 reps';
  static const String lbsText = '80 lbs \n80 lbs \n80 lbs';
  static const String rpesText = '5 rpe \n5 rpe \n5 rpe';
  static const String noteText = 'Note:';
  static const String loreumText =
      'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. less';
  static const String benchPressText = 'Bench Press';
  static const String deadLiftText = 'Deadlift';

  static const String updatePlanText = 'UPDATE PLAN';
  static const String resetprogText = 'RESET PROGRAM FULLY';
  static const String reanswerText = 'RE-ANSWER QUESTIONARIE';

  //completeExercise
  static const String complteExTitleText = 'Single Leg Extentions';
  static const String exerciseNoteText = 'Exercise Notes';
  static const String exerciseDetailText = 'Exercise Details';
  static const String completeExerciseText = 'Complete Exercise';
  static const String saveText = 'SAVE';

  //select exercise
  static const String selectExerciseText = 'Select Exercise';
  static const String squareVarientText = 'SQUARE VARIENT';
  static const String highSquatText = 'HighBar Squat';
  static const String pausedSquat = 'Paused Squat';
  static const String pinSquatText = 'Pin Squat';
  static const String frontSquat = 'Front Squat';
  static const String resetText = 'Reset';
  static const String k80KgText = '80 KG';

  //bottomsheet
  static const String areYouSureText =
      'Are you sure you want to switch exercise?';
  static const String yesReset = 'YES, RESET';
  static const String noReset = 'NO, DONT RESET';

  //program-filter
  static const String hyperTrophyText = 'HyperTrophy';
  static const String strengthText = 'Strength';
  static const String allText = 'All';

  //program library
  static const String programLibrartAppTitle = 'Program Library';
  static const String programLibraryTitleText =
      'Jamal Browner’s 12 Week Intermediate Vol. 4';
  static const String dollarText = '\$124.99';
  static const String dollarDiscountText = '\$154.99';

  static const String programLengthText = 'Program Length : 12 weeks(3 months)';
  static const String overaalLiftingText =
      'Overall Lifting Frequency: 4 or 5 Days/Weekly';
  static const String typeText = 'Type: RPE & Percentage Based(new System)';

  static const String detailsText = 'Details';
  static const String reviewText = 'Review';

  //program detail
  static const String programDetailText =
      'During the 2+ years since we launched the intermediate V1 we’ve helped thousands of guys destroy their previous PRs and learned a hell of a lot about what makes a good program great. Every time we drop something new our aim is to set new standards for what you guys expect from a one time purchase program. The relentless positive feedback, insane results and non-stop PR videos from V3 were incredible to see and made us realize we had a task on our hands for V4. Inspired by the results of V3, we went to work on something that would completely change the industry. We bring you…. V4.';
  static const String reviewDetailText =
      'You can’t go wrong with this bundle, sick programs. Thank you Jamal and SST Team';
  static const String addYourReview = 'ADD YOUR REVIEW';
  static const String verifiefOwner = '(Verified Owner)';
  static const String datesText = 'October 9, 2021';

  static const String noReviewsAddedText = 'No review added yet!';
  static const String noReviewAddedSubtitleText =
      'You can add your review to share your experience of plan';
  static const String buyNowText = 'Buy now';

  //filter-community
  static const String filterText = 'filter';
  static const String filterFeedType = 'Filter feed type';
  static const String userForumText = 'User Forum';
  static const String filterByCategoryText = 'Filter by Category';
  static const String applyText = 'APPLY';
  static const String nutritionText = 'Nutrition';
  static const String extraText = 'Extra';

  //community
  static const String loreumCommunityText =
      'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s';

  //communty comment
  static const String typeCommentText = 'Type your Comment';
  static const String typeReplyText = 'Type your Reply';
  static const String reply25Text = 'Reply(25)';

  //bottom
  static const String addPrivateVideoText = 'Add Private Video';
  static const String createFeed = 'CREATE FEED';
  static const String feedTitleText = 'Feed Title';
  static const String descriptionText = 'description';

  static const String createText = 'CREATE';

  //private
  static const String privateVideoText = 'Private Video';

  //private video sheet
  static const String enterVideoTitle = 'Enter video title';

  static const String addPhotoText = 'Add Photo/Video';
  static const String addText = 'ADD';

  //videolibrary
  static const String durationText = '10m ago';
  static const String jamelVideoTitleText = 'Jamal Browner’s 12 Week';

  //profile
  static const String johnSmithText = 'John Smith';
  static const String johnEmail = 'johnsmith12@gmail.com';

  static const String premiumMember = 'Premium Member';
  static const String becomePremiumText = 'Become Premium Member';
  static const String editProfileText = 'EDIT PROFILE';
  static const String weightsText = 'Weight: \n78 Kg';
  static const String heightsText = 'Height: \n5.5 Feet';
  static const String unitPrefText = 'Unit Preference: \nMetric';
  static const String trainingExText = 'Training Experience:\n2-3 Years';
  static const String goalText = 'Goal:\nWeight Loss';
  static const String premiumBenefitText = 'Premium Benefits';
  static const String communityAccess = 'Community Access';
  static const String privateVideoUploadText = 'private Video Upload';
  static const String discountedRate = 'Discounted Price';
  static const String accessText = 'Access to 2 Free Programs';
  static const String subscribeNow = 'SUBSCRIBE NOW';
  static const String priceText = '\$29.99/Yearly';
  static const String premiumMemberText = 'Premium Member';
  static const String youArePrimeMember = 'You are a premium member';
  static const String currentPlanText = 'Current Plan';

  static const String pricePremiumText = '\$29.99';
  static const String validTillText = 'Valid Till: Dec 09, 2022';

  static const String quesTitle = 'Questionnaires';
  static const String stressfulText =
      'Stressful(Mediocre Sleep & Long Work/ School hours)';
  static const String averageText =
      'Average(Decent Sleep & Regular Work/ School hours)';
  static const String lowText =
      'Low(Good or Great Sleep & Light Work/ School hours)';
  static const String questionaryHas4PartText =
      'THIS QUESTIONNAIRE HAS 4 PARTS. Please rate the following below based on your experience lifting, these selections will impact your program significantly:\nNOTE: If you are unsure about the answer to one of these you should leave it at a two (2) rating.';
  static const String cantRecoverText =
      'I usually cant recover from too much volume on this lift.';
  static const String averageAbilityText =
      'I can handle an average amount of volume on this lift.';
  static const String lotOfRecoverText =
      'I can usually handle a lot of volume on this lift and reco';
  static const String rateQuesText =
      '1. Rate your ability to handle/recover from volume for the Squat';
  static const String dontHaveAbilityText =
      'I dont have great technique. (Not very efficient)';
  static const String averageAbility =
      'I have average to good technique on this lift.';
  static const String flowLessAbilityText =
      'My technique is almost flawless. (Very efficient) ';
  static const String quickGuideText = 'QUICK QUESTIONNARIE GUIDE';
  static const String ques2Guide =
      '1. If youre a beginner you should lean more toward a rating of 1 or 2 for these questions.\n 2. If youre used to high volume or intensity but you usually do less frequency than this program has (3 Squat, 4 Bench & 2 Deadlift) you should lean toward 2. \n3. Conventional pullers should lean toward a lor 2 rating. Sumo pullers can go with 2 or 3 if your technique is really solid.';
  static const String rateyourTechniqueonTheSquat =
      '2. Rate your technique on the Squat:';
  static const String generalText = 'General';
  static const String squatText = 'Squat';
  static const String genderText = 'Gender';

  static const colorGrey = Color(0xFF1D1D1D);
  static const colorLightGrey = Color(0xFF979797);
  static const colorPrimaryGrey = Color(0xFF252525);
  static const colorBottom = Color(0xFF1F1F1F);
  static const colorBottomItem = Color(0xFF575555);
  static const colorActionSheetButton = Color(0xFF696969);
  static const colorRed = Color(0xFFED1F24);
  static const colorYellow = Color(0xFFFFD600);
}
