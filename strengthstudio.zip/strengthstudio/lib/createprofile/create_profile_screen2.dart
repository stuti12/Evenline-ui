import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../constants/colors.dart';
import '../constants/helper.dart';
import '../constants/strings.dart';
import '../custom/custom_button.dart';
import '../custom/text_style.dart';
import 'create_profile_screen3.dart';

void main() {
  runApp(const CreateProfileScreen2());
}

class CreateProfileScreen2 extends StatefulWidget {
  const CreateProfileScreen2({Key? key}) : super(key: key);

  @override
  State<CreateProfileScreen2> createState() => _CreateProfileScreen2State();
}

class _CreateProfileScreen2State extends State<CreateProfileScreen2> {
  static final _formKey = GlobalKey<FormState>();
  static final TextEditingController _squatMaxText = TextEditingController();
  static final TextEditingController _deadliftText = TextEditingController();

  static final TextEditingController _benchPressText = TextEditingController();

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
        onTap: () {
          FocusScope.of(context).requestFocus(FocusNode());
        },
        child: Scaffold(
            backgroundColor: AppColors.blackColor,
            appBar: AppBar(
              backgroundColor: AppColors.blackColor,
              title: const Text(Strings.createProfileText,
                  style: TextStyle(color: Colors.white)),
              leading: IconButton(
                icon: const Icon(Icons.arrow_back),
                onPressed: () {
                  Navigator.of(context, rootNavigator: false).pop(context);
                },
              ),
              centerTitle: true,
            ),
            body: SingleChildScrollView(
              child: Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16.0),
                    child: ScreenStepper2()
                  ),
                  ClipRRect(
                    borderRadius: const BorderRadius.only(
                        topRight: Radius.circular(30), topLeft: Radius.circular(30)),
                    child: Container(
                      color: AppColors.colorPrimaryGrey,
                      child: Column(
                        children: [
                          Form(
                            key: _formKey,
                            child: Padding(
                              padding: const EdgeInsets.symmetric(horizontal: 18.0),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  const Padding(
                                    padding: EdgeInsets.only(top: 8.0),
                                    child: Text(Strings.recordText,
                                        style: TextStyle(
                                            fontFamily: 'Lato',
                                            fontSize: 18,
                                            color: Colors.white)),
                                  ),
                                  Container(
                                    width: double.infinity,
                                    color: AppColors.colorGrey,
                                    margin: const EdgeInsets.symmetric(
                                        horizontal: 10.0, vertical: 16.0),
                                    child: TextFormField(
                                      controller: _squatMaxText,
                                      keyboardType: TextInputType.number,
                                      textInputAction: TextInputAction.next,
                                      style: const TextStyle(color: Colors.white,fontFamily: 'Lato'),
                                      cursorColor: Colors.white,
                                      decoration: const InputDecoration(
                                        filled: true,
                                        labelStyle: TextStyle(color: Colors.red),
                                        focusedBorder: OutlineInputBorder(
                                            borderSide: BorderSide(color: Colors.red),
                                            borderRadius:
                                            BorderRadius.all(Radius.circular(5.0))),
                                        border: OutlineInputBorder(
                                            borderSide: BorderSide(color: Colors.red)),
                                        labelText: Strings.squatMaxText,
                                        hintText: Strings.squatMaxText,
                                        hintStyle: TextStyle(color: Colors.grey,fontFamily: 'Lato'),
                                      ),
                                      validator: (value) {
                                        if (value?.isEmpty ?? true) {
                                          return 'Please Enter Squat Max';
                                        }
                                        return null;
                                      },
                                    ),
                                  ),
                                  Container(
                                    width: double.infinity,
                                    color: Strings.colorGrey,
                                    margin: const EdgeInsets.symmetric(
                                        horizontal: 10.0, vertical: 16.0),
                                    child: TextFormField(
                                      controller: _benchPressText,
                                      keyboardType: TextInputType.number,
                                      textInputAction: TextInputAction.next,
                                      style: const TextStyle(color: Colors.white,fontFamily: 'Lato'),
                                      cursorColor: Colors.white,
                                      decoration: const InputDecoration(
                                        filled: true,
                                        labelStyle: TextStyle(color: Colors.red),
                                        focusedBorder: OutlineInputBorder(
                                            borderSide: BorderSide(color: Colors.red),
                                            borderRadius:
                                            BorderRadius.all(Radius.circular(5.0))),
                                        border: OutlineInputBorder(
                                            borderSide: BorderSide(color: Colors.red)),
                                        labelText: Strings.benchPressMax,
                                        hintText: Strings.benchPressMax,
                                        hintStyle: TextStyle(color: Colors.grey,fontFamily: 'Lato'),
                                      ),
                                      validator: (value) {
                                        if (value?.isEmpty ?? true) {
                                          return 'Please Enter Bench Press';
                                        }
                                        return null;
                                      },
                                    ),
                                  ),
                                  Container(
                                    width: double.infinity,
                                    color: Strings.colorGrey,
                                    margin: const EdgeInsets.symmetric(
                                        horizontal: 10.0, vertical: 16.0),
                                    child: TextFormField(
                                      controller: _deadliftText,
                                      textInputAction: TextInputAction.next,
                                      keyboardType: TextInputType.number,
                                      style: const TextStyle(color: Colors.white,fontFamily: 'Lato'),
                                      cursorColor: Colors.white,
                                      decoration: const InputDecoration(
                                        filled: true,
                                        labelStyle: TextStyle(color: Colors.red),
                                        focusedBorder: OutlineInputBorder(
                                            borderSide: BorderSide(color: Colors.red),
                                            borderRadius:
                                            BorderRadius.all(Radius.circular(5.0))),
                                        border: OutlineInputBorder(
                                            borderSide: BorderSide(color: Colors.red)),
                                        labelText: Strings.deadliftText,
                                        hintText: Strings.deadliftText,
                                        hintStyle: TextStyle(color: Colors.grey,fontFamily: 'Lato'),
                                      ),
                                      validator: (value) {
                                        if (value?.isEmpty ?? true) {
                                          return 'Please Enter Deadlift';
                                        }
                                        return null;
                                      },
                                    ),
                                  ),
                                  SizedBox(height: 10.h),
                                  RichText(
                                    text: TextSpan(
                                      text: Strings.metricesText,
                                      style: UITextStyle.regularTextStyle(
                                          color: Colors.white, fontSize: 18),
                                    ),
                                  ),
                                  SizedBox(height: 5.h),
                                  Container(
                                    width: double.infinity,
                                    color: Strings.colorGrey,
                                    margin: const EdgeInsets.symmetric(
                                        horizontal: 10.0, vertical: 16.0),
                                    child: TextFormField(
                                      keyboardType: TextInputType.number,
                                      textInputAction: TextInputAction.next,
                                      style: const TextStyle(color: Colors.white,fontFamily: 'Lato'),
                                      cursorColor: Colors.white,
                                      decoration: const InputDecoration(
                                        filled: true,
                                        labelStyle: TextStyle(color: Colors.red),
                                        focusedBorder: OutlineInputBorder(
                                            borderSide: BorderSide(color: Colors.red),
                                            borderRadius:
                                            BorderRadius.all(Radius.circular(5.0))),
                                        border: OutlineInputBorder(
                                            borderSide: BorderSide(color: Colors.red)),
                                        labelText: Strings.weightText,
                                        hintText: Strings.weightText,
                                        hintStyle: TextStyle(color: Colors.grey,fontFamily: 'Lato'),
                                      ),
                                      validator: (value) {
                                        if (value?.isEmpty ?? true) {
                                          return 'Please Enter Width';
                                        }
                                        return null;
                                      },
                                    ),
                                  ),
                                  Container(
                                    width: double.infinity,
                                    color: Strings.colorGrey,
                                    margin: const EdgeInsets.symmetric(
                                        horizontal: 10.0, vertical: 16.0),
                                    child: TextFormField(
                                      keyboardType: TextInputType.number,
                                      textInputAction: TextInputAction.done,
                                      style: const TextStyle(color: Colors.white,fontFamily: 'Lato'),
                                      cursorColor: Colors.white,
                                      decoration: const InputDecoration(
                                        filled: true,
                                        labelStyle: TextStyle(color: Colors.red),
                                        focusedBorder: OutlineInputBorder(
                                            borderSide: BorderSide(color: Colors.red),
                                            borderRadius:
                                            BorderRadius.all(Radius.circular(5.0))),
                                        border: OutlineInputBorder(
                                            borderSide: BorderSide(color: Colors.red)),
                                        labelText: Strings.heightText,
                                        hintText: Strings.heightText,
                                        hintStyle: TextStyle(color: Colors.grey,fontFamily: 'Lato'),
                                      ),
                                      validator: (value) {
                                        if (value?.isEmpty ?? true) {
                                          return 'Please Enter Height';
                                        }
                                        return null;
                                      },
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Container(
                      padding: EdgeInsets.symmetric(vertical: 14.0, horizontal: 30.0),
                      width: double.infinity,
                      color: Strings.colorPrimaryGrey,
                      height: 90.h,
                      child: CustomButton(
                        bgColor: Strings.colorRed,
                        title: Strings.nextText,
                        onTap: () {
                          if (_formKey.currentState!.validate()) {
                            Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) =>
                                    const CreateProfileScreen3()));
                          }
                        },
                      )),
                ],
              ),
            )
        )

    );
  }
}

