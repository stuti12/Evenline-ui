import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../constants/colors.dart';
import '../constants/helper.dart';
import '../constants/strings.dart';
import '../custom/custom_button.dart';
import '../tabbarpage/tab_bar.dart';

void main() {
  runApp(const CreateProfileScreen3());
}


enum BestTutorSite { getStrong, build, power, recomposition }

enum years { lessthamone, onethree, threefive, fiveplus }


class CreateProfileScreen3 extends StatefulWidget {
  const CreateProfileScreen3({Key? key}) : super(key: key);

  @override
  State<CreateProfileScreen3> createState() => _CreateProfileScreen3State();
}

class _CreateProfileScreen3State extends State<CreateProfileScreen3> {
  static final _formKey = GlobalKey<FormState>();
  BestTutorSite _site = BestTutorSite.getStrong;
  years _value = years.lessthamone;

  @override
  Widget build(BuildContext context) {
    BestTutorSite _site = BestTutorSite.getStrong;
    years _value = years.lessthamone;

    return GestureDetector(
        onTap: () {
          FocusScope.of(context).requestFocus(FocusNode());
        },
        child: MaterialApp(
            debugShowCheckedModeBanner: false,
            home: Scaffold(backgroundColor: AppColors.blackColor,
                appBar: AppBar(
                  backgroundColor: AppColors.blackColor,
                  title: const Text(Strings.createProfileText,
                      style: TextStyle(color: Colors.white)),
                  leading: IconButton(
                    icon: const Icon(Icons.arrow_back),
                    onPressed: () {
                      Navigator.of(context, rootNavigator: false).pop(context);
                    },
                  ),
                  centerTitle: true,
                ),
                body: SingleChildScrollView(
                  child: Column(
                    children: [
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 16.0),
                        child: ScreenStepper3(),
                      ),
                      ClipRRect(
                        borderRadius: const BorderRadius.only(
                            topRight: Radius.circular(30), topLeft: Radius.circular(30)),
                        child: Container(
                          color: AppColors.colorPrimaryGrey,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Form(
                                key: _formKey,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    const Padding(
                                      padding: EdgeInsets.only(
                                          left: 15.0, right: 15.0, top: 20.0),
                                      child: Text(Strings.selectYourGoalText,
                                          style: TextStyle(
                                              fontFamily: 'Lato',
                                              fontSize: 18,
                                              color: Colors.white)),
                                    ),
                                    RadioListTile<BestTutorSite>(
                                      activeColor: Colors.grey,
                                      title: const Text(
                                        'Get Stronger',
                                        style: TextStyle(
                                            color: Colors.white, fontFamily: 'Lato'),
                                      ),
                                      value: BestTutorSite.power,
                                      groupValue: _site,
                                      onChanged: (BestTutorSite? value) {
                                        setState(() {
                                          _site = value!;
                                        });
                                      },
                                    ),
                                    RadioListTile<BestTutorSite>(
                                      activeColor: Colors.grey,
                                      title: const Text(
                                        Strings.buildText,
                                        style: TextStyle(
                                            color: Colors.white, fontFamily: 'Lato'),
                                      ),
                                      value: BestTutorSite.build,
                                      groupValue: _site,
                                      onChanged: (BestTutorSite? value) {
                                        setState(() {
                                          _site = value!;
                                        });
                                      },
                                    ),
                                    RadioListTile<BestTutorSite>(
                                      activeColor: Colors.grey,
                                      title: const Text(
                                        Strings.powerBuildingText,
                                        style: TextStyle(
                                            color: Colors.white, fontFamily: 'Lato'),
                                      ),
                                      value: BestTutorSite.recomposition,
                                      groupValue: _site,
                                      onChanged: (BestTutorSite? value) {
                                        setState(() {
                                          _site = value!;
                                        });
                                      },
                                    ),
                                    const Padding(
                                        padding: EdgeInsets.only(
                                            left: 15.0, right: 15.0, top: 20.0),
                                        child: Text(Strings.trainingExperienceText,
                                            style: TextStyle(
                                                fontFamily: 'Lato',
                                                fontSize: 18,
                                                color: Colors.white))),
                                    RadioListTile<years>(
                                      activeColor: Colors.grey,
                                      title: const Text(
                                        Strings.lessThan1Text,
                                        style: TextStyle(
                                            color: Colors.white, fontFamily: 'Lato'),
                                      ),
                                      value: years.lessthamone,
                                      groupValue: _value,
                                      onChanged: (years? value) {
                                        setState(() {
                                          _value = value!;
                                        });
                                      },
                                    ),
                                    RadioListTile<years>(
                                      activeColor: Colors.grey,
                                      title: const Text(
                                        Strings.oneTwoYearsText,
                                        style: TextStyle(
                                            color: Colors.white, fontFamily: 'Lato'),
                                      ),
                                      value: years.onethree,
                                      groupValue: _value,
                                      onChanged: (years? value) {
                                        setState(() {
                                          _value = value!;
                                        });
                                      },
                                    ),
                                    RadioListTile<years>(
                                      activeColor: Colors.grey,
                                      title: const Text(
                                        Strings.threefiveText,
                                        style: TextStyle(
                                            color: Colors.white, fontFamily: 'Lato'),
                                      ),
                                      value: years.threefive,
                                      groupValue: _value,
                                      onChanged: (years? value) {
                                        setState(() {
                                          _value = value!;
                                        });
                                      },
                                    ),
                                    RadioListTile<years>(
                                      activeColor: Colors.grey,
                                      title: const Text(
                                        Strings.threefiveText,
                                        style: TextStyle(
                                            color: Colors.white, fontFamily: 'Lato'),
                                      ),
                                      value: years.fiveplus,
                                      groupValue: _value,
                                      onChanged: (years? value) {
                                        setState(() {
                                          _value = value!;
                                        });
                                      },
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      Container(
                          padding:
                          const EdgeInsets.symmetric(vertical: 14.0, horizontal: 30.0),
                          width: double.infinity,
                          color: AppColors.colorPrimaryGrey,
                          height: 90.h,
                          child: CustomButton(
                            bgColor: Strings.colorRed,
                            title: Strings.submitText,
                            onTap: () {
                              Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) => const TabbarPage()));
                            },
                          )),
                    ],
                  ),
                )
            )
        ));
  }
}



