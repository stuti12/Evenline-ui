import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:intl/intl.dart';
import 'package:strengthstudio/constants/colors.dart';
import 'package:toggle_switch/toggle_switch.dart';

import '../constants/helper.dart';
import '../constants/strings.dart';
import '../custom/custom_button.dart';
import '../custom/text_style.dart';
import 'create_profile_screen2.dart';

void main() {
  runApp(const CreateProfileScreen());
}

class CreateProfileScreen extends StatefulWidget {
  const CreateProfileScreen({super.key});

  @override
  State<CreateProfileScreen> createState() => _CreateProfileScreenState();
}

class _CreateProfileScreenState extends State<CreateProfileScreen> {
  static final _formKey = GlobalKey<FormState>();
  final TextEditingController _fname = TextEditingController();

  final TextEditingController _lname = TextEditingController();

  final TextEditingController _uname = TextEditingController();
  TextEditingController dateinput = TextEditingController();

  bool next = true;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        FocusScope.of(context).requestFocus(FocusNode());
      },
      child: Scaffold(
        backgroundColor: AppColors.blackColor,
        appBar: AppBar(
          backgroundColor: AppColors.blackColor,
          title: const Text(Strings.createProfileText,
              style: TextStyle(color: Colors.white)),
          leading: IconButton(
            icon: const Icon(Icons.arrow_back),
            onPressed: () {
              Navigator.of(context, rootNavigator: false).pop(context);
            },
          ),
          centerTitle: true,
        ),
        body: SingleChildScrollView(
          child: Column(
            children: [
              Container(
                  width: ScreenUtil().screenWidth,
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 5.0),
                    child: ScreenStepper(),
                  )),
              ClipRRect(
                borderRadius: const BorderRadius.only(
                    topRight: Radius.circular(30), topLeft: Radius.circular(30)),
                child: Container(
                  color: AppColors.colorPrimaryGrey,
                  child: Column(
                    mainAxisSize: MainAxisSize.max,
                    children: <Widget>[
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Padding(
                              padding: EdgeInsets.only(
                                  left: 35.0, right: 15.0, top: 20.0),
                              child: CircleAvatar(
                                  backgroundColor: AppColors.colorGrey,
                                  child: Icon(
                                    Icons.camera_alt_outlined,
                                    color: Colors.white,
                                    size: 24,
                                  ))),
                          Form(
                            key: _formKey,
                            child: Padding(
                              padding: EdgeInsets.only(
                                  top: 20.h, left: 30.w, right: 30.w, bottom: 10.h),
                              child: Column(
                                children: [
                                  Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      //fname Field
                                      Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceEvenly,
                                        children: [
                                          Expanded(
                                            child: Container(
                                              color: AppColors.colorGrey,
                                              margin: const EdgeInsets.symmetric(
                                                  vertical: 16.0,horizontal: 10.0),
                                              child: TextFormField(
                                                controller: _fname,
                                                textInputAction: TextInputAction.next,
                                                style: const TextStyle(
                                                    color: Colors.white,fontFamily: 'Lato'),
                                                cursorColor: Colors.white,
                                                decoration: const InputDecoration(
                                                  filled: true,
                                                  labelStyle:
                                                      TextStyle(color: Colors.red),
                                                  focusedBorder: OutlineInputBorder(
                                                      borderSide: BorderSide(
                                                          color: Colors.red),
                                                      borderRadius: BorderRadius.all(
                                                          Radius.circular(5.0))),
                                                  border: OutlineInputBorder(
                                                      borderSide: BorderSide(
                                                          color: Colors.red)),
                                                  labelText: Strings.firstNameText,
                                                  hintText: Strings.firstNameText,
                                                  hintStyle:
                                                      TextStyle(color: Colors.grey,fontFamily: 'Lato'),
                                                ),
                                                validator: (value) {
                                                  if (value?.isEmpty ?? true) {
                                                    return 'Please Enter FirstName';
                                                  }
                                                  return null;
                                                },
                                              ),
                                            ),
                                          ),
                                          Expanded(child: Container(
                                            color: AppColors.colorGrey,
                                            margin: const EdgeInsets.symmetric(
                                                vertical: 16.0,horizontal: 10.0),
                                            child: TextFormField(
                                              controller: _lname,
                                              keyboardType: TextInputType.name,
                                              textInputAction: TextInputAction.next,
                                              style: const TextStyle(fontFamily: 'Lato',
                                                  color: Colors.white),
                                              cursorColor: Colors.white,
                                              decoration: const InputDecoration(
                                                filled: true,
                                                labelStyle:
                                                TextStyle(color: Colors.red),
                                                focusedBorder: OutlineInputBorder(
                                                    borderSide: BorderSide(
                                                        color: Colors.red),
                                                    borderRadius: BorderRadius.all(
                                                        Radius.circular(5.0))),
                                                border: OutlineInputBorder(
                                                    borderSide: BorderSide(
                                                        color: Colors.red)),
                                                labelText: Strings.lastNameText,
                                                hintText: Strings.lastNameText,
                                                hintStyle:
                                                TextStyle(color: Colors.grey,fontFamily: 'Lato'),
                                              ),
                                              validator: (value) {
                                                if (value?.isEmpty ?? true) {
                                                  return 'Please Enter LastName';
                                                }
                                                return null;
                                              },
                                            ),
                                          ),)

                                        ],
                                      ),
                                      //lname

                                      //username
                                      Container(
                                        width: ScreenUtil().screenWidth,
                                        color: AppColors.colorGrey,
                                        margin: const EdgeInsets.symmetric(
                                            horizontal: 10.0, vertical: 16.0),
                                        child: TextFormField(
                                          controller: _uname,
                                          keyboardType: TextInputType.name,
                                          textInputAction: TextInputAction.next,
                                          style: const TextStyle(color: Colors.white,fontFamily: 'Lato'),
                                          cursorColor: Colors.white,
                                          decoration: const InputDecoration(
                                            filled: true,
                                            labelStyle:
                                                TextStyle(color: Colors.red),
                                            focusedBorder: OutlineInputBorder(
                                                borderSide:
                                                    BorderSide(color: Colors.red),
                                                borderRadius: BorderRadius.all(
                                                    Radius.circular(5.0))),
                                            border: OutlineInputBorder(
                                                borderSide:
                                                    BorderSide(color: Colors.red)),
                                            labelText: Strings.userNameText,
                                            hintText: Strings.userNameText,
                                            hintStyle:
                                                TextStyle(color: Colors.grey,fontFamily: 'Lato'),
                                          ),
                                          validator: (value) {
                                            if (value?.isEmpty ?? true) {
                                              return 'Please Enter Username';
                                            }
                                            return null;
                                          },
                                        ),
                                      ),

                                      SizedBox(height: 10.h),
                                      Container(
                                          width: ScreenUtil().screenWidth,
                                          child: Row(
                                            children: [
                                              RichText(
                                                text: TextSpan(
                                                  text: Strings.genderText,
                                                  style:
                                                      UITextStyle.regularTextStyle(
                                                          color: Colors.white,
                                                          fontSize: 18),
                                                ),
                                              ),
                                              Expanded(
                                                child: Align(
                                                  alignment: Alignment.topRight,
                                                  child: ToggleSwitch(
                                                    minWidth: 100.0,
                                                    minHeight: 50.0,
                                                    fontSize: 16.0,
                                                    initialLabelIndex: 1,
                                                    activeBgColor: const [
                                                      AppColors.colorRed
                                                    ],
                                                    activeFgColor: Colors.white,
                                                    inactiveBgColor:
                                                        AppColors.colorGrey,
                                                    inactiveFgColor: Colors.white,
                                                    totalSwitches: 2,
                                                    labels: const [
                                                      'Male',
                                                      'Female'
                                                    ],
                                                    onToggle: (index) {

                                                    },
                                                  ),
                                                ),
                                              ),
                                            ],
                                          )),
                                      SizedBox(height: 10.h),
                                      Container(
                                        width: ScreenUtil().screenWidth,
                                        color: AppColors.colorGrey,
                                        margin: const EdgeInsets.symmetric(
                                            horizontal: 10.0, vertical: 16.0),
                                        child: TextFormField(
                                          controller: dateinput,
                                          textInputAction: TextInputAction.done,
                                          onTap: () async {
                                            //show picker
                                            DateTime? pickedDate = await showDatePicker(
                                                context: context,
                                                initialDate: DateTime.now(),
                                                firstDate: DateTime(2000),
                                                //DateTime.now() - not to allow to choose before today.
                                                lastDate: DateTime(2101));

                                            if (pickedDate != null) {
                                              String formattedDate =
                                                  DateFormat('yyyy-MM-dd')
                                                      .format(pickedDate);
                                              setState(() {
                                                dateinput.text =
                                                    formattedDate; //set output date to TextField value.
                                              });
                                            } else {
                                              print("Date is not selected");
                                            }
                                          },
                                          style: const TextStyle(color: Colors.white,fontFamily: 'Lato'),
                                          cursorColor: Colors.white,
                                          decoration: const InputDecoration(
                                            filled: true,
                                            labelStyle:
                                                TextStyle(color: Colors.red),
                                            focusedBorder: OutlineInputBorder(
                                                borderSide:
                                                    BorderSide(color: Colors.red),
                                                borderRadius: BorderRadius.all(
                                                    Radius.circular(5.0))),
                                            border: OutlineInputBorder(
                                                borderSide:
                                                    BorderSide(color: Colors.red)),
                                            labelText: Strings.dateOfBirthText,
                                            hintText: Strings.dateOfBirthText,
                                            hintStyle:
                                                TextStyle(color: Colors.grey,fontFamily: 'Lato'),
                                          ),
                                          validator: (value) {
                                            if (value?.isEmpty ?? true) {
                                              return 'Please Enter Date of Birth';
                                            }

                                            return null;
                                          },
                                        ),
                                      ),
                                      SizedBox(height: 10.h),
                                      Container(
                                        width: ScreenUtil().screenWidth,
                                        child: Row(
                                          children: [
                                            RichText(
                                              text: TextSpan(
                                                text: Strings.unitPreferenceText,
                                                style: UITextStyle.regularTextStyle(
                                                    color: Colors.white,
                                                    fontSize: 18),
                                              ),
                                            ),
                                            Expanded(
                                              child: Align(
                                                alignment: Alignment.topRight,
                                                child: ToggleSwitch(
                                                  minWidth: 70.0,
                                                  minHeight: 50.0,
                                                  fontSize: 16.0,
                                                  initialLabelIndex: 1,
                                                  activeBgColor: const [
                                                    AppColors.colorRed
                                                  ],
                                                  activeFgColor: Colors.white,
                                                  inactiveBgColor:
                                                      AppColors.colorGrey,
                                                  inactiveFgColor: Colors.white,
                                                  totalSwitches: 2,
                                                  labels: const [
                                                    Strings.metricText,
                                                    Strings.imperialText
                                                  ],
                                                  onToggle: (index) {
                                                  },
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      //button
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
              Container(
                  padding:
                      const EdgeInsets.symmetric(vertical: 14.0, horizontal: 30.0),
                  width: ScreenUtil().screenWidth,
                  color: AppColors.colorPrimaryGrey,
                  height: 90.h,
                  child: CustomButton(
                    bgColor: AppColors.colorRed,
                    height: 55.h,
                    title: Strings.nextText,
                    onTap: () {
                      if (_formKey.currentState!.validate()) {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) =>
                                    const CreateProfileScreen2()));
                      }
                    },
                  )),
            ],
          ),
        ),
      ),
    );
  }
}

