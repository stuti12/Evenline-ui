import 'package:flutter/material.dart';

class CustomCommunitySearchDelegate extends SearchDelegate {
  List<String> searchItems = [
    "Jamal Browner’s 12 Week Intermediate Vol. 4",
    "Jamal Browner’s 12 Week Intermediate Vol. 4",
    "Jamal Browner’s 12 Week Intermediate Vol. 4",
    "Jamal Browner’s 12 Week Intermediate Vol. 4",
    "Jamal Browner’s 12 Week Intermediate Vol. 4",
    "Jamal Browner’s 12 Week Intermediate Vol. 4",
  ];

  @override
  List<Widget>? buildActions(BuildContext context) {
    return [
      IconButton(
        icon: Icon(Icons.clear),
        onPressed: () {
          query = '';
          close(context, null);
        },
      )
    ];
  }

  @override
  Widget? buildLeading(BuildContext context) {
    return IconButton(
      icon: Icon(Icons.arrow_back),
      onPressed: () {
        close(context, null);
      },
    );
  }

  @override
  Widget buildResults(BuildContext context) {
    List<String> matchQuery = [];
    for (var fruit in searchItems) {
      if (fruit.toLowerCase().contains(query.toLowerCase())) {
        matchQuery.add(fruit);
      }
    }
    return ListView.builder(
        itemCount: matchQuery.length,
        itemBuilder: (context, index) {
          var result = matchQuery[index];
          return ListTile(title: Text(result));
        });
  }

  @override
  Widget buildSuggestions(BuildContext context) {
    List<String> matchQuery = [];
    for (var fruit in searchItems) {
      if (fruit.toLowerCase().contains(query.toLowerCase())) {
        matchQuery.add(fruit);
      }
    }
    return ListView.builder(
        itemCount: matchQuery.length,
        itemBuilder: (context, index) {
          var result = matchQuery[index];
          return ListTile();
        });
  }
}
