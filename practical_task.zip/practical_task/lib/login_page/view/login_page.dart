import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:formz/formz.dart';
import 'package:practical_task/registration/view/registration_page.dart';
import 'package:practical_task/utils/ui_text_style.dart';

import '../../home_page/view/home_page.dart';
import '../../utils/app_colors.dart';
import '../../utils/string.dart';
import '../../utils/utils.dart';
import '../cubit/loginpage_cubit.dart';

class LoginPage extends StatelessWidget {
  const LoginPage({super.key});

  static Route<void> route() => MaterialPageRoute<void>(
        builder: (_) =>
            BlocProvider(create: (context) => LoginPageCubit(), child: const LoginPage()),
      );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: AppColor.pinkColor,
        title: const Text(
          ConstantString.appName,
          style: TextStyle(color: Colors.white),
        ),
      ),
      body: BlocProvider(
        create: (context) => LoginPageCubit(),
        child: BlocListener<LoginPageCubit, LoginPageState>(
          listenWhen: (previous, current) => current.status != previous.status,
          listener: (context, state) {
            if (state.status.isSuccess) {
              Navigator.pushAndRemoveUntil(
                context,
                HomePage.route(),
                    (route) => false,
              );
            } else if (state.status.isInProgress) {
              //   ProgressHUD.of(context)?.show();
            } else if (state.status.isFailure) {
              SnackBarUtils.showSnackBar(context, state.errorMessage);
            }
          },
          child: BlocBuilder<LoginPageCubit, LoginPageState>(
            builder: (context, state) {
              return Padding(
                padding: const EdgeInsets.all(10.0),
                child: Column(
                  children: [
                    const SizedBox(
                      height: 20,
                    ),
                    TextField(
                      onChanged: (value) => context.read<LoginPageCubit>().emailChanged(value),
                      keyboardType: TextInputType.emailAddress,
                      textInputAction: TextInputAction.next,
                      decoration:  InputDecoration(
                        border: const OutlineInputBorder(),
                        labelText: ConstantString.email,
                        hintText: ConstantString.email,
                        labelStyle: UITextStyle.regularTextStyle(fontSize: 14, color: AppColor.blackColor),
                      ),
                    ),
                    const SizedBox(
                      height: 20,
                    ),
                    TextField(
                      onChanged: (value) => context.read<LoginPageCubit>().passwordChange(value),
                      keyboardType: TextInputType.visiblePassword,
                      textInputAction: TextInputAction.done,
                      obscureText: state.passwordVisible,
                      decoration: InputDecoration(
                        border: const OutlineInputBorder(),
                        labelText: ConstantString.password,
                        hintText: ConstantString.password,
                        suffixIcon: IconButton(
                          icon: state.passwordVisible
                              ? const Icon(Icons.visibility_off)
                              : const Icon(Icons.visibility),
                          onPressed: () {
                            context.read<LoginPageCubit>().togglePasswordVisibility();
                          },
                        ),
                        labelStyle: UITextStyle.regularTextStyle(fontSize: 14, color: AppColor.blackColor),
                      ),
                    ),
                    const SizedBox(
                      height: 20,
                    ),
                    TextButton(onPressed: (){Navigator.push(context, RegistrationPage.route());}, child: Text(ConstantString.create,style: UITextStyle.regularTextStyle())),
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        onPressed: () async {
                          final loginPageCubit = context.read<LoginPageCubit>();
                          if (state.userEmail.isEmpty) {
                            SnackBarUtils.showSnackBar(context, ConstantString.emptyEmailError);
                          } else if (!loginPageCubit.checkEmail(state.userEmail)) {
                            SnackBarUtils.showSnackBar(context, ConstantString.invalidEmailError);
                          } else if (state.userPassword.isEmpty) {
                            SnackBarUtils.showSnackBar(context, ConstantString.emptyPasswordError);
                          } else if (!loginPageCubit.checkPassword(state.userPassword)) {
                            SnackBarUtils.showSnackBar(context,ConstantString.invalidPasswordError);
                          } else {
                            var isExist = await loginPageCubit.login(
                                email: state.userEmail, password: state.userPassword);
                            if (isExist == true) {
                              if (context.mounted) {
                                loginPageCubit.loginSuccess(userEmail:state.userEmail);
                              }
                            }else {
                              if(context.mounted){
                                Navigator.push(context, RegistrationPage.route());
                              }
                            }
                          }
                        },
                        child:  Text(
                          ConstantString.login,
                          style: UITextStyle.regularTextStyle(fontSize: 14),
                        ),
                      ),
                    )
                  ],
                ),
              );
            },
          ),
        ),
      ),
    );
  }
}
