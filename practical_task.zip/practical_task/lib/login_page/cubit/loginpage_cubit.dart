import 'package:bloc/bloc.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:formz/formz.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:practical_task/utils/string.dart';

import '../../utils/user_session.dart';

part 'loginpage_state.dart';

part 'loginpage_cubit.freezed.dart';

class LoginPageCubit extends Cubit<LoginPageState> {
  LoginPageCubit() : super(const LoginPageState());
  final FirebaseAuth _auth = FirebaseAuth.instance;

  final FirebaseFirestore fireStore = FirebaseFirestore.instance;

  Future<bool?> login({
    required String email,
    required String password,
  }) async {
    emit(
      state.copyWith(
        status: FormzSubmissionStatus.inProgress,
      ),
    );

    bool? accountFound;
    try {
      await _auth.signInWithEmailAndPassword(
        email: email,
        password: password,
      );
      accountFound = true;
    } on FirebaseAuthException catch (e) {
      switch (e.code) {

        case 'wrong-password':
          emit(
            state.copyWith(
              errorMessage: "Incorrect password, please try again.",
              status: FormzSubmissionStatus.failure,
            ),
          );
          break;
        default:
          emit(
            state.copyWith(
              errorMessage: e.message ?? ConstantString.somethingWentWrong,
              status: FormzSubmissionStatus.failure,
            ),
          );
          break;
      }
    } catch (e) {
      emit(
        state.copyWith(
          errorMessage: e.toString(),
          status: FormzSubmissionStatus.failure,
        ),
      );
    }

    return accountFound;
  }


  void loginSuccess({required String userEmail}) {
    UserSession.saveUserEmail(userEmail);
    emit(
      state.copyWith(
        status: FormzSubmissionStatus.success,
      ),
    );
  }


  void emailChanged(String value) {
    emit(state.copyWith(
      userEmail: value,
    ));
  }

  void passwordChange(String value) {
    emit(state.copyWith(
      userPassword: value,
    ));
  }


  bool checkEmail(String email) {
    final bool emailValid =
        RegExp(r"^[a-zA-Z0-9.a-zA-Z0-9.!#$%&'*+-/=?^_`{|}~]+@[a-zA-Z0-9]+\.[a-zA-Z]+")
            .hasMatch(email);
    return emailValid;
  }

  bool checkPassword(String password) {
    final bool passwordValid =
        RegExp(r"^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,}$")
            .hasMatch(password);
    return passwordValid;
  }

  void togglePasswordVisibility() {
    emit(state.copyWith(passwordVisible: !state.passwordVisible));
  }
}
