import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:practical_task/home_page/view/home_page.dart';

import '../../login_page/view/login_page.dart';
import '../../utils/user_session.dart';
import '../cubit/splash_page_cubit.dart';

class SplashPage extends StatelessWidget {
  const SplashPage({super.key});

  static Route<void> route() => MaterialPageRoute<void>(
    builder: (_) => BlocProvider(
      lazy: false,
      create: (context) => SplashPageCubit(),
      child: const SplashPage(),
    ),
  );

  @override
  Widget build(BuildContext context) {
    Future<void> checkEmailAndNavigate() async {
      final userEmail = await UserSession.getUserEmail();

      if (context.mounted) {
        if (userEmail == null) {
          Navigator.pushAndRemoveUntil(
            context,
            LoginPage.route(),
                (route) => false,
          );
        } else {
          Navigator.pushAndRemoveUntil(
            context,
            HomePage.route(),
                (route) => false,
          );
        }
      }
    }

    WidgetsBinding.instance.addPostFrameCallback((_) {
      checkEmailAndNavigate();
    });

    return const Scaffold(
      body: Center(
        child: Text(
          'Practical',
          style: TextStyle(
            color: Colors.black,
            fontSize: 20,
          ),
        ),
      ),
    );
  }
}