part of 'temp_page_cubit.dart';

@freezed
class TempPageState with _$TempPageState {
  const factory TempPageState({
    @Default('') String errorMessage,
    @Default([]) List<Result?> users,
    @Default(false) bool isLoadMore,
    @Default(1) int currentPage,
    @Default(FormzSubmissionStatus.initial) FormzSubmissionStatus status
}) = _TempPageState;
}
