import 'package:bloc/bloc.dart';
import 'package:dio/dio.dart';
import 'package:formz/formz.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

import '../model/user_info.dart';

part 'temp_page_state.dart';
part 'temp_page_cubit.freezed.dart';

class TempPageCubit extends Cubit<TempPageState> {
  TempPageCubit() : super(const TempPageState()){
    fetch();
  }
  int _currentPage = 1;

  Future<void> fetch()async{
    if (state.isLoadMore) return;
    if (_currentPage == 1) {
      emit(state.copyWith(status: FormzSubmissionStatus.inProgress));
    } else {
      emit(state.copyWith(isLoadMore: true));
    }
    try {
      Dio dio = Dio();
      final response = await dio.get('https://randomuser.me/api/',queryParameters: {'page':_currentPage,'results': 15});
      print('Response $response');
      final List<dynamic> usersData = await response.data['results'];
      print('Response2 ${usersData.length}');
      final List<Result?> users = usersData.map((userData) {
        try {
          return Result.fromJson(userData);
        } catch (e) {
          return null;
        }
      }).toList();

      print('Response3 ${users.length}');
      if (_currentPage == 1) {
        emit(state.copyWith(users: users, status: FormzSubmissionStatus.success));
      } else {
        emit(state.copyWith(users: [...state.users, ...users], isLoadMore: false));
      }
      _currentPage++;
    } catch (e) {
   //   emit(state.copyWith(errorMessage: e.toString(),status: FormzSubmissionStatus.failure));
      print('Response3 ${e.toString()}');

    }
  }
}
