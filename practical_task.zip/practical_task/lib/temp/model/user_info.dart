import 'package:freezed_annotation/freezed_annotation.dart';

part 'user_info.freezed.dart';
part 'user_info.g.dart';

@freezed
class UserInfo with _$UserInfo {
  const factory UserInfo({
    List<Result>? results,
    Info? info,
  }) = _UserInfo;

  factory UserInfo.fromJson(Map<String, dynamic> json) => _$UserInfoFromJson(json);
}

@freezed
class Info with _$Info {
  const factory Info({
    String? seed,
    int? results,
    int? page,
    String? version,
  }) = _Info;

  factory Info.fromJson(Map<String, dynamic> json) => _$InfoFromJson(json);
}

@freezed
class Result with _$Result {
  const factory Result({
    String? gender,
    Name? name,
    Location? location,
    String? email,
    Login? login,
    Dob? dob,
    Dob? registered,
    String? phone,
    String? cell,
    Id? id,
    Picture? picture,
    String? nat,
  }) = _Result;

  factory Result.fromJson(Map<String, dynamic> json) => _$ResultFromJson(json);
}

@freezed
class Dob with _$Dob {
  const factory Dob({
    DateTime? date,
    int? age,
  }) = _Dob;

  factory Dob.fromJson(Map<String, dynamic> json) => _$DobFromJson(json);
}

@freezed
class Id with _$Id {
  const factory Id({
    String? name,
    String? value,
  }) = _Id;

  factory Id.fromJson(Map<String, dynamic> json) => _$IdFromJson(json);
}

@freezed
class Location with _$Location {
  const factory Location({
    Street? street,
    String? city,
    String? state,
    String? country,
    int? postcode,
    Coordinates? coordinates,
    Timezone? timezone,
  }) = _Location;

  factory Location.fromJson(Map<String, dynamic> json) => _$LocationFromJson(json);
}

@freezed
class Coordinates with _$Coordinates {
  const factory Coordinates({
    String? latitude,
    String? longitude,
  }) = _Coordinates;

  factory Coordinates.fromJson(Map<String, dynamic> json) => _$CoordinatesFromJson(json);
}

@freezed
class Street with _$Street {
  const factory Street({
    int? number,
    String? name,
  }) = _Street;

  factory Street.fromJson(Map<String, dynamic> json) => _$StreetFromJson(json);
}

@freezed
class Timezone with _$Timezone {
  const factory Timezone({
    String? offset,
    String? description,
  }) = _Timezone;

  factory Timezone.fromJson(Map<String, dynamic> json) => _$TimezoneFromJson(json);
}

@freezed
class Login with _$Login {
  const factory Login({
    String? uuid,
    String? username,
    String? password,
    String? salt,
    String? md5,
    String? sha1,
    String? sha256,
  }) = _Login;

  factory Login.fromJson(Map<String, dynamic> json) => _$LoginFromJson(json);
}

@freezed
class Name with _$Name {
  const factory Name({
    String? title,
    String? first,
    String? last,
  }) = _Name;

  factory Name.fromJson(Map<String, dynamic> json) => _$NameFromJson(json);
}

@freezed
class Picture with _$Picture {
  const factory Picture({
    String? large,
    String? medium,
    String? thumbnail,
  }) = _Picture;

  factory Picture.fromJson(Map<String, dynamic> json) => _$PictureFromJson(json);
}
