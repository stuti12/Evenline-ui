import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:formz/formz.dart';
import 'package:practical_task/temp/cubit/temp_page_cubit.dart';

class TempPage extends StatefulWidget {
  const TempPage({super.key});

  static Route<void> route() => MaterialPageRoute<void>(
        builder: (_) => BlocProvider(
          create: (context) => TempPageCubit(),
          child: const TempPage(),
        ),
      );

  @override
  State<TempPage> createState() => _TempPageState();
}

class _TempPageState extends State<TempPage> {
  ScrollController scrollController = ScrollController();

  @override
  void initState() {
    scrollController.addListener(_scrollListener);
    super.initState();
  }
  _scrollListener() {
    if (scrollController.offset >= scrollController.position.maxScrollExtent &&
        !scrollController.position.outOfRange) {
      context.read<TempPageCubit>().fetch();
    }
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: BlocBuilder<TempPageCubit, TempPageState>(
        builder: (context, state) {

          if (state.status == FormzSubmissionStatus.success && state.users.isNotEmpty) {
            return ListView.builder(
              controller: scrollController,
              itemCount: state.users.length+1,
              itemBuilder: (context, index) {
                if (index < state.users.length) {
                  final user = state.users[index];
                  return ListTile(
                    leading:user?.picture?.medium!=null? Image.network(user?.picture?.medium ?? ''):Icon(Icons.person,size: 50,),
                    title: Text(user?.name?.first ?? 'Name'),
                    subtitle: Text(user?.email ?? 'Email'),
                  );
                } else if (state.isLoadMore) {
                  return const Center(
                    child: CircularProgressIndicator(),
                  );
                } else {
                  return const SizedBox.shrink();
                }
              },
            );
          }
           else if (state.status == FormzSubmissionStatus.inProgress && state.users.isEmpty) {
             return const Center(
               child: CircularProgressIndicator(),
             );
           }
           else {
            return const Center(
              child: Text("An error occurred."),
            );
          }
        },
      ),
    );
  }
}
