part of 'weather_page_cubit.dart';

@freezed
class WeatherPageState with _$WeatherPageState {
  const factory WeatherPageState({
    @Default("") String city,
    @Default(0.0) double temp,
    @Default(0.0) double feels,
    @Default(0.0) double wind,
    @Default(0) int humidity,
    @Default(0) int visibility,
    @Default(0) int sunset,
    @Default(0) int sunrise,
    @Default(0) int population,
    @Default(0) int precipitation,
    @Default(0.0) double longitude,
    @Default(0.0) double latitude,
    @Default(false) bool showMore,
    @Default("") String errorMessage,
    @Default([]) List<WeeklyWeatherList>? weeklyWeatherList,
    @Default([]) List<WeeklyWeatherList>? weeklyWeatherListFilter,
    @Default([]) List<WeatherList>? dailyWeathersList,
    @Default([]) List<List<WeeklyWeatherList>>? hourList,
    @Default([]) List<Weather>? weatherList,
    @Default(FormzSubmissionStatus.initial) FormzSubmissionStatus status,
  }) = _WeatherPageState;
}
