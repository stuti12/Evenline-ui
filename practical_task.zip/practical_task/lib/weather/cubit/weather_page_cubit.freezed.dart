// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'weather_page_cubit.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

/// @nodoc
mixin _$WeatherPageState {
  String get city => throw _privateConstructorUsedError;
  double get temp => throw _privateConstructorUsedError;
  double get feels => throw _privateConstructorUsedError;
  double get wind => throw _privateConstructorUsedError;
  int get humidity => throw _privateConstructorUsedError;
  int get visibility => throw _privateConstructorUsedError;
  int get sunset => throw _privateConstructorUsedError;
  int get sunrise => throw _privateConstructorUsedError;
  int get population => throw _privateConstructorUsedError;
  int get precipitation => throw _privateConstructorUsedError;
  double get longitude => throw _privateConstructorUsedError;
  double get latitude => throw _privateConstructorUsedError;
  bool get showMore => throw _privateConstructorUsedError;
  String get errorMessage => throw _privateConstructorUsedError;
  List<WeeklyWeatherList>? get weeklyWeatherList =>
      throw _privateConstructorUsedError;
  List<WeeklyWeatherList>? get weeklyWeatherListFilter =>
      throw _privateConstructorUsedError;
  List<WeatherList>? get dailyWeathersList =>
      throw _privateConstructorUsedError;
  List<List<WeeklyWeatherList>>? get hourList =>
      throw _privateConstructorUsedError;
  List<Weather>? get weatherList => throw _privateConstructorUsedError;
  FormzSubmissionStatus get status => throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $WeatherPageStateCopyWith<WeatherPageState> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $WeatherPageStateCopyWith<$Res> {
  factory $WeatherPageStateCopyWith(
          WeatherPageState value, $Res Function(WeatherPageState) then) =
      _$WeatherPageStateCopyWithImpl<$Res, WeatherPageState>;
  @useResult
  $Res call(
      {String city,
      double temp,
      double feels,
      double wind,
      int humidity,
      int visibility,
      int sunset,
      int sunrise,
      int population,
      int precipitation,
      double longitude,
      double latitude,
      bool showMore,
      String errorMessage,
      List<WeeklyWeatherList>? weeklyWeatherList,
      List<WeeklyWeatherList>? weeklyWeatherListFilter,
      List<WeatherList>? dailyWeathersList,
      List<List<WeeklyWeatherList>>? hourList,
      List<Weather>? weatherList,
      FormzSubmissionStatus status});
}

/// @nodoc
class _$WeatherPageStateCopyWithImpl<$Res, $Val extends WeatherPageState>
    implements $WeatherPageStateCopyWith<$Res> {
  _$WeatherPageStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? city = null,
    Object? temp = null,
    Object? feels = null,
    Object? wind = null,
    Object? humidity = null,
    Object? visibility = null,
    Object? sunset = null,
    Object? sunrise = null,
    Object? population = null,
    Object? precipitation = null,
    Object? longitude = null,
    Object? latitude = null,
    Object? showMore = null,
    Object? errorMessage = null,
    Object? weeklyWeatherList = freezed,
    Object? weeklyWeatherListFilter = freezed,
    Object? dailyWeathersList = freezed,
    Object? hourList = freezed,
    Object? weatherList = freezed,
    Object? status = null,
  }) {
    return _then(_value.copyWith(
      city: null == city
          ? _value.city
          : city // ignore: cast_nullable_to_non_nullable
              as String,
      temp: null == temp
          ? _value.temp
          : temp // ignore: cast_nullable_to_non_nullable
              as double,
      feels: null == feels
          ? _value.feels
          : feels // ignore: cast_nullable_to_non_nullable
              as double,
      wind: null == wind
          ? _value.wind
          : wind // ignore: cast_nullable_to_non_nullable
              as double,
      humidity: null == humidity
          ? _value.humidity
          : humidity // ignore: cast_nullable_to_non_nullable
              as int,
      visibility: null == visibility
          ? _value.visibility
          : visibility // ignore: cast_nullable_to_non_nullable
              as int,
      sunset: null == sunset
          ? _value.sunset
          : sunset // ignore: cast_nullable_to_non_nullable
              as int,
      sunrise: null == sunrise
          ? _value.sunrise
          : sunrise // ignore: cast_nullable_to_non_nullable
              as int,
      population: null == population
          ? _value.population
          : population // ignore: cast_nullable_to_non_nullable
              as int,
      precipitation: null == precipitation
          ? _value.precipitation
          : precipitation // ignore: cast_nullable_to_non_nullable
              as int,
      longitude: null == longitude
          ? _value.longitude
          : longitude // ignore: cast_nullable_to_non_nullable
              as double,
      latitude: null == latitude
          ? _value.latitude
          : latitude // ignore: cast_nullable_to_non_nullable
              as double,
      showMore: null == showMore
          ? _value.showMore
          : showMore // ignore: cast_nullable_to_non_nullable
              as bool,
      errorMessage: null == errorMessage
          ? _value.errorMessage
          : errorMessage // ignore: cast_nullable_to_non_nullable
              as String,
      weeklyWeatherList: freezed == weeklyWeatherList
          ? _value.weeklyWeatherList
          : weeklyWeatherList // ignore: cast_nullable_to_non_nullable
              as List<WeeklyWeatherList>?,
      weeklyWeatherListFilter: freezed == weeklyWeatherListFilter
          ? _value.weeklyWeatherListFilter
          : weeklyWeatherListFilter // ignore: cast_nullable_to_non_nullable
              as List<WeeklyWeatherList>?,
      dailyWeathersList: freezed == dailyWeathersList
          ? _value.dailyWeathersList
          : dailyWeathersList // ignore: cast_nullable_to_non_nullable
              as List<WeatherList>?,
      hourList: freezed == hourList
          ? _value.hourList
          : hourList // ignore: cast_nullable_to_non_nullable
              as List<List<WeeklyWeatherList>>?,
      weatherList: freezed == weatherList
          ? _value.weatherList
          : weatherList // ignore: cast_nullable_to_non_nullable
              as List<Weather>?,
      status: null == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as FormzSubmissionStatus,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$_WeatherPageStateCopyWith<$Res>
    implements $WeatherPageStateCopyWith<$Res> {
  factory _$$_WeatherPageStateCopyWith(
          _$_WeatherPageState value, $Res Function(_$_WeatherPageState) then) =
      __$$_WeatherPageStateCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String city,
      double temp,
      double feels,
      double wind,
      int humidity,
      int visibility,
      int sunset,
      int sunrise,
      int population,
      int precipitation,
      double longitude,
      double latitude,
      bool showMore,
      String errorMessage,
      List<WeeklyWeatherList>? weeklyWeatherList,
      List<WeeklyWeatherList>? weeklyWeatherListFilter,
      List<WeatherList>? dailyWeathersList,
      List<List<WeeklyWeatherList>>? hourList,
      List<Weather>? weatherList,
      FormzSubmissionStatus status});
}

/// @nodoc
class __$$_WeatherPageStateCopyWithImpl<$Res>
    extends _$WeatherPageStateCopyWithImpl<$Res, _$_WeatherPageState>
    implements _$$_WeatherPageStateCopyWith<$Res> {
  __$$_WeatherPageStateCopyWithImpl(
      _$_WeatherPageState _value, $Res Function(_$_WeatherPageState) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? city = null,
    Object? temp = null,
    Object? feels = null,
    Object? wind = null,
    Object? humidity = null,
    Object? visibility = null,
    Object? sunset = null,
    Object? sunrise = null,
    Object? population = null,
    Object? precipitation = null,
    Object? longitude = null,
    Object? latitude = null,
    Object? showMore = null,
    Object? errorMessage = null,
    Object? weeklyWeatherList = freezed,
    Object? weeklyWeatherListFilter = freezed,
    Object? dailyWeathersList = freezed,
    Object? hourList = freezed,
    Object? weatherList = freezed,
    Object? status = null,
  }) {
    return _then(_$_WeatherPageState(
      city: null == city
          ? _value.city
          : city // ignore: cast_nullable_to_non_nullable
              as String,
      temp: null == temp
          ? _value.temp
          : temp // ignore: cast_nullable_to_non_nullable
              as double,
      feels: null == feels
          ? _value.feels
          : feels // ignore: cast_nullable_to_non_nullable
              as double,
      wind: null == wind
          ? _value.wind
          : wind // ignore: cast_nullable_to_non_nullable
              as double,
      humidity: null == humidity
          ? _value.humidity
          : humidity // ignore: cast_nullable_to_non_nullable
              as int,
      visibility: null == visibility
          ? _value.visibility
          : visibility // ignore: cast_nullable_to_non_nullable
              as int,
      sunset: null == sunset
          ? _value.sunset
          : sunset // ignore: cast_nullable_to_non_nullable
              as int,
      sunrise: null == sunrise
          ? _value.sunrise
          : sunrise // ignore: cast_nullable_to_non_nullable
              as int,
      population: null == population
          ? _value.population
          : population // ignore: cast_nullable_to_non_nullable
              as int,
      precipitation: null == precipitation
          ? _value.precipitation
          : precipitation // ignore: cast_nullable_to_non_nullable
              as int,
      longitude: null == longitude
          ? _value.longitude
          : longitude // ignore: cast_nullable_to_non_nullable
              as double,
      latitude: null == latitude
          ? _value.latitude
          : latitude // ignore: cast_nullable_to_non_nullable
              as double,
      showMore: null == showMore
          ? _value.showMore
          : showMore // ignore: cast_nullable_to_non_nullable
              as bool,
      errorMessage: null == errorMessage
          ? _value.errorMessage
          : errorMessage // ignore: cast_nullable_to_non_nullable
              as String,
      weeklyWeatherList: freezed == weeklyWeatherList
          ? _value._weeklyWeatherList
          : weeklyWeatherList // ignore: cast_nullable_to_non_nullable
              as List<WeeklyWeatherList>?,
      weeklyWeatherListFilter: freezed == weeklyWeatherListFilter
          ? _value._weeklyWeatherListFilter
          : weeklyWeatherListFilter // ignore: cast_nullable_to_non_nullable
              as List<WeeklyWeatherList>?,
      dailyWeathersList: freezed == dailyWeathersList
          ? _value._dailyWeathersList
          : dailyWeathersList // ignore: cast_nullable_to_non_nullable
              as List<WeatherList>?,
      hourList: freezed == hourList
          ? _value._hourList
          : hourList // ignore: cast_nullable_to_non_nullable
              as List<List<WeeklyWeatherList>>?,
      weatherList: freezed == weatherList
          ? _value._weatherList
          : weatherList // ignore: cast_nullable_to_non_nullable
              as List<Weather>?,
      status: null == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as FormzSubmissionStatus,
    ));
  }
}

/// @nodoc

class _$_WeatherPageState implements _WeatherPageState {
  const _$_WeatherPageState(
      {this.city = "",
      this.temp = 0.0,
      this.feels = 0.0,
      this.wind = 0.0,
      this.humidity = 0,
      this.visibility = 0,
      this.sunset = 0,
      this.sunrise = 0,
      this.population = 0,
      this.precipitation = 0,
      this.longitude = 0.0,
      this.latitude = 0.0,
      this.showMore = false,
      this.errorMessage = "",
      final List<WeeklyWeatherList>? weeklyWeatherList = const [],
      final List<WeeklyWeatherList>? weeklyWeatherListFilter = const [],
      final List<WeatherList>? dailyWeathersList = const [],
      final List<List<WeeklyWeatherList>>? hourList = const [],
      final List<Weather>? weatherList = const [],
      this.status = FormzSubmissionStatus.initial})
      : _weeklyWeatherList = weeklyWeatherList,
        _weeklyWeatherListFilter = weeklyWeatherListFilter,
        _dailyWeathersList = dailyWeathersList,
        _hourList = hourList,
        _weatherList = weatherList;

  @override
  @JsonKey()
  final String city;
  @override
  @JsonKey()
  final double temp;
  @override
  @JsonKey()
  final double feels;
  @override
  @JsonKey()
  final double wind;
  @override
  @JsonKey()
  final int humidity;
  @override
  @JsonKey()
  final int visibility;
  @override
  @JsonKey()
  final int sunset;
  @override
  @JsonKey()
  final int sunrise;
  @override
  @JsonKey()
  final int population;
  @override
  @JsonKey()
  final int precipitation;
  @override
  @JsonKey()
  final double longitude;
  @override
  @JsonKey()
  final double latitude;
  @override
  @JsonKey()
  final bool showMore;
  @override
  @JsonKey()
  final String errorMessage;
  final List<WeeklyWeatherList>? _weeklyWeatherList;
  @override
  @JsonKey()
  List<WeeklyWeatherList>? get weeklyWeatherList {
    final value = _weeklyWeatherList;
    if (value == null) return null;
    if (_weeklyWeatherList is EqualUnmodifiableListView)
      return _weeklyWeatherList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  final List<WeeklyWeatherList>? _weeklyWeatherListFilter;
  @override
  @JsonKey()
  List<WeeklyWeatherList>? get weeklyWeatherListFilter {
    final value = _weeklyWeatherListFilter;
    if (value == null) return null;
    if (_weeklyWeatherListFilter is EqualUnmodifiableListView)
      return _weeklyWeatherListFilter;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  final List<WeatherList>? _dailyWeathersList;
  @override
  @JsonKey()
  List<WeatherList>? get dailyWeathersList {
    final value = _dailyWeathersList;
    if (value == null) return null;
    if (_dailyWeathersList is EqualUnmodifiableListView)
      return _dailyWeathersList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  final List<List<WeeklyWeatherList>>? _hourList;
  @override
  @JsonKey()
  List<List<WeeklyWeatherList>>? get hourList {
    final value = _hourList;
    if (value == null) return null;
    if (_hourList is EqualUnmodifiableListView) return _hourList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  final List<Weather>? _weatherList;
  @override
  @JsonKey()
  List<Weather>? get weatherList {
    final value = _weatherList;
    if (value == null) return null;
    if (_weatherList is EqualUnmodifiableListView) return _weatherList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  @override
  @JsonKey()
  final FormzSubmissionStatus status;

  @override
  String toString() {
    return 'WeatherPageState(city: $city, temp: $temp, feels: $feels, wind: $wind, humidity: $humidity, visibility: $visibility, sunset: $sunset, sunrise: $sunrise, population: $population, precipitation: $precipitation, longitude: $longitude, latitude: $latitude, showMore: $showMore, errorMessage: $errorMessage, weeklyWeatherList: $weeklyWeatherList, weeklyWeatherListFilter: $weeklyWeatherListFilter, dailyWeathersList: $dailyWeathersList, hourList: $hourList, weatherList: $weatherList, status: $status)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_WeatherPageState &&
            (identical(other.city, city) || other.city == city) &&
            (identical(other.temp, temp) || other.temp == temp) &&
            (identical(other.feels, feels) || other.feels == feels) &&
            (identical(other.wind, wind) || other.wind == wind) &&
            (identical(other.humidity, humidity) ||
                other.humidity == humidity) &&
            (identical(other.visibility, visibility) ||
                other.visibility == visibility) &&
            (identical(other.sunset, sunset) || other.sunset == sunset) &&
            (identical(other.sunrise, sunrise) || other.sunrise == sunrise) &&
            (identical(other.population, population) ||
                other.population == population) &&
            (identical(other.precipitation, precipitation) ||
                other.precipitation == precipitation) &&
            (identical(other.longitude, longitude) ||
                other.longitude == longitude) &&
            (identical(other.latitude, latitude) ||
                other.latitude == latitude) &&
            (identical(other.showMore, showMore) ||
                other.showMore == showMore) &&
            (identical(other.errorMessage, errorMessage) ||
                other.errorMessage == errorMessage) &&
            const DeepCollectionEquality()
                .equals(other._weeklyWeatherList, _weeklyWeatherList) &&
            const DeepCollectionEquality().equals(
                other._weeklyWeatherListFilter, _weeklyWeatherListFilter) &&
            const DeepCollectionEquality()
                .equals(other._dailyWeathersList, _dailyWeathersList) &&
            const DeepCollectionEquality().equals(other._hourList, _hourList) &&
            const DeepCollectionEquality()
                .equals(other._weatherList, _weatherList) &&
            (identical(other.status, status) || other.status == status));
  }

  @override
  int get hashCode => Object.hashAll([
        runtimeType,
        city,
        temp,
        feels,
        wind,
        humidity,
        visibility,
        sunset,
        sunrise,
        population,
        precipitation,
        longitude,
        latitude,
        showMore,
        errorMessage,
        const DeepCollectionEquality().hash(_weeklyWeatherList),
        const DeepCollectionEquality().hash(_weeklyWeatherListFilter),
        const DeepCollectionEquality().hash(_dailyWeathersList),
        const DeepCollectionEquality().hash(_hourList),
        const DeepCollectionEquality().hash(_weatherList),
        status
      ]);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_WeatherPageStateCopyWith<_$_WeatherPageState> get copyWith =>
      __$$_WeatherPageStateCopyWithImpl<_$_WeatherPageState>(this, _$identity);
}

abstract class _WeatherPageState implements WeatherPageState {
  const factory _WeatherPageState(
      {final String city,
      final double temp,
      final double feels,
      final double wind,
      final int humidity,
      final int visibility,
      final int sunset,
      final int sunrise,
      final int population,
      final int precipitation,
      final double longitude,
      final double latitude,
      final bool showMore,
      final String errorMessage,
      final List<WeeklyWeatherList>? weeklyWeatherList,
      final List<WeeklyWeatherList>? weeklyWeatherListFilter,
      final List<WeatherList>? dailyWeathersList,
      final List<List<WeeklyWeatherList>>? hourList,
      final List<Weather>? weatherList,
      final FormzSubmissionStatus status}) = _$_WeatherPageState;

  @override
  String get city;
  @override
  double get temp;
  @override
  double get feels;
  @override
  double get wind;
  @override
  int get humidity;
  @override
  int get visibility;
  @override
  int get sunset;
  @override
  int get sunrise;
  @override
  int get population;
  @override
  int get precipitation;
  @override
  double get longitude;
  @override
  double get latitude;
  @override
  bool get showMore;
  @override
  String get errorMessage;
  @override
  List<WeeklyWeatherList>? get weeklyWeatherList;
  @override
  List<WeeklyWeatherList>? get weeklyWeatherListFilter;
  @override
  List<WeatherList>? get dailyWeathersList;
  @override
  List<List<WeeklyWeatherList>>? get hourList;
  @override
  List<Weather>? get weatherList;
  @override
  FormzSubmissionStatus get status;
  @override
  @JsonKey(ignore: true)
  _$$_WeatherPageStateCopyWith<_$_WeatherPageState> get copyWith =>
      throw _privateConstructorUsedError;
}
