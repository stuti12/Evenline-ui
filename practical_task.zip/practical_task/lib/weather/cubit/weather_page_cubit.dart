import 'dart:convert';

import 'package:bloc/bloc.dart';
import 'package:flutter/cupertino.dart';
import 'package:formz/formz.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:geocoding/geocoding.dart';
import 'package:geolocator/geolocator.dart';
import 'package:practical_task/utils/string.dart';
import 'package:practical_task/weather/api.dart';

import '../../models/current_weather_model.dart';
import '../../models/daily_weather.dart';
import '../../models/weekly_weather.dart';
import '../../utils/permission.dart';

part 'weather_page_state.dart';

part 'weather_page_cubit.freezed.dart';

class WeatherPageCubit extends Cubit<WeatherPageState> {
  WeatherPageCubit() : super(const WeatherPageState()) {

    apiCall();
  }
  BaseService service = BaseService();
  GetUserLocation globalController = GetUserLocation();

  toggleShow(){
    emit(state.copyWith(showMore: !state.showMore));
  }

  Future _getLocation() async {
    await globalController.getLocationPermission();
    Position position = await getCurrentLoc();
    List placemarks = await placemarkFromCoordinates(position.latitude, position.longitude);
    Placemark place = placemarks[0];
    String lCity = '${place.subLocality},${place.locality}';
    return lCity;
  }

  Future getCurrentLoc() async {
    Position position = await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.best);
    emit(state.copyWith(latitude: position.latitude, longitude: position.longitude));
    return position;
  }

  void addWeather(Weather weather){
    emit(state.copyWith(weatherList: [...?state.weatherList,weather]));
  }

  //Current Weather api call
  Future<CurrentWeather> buildCurrentWeather() async {
    String lCity = await _getLocation();
    emit(state.copyWith(city: lCity,status: FormzSubmissionStatus.inProgress));
    var result = await service
        .request("${ConstantString.baseUrl}data/2.5/weather?lat=${state.latitude}&lon=${state.longitude}&appid=${BaseService.apiKey}");
    var weatherData = CurrentWeather.fromJson(result.data);
    if (weatherData.weather != null && weatherData.weather?.isNotEmpty==true) {
      addWeather(weatherData.weather![0]);
    }
    debugPrint("7/8 response-->${jsonEncode(weatherData)}");

    if(weatherData.main!=null){
      double temp = weatherData.main!.temp! - 273.15;
      double feels = weatherData.main!.feelsLike ?? 10.0;
      emit(state.copyWith(temp: temp, wind: double.parse(weatherData.wind?.speed.toString() ?? '0'), feels: feels, visibility: double.parse(weatherData.visibility.toString()) ~/ 1000));
    }

    emit(state.copyWith(humidity: weatherData.main?.humidity ?? 0, sunrise: weatherData.sys?.sunrise ?? 0, sunset: weatherData.sys?.sunset ?? 0));

    return weatherData;
  }

  // Daily weather
  Future<DailyWeatherData> fetchDailyWeather() async {
    String lCity = await _getLocation();
    emit(state.copyWith(city: lCity,status: FormzSubmissionStatus.inProgress));
    var result = await service
        .request("${ConstantString.baseUrl}data/2.5/forecast?lat=${state.latitude}&lon=${state.longitude}&appid=${BaseService.apiKey}");
    var dailyWeatherData = DailyWeatherData.fromJson(result.data);
    List<WeatherList> updatedDailyWeathersList = [];
    for (var i in dailyWeatherData.list!) {
      updatedDailyWeathersList.add(i);
    }
    emit(state.copyWith(dailyWeathersList: updatedDailyWeathersList,status: FormzSubmissionStatus.success,population: dailyWeatherData.city?.population??1000));

    return dailyWeatherData;
  }

  Future<void> fetchWeeklyWeather() async {
   String lCity = await _getLocation();
    emit(state.copyWith(city: lCity,status: FormzSubmissionStatus.inProgress));

    var result = await service.request(
      "${ConstantString.baseUrl}data/2.5/forecast?lat=${state.latitude}&lon=${state.longitude}&cnt=40&appid=${BaseService.apiKey}",
    );
    var weeklyWeatherData = WeeklyWeather.fromJson(result.data);

    // Process the data and set the state
    List<WeeklyWeatherList> dateFilter = weeklyWeatherData.list ?? [];
    List<WeeklyWeatherList> weeklyWeatherListFilter = [];
    List<List<WeeklyWeatherList>> hourList = [];

    for (var i = 0; i < dateFilter.length; i++) {
      if (weeklyWeatherListFilter.isNotEmpty) {
        if (weeklyWeatherListFilter.last.dtTxt?.substring(0, 10) != dateFilter[i].dtTxt?.substring(0, 10)) {
          weeklyWeatherListFilter.add(dateFilter[i]);
        }
      } else {
        weeklyWeatherListFilter.add(dateFilter[i]);
      }
    }

    for (int k = 0; k < weeklyWeatherListFilter.length; k++) {
      List<WeeklyWeatherList> local = [];
     state.weeklyWeatherList?.where((i) => i.dtTxt?.substring(0, 10) == weeklyWeatherListFilter[k].dtTxt?.substring(0, 10)).map((e) {
        local.add(e);
        emit(state.copyWith(
            precipitation: local[0].pop
        ));
      }).toList();
      hourList.add(local);
    }

    emit(state.copyWith(
      weeklyWeatherList: weeklyWeatherData.list ?? [],
      weeklyWeatherListFilter: weeklyWeatherListFilter,
      hourList: hourList,
        status: FormzSubmissionStatus.success
    ));
  }

  //today screen apicall
  apiCall() async {
    await buildCurrentWeather();
    await fetchDailyWeather();
    await fetchWeeklyWeather();
  }
}
