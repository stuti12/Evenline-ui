import 'package:dio/dio.dart';

import '../utils/string.dart';

class BaseService {
  static const String apiKey = "99420999be5347c40531d011ef4e00c5";

  final Dio _dio = Dio(BaseOptions(
      baseUrl: ConstantString.baseUrl,
      validateStatus: (status) {
        return status! < 500;
      },
      headers: {
        "Accept": "*/*",
        "Content-Type": "application/json",
        "Connection": "keep-alive",
      },
      ));

  Future<Response> request(String url, {dynamic body, String? method}) async {
    var res = _dio.request(url,
        data: body,
        options: Options(
          method: method,
        ));
    return res;
  }
}

handleError(DioError error) {
  print(error.response.toString());
  if (error.message!.contains('SocketException')) {
    return 'Cannot connect. Check that you have internet connection';
  }

  if (error.response == null || error.response!.data is String) {
    return 'Something went wrong. Please try again later';
  }
  return 'Something went wrong. Please try again later';
}