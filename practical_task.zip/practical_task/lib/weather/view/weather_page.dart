import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:formz/formz.dart';
import 'package:intl/intl.dart';
import 'package:practical_task/weather/cubit/weather_page_cubit.dart';
import 'package:syncfusion_flutter_gauges/gauges.dart';

import '../../utils/app_colors.dart';
import '../../utils/app_image.dart';
import '../../utils/gradient_text.dart';
import '../../utils/string.dart';
import '../../utils/utils.dart';

class WeatherPage extends StatelessWidget {
  const WeatherPage({super.key});

  static Route<void> route() => MaterialPageRoute<void>(
        builder: (_) => BlocProvider(create: (context) => WeatherPageCubit(), child: const WeatherPage()),
      );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Weather'),
        backgroundColor: AppColor.dividerColor,
      ),
      body: BlocListener<WeatherPageCubit, WeatherPageState>(
        listenWhen: (previous, current) => previous.status != current.status,
        listener: (context, state) {},
        child: BlocBuilder<WeatherPageCubit, WeatherPageState>(
          builder: (context, state) {
            if (state.status == FormzSubmissionStatus.inProgress) {
              return const Center(
                child: CircularProgressIndicator(),
              );
            } else if (state.status == FormzSubmissionStatus.success) {
              return SingleChildScrollView(
                child: Padding(
                  padding: EdgeInsets.symmetric(horizontal: 18.w),
                  child: Column(
                    children: [
                      Column(
                        children: [
                          SizedBox(
                            height: 10.h,
                          ),
                          Container(
                            decoration: BoxDecoration(color: AppColor.dividerColor, borderRadius: BorderRadius.all(Radius.circular(30.r))),
                            child: Padding(
                              padding: EdgeInsets.symmetric(horizontal: 17.w, vertical: 7.h),
                              child: Text(
                                DateFormat('EEEE, dd MMM').format(DateTime.now()),
                                style: TextStyle(
                                  color: AppColor.blackColor,
                                ),
                              ),
                            ),
                          ),

                          //temprature
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceAround,
                            children: [
                              BlocBuilder<WeatherPageCubit, WeatherPageState>(
                                builder: (context, state) {
                                  return state.weatherList?.isNotEmpty == true
                                      ? FadeInImage(
                                          placeholder: AssetImage(AppImage.icPlaceholder),
                                          image: NetworkImage(
                                              '${ConstantString.baseImageUrl}${context.read<WeatherPageCubit>().state.weatherList?[0].icon}@2x.png'))
                                      /*  Image.network(
                                    '${ConstantString.baseImageUrl}${context.read<WeatherPageCubit>().state.weatherList?[0].icon}@2x.png',
                                  )*/
                                      : Image.asset(AppImage.icPlaceholder);
                                },
                              ),
                              BlocBuilder<WeatherPageCubit, WeatherPageState>(
                                builder: (context, state) {
                                  return Column(
                                    children: [
                                      GradientText(
                                        '${(state.temp).toStringAsFixed(0)}${'\u00B0'}',
                                        style: TextStyle(
                                          fontWeight: FontWeight.bold,
                                          fontSize: 54.sp,
                                          shadows: [Shadow(blurRadius: 2.r, color: AppColor.transparentColor)],
                                        ),
                                        gradient: LinearGradient(colors: [AppColor.dividerColor, AppColor.hintTextColor]),
                                      ),
                                      state.weatherList?.isNotEmpty == true
                                          ? Text(
                                              state.weatherList?[0].description.toString() ?? '',
                                              style: TextStyle(
                                                fontWeight: FontWeight.w400,
                                                color: AppColor.whiteColor,
                                              ),
                                            )
                                          : Text(
                                              "NA",
                                              style: TextStyle(fontWeight: FontWeight.w400, color: AppColor.whiteColor),
                                            )
                                    ],
                                  );
                                },
                              )
                            ],
                          ),
                          SizedBox(
                            height: 10.h,
                          ),
                          Row(
                            children: [
                              /*  BlocBuilder<WeatherPageCubit, WeatherPageState>(
                        builder: (context, state) {
                          return RichText(
                            text: TextSpan(
                                text:
                                '${((state.weeklyWeatherListFilter?[0].main?.tempMax) - 273.15).toStringAsFixed(0)}${'\u00B0'}/${((state
                                    .weeklyWeatherListFilter?[0].main?.tempMin ?? 0) - 273.15).toStringAsFixed(0)}${'\u00B0'} ',
                                style: TextStyle(fontWeight: FontWeight.w500, fontSize: 12.sp, color: AppColor.textColor),
                              ),
                          );
                        },
                      ),*/

                              BlocBuilder<WeatherPageCubit, WeatherPageState>(
                                builder: (context, state) {
                                  return RichText(
                                    text: TextSpan(
                                        text: ' | Feels like ',
                                        style: TextStyle(fontWeight: FontWeight.w500, fontSize: 12.sp, color: AppColor.textColor),
                                        children: <TextSpan>[
                                          TextSpan(
                                            text: '${((state.feels) - 273.15).toStringAsFixed(0)}${'\u00B0'}C',
                                            style: TextStyle(fontWeight: FontWeight.w400, fontSize: 12.sp, color: AppColor.textColor),
                                          ),
                                        ]),
                                  );
                                },
                              ),
                              const Spacer(),
                              Text(
                                '|',
                                style: TextStyle(color: AppColor.textColor),
                              ),
                              const Spacer(),
                              BlocBuilder<WeatherPageCubit, WeatherPageState>(
                                builder: (context, state) {
                                  return RichText(
                                    text: TextSpan(
                                        text: ConstantString.textWind,
                                        style: TextStyle(fontWeight: FontWeight.w500, fontSize: 12.sp, color: AppColor.textColor),
                                        children: <TextSpan>[
                                          TextSpan(
                                            text: '${state.wind.toString()} km',
                                            style: TextStyle(fontWeight: FontWeight.w400, fontSize: 12.sp, color: AppColor.textColor),
                                          ),
                                          TextSpan(
                                            text: '/ H WSW',
                                            style: TextStyle(fontWeight: FontWeight.w400, fontSize: 12.sp, color: AppColor.textColor),
                                          ),
                                        ]),
                                  );
                                },
                              )
                            ],
                          ),
                          SizedBox(
                            height: 16.h,
                          ),
                          Padding(
                            padding: EdgeInsets.symmetric(horizontal: 16.w),
                            child: Divider(
                              height: 1.h,
                              color: AppColor.textColor,
                            ),
                          ),
                          SizedBox(
                            height: 16.h,
                          ),
                          //precipitation
                          Padding(
                            padding: EdgeInsets.symmetric(horizontal: 8.w),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Expanded(
                                  child: Row(
                                    children: [
                                      Image.asset(
                                        AppImage.imgPrecipitation,
                                        width: 30.w,
                                        height: 30.w,
                                      ),
                                      SizedBox(
                                        width: 5.w,
                                      ),
                                      RichText(
                                        text: TextSpan(
                                            text: ConstantString.textPrecipitations,
                                            style: TextStyle(fontWeight: FontWeight.w500, fontSize: 12.sp, color: AppColor.textColor),
                                            children: <TextSpan>[
                                              TextSpan(
                                                text: '${state.precipitation.toString()} %',
                                                style: TextStyle(fontWeight: FontWeight.w400, fontSize: 12.sp, color: AppColor.textColor),
                                              ),
                                            ]),
                                      ),
                                    ],
                                  ),
                                ),
                                Row(
                                  children: [
                                    Image.asset(
                                      AppImage.imgRainy,
                                      width: 20.w,
                                      height: 20.w,
                                    ),
                                    SizedBox(
                                      width: 5.w,
                                    ),
                                    BlocBuilder<WeatherPageCubit, WeatherPageState>(
                                      builder: (context, state) {
                                        return RichText(
                                          text: TextSpan(
                                              text: ConstantString.textHumidity,
                                              style: TextStyle(fontWeight: FontWeight.w500, fontSize: 12.sp, color: AppColor.textColor),
                                              children: <TextSpan>[
                                                TextSpan(
                                                  text: '${state.humidity.toString()} %',
                                                  style: TextStyle(fontWeight: FontWeight.w400, fontSize: 12.sp, color: AppColor.textColor),
                                                ),
                                              ]),
                                        );
                                      },
                                    )
                                  ],
                                ),
                              ],
                            ),
                          ),
                          SizedBox(
                            height: 10.h,
                          ),
                          //wind
                          Padding(
                            padding: EdgeInsets.symmetric(horizontal: 8.w),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Row(
                                  children: [
                                    Image.asset(
                                      AppImage.imgSun,
                                      width: 30.w,
                                      height: 30.w,
                                    ),
                                    SizedBox(
                                      width: 5.w,
                                    ),
                                    BlocBuilder<WeatherPageCubit, WeatherPageState>(
                                      builder: (context, state) {
                                        return RichText(
                                          overflow: TextOverflow.ellipsis,
                                          text: TextSpan(
                                              text: ConstantString.textWind,
                                              style: TextStyle(fontWeight: FontWeight.w500, fontSize: 12, color: AppColor.textColor),
                                              children: <TextSpan>[
                                                TextSpan(
                                                  text: '${state.wind.toString()} km/h',
                                                  style: TextStyle(fontWeight: FontWeight.w400, fontSize: 12.sp, color: AppColor.textColor),
                                                ),
                                              ]),
                                        );
                                      },
                                    )
                                  ],
                                ),
                                Row(
                                  children: [
                                    Image.asset(
                                      AppImage.imgMoon,
                                      width: 30.w,
                                      height: 30.w,
                                    ),
                                    SizedBox(
                                      width: 5.w,
                                    ),
                                    BlocBuilder<WeatherPageCubit, WeatherPageState>(
                                      builder: (context, state) {
                                        return RichText(
                                          text: TextSpan(
                                              text: '${ConstantString.textsunset}: ',
                                              style: TextStyle(fontWeight: FontWeight.w500, fontSize: 12.sp, color: AppColor.blackColor),
                                              children: <TextSpan>[
                                                TextSpan(
                                                  text:
                                                      '${(DateTime.now().hour * 100 / DateTime.fromMillisecondsSinceEpoch(state.sunset * 1000).hour).toStringAsFixed(0)}'
                                                      '${'%'}',
                                                  style: TextStyle(fontWeight: FontWeight.w400, fontSize: 12.sp, color: AppColor.textColor),
                                                ),
                                              ]),
                                        );
                                      },
                                    )
                                  ],
                                ),
                              ],
                            ),
                          ),
                          SizedBox(
                            height: 20.h,
                          ),
                          SizedBox(
                              height: 120.h,
                              child: BlocBuilder<WeatherPageCubit, WeatherPageState>(
                                builder: (context, state) {
                                  return ListView.builder(
                                      scrollDirection: Axis.horizontal,
                                      itemCount: state.dailyWeathersList?.length ?? 0,
                                      itemBuilder: (context, int index) {
                                        if (state.dailyWeathersList != null && state.dailyWeathersList!.isNotEmpty) {
                                          return temperaturesData(index: index);
                                        } else {
                                          return const SizedBox.shrink();
                                        }
                                      });
                                },
                              )),
                          SizedBox(
                            height: 14.h,
                          ),
                        ],
                      ),
                      //expand container
                      Container(
                        margin: EdgeInsets.symmetric(vertical: 4.h),
                        decoration: BoxDecoration(
                            gradient: GradientWidgetToday.linearGradient(), borderRadius: BorderRadius.all(Radius.circular(10.r))),
                        child: Column(
                          children: [
                            SizedBox(
                              height: 20.h,
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.end,
                              children: [
                                Text(
                                  ConstantString.high,
                                  style: TextStyle(color: AppColor.blackColor, fontWeight: FontWeight.w400),
                                ),
                                SizedBox(
                                  width: 10.w,
                                ),
                                Text(
                                  '|',
                                  style: TextStyle(color: AppColor.blackColor, fontWeight: FontWeight.w400),
                                ),
                                SizedBox(
                                  width: 10.w,
                                ),
                                Text(
                                  ConstantString.low,
                                  style: TextStyle(color: AppColor.blackColor, fontWeight: FontWeight.w400),
                                ),
                                SizedBox(
                                  width: 18.w,
                                ),
                              ],
                            ),
                            BlocBuilder<WeatherPageCubit, WeatherPageState>(
                              builder: (context, state) {
                                return ListView.builder(
                                    physics: const ClampingScrollPhysics(),
                                    padding: EdgeInsets.zero,
                                    itemCount: state.weeklyWeatherListFilter?.length,
                                    shrinkWrap: true,
                                    itemBuilder: (context, int weatherIndex) {
                                      return ListTileTheme(
                                        horizontalTitleGap: 0.0,
                                        dense: true,
                                        child: ExpansionTile(
                                            controlAffinity: ListTileControlAffinity.leading,
                                            iconColor: AppColor.whiteColor,
                                            collapsedIconColor: AppColor.blackColor,
                                            textColor: AppColor.blackColor,
                                            title: Row(
                                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                              children: [
                                                SizedBox(
                                                    width: 0.3.sw,
                                                    child:
                                                    BlocBuilder<WeatherPageCubit, WeatherPageState>(
                                                      builder: (context, state) {
                                                        return Text(
                                                          DateFormat('EEEE').format(DateFormat("yyyy-MM-DD").parse(
                                                              '${(state.weeklyWeatherListFilter?[weatherIndex].dtTxt)?.substring(0, 10)}')),
                                                          style: TextStyle(
                                                              fontSize: 13.sp, fontWeight: FontWeight.w500, color: AppColor.whiteColor),
                                                        );
                                                      },
                                                    ),
                                                ),
                                                BlocBuilder<WeatherPageCubit, WeatherPageState>(
                                                  builder: (context, state) {
                                                    return state.weeklyWeatherListFilter?.isNotEmpty == true
                                                        ? FadeInImage(
                                                            width: 60,
                                                            placeholder: AssetImage(AppImage.icPlaceholder),
                                                            image: NetworkImage(
                                                              '${ConstantString.baseImageUrl}${state.weeklyWeatherListFilter?[weatherIndex].weather?[0].icon}@2x.png',
                                                            ),
                                                          )
                                                        : Image.asset(
                                                            AppImage.iconCloud,
                                                            height: 30.h,
                                                          );
                                                  },
                                                ),
                                                BlocBuilder<WeatherPageCubit, WeatherPageState>(
                                                  builder: (context, state) {
                                                    return Text(
                                                      '${((state.weeklyWeatherListFilter?[weatherIndex].main?.tempMax ?? 0) - 273.15).toStringAsFixed(0)}${"\u00B0"}',
                                                      style: TextStyle(
                                                          color: AppColor.whiteColor, fontSize: 12.sp, fontWeight: FontWeight.w600),
                                                      overflow: TextOverflow.ellipsis,
                                                    );
                                                  },
                                                ),
                                                BlocBuilder<WeatherPageCubit, WeatherPageState>(
                                                  builder: (context, state) {
                                                    return Text(
                                                      '${((state.weeklyWeatherListFilter?[weatherIndex].main?.tempMin ?? 0) - 273.15).toStringAsFixed(0)}${"\u00B0"}',
                                                      style: TextStyle(
                                                          color: AppColor.whiteColor, fontSize: 12.sp, fontWeight: FontWeight.w600),
                                                      overflow: TextOverflow.ellipsis,
                                                    );
                                                  },
                                                ),
                                              ],
                                            ),
                                            children: [
                                              Container(
                                                margin: EdgeInsets.only(bottom: 8.h),
                                                height: 120.h,
                                                child: ListView.builder(
                                                    scrollDirection: Axis.horizontal,
                                                    itemCount: state.hourList?[weatherIndex].length,
                                                    itemBuilder: (context, int hourIndex) {
                                                      return weatherDetail(dayIndex: weatherIndex, hourIndex: hourIndex);
                                                    }),
                                              ),
                                            ]),
                                      );
                                    });
                              },
                            )
                          ],
                        ),
                      ),
                      SizedBox(
                        height: 10.h,
                      ),
//DETails
                      Container(
                        padding: EdgeInsets.symmetric(horizontal: 14.w),
                        decoration: BoxDecoration(
                            gradient: GradientWidgetToday.linearGradient(), borderRadius: BorderRadius.all(Radius.circular(10.r))),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            SizedBox(
                              height: 10.h,
                            ),
                            Text(
                              'Details',
                              style: TextStyle(fontWeight: FontWeight.w600, fontSize: 14.sp, color: AppColor.whiteColor),
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              children: [
                                BlocBuilder<WeatherPageCubit, WeatherPageState>(
                                  builder: (context, state) {
                                    return state.weatherList?.isNotEmpty == true
                                        ? FadeInImage(
                                            placeholder: AssetImage(AppImage.icPlaceholder),
                                            image: NetworkImage(
                                              '${ConstantString.baseImageUrl}${state.weatherList?[0].icon}@2x.png',
                                            ))
                                        : Image.asset(
                                            AppImage.iconCloud,
                                            height: 30.h,
                                          );
                                  },
                                ),
                                Expanded(
                                  child: Padding(
                                    padding: EdgeInsets.only(right: 20.w),
                                    child: Column(
                                      children: [
                                        Row(
                                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                          children: [
                                            Text(
                                              ConstantString.textFeels,
                                              style: TextStyle(fontWeight: FontWeight.w400, fontSize: 13.sp, color: AppColor.blackColor),
                                            ),
                                            BlocBuilder<WeatherPageCubit, WeatherPageState>(
                                              builder: (context, state) {
                                                return Text(
                                                  '${(state.feels - 273.15).toStringAsFixed(0)}${'\u00B0'}',
                                                  style:
                                                      TextStyle(fontWeight: FontWeight.w400, fontSize: 13.sp, color: AppColor.whiteColor),
                                                );
                                              },
                                            )
                                          ],
                                        ),
                                        SizedBox(
                                          height: 10.h,
                                        ),
                                        Row(
                                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                          children: [
                                            Text(
                                              ConstantString.textHumidity,
                                              style: TextStyle(fontWeight: FontWeight.w400, fontSize: 13.sp, color: AppColor.blackColor),
                                            ),
                                            BlocBuilder<WeatherPageCubit, WeatherPageState>(
                                              builder: (context, state) {
                                                return Text(
                                                  '${(state.humidity)}${'%'}',
                                                  style:
                                                      TextStyle(fontWeight: FontWeight.w400, fontSize: 13.sp, color: AppColor.whiteColor),
                                                );
                                              },
                                            )
                                          ],
                                        ),
                                        SizedBox(
                                          height: 10.h,
                                        ),
                                        Row(
                                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                          children: [
                                            Text(
                                              ConstantString.textVisibility,
                                              style: TextStyle(fontWeight: FontWeight.w400, fontSize: 13.sp, color: AppColor.blackColor),
                                            ),
                                            BlocBuilder<WeatherPageCubit, WeatherPageState>(
                                              builder: (context, state) {
                                                return Text(
                                                  '${(state.visibility)}${'km'}',
                                                  style:
                                                      TextStyle(fontWeight: FontWeight.w400, fontSize: 13.sp, color: AppColor.whiteColor),
                                                );
                                              },
                                            )
                                          ],
                                        ),
                                        SizedBox(
                                          height: 10.h,
                                        ),
                                        Row(
                                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                          children: [
                                            Text(
                                              ConstantString.textUV,
                                              style: TextStyle(fontWeight: FontWeight.w400, fontSize: 13, color: AppColor.blackColor),
                                            ),
                                            Text(
                                              'NA',
                                              style: TextStyle(fontWeight: FontWeight.w400, fontSize: 13.sp, color: AppColor.whiteColor),
                                            ),
                                          ],
                                        ),
                                        SizedBox(
                                          height: 10.h,
                                        ),
                                        Row(
                                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                          children: [
                                            Text(
                                              ConstantString.textDewPoint,
                                              style: TextStyle(fontWeight: FontWeight.w400, fontSize: 13, color: AppColor.blackColor),
                                            ),
                                            Text(
                                              'NA',
                                              style: TextStyle(fontWeight: FontWeight.w400, fontSize: 13.sp, color: AppColor.whiteColor),
                                            ),
                                          ],
                                        ),
                                      ],
                                    ),
                                  ),
                                )
                              ],
                            ),
                            SizedBox(
                              height: 20.h,
                            ),
                            Text(
                              ConstantString.textNote,
                              style: TextStyle(color: AppColor.blackColor, fontSize: 12.sp),
                            ),
                            SizedBox(
                              height: 20.h,
                            )
                          ],
                        ),
                      ),
                      SizedBox(
                        height: 10.h,
                      ),

                      //air
                      Container(
                        padding: EdgeInsets.symmetric(horizontal: 14.w),
                        decoration: BoxDecoration(
                            gradient: GradientWidgetToday.linearGradient(), borderRadius: BorderRadius.all(Radius.circular(10.r))),
                        child: Column(
                          children: [
                            Row(
                              children: [
                                SizedBox(
                                  height: 10.h,
                                ),
                                Text(
                                  ConstantString.textAir,
                                  style: TextStyle(fontWeight: FontWeight.w600, fontSize: 14.sp, color: AppColor.whiteColor),
                                ),
                                Expanded(
                                  child: Align(
                                    alignment: Alignment.topRight,
                                    child: IconButton(
                                        onPressed: () {},
                                        icon: Icon(
                                          Icons.info_outline,
                                          color: AppColor.whiteColor,
                                        )),
                                  ),
                                )
                              ],
                            ),
                            SizedBox(
                              height: 10.h,
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              children: [
                                BlocBuilder<WeatherPageCubit, WeatherPageState>(
                                  builder: (context, state) {
                                    return SizedBox(
                                      height: 80.h,
                                      width: 0.3.sw,
                                      child: SfRadialGauge(axes: <RadialAxis>[
                                        RadialAxis(
                                          annotations: [
                                            GaugeAnnotation(
                                              positionFactor: 0.1,
                                              angle: 90,
                                              widget: RichText(
                                                textAlign: TextAlign.center,

                                                text: TextSpan(
                                                    text: '${(state.temp).toStringAsFixed(0)}\n',
                                                    style:
                                                        TextStyle(fontWeight: FontWeight.w500, fontSize: 18.sp, color: AppColor.whiteColor),
                                                    children: <TextSpan>[
                                                      TextSpan(
                                                        text: state.temp>22 && state.temp<33 ?'Moderate':state.temp <= 22 ? 'Low' : 'High',
                                                        style: TextStyle(
                                                            fontWeight: FontWeight.w400, fontSize: 10.sp, color: AppColor.whiteColor),
                                                      ),
                                                    ]),
                                              ),
                                            )
                                          ],
                                          minimum: 0,
                                          maximum: 100,
                                          showLabels: false,
                                          showTicks: false,
                                          axisLineStyle: AxisLineStyle(
                                            thickness: 0.1,
                                            cornerStyle: CornerStyle.bothCurve,
                                            color: const Color(0xFFFE1D1D),
                                            gradient: SweepGradient(colors: <Color>[
                                              AppColor.pinkColor,
                                              AppColor.pinkColor,
                                              AppColor.primaryColor,
                                              AppColor.dividerColor,
                                            ], stops: const <double>[
                                              0.15,
                                              0.20,
                                              0.60,
                                              0.80
                                            ]),
                                            thicknessUnit: GaugeSizeUnit.factor,
                                          ),
                                        )
                                      ]),
                                    );
                                  },
                                ),
                                Expanded(
                                  child: Text(
                                    ConstantString.textAirNote,
                                    style: TextStyle(color: AppColor.blackColor, fontSize: 12.sp),
                                  ),
                                )
                              ],
                            ),
                            SizedBox(
                              height: 10.h,
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                RichText(
                                  text: TextSpan(
                                      text: 'US EPA AQI ',
                                      style: TextStyle(fontWeight: FontWeight.w500, fontSize: 12.sp, color: AppColor.blackColor),
                                      children: <TextSpan>[
                                        TextSpan(
                                          text: 'NA',
                                          style: TextStyle(fontWeight: FontWeight.w400, fontSize: 12.sp, color: AppColor.whiteColor),
                                        ),
                                      ]),
                                ),
                                RichText(
                                  text: TextSpan(
                                      text: 'Dominant poppulant',
                                      style: TextStyle(fontWeight: FontWeight.w500, fontSize: 12.sp, color: AppColor.blackColor),
                                      children: <TextSpan>[
                                        TextSpan(
                                          text: ' PM 10',
                                          style: TextStyle(fontWeight: FontWeight.w400, fontSize: 12.sp, color: AppColor.whiteColor),
                                        ),
                                      ]),
                                ),
                              ],
                            ),
                            SizedBox(
                              height: 20.h,
                            )
                          ],
                        ),
                      ),
                      SizedBox(
                        height: 20.h,
                      ),

//corona
                      Container(
                        padding: EdgeInsets.symmetric(horizontal: 14.w),
                        decoration: BoxDecoration(
                            gradient: GradientWidgetToday.linearGradient(), borderRadius: BorderRadius.all(Radius.circular(10.r))),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                SizedBox(
                                  height: 10.h,
                                ),
                                Text(
                                  ConstantString.textCorona,
                                  style: TextStyle(fontWeight: FontWeight.w600, fontSize: 14.sp, color: AppColor.whiteColor),
                                ),
                                Expanded(
                                  child: Align(
                                      alignment: Alignment.topRight,
                                      child: IconButton(
                                          onPressed: () {},
                                          icon: Icon(
                                            Icons.more_horiz,
                                            color: AppColor.whiteColor,
                                          ))),
                                )
                              ],
                            ),
                            SizedBox(
                              height: 4.h,
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      BlocBuilder<WeatherPageCubit, WeatherPageState>(
                                        builder: (context, state) {
                                          return Text(
                                            (state.city),
                                            style: TextStyle(fontWeight: FontWeight.w400, fontSize: 13.sp, color: AppColor.whiteColor),
                                          );
                                        },
                                      ),
                                      SizedBox(
                                        height: 4.h,
                                      ),
                                      Text(
                                        ConstantString.textConfirmCase,
                                        style: TextStyle(fontWeight: FontWeight.w500, fontSize: 13.sp, color: AppColor.whiteColor),
                                      ),
                                    ],
                                  ),
                                ),
                                Column(
                                  children: [
                                    Text(
                                      ConstantString.textToday,
                                      style: TextStyle(fontWeight: FontWeight.w400, fontSize: 13.sp, color: AppColor.blackColor),
                                    ),
                                    SizedBox(
                                      height: 10.h,
                                    ),
                                    Container(
                                      decoration:
                                          BoxDecoration(color: AppColor.dividerColor, borderRadius: BorderRadius.all(Radius.circular(4.r))),
                                      child: Padding(
                                        padding: EdgeInsets.only(left: 8.w, right: 8.w, top: 2.h, bottom: 6.h),
                                        child: Text(
                                          textAlign: TextAlign.center,
                                          '56676767',
                                          style: TextStyle(
                                            color: AppColor.blackColor,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                                SizedBox(
                                  width: 10.w,
                                ),
                                Column(
                                  children: [
                                    Text(
                                      ConstantString.textTotal,
                                      style: TextStyle(fontWeight: FontWeight.w400, fontSize: 13.sp, color: AppColor.textColor),
                                    ),
                                    SizedBox(
                                      height: 10.h,
                                    ),
                                    Container(
                                      decoration: BoxDecoration(borderRadius: BorderRadius.all(Radius.circular(4.r))),
                                      child: Padding(
                                        padding: EdgeInsets.only(left: 8.w, right: 8.w, top: 2.h, bottom: 6.h),
                                        child: Text(
                                          textAlign: TextAlign.center,
                                          '56676767',
                                          style: TextStyle(
                                            color: AppColor.blackColor,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                )
                              ],
                            ),
                            SizedBox(
                              height: 20.h,
                            ),
                            Divider(
                              height: 0.5.h,
                              color: AppColor.blackColor,
                            ),
                            SizedBox(
                              height: 10.h,
                            ),
                            Wrap(
                              crossAxisAlignment: WrapCrossAlignment.start,
                              children: [
                                Text(
                                  ConstantString.textMore,
                                  style: TextStyle(fontSize: 13, color: AppColor.whiteColor),
                                ),
                                InkWell(
                                    onTap: () {
                                      context.read<WeatherPageCubit>().toggleShow();
                                    },
                                    child: const Icon(
                                      Icons.keyboard_arrow_down,
                                      color: Colors.white,
                                    )),
                              ],
                            ),
                            Visibility(
                              visible: state.showMore,
                              child: Column(
                                children: [
                                  SizedBox(
                                    height: 10.h,
                                  ),
                                  RichText(
                                    text: TextSpan(
                                        text: 'Population ',
                                        style: TextStyle(fontWeight: FontWeight.w500, fontSize: 13, color: AppColor.blackColor),
                                        children: <TextSpan>[
                                          TextSpan(
                                            text: '${state.population}',
                                            style: TextStyle(fontWeight: FontWeight.w400, fontSize: 13, color: AppColor.whiteColor),
                                          ),
                                        ]),
                                  ),
                                  SizedBox(
                                    height: 10.h,
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),

                      SizedBox(
                        height: 10.h,
                      ),
                      //Sun

                      Container(
                        padding: EdgeInsets.symmetric(horizontal: 14.w),
                        decoration: BoxDecoration(
                            gradient: GradientWidgetToday.linearGradient(), borderRadius: BorderRadius.all(Radius.circular(10.r))),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            SizedBox(
                              height: 10.h,
                            ),
                            Text(
                              ConstantString.textSunAndMoon,
                              style: TextStyle(fontWeight: FontWeight.w600, fontSize: 14.sp, color: AppColor.whiteColor),
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Column(
                                  children: [
                                    BlocBuilder<WeatherPageCubit, WeatherPageState>(
                                      builder: (context, state) {
                                        return Text(
                                          '${DateFormat.Hm().format(
                                            DateTime.fromMillisecondsSinceEpoch(state.sunrise * 1000),
                                          )} ${'AM'}',
                                          style: TextStyle(fontWeight: FontWeight.w400, fontSize: 13.sp, color: AppColor.whiteColor),
                                        );
                                      },
                                    ),
                                    SizedBox(
                                      height: 6.h,
                                    ),
                                    Text(
                                      ConstantString.textSunRise,
                                      style: TextStyle(fontWeight: FontWeight.w500, fontSize: 12.sp, color: AppColor.blackColor),
                                    ),
                                  ],
                                ),

                                Padding(
                                  padding: EdgeInsets.only(top: 16.h),
                                  child: Stack(alignment: Alignment.topRight, children: [
                                    SizedBox(
                                      height: 70.h,
                                      width: 0.2.sw,
                                      child: SfRadialGauge(axes: <RadialAxis>[
                                        RadialAxis(
                                          showLabels: false,
                                          showTicks: false,
                                          axisLineStyle: AxisLineStyle(
                                            thickness: 0.03,
                                            color: AppColor.blackColor,
                                            thicknessUnit: GaugeSizeUnit.factor,
                                          ),
                                          startAngle: 180,
                                          endAngle: 360,
                                        ),
                                      ]),
                                    ),
                                    Positioned(
                                        top: 0.h,
                                        right: 0.w,
                                        child: Image.asset(
                                          AppImage.imgIconSun,
                                          height: 24.h,
                                        ))
                                  ]),
                                ),
                                // CircularBorder(width: 1.r,size: 45.h,),
                                Column(
                                  children: [
                                    BlocBuilder<WeatherPageCubit, WeatherPageState>(
                                      builder: (context, state) {
                                        return Text(
                                          '${DateFormat.Hm().format(
                                            DateTime.fromMillisecondsSinceEpoch(state.sunset * 1000),
                                          )} ${'PM'}',
                                          style: TextStyle(fontWeight: FontWeight.w400, fontSize: 13.sp, color: AppColor.whiteColor),
                                        );
                                      },
                                    ),
                                    SizedBox(
                                      height: 6.h,
                                    ),
                                    Text(
                                      ConstantString.textsunset,
                                      style: TextStyle(fontWeight: FontWeight.w500, fontSize: 12, color: AppColor.blackColor),
                                    ),
                                  ],
                                ),
                              ],
                            )
                          ],
                        ),
                      ),
                      SizedBox(
                        height: 20.h,
                      )
                    ],
                  ),
                ),
              );
            } else {
              return const Center(
                child: CircularProgressIndicator(),
              );
            }
          },
        ),
      ),
    );
  }

  Widget temperaturesData({required int index}) {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 8.w),
      decoration: BoxDecoration(color: AppColor.hintTextColor, borderRadius: BorderRadius.all(Radius.circular(30.r))),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          BlocBuilder<WeatherPageCubit, WeatherPageState>(
            builder: (context, state) {
              return state.dailyWeathersList?[index].dtTxt?.isNotEmpty == true
                  ? Text(
                      state.dailyWeathersList?[index].dtTxt?.substring(11, 16) ?? "",
                      style: TextStyle(
                        fontSize: 12.sp,
                        color: AppColor.textColor,
                      ),
                    )
                  : const Text('NA');
            },
          ),
          BlocBuilder<WeatherPageCubit, WeatherPageState>(
            builder: (context, state) {
              return state.dailyWeathersList?[index].weather?.isNotEmpty == true
                  ? FadeInImage(
                      width: 50,
                      placeholder: AssetImage(AppImage.icPlaceholder),
                      image: NetworkImage(
                        '${ConstantString.baseImageUrl}${state.dailyWeathersList?[index].weather?[0].icon}@2x.png',
                      ))
                  : Image.asset(AppImage.icPlaceholder);
            },
          ),
          BlocBuilder<WeatherPageCubit, WeatherPageState>(
            builder: (context, state) {
              return Text(
                '${((state.dailyWeathersList?[index].main?.temp ?? 0.0) - 273.15).toStringAsFixed(0)} ${"\u00B0C"}',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 14.sp,
                  fontWeight: FontWeight.w600,
                ),
              );
            },
          )
        ],
      ),
    );
  }

  Widget weatherDetail({required int dayIndex, required int hourIndex}) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 6.w),
      margin: EdgeInsets.symmetric(horizontal: 10.w),
      decoration: BoxDecoration(color: AppColor.blackColor, borderRadius: BorderRadius.all(Radius.circular(8.r))),
      child: BlocBuilder<WeatherPageCubit, WeatherPageState>(
        builder: (context, state) {
          return Column(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              state.hourList?.isNotEmpty == true
                  ? Image.network(
                      '${ConstantString.baseImageUrl}${state.hourList?[dayIndex][hourIndex].weather?[0].icon}@2x.png',
                    )
                  : Image.asset(AppImage.icPlaceholder),
              Text(
                '${((state.hourList?[dayIndex][hourIndex].main?.temp) - 273.15).toStringAsFixed(0)}${'\u00B0'}',
                style: TextStyle(color: AppColor.blackColor, fontSize: 12.sp, fontWeight: FontWeight.w600),
              ),
              Text(
                DateFormat('hh a').format(DateTime.parse(
                    DateFormat("HH").parse((state.hourList?[dayIndex][hourIndex].dtTxt?.substring(11, 13)) ?? '').toString())),
                style: TextStyle(color: AppColor.blackColor, fontSize: 12.sp, fontWeight: FontWeight.w600),
              ),
            ],
          );
        },
      ),
    );
  }
}
