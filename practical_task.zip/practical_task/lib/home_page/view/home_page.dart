import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:formz/formz.dart';
import 'package:practical_task/home_page/cubit/home_page_cubit.dart';
import 'package:practical_task/utils/app_colors.dart';
import 'package:practical_task/utils/ui_text_style.dart';
import 'package:practical_task/weather/view/weather_page.dart';

import '../../utils/app_image.dart';
import '../../utils/string.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  static Route<void> route() => MaterialPageRoute<void>(
        builder: (_) => BlocProvider(create: (context) => HomePageCubit()..fetchUserData(), child: const HomePage()),
      );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: AppColor.pinkColor,
        title: Text(
          ConstantString.appName,
          style: UITextStyle.regularTextStyle(color: AppColor.whiteColor, fontSize: 20),
        ),
      ),
      drawer: Drawer(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            DrawerHeader(
              decoration: BoxDecoration(
                color: AppColor.pinkColor,
              ), //BoxDecoration
              child: BlocBuilder<HomePageCubit, HomePageState>(
                builder: (context, state) {
                  return UserAccountsDrawerHeader(
                    decoration: BoxDecoration(color: AppColor.pinkColor),
                    accountName: Text(
                      state.name,
                      style: UITextStyle.regularTextStyle(fontSize: 18),
                    ),
                    accountEmail: Text(
                      state.userEmail,
                      style: UITextStyle.regularTextStyle(fontSize: 14),
                    ),
                  );
                },
              ),
            ),
            Row(
              children: [
                SizedBox(
                  width: 4.w,
                ),
                Image.asset(AppImage.iconCloud),
                TextButton(
                  onPressed: () {
                    Navigator.push(context, WeatherPage.route());
                  },
                  child: Text(
                    'Weather',
                    style: UITextStyle.regularTextStyle(fontSize: 18),
                  ),
                ),
              ],
            )
          ],
        ),
      ),
      body: BlocListener<HomePageCubit, HomePageState>(
        listener: (context, state) {
          //  context.read<HomePageCubit>().fetchUserData();
        },
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: BlocBuilder<HomePageCubit, HomePageState>(
            builder: (context, state) {
              if (state.status == FormzSubmissionStatus.inProgress) {
                return const Center(child: CircularProgressIndicator(),);
              } else if (state.status == FormzSubmissionStatus.success) {
                return Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          ConstantString.name,
                          style: UITextStyle.regularTextStyle(fontWeight: FontWeight.w500, fontSize: 20),
                        ),
                        Text(
                          state.name,
                          style: UITextStyle.regularTextStyle(fontWeight: FontWeight.w400, fontSize: 16),
                        ),
                      ],
                    ),
                    SizedBox(height: 20.h),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          ConstantString.email,
                          style: UITextStyle.regularTextStyle(fontWeight: FontWeight.w500, fontSize: 20),
                        ),
                        Text(
                          state.userEmail,
                          style: UITextStyle.regularTextStyle(fontWeight: FontWeight.w400, fontSize: 16),
                        ),
                      ],
                    ),
                    SizedBox(height: 20.h),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          ConstantString.phoneNumber,
                          style: UITextStyle.regularTextStyle(fontWeight: FontWeight.w500, fontSize: 20),
                        ),
                        Text(
                          state.phone,
                          style: UITextStyle.regularTextStyle(fontWeight: FontWeight.w400, fontSize: 16),
                        ),
                      ],
                    ),
                    SizedBox(height: 20.h),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          ConstantString.gender,
                          style: UITextStyle.regularTextStyle(fontWeight: FontWeight.w500, fontSize: 20),
                        ),
                        Text(
                          state.gender,
                          style: UITextStyle.regularTextStyle(fontWeight: FontWeight.w400, fontSize: 16),
                        ),
                      ],
                    ),
                  ],
                );
              } else {
                return Container();
              }
            },
          ),
        ),
      ),
    );
  }
}
