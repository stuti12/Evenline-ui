import 'package:bloc/bloc.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:formz/formz.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

import '../../utils/string.dart';

part 'home_page_state.dart';
part 'home_page_cubit.freezed.dart';

class HomePageCubit extends Cubit<HomePageState> {
  HomePageCubit() : super(const HomePageState());
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  Future<void> fetchUserData() async {
    emit(state.copyWith(status: FormzSubmissionStatus.inProgress));
    try {
      final userId = _auth.currentUser?.uid;
      if (userId != null) {
        final userDataSnapshot = await _firestore.collection(UsersCollectionKeys.collectionName).doc(userId).get();
        if (userDataSnapshot.exists) {
          final userData = userDataSnapshot.data();
          if (userData != null) {
            emit(state.copyWith(
              name: userData[UsersCollectionKeys.name],
              userEmail: userData[UsersCollectionKeys.email],
              phone: userData[UsersCollectionKeys.phone],
              gender: userData[UsersCollectionKeys.gender],
              status: FormzSubmissionStatus.success
            ));
          }
        }
      }

    } catch (e) {
      emit(state.copyWith(
          errorMessage: e.toString(),
          status: FormzSubmissionStatus.failure
      ));
    }
  }
}
