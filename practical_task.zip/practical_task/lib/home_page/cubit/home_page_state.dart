part of 'home_page_cubit.dart';

@freezed
class HomePageState with _$HomePageState {
  const factory HomePageState({
    @Default("") String userEmail,
    @Default("") String name,
    @Default("") String gender,
    @Default("") String phone,
    @Default("") String errorMessage,
    @Default(true) bool passwordVisible,
    @Default(false) bool isEmailExist,
    @Default(FormzSubmissionStatus.initial) FormzSubmissionStatus status,
  }) = _HomePageState;
}
