import 'package:bloc/bloc.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:formz/formz.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

import '../../models/users.dart';
import '../../utils/user_session.dart';
import '../../utils/utils.dart';

part 'registration_page_state.dart';

part 'registration_page_cubit.freezed.dart';

class RegistrationPageCubit extends Cubit<RegistrationPageState> {
  RegistrationPageCubit() : super(const RegistrationPageState());
  final FirebaseAuth _auth = FirebaseAuth.instance;

  final FirebaseFirestore fireStore = FirebaseFirestore.instance;

  void nameChanged(String value) {
    emit(
      state.copyWith(
        userName: value,
      ),
    );
  }

  void phoneChange(String value) {
    emit(state.copyWith(
      phoneNumber: value,
    ));
  }

  void emailChanged(String value) {
    emit(state.copyWith(
      userEmail: value,
    ));
  }

  void passwordChange(String value) {
    emit(state.copyWith(
      userPassword: value,
    ));
  }
  void onGenderValueChanged(String value) {
    emit(state.copyWith(gender: value,));
  }

  bool checkPhone(String phone) {
    final bool phoneValid = RegExp(RegularExpressions.mobileNumber).hasMatch(phone);
    return phoneValid;
  }

  bool checkEmail(String email) {
    final bool emailValid = RegExp(r"^[a-zA-Z0-9.a-zA-Z0-9.!#$%&'*+-/=?^_`{|}~]+@[a-zA-Z0-9]+\.[a-zA-Z]+").hasMatch(email);
    return emailValid;
  }

  bool checkPassword(String password) {
    final bool passwordValid = RegExp(r"^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,}$").hasMatch(password);
    return passwordValid;
  }

  void togglePasswordVisibility() {
    emit(state.copyWith(passwordVisible: !state.passwordVisible));
  }

  ///Sign up method
  Future<void> signUpUser({required String name, required String email, required String password, required String phoneNumber,required String? gender}) async {
    emit(
      state.copyWith(
        status: FormzSubmissionStatus.inProgress,
      ),
    );
    try {
      UserCredential user = await _auth.createUserWithEmailAndPassword(email: email, password: password);

      Users mUser = Users(name: name, phoneNumber: phoneNumber,email: email, password: password,gender: gender );
      print("Gender value in signUpUser: ${mUser.gender}");

      await fireStore.collection('Users').doc(user.user?.uid).set(mUser.toJson());
      emit(
        state.copyWith(
          status: FormzSubmissionStatus.success,
        ),
      );
    } catch (e) {
      emit(
        state.copyWith(
          errorMessage: e.toString(),
          status: FormzSubmissionStatus.failure,
        ),
      );
    }
  }

  ///store data to shared preference
  void registrationSuccess({required String userEmail}) {
    UserSession.saveUserEmail(userEmail);
    emit(
      state.copyWith(
        status: FormzSubmissionStatus.success,
      ),
    );
  }
}
