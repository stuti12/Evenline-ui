part of 'registration_page_cubit.dart';

@freezed
class RegistrationPageState with _$RegistrationPageState {
  const factory RegistrationPageState({
    @Default("") String userName,
    @Default("") String userEmail,
    @Default("") String userPassword,
    @Default("") String phoneNumber,
    @Default("") String gender,
    @Default(['Male','Female']) List<String> genderList,
    @Default("") String errorMessage,
    @Default(true) bool passwordVisible,
    @Default(false) bool isEmailExist,
    @Default(FormzSubmissionStatus.initial) FormzSubmissionStatus status,
  }) = _RegistrationPageState;
}
