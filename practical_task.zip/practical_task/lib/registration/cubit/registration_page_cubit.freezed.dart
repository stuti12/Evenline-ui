// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'registration_page_cubit.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

/// @nodoc
mixin _$RegistrationPageState {
  String get userName => throw _privateConstructorUsedError;
  String get userEmail => throw _privateConstructorUsedError;
  String get userPassword => throw _privateConstructorUsedError;
  String get phoneNumber => throw _privateConstructorUsedError;
  String get gender => throw _privateConstructorUsedError;
  List<String> get genderList => throw _privateConstructorUsedError;
  String get errorMessage => throw _privateConstructorUsedError;
  bool get passwordVisible => throw _privateConstructorUsedError;
  bool get isEmailExist => throw _privateConstructorUsedError;
  FormzSubmissionStatus get status => throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $RegistrationPageStateCopyWith<RegistrationPageState> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $RegistrationPageStateCopyWith<$Res> {
  factory $RegistrationPageStateCopyWith(RegistrationPageState value,
          $Res Function(RegistrationPageState) then) =
      _$RegistrationPageStateCopyWithImpl<$Res, RegistrationPageState>;
  @useResult
  $Res call(
      {String userName,
      String userEmail,
      String userPassword,
      String phoneNumber,
      String gender,
      List<String> genderList,
      String errorMessage,
      bool passwordVisible,
      bool isEmailExist,
      FormzSubmissionStatus status});
}

/// @nodoc
class _$RegistrationPageStateCopyWithImpl<$Res,
        $Val extends RegistrationPageState>
    implements $RegistrationPageStateCopyWith<$Res> {
  _$RegistrationPageStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? userName = null,
    Object? userEmail = null,
    Object? userPassword = null,
    Object? phoneNumber = null,
    Object? gender = null,
    Object? genderList = null,
    Object? errorMessage = null,
    Object? passwordVisible = null,
    Object? isEmailExist = null,
    Object? status = null,
  }) {
    return _then(_value.copyWith(
      userName: null == userName
          ? _value.userName
          : userName // ignore: cast_nullable_to_non_nullable
              as String,
      userEmail: null == userEmail
          ? _value.userEmail
          : userEmail // ignore: cast_nullable_to_non_nullable
              as String,
      userPassword: null == userPassword
          ? _value.userPassword
          : userPassword // ignore: cast_nullable_to_non_nullable
              as String,
      phoneNumber: null == phoneNumber
          ? _value.phoneNumber
          : phoneNumber // ignore: cast_nullable_to_non_nullable
              as String,
      gender: null == gender
          ? _value.gender
          : gender // ignore: cast_nullable_to_non_nullable
              as String,
      genderList: null == genderList
          ? _value.genderList
          : genderList // ignore: cast_nullable_to_non_nullable
              as List<String>,
      errorMessage: null == errorMessage
          ? _value.errorMessage
          : errorMessage // ignore: cast_nullable_to_non_nullable
              as String,
      passwordVisible: null == passwordVisible
          ? _value.passwordVisible
          : passwordVisible // ignore: cast_nullable_to_non_nullable
              as bool,
      isEmailExist: null == isEmailExist
          ? _value.isEmailExist
          : isEmailExist // ignore: cast_nullable_to_non_nullable
              as bool,
      status: null == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as FormzSubmissionStatus,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$_RegistrationPageStateCopyWith<$Res>
    implements $RegistrationPageStateCopyWith<$Res> {
  factory _$$_RegistrationPageStateCopyWith(_$_RegistrationPageState value,
          $Res Function(_$_RegistrationPageState) then) =
      __$$_RegistrationPageStateCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String userName,
      String userEmail,
      String userPassword,
      String phoneNumber,
      String gender,
      List<String> genderList,
      String errorMessage,
      bool passwordVisible,
      bool isEmailExist,
      FormzSubmissionStatus status});
}

/// @nodoc
class __$$_RegistrationPageStateCopyWithImpl<$Res>
    extends _$RegistrationPageStateCopyWithImpl<$Res, _$_RegistrationPageState>
    implements _$$_RegistrationPageStateCopyWith<$Res> {
  __$$_RegistrationPageStateCopyWithImpl(_$_RegistrationPageState _value,
      $Res Function(_$_RegistrationPageState) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? userName = null,
    Object? userEmail = null,
    Object? userPassword = null,
    Object? phoneNumber = null,
    Object? gender = null,
    Object? genderList = null,
    Object? errorMessage = null,
    Object? passwordVisible = null,
    Object? isEmailExist = null,
    Object? status = null,
  }) {
    return _then(_$_RegistrationPageState(
      userName: null == userName
          ? _value.userName
          : userName // ignore: cast_nullable_to_non_nullable
              as String,
      userEmail: null == userEmail
          ? _value.userEmail
          : userEmail // ignore: cast_nullable_to_non_nullable
              as String,
      userPassword: null == userPassword
          ? _value.userPassword
          : userPassword // ignore: cast_nullable_to_non_nullable
              as String,
      phoneNumber: null == phoneNumber
          ? _value.phoneNumber
          : phoneNumber // ignore: cast_nullable_to_non_nullable
              as String,
      gender: null == gender
          ? _value.gender
          : gender // ignore: cast_nullable_to_non_nullable
              as String,
      genderList: null == genderList
          ? _value._genderList
          : genderList // ignore: cast_nullable_to_non_nullable
              as List<String>,
      errorMessage: null == errorMessage
          ? _value.errorMessage
          : errorMessage // ignore: cast_nullable_to_non_nullable
              as String,
      passwordVisible: null == passwordVisible
          ? _value.passwordVisible
          : passwordVisible // ignore: cast_nullable_to_non_nullable
              as bool,
      isEmailExist: null == isEmailExist
          ? _value.isEmailExist
          : isEmailExist // ignore: cast_nullable_to_non_nullable
              as bool,
      status: null == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as FormzSubmissionStatus,
    ));
  }
}

/// @nodoc

class _$_RegistrationPageState implements _RegistrationPageState {
  const _$_RegistrationPageState(
      {this.userName = "",
      this.userEmail = "",
      this.userPassword = "",
      this.phoneNumber = "",
      this.gender = "",
      final List<String> genderList = const ['Male', 'Female'],
      this.errorMessage = "",
      this.passwordVisible = true,
      this.isEmailExist = false,
      this.status = FormzSubmissionStatus.initial})
      : _genderList = genderList;

  @override
  @JsonKey()
  final String userName;
  @override
  @JsonKey()
  final String userEmail;
  @override
  @JsonKey()
  final String userPassword;
  @override
  @JsonKey()
  final String phoneNumber;
  @override
  @JsonKey()
  final String gender;
  final List<String> _genderList;
  @override
  @JsonKey()
  List<String> get genderList {
    if (_genderList is EqualUnmodifiableListView) return _genderList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_genderList);
  }

  @override
  @JsonKey()
  final String errorMessage;
  @override
  @JsonKey()
  final bool passwordVisible;
  @override
  @JsonKey()
  final bool isEmailExist;
  @override
  @JsonKey()
  final FormzSubmissionStatus status;

  @override
  String toString() {
    return 'RegistrationPageState(userName: $userName, userEmail: $userEmail, userPassword: $userPassword, phoneNumber: $phoneNumber, gender: $gender, genderList: $genderList, errorMessage: $errorMessage, passwordVisible: $passwordVisible, isEmailExist: $isEmailExist, status: $status)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_RegistrationPageState &&
            (identical(other.userName, userName) ||
                other.userName == userName) &&
            (identical(other.userEmail, userEmail) ||
                other.userEmail == userEmail) &&
            (identical(other.userPassword, userPassword) ||
                other.userPassword == userPassword) &&
            (identical(other.phoneNumber, phoneNumber) ||
                other.phoneNumber == phoneNumber) &&
            (identical(other.gender, gender) || other.gender == gender) &&
            const DeepCollectionEquality()
                .equals(other._genderList, _genderList) &&
            (identical(other.errorMessage, errorMessage) ||
                other.errorMessage == errorMessage) &&
            (identical(other.passwordVisible, passwordVisible) ||
                other.passwordVisible == passwordVisible) &&
            (identical(other.isEmailExist, isEmailExist) ||
                other.isEmailExist == isEmailExist) &&
            (identical(other.status, status) || other.status == status));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType,
      userName,
      userEmail,
      userPassword,
      phoneNumber,
      gender,
      const DeepCollectionEquality().hash(_genderList),
      errorMessage,
      passwordVisible,
      isEmailExist,
      status);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_RegistrationPageStateCopyWith<_$_RegistrationPageState> get copyWith =>
      __$$_RegistrationPageStateCopyWithImpl<_$_RegistrationPageState>(
          this, _$identity);
}

abstract class _RegistrationPageState implements RegistrationPageState {
  const factory _RegistrationPageState(
      {final String userName,
      final String userEmail,
      final String userPassword,
      final String phoneNumber,
      final String gender,
      final List<String> genderList,
      final String errorMessage,
      final bool passwordVisible,
      final bool isEmailExist,
      final FormzSubmissionStatus status}) = _$_RegistrationPageState;

  @override
  String get userName;
  @override
  String get userEmail;
  @override
  String get userPassword;
  @override
  String get phoneNumber;
  @override
  String get gender;
  @override
  List<String> get genderList;
  @override
  String get errorMessage;
  @override
  bool get passwordVisible;
  @override
  bool get isEmailExist;
  @override
  FormzSubmissionStatus get status;
  @override
  @JsonKey(ignore: true)
  _$$_RegistrationPageStateCopyWith<_$_RegistrationPageState> get copyWith =>
      throw _privateConstructorUsedError;
}
