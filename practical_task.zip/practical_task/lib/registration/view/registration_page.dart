import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:formz/formz.dart';
import 'package:practical_task/home_page/view/home_page.dart';
import 'package:practical_task/registration/cubit/registration_page_cubit.dart';
import 'package:practical_task/utils/app_colors.dart';
import 'package:practical_task/utils/string.dart';
import 'package:practical_task/utils/ui_text_style.dart';

import '../../utils/custom_drop_down.dart';
import '../../utils/utils.dart';

class RegistrationPage extends StatelessWidget {
  const RegistrationPage({super.key});

  static Route<void> route() => MaterialPageRoute<void>(
        builder: (_) => BlocProvider(create: (context) => RegistrationPageCubit(), child: const RegistrationPage()),
      );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      appBar: AppBar(
        backgroundColor: AppColor.pinkColor,
        title: Text(
          ConstantString.appName,
          style: UITextStyle.regularTextStyle(fontSize: 14, color: AppColor.whiteColor),
        ),
      ),
      body: BlocProvider(
        create: (context) => RegistrationPageCubit(),
        child: BlocListener<RegistrationPageCubit, RegistrationPageState>(
          listenWhen: (previous, current) => current.status != previous.status,
          listener: (context, state) {
            if (state.status.isSuccess) {
                 Navigator.pushAndRemoveUntil(
                context,
                HomePage.route(),
                (route) => false,
              );
            } else if (state.status.isInProgress) {
              //   ProgressHUD.of(context)?.show();
            } else if (state.status.isFailure) {
              SnackBarUtils.showSnackBar(context, state.errorMessage);
            }
          },
          child: BlocBuilder<RegistrationPageCubit, RegistrationPageState>(
            builder: (context, state) {
              return Padding(
                padding: const EdgeInsets.all(10.0),
                child: Column(
                  children: [
                    const SizedBox(
                      height: 20,
                    ),
                    TextField(
                      onChanged: (value) => context.read<RegistrationPageCubit>().nameChanged(value),
                      keyboardType: TextInputType.text,
                      textInputAction: TextInputAction.next,
                      decoration:  InputDecoration(
                        labelText: ConstantString.name,
                        hintText: ConstantString.name,
                        border: const OutlineInputBorder(),
                        labelStyle: UITextStyle.regularTextStyle(fontSize: 14, color: AppColor.blackColor),
                      ),
                    ),
                    const SizedBox(
                      height: 20,
                    ),
                    TextField(
                      inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                      onChanged: (value) => context.read<RegistrationPageCubit>().phoneChange(value),
                      keyboardType: TextInputType.phone,
                      textInputAction: TextInputAction.next,
                      decoration:  InputDecoration(
                        labelText: ConstantString.phoneNumber,
                        hintText: ConstantString.phoneNumber,
                        border: const OutlineInputBorder(),
                        labelStyle: UITextStyle.regularTextStyle(fontSize: 14, color: AppColor.blackColor),
                      ),
                    ),
                    const SizedBox(
                      height: 20,
                    ),
                    TextField(
                      onChanged: (value) => context.read<RegistrationPageCubit>().emailChanged(value),
                      keyboardType: TextInputType.emailAddress,
                      textInputAction: TextInputAction.next,
                      decoration:  InputDecoration(
                        border: const OutlineInputBorder(),
                        labelText: ConstantString.email,
                        hintText: ConstantString.email,
                        labelStyle: UITextStyle.regularTextStyle(fontSize: 14, color: AppColor.blackColor),
                      ),
                    ),
                    const SizedBox(
                      height: 20,
                    ),
                    const _GenderInput(),
                    const SizedBox(
                      height: 20,
                    ),
                    TextField(
                      onChanged: (value) => context.read<RegistrationPageCubit>().passwordChange(value),
                      keyboardType: TextInputType.visiblePassword,
                      textInputAction: TextInputAction.done,
                      obscureText: state.passwordVisible,
                      decoration: InputDecoration(
                        border: const OutlineInputBorder(),
                        labelText: ConstantString.password,
                        hintText: ConstantString.password,
                        suffixIcon: IconButton(
                          icon: state.passwordVisible ? const Icon(Icons.visibility_off) : const Icon(Icons.visibility),
                          onPressed: () {
                            context.read<RegistrationPageCubit>().togglePasswordVisibility();
                          },
                        ),
                        labelStyle: UITextStyle.regularTextStyle(fontSize: 14, color: AppColor.blackColor),
                      ),
                    ),
                    const SizedBox(
                      height: 20,
                    ),
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        onPressed: () async {
                          final loginPageCubit = context.read<RegistrationPageCubit>();
                          if (state.userName.isEmpty) {
                            SnackBarUtils.showSnackBar(context, ConstantString.emptyNameError);
                          } else if (state.phoneNumber.isEmpty) {
                            SnackBarUtils.showSnackBar(context, ConstantString.emptyPhoneError);
                          } else if (!loginPageCubit.checkPhone(state.phoneNumber)) {
                            SnackBarUtils.showSnackBar(context, ConstantString.invalidPhoneError);
                          } else if (state.userEmail.isEmpty) {
                            SnackBarUtils.showSnackBar(context, ConstantString.emptyEmailError);
                          } else if (!loginPageCubit.checkEmail(state.userEmail)) {
                            SnackBarUtils.showSnackBar(context, ConstantString.invalidEmailError);
                          } else if (state.userPassword.isEmpty) {
                            SnackBarUtils.showSnackBar(context, ConstantString.emptyPasswordError);
                          } else if (!loginPageCubit.checkPassword(state.userPassword)) {
                            SnackBarUtils.showSnackBar(context, ConstantString.invalidPasswordError);
                          } else {
                            await loginPageCubit.signUpUser(name: state.userName, email: state.userEmail, password: state.userPassword, phoneNumber: state.phoneNumber,gender:state.gender);
                            loginPageCubit.registrationSuccess(userEmail: state.userEmail);
                          }
                        },
                        child: Text(
                          ConstantString.register,
                          style: UITextStyle.regularTextStyle(fontSize: 16),
                        ),
                      ),
                    )
                  ],
                ),
              );
            },
          ),
        ),
      ),
    );
  }
}

class _GenderInput extends StatelessWidget {
  const _GenderInput({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<RegistrationPageCubit, RegistrationPageState>(
      builder: (context, state) {
        return CustomBorderedDropdown(
          hintText: ConstantString.gender,
          optionsList: state.genderList,
          onValueChanged: (String? value) {
            context.read<RegistrationPageCubit>().onGenderValueChanged(value ?? '');
          },
        );
      },
    );
  }
}
