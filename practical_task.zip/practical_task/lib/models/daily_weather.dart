import 'package:freezed_annotation/freezed_annotation.dart';
part 'daily_weather.g.dart';
@JsonSerializable()
class DailyWeatherData {
  String? cod;
  int? message;
  int? cnt;
  List<WeatherList>? list;
  City? city;

  DailyWeatherData({this.cod, this.message, this.cnt, this.list, this.city});

  factory DailyWeatherData.fromJson(Map<String, dynamic> json) => _$DailyWeatherDataFromJson(json);

  /// Connect the generated [_$DailyWeatherDataToJson] function to the `toJson` method.
  Map<String, dynamic> toJson() => _$DailyWeatherDataToJson(this);
}

@JsonSerializable()
class WeatherList {
  int? dt;
  DailyMain? main;
  List<DailyWeather>? weather;
  DailyClouds? clouds;
  DailyWind? wind;
  int? visibility;
  dynamic pop;
  DailySys? sys;
  String? dtTxt;

  WeatherList(
      {this.dt,
      this.main,
      this.weather,
      this.clouds,
      this.wind,
      this.visibility,
      this.pop,
      this.sys,
      this.dtTxt});

  factory WeatherList.fromJson(Map<String, dynamic> json) => _$WeatherListFromJson(json);

  /// Connect the generated [_$WeatherListToJson] function to the `toJson` method.
  Map<String, dynamic> toJson() => _$WeatherListToJson(this);
}

@JsonSerializable()
class DailyMain {
  dynamic? temp;
  dynamic feelsLike;
  dynamic? tempMin;
  dynamic tempMax;
  int? pressure;
  int? seaLevel;
  int? grndLevel;
  int? humidity;
  dynamic tempKf;

  DailyMain(
      {this.temp,
      this.feelsLike,
      this.tempMin,
      this.tempMax,
      this.pressure,
      this.seaLevel,
      this.grndLevel,
      this.humidity,
      this.tempKf});

  factory DailyMain.fromJson(Map<String, dynamic> json) => _$DailyMainFromJson(json);

  /// Connect the generated [_$DailyMainToJson] function to the `toJson` method.
  Map<String, dynamic> toJson() => _$DailyMainToJson(this);
}

@JsonSerializable()
class DailyWeather {
  int? id;
  String? main;
  String? description;
  String? icon;

  DailyWeather({this.id, this.main, this.description, this.icon});

  factory DailyWeather.fromJson(Map<String, dynamic> json) => _$DailyWeatherFromJson(json);

  /// Connect the generated [_$DailyWeatherToJson] function to the `toJson` method.
  Map<String, dynamic> toJson() => _$DailyWeatherToJson(this);
}

@JsonSerializable()
class DailyClouds {
  int? all;

  DailyClouds({this.all});

  factory DailyClouds.fromJson(Map<String, dynamic> json) => _$DailyCloudsFromJson(json);

  /// Connect the generated [_$DailyCloudsToJson] function to the `toJson` method.
  Map<String, dynamic> toJson() => _$DailyCloudsToJson(this);
}

@JsonSerializable()
class DailyWind {
  dynamic speed;
  int? deg;
  dynamic gust;

  DailyWind({this.speed, this.deg, this.gust});

  factory DailyWind.fromJson(Map<String, dynamic> json) => _$DailyWindFromJson(json);

  /// Connect the generated [_$DailyWindToJson] function to the `toJson` method.
  Map<String, dynamic> toJson() => _$DailyWindToJson(this);
}

@JsonSerializable()
class DailySys {
  String? pod;

  DailySys({this.pod});

  factory DailySys.fromJson(Map<String, dynamic> json) => _$DailySysFromJson(json);

  /// Connect the generated [_$DailySysToJson] function to the `toJson` method.
  Map<String, dynamic> toJson() => _$DailySysToJson(this);
}

@JsonSerializable()
class City {
  int? id;
  String? name;
  DailyCoord? coord;
  String? country;
  int? population;
  int? timezone;
  int? sunrise;
  int? sunset;

  City(
      {this.id,
      this.name,
      this.coord,
      this.country,
      this.population,
      this.timezone,
      this.sunrise,
      this.sunset});

  factory City.fromJson(Map<String, dynamic> json) => _$CityFromJson(json);

  /// Connect the generated [_$CityToJson] function to the `toJson` method.
  Map<String, dynamic> toJson() => _$CityToJson(this);
}

@JsonSerializable()
class DailyCoord {
  double? lat;
  double? lon;

  DailyCoord({this.lat, this.lon});

  factory DailyCoord.fromJson(Map<String, dynamic> json) => _$DailyCoordFromJson(json);
  
  Map<String, dynamic> toJson() => _$DailyCoordToJson(this);
}
