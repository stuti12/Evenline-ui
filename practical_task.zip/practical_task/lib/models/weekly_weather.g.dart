// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'weekly_weather.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

WeeklyWeather _$WeeklyWeatherFromJson(Map<String, dynamic> json) =>
    WeeklyWeather(
      cod: json['cod'],
      message: json['message'] as int?,
      cnt: json['cnt'] as int?,
      list: (json['list'] as List<dynamic>?)
          ?.map((e) => WeeklyWeatherList.fromJson(e as Map<String, dynamic>))
          .toList(),
      city: json['city'] == null
          ? null
          : City.fromJson(json['city'] as Map<String, dynamic>),
    );

Map<String, dynamic> _$WeeklyWeatherToJson(WeeklyWeather instance) =>
    <String, dynamic>{
      'cod': instance.cod,
      'message': instance.message,
      'cnt': instance.cnt,
      'list': instance.list,
      'city': instance.city,
    };

WeeklyWeatherList _$WeeklyWeatherListFromJson(Map<String, dynamic> json) =>
    WeeklyWeatherList(
      dt: json['dt'] as int?,
      main: json['main'] == null
          ? null
          : WeeklyWeatherMain.fromJson(json['main'] as Map<String, dynamic>),
      weather: (json['weather'] as List<dynamic>?)
          ?.map((e) => WeeklyWeathers.fromJson(e as Map<String, dynamic>))
          .toList(),
      clouds: json['clouds'] == null
          ? null
          : WeeklyClouds.fromJson(json['clouds'] as Map<String, dynamic>),
      wind: json['wind'] == null
          ? null
          : WeeklyWind.fromJson(json['wind'] as Map<String, dynamic>),
      visibility: json['visibility'] as int?,
      pop: json['pop'],
      sys: json['sys'] == null
          ? null
          : WeeklyWeatherSys.fromJson(json['sys'] as Map<String, dynamic>),
      dtTxt: json['dtTxt'] as String?,
    );

Map<String, dynamic> _$WeeklyWeatherListToJson(WeeklyWeatherList instance) =>
    <String, dynamic>{
      'dt': instance.dt,
      'main': instance.main,
      'weather': instance.weather,
      'clouds': instance.clouds,
      'wind': instance.wind,
      'visibility': instance.visibility,
      'pop': instance.pop,
      'sys': instance.sys,
      'dtTxt': instance.dtTxt,
    };

WeeklyWeatherMain _$WeeklyWeatherMainFromJson(Map<String, dynamic> json) =>
    WeeklyWeatherMain(
      temp: json['temp'],
      feelsLike: json['feelsLike'],
      tempMin: json['tempMin'],
      tempMax: json['tempMax'],
      pressure: json['pressure'] as int?,
      seaLevel: json['seaLevel'] as int?,
      grndLevel: json['grndLevel'] as int?,
      humidity: json['humidity'] as int?,
      tempKf: json['tempKf'],
    );

Map<String, dynamic> _$WeeklyWeatherMainToJson(WeeklyWeatherMain instance) =>
    <String, dynamic>{
      'temp': instance.temp,
      'feelsLike': instance.feelsLike,
      'tempMin': instance.tempMin,
      'tempMax': instance.tempMax,
      'pressure': instance.pressure,
      'seaLevel': instance.seaLevel,
      'grndLevel': instance.grndLevel,
      'humidity': instance.humidity,
      'tempKf': instance.tempKf,
    };

WeeklyWeathers _$WeeklyWeathersFromJson(Map<String, dynamic> json) =>
    WeeklyWeathers(
      id: json['id'] as int?,
      main: json['main'] as String?,
      description: json['description'] as String?,
      icon: json['icon'] as String?,
    );

Map<String, dynamic> _$WeeklyWeathersToJson(WeeklyWeathers instance) =>
    <String, dynamic>{
      'id': instance.id,
      'main': instance.main,
      'description': instance.description,
      'icon': instance.icon,
    };

WeeklyClouds _$WeeklyCloudsFromJson(Map<String, dynamic> json) => WeeklyClouds(
      all: json['all'] as int?,
    );

Map<String, dynamic> _$WeeklyCloudsToJson(WeeklyClouds instance) =>
    <String, dynamic>{
      'all': instance.all,
    };

WeeklyWind _$WeeklyWindFromJson(Map<String, dynamic> json) => WeeklyWind(
      speed: json['speed'],
      deg: json['deg'] as int?,
      gust: json['gust'],
    );

Map<String, dynamic> _$WeeklyWindToJson(WeeklyWind instance) =>
    <String, dynamic>{
      'speed': instance.speed,
      'deg': instance.deg,
      'gust': instance.gust,
    };

WeeklyWeatherSys _$WeeklyWeatherSysFromJson(Map<String, dynamic> json) =>
    WeeklyWeatherSys(
      pod: json['pod'] as String?,
    );

Map<String, dynamic> _$WeeklyWeatherSysToJson(WeeklyWeatherSys instance) =>
    <String, dynamic>{
      'pod': instance.pod,
    };

City _$CityFromJson(Map<String, dynamic> json) => City(
      id: json['id'] as int?,
      name: json['name'] as String?,
      coord: json['coord'] == null
          ? null
          : Coord.fromJson(json['coord'] as Map<String, dynamic>),
      country: json['country'] as String?,
      population: json['population'] as int?,
      timezone: json['timezone'] as int?,
      sunrise: json['sunrise'] as int?,
      sunset: json['sunset'] as int?,
    );

Map<String, dynamic> _$CityToJson(City instance) => <String, dynamic>{
      'id': instance.id,
      'name': instance.name,
      'coord': instance.coord,
      'country': instance.country,
      'population': instance.population,
      'timezone': instance.timezone,
      'sunrise': instance.sunrise,
      'sunset': instance.sunset,
    };

Coord _$CoordFromJson(Map<String, dynamic> json) => Coord(
      lat: (json['lat'] as num?)?.toDouble(),
      lon: (json['lon'] as num?)?.toDouble(),
    );

Map<String, dynamic> _$CoordToJson(Coord instance) => <String, dynamic>{
      'lat': instance.lat,
      'lon': instance.lon,
    };
