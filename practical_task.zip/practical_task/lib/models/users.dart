import 'package:json_annotation/json_annotation.dart';

part 'users.g.dart';

@JsonSerializable(explicitToJson: true)
class Users {
  @JsonKey(name: 'name')
  final String? name;

  @JsonKey(name: 'email')
  final String? email;

  @JsonKey(name: 'password')
  final String? password;

  @JsonKey(name: 'phoneNumber')
  final String? phoneNumber;

  @JsonKey(name: 'gender')
  final String? gender;

  const Users({this.name, required this.email, required this.password,required this.phoneNumber,this.gender});

  factory Users.fromJson(Map<String, dynamic> json) => _$UsersFromJson(json);

  Map<String, dynamic> toJson() => _$UsersToJson(this);
}
