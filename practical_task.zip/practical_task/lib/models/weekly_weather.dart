import 'package:freezed_annotation/freezed_annotation.dart';
part 'weekly_weather.g.dart';
@JsonSerializable()
class WeeklyWeather {
  dynamic cod;
  int? message;
  int? cnt;
  List<WeeklyWeatherList>? list;
  City? city;

  WeeklyWeather({this.cod, this.message, this.cnt, this.list, this.city});

  factory WeeklyWeather.fromJson(Map<String, dynamic> json) => _$WeeklyWeatherFromJson(json);

  /// Connect the generated [_$WeeklyWeatherToJson] function to the `toJson` method.
  Map<String, dynamic> toJson() => _$WeeklyWeatherToJson(this);
}

@JsonSerializable()
class WeeklyWeatherList {
  int? dt;
  WeeklyWeatherMain? main;
  List<WeeklyWeathers>? weather;
  WeeklyClouds? clouds;
  WeeklyWind? wind;
  int? visibility;
  dynamic pop;
  WeeklyWeatherSys? sys;
  String? dtTxt;

  WeeklyWeatherList(
      {this.dt,
      this.main,
      this.weather,
      this.clouds,
      this.wind,
      this.visibility,
      this.pop,
      this.sys,
      this.dtTxt});

  factory WeeklyWeatherList.fromJson(Map<String, dynamic> json) => _$WeeklyWeatherListFromJson(json);

  /// Connect the generated [_$WeeklyWeatherListToJson] function to the `toJson` method.
  Map<String, dynamic> toJson() => _$WeeklyWeatherListToJson(this);
}

@JsonSerializable()
class WeeklyWeatherMain {
  dynamic temp;
  dynamic feelsLike;
  dynamic tempMin;
  dynamic tempMax;
  int? pressure;
  int? seaLevel;
  int? grndLevel;
  int? humidity;
  dynamic tempKf;

  WeeklyWeatherMain(
      {this.temp,
      this.feelsLike,
      this.tempMin,
      this.tempMax,
      this.pressure,
      this.seaLevel,
      this.grndLevel,
      this.humidity,
      this.tempKf});

  factory WeeklyWeatherMain.fromJson(Map<String, dynamic> json) => _$WeeklyWeatherMainFromJson(json);
  Map<String, dynamic> toJson() => _$WeeklyWeatherMainToJson(this);
}

@JsonSerializable()
class WeeklyWeathers {
  int? id;
  String? main;
  String? description;
  String? icon;

  WeeklyWeathers({this.id, this.main, this.description, this.icon});

  factory WeeklyWeathers.fromJson(Map<String, dynamic> json) => _$WeeklyWeathersFromJson(json);

  Map<String, dynamic> toJson() => _$WeeklyWeathersToJson(this);
}

@JsonSerializable()
class WeeklyClouds {
  int? all;

  WeeklyClouds({this.all});

  factory WeeklyClouds.fromJson(Map<String, dynamic> json) => _$WeeklyCloudsFromJson(json);
  
  Map<String, dynamic> toJson() => _$WeeklyCloudsToJson(this);
}

@JsonSerializable()
class WeeklyWind {
  dynamic speed;
  int? deg;
  dynamic gust;

  WeeklyWind({this.speed, this.deg, this.gust});

  factory WeeklyWind.fromJson(Map<String, dynamic> json) => _$WeeklyWindFromJson(json);
  
  Map<String, dynamic> toJson() => _$WeeklyWindToJson(this);
}

@JsonSerializable()
class WeeklyWeatherSys {
  String? pod;

  WeeklyWeatherSys({this.pod});

  factory WeeklyWeatherSys.fromJson(Map<String, dynamic> json) => _$WeeklyWeatherSysFromJson(json);
  
  Map<String, dynamic> toJson() => _$WeeklyWeatherSysToJson(this);
}

@JsonSerializable()
class City {
  int? id;
  String? name;
  Coord? coord;
  String? country;
  int? population;
  int? timezone;
  int? sunrise;
  int? sunset;

  City(
      {this.id,
      this.name,
      this.coord,
      this.country,
      this.population,
      this.timezone,
      this.sunrise,
      this.sunset});

  factory City.fromJson(Map<String, dynamic> json) => _$CityFromJson(json);
  Map<String, dynamic> toJson() => _$CityToJson(this);
}

@JsonSerializable()
class Coord {
  double? lat;
  double? lon;

  Coord({this.lat, this.lon});

  factory Coord.fromJson(Map<String, dynamic> json) => _$CoordFromJson(json);

  /// Connect the generated [_$CoordToJson] function to the `toJson` method.
  Map<String, dynamic> toJson() => _$CoordToJson(this);
}
