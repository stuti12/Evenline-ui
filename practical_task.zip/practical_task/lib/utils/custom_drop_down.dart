import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:practical_task/utils/ui_text_style.dart';
import 'app_colors.dart';

class CustomBorderedDropdown extends StatefulWidget {
  final String hintText;
  final String? suffixIcon;
  final List<String> optionsList;
  final String? selectedValue;
  final bool isEmpty;
  final Function(String?)? onValueChanged;

  const CustomBorderedDropdown(
      {super.key,
      required this.hintText,
      this.suffixIcon,
      required this.optionsList,
      this.onValueChanged,
      this.selectedValue,
      this.isEmpty = true});

  @override
  _CustomBorderedDropdownState createState() => _CustomBorderedDropdownState();
}

class _CustomBorderedDropdownState extends State<CustomBorderedDropdown> {
  String? _selectedValue;
  bool isEmpty = true;

  @override
  void initState() {
    setState(() {
      isEmpty = widget.isEmpty;
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 55.h,
      child: InputDecorator(
        isEmpty: isEmpty,
        decoration: InputDecoration(
          isDense: true,
          hintText: widget.hintText,
          labelText: widget.hintText,
          //contentPadding: EdgeInsets.only(top: 10.h,right: 16.w),
          hintStyle: UITextStyle.regularTextStyle(
            color: AppColor.blackColor,
            fontWeight: FontWeight.w400,
            fontSize: 16,
          ),

          border: OutlineInputBorder(
              borderSide: BorderSide(color: AppColor.blackColor), borderRadius: BorderRadius.all(Radius.circular(5.r),),),
          enabledBorder: OutlineInputBorder(
              borderSide: BorderSide(color: AppColor.blackColor), borderRadius: BorderRadius.all(Radius.circular(5.r),),),
          focusedBorder: OutlineInputBorder(
              borderSide: BorderSide(color: AppColor.blackColor), borderRadius: BorderRadius.all(Radius.circular(5.r),),),
        ),
        child: Theme(
          data: Theme.of(context).copyWith(
              splashColor: AppColor.transparentColor, highlightColor: AppColor.transparentColor, hoverColor: AppColor.transparentColor),
          child: DropdownButtonHideUnderline(
            child: DropdownButton<String>(
              value: _selectedValue ?? widget.selectedValue,
              icon: Icon(
               Icons.arrow_drop_down,
                color: AppColor.blackColor,
              ),
              style: UITextStyle.regularTextStyle(color: AppColor.blackColor, fontWeight: FontWeight.w400, fontSize: 16,),
              onChanged: (String? newValue) {
                setState(() {
                  _selectedValue = widget.selectedValue;
                  _selectedValue = newValue;
                  isEmpty = false;
                });
                widget.onValueChanged!(newValue);
              },
              items: widget.optionsList.map((String option) {
                return DropdownMenuItem<String>(
                  value: option,
                  child: SizedBox(
                    width: 0.22.sw,
                    child: Text(
                      option,
                      overflow: TextOverflow.clip,
                      style: UITextStyle.regularTextStyle(color: AppColor.blackColor, fontWeight: FontWeight.w400, fontSize: 16,),
                    ),
                  ),
                );
              }).toList(),
            ),
          ),
        ),
      ),
    );
  }
}
