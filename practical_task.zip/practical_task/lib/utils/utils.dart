import 'package:flutter/material.dart';

import 'app_colors.dart';

class SnackBarUtils {
  static void showSnackBar(
    BuildContext context,
    String message, {
    int duration = 2,
    SnackBarAction? action,
    TextStyle? textStyle,
    Color? backgroundColor,
  }) {
    if (message.isEmpty) {
      return;
    }

    final snackBar = SnackBar(
      content: Text(
        message,
        style: textStyle ??
            const TextStyle(
              fontWeight: FontWeight.w500,
              fontSize: 14,
              color: Colors.white,
            ),
      ),
      backgroundColor: backgroundColor ?? Colors.black,
      duration: Duration(seconds: duration),
      action: action,
    );

    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(snackBar);
  }
}

class RegularExpressions {
  static const String email = r'[a-zA-Z0-9._-]+@[a-z]+\.+[a-z]+';
  static const String mobileNumber = r'^\d{10}$';
  static const String password = r'^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,}$';
}

class GradientWidgetToday {
  static LinearGradient linearGradient() => LinearGradient(colors: [
    AppColor.dividerColor,
    AppColor.hintTextColor,
  ]);
}
