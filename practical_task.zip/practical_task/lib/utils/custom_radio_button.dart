import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:practical_task/utils/ui_text_style.dart';

import 'app_colors.dart';

class CustomRadioListTile extends StatelessWidget {
  final String title;
  final String value;
  final Color? activeColor;
  final String? groupValue;
  final ValueChanged<String?> onChanged;

  const CustomRadioListTile({
    Key? key,
    required this.title,
    required this.value,
    this.activeColor,
    required this.groupValue,
    required this.onChanged,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final isSelected = value == groupValue;
    return Container(
      margin: const EdgeInsets.all(8),
      child: ListTile(
        minLeadingWidth: 10.w,
        horizontalTitleGap: 20.w,
        onTap: () {
          onChanged(value);
        },
        contentPadding: EdgeInsets.symmetric(horizontal: 15.w),
        shape: OutlineInputBorder(
          borderRadius: BorderRadius.circular(5),
          borderSide: const BorderSide(width: 0.6, color: Color(0xff8E8383)),
        ),
        leading: isSelected
            ? const Icon(Icons.circle_outlined)
            : const Icon(Icons.check_circle),
        title: Align(
          alignment: const Alignment(-1.1, 0),
          child: Text(
            title,
            style: UITextStyle.regularTextStyle(
              color: AppColor.blackColor,
              fontWeight: FontWeight.w400,
              fontSize: 16.sp,
            ),
          ),
        ),
      ),
    );
  }
}
