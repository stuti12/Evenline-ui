class AppImage {
  static const String _prefixPath = 'assets/images';
  static String icPlaceholder = '$_prefixPath/ic_cloudy.png';
  static String imgMoon = '${AppImage._prefixPath}/img_moon.png';
  static String imgSun = '${AppImage._prefixPath}/img_sun.png';
  static String imgIconSun = '${AppImage._prefixPath}/ic_sun.png';
  static String imgProfile = '${AppImage._prefixPath}/ic_profile.png';
  static String imgCloud = '${AppImage._prefixPath}/img_cloud.png';
  static String iconCloud = '${AppImage._prefixPath}/ic_cloudy.png';
  static String imgRainy = '${AppImage._prefixPath}/ic_rainy.png';
  static String imgTodayWeather = '${AppImage._prefixPath}/img_today_weather.png';
  static String imgPrecipitation = '${AppImage._prefixPath}/img_precipitation.png';
}
