import 'package:flutter/material.dart';

class AppColor {
  static Color primaryColor = const Color(0xFF000000);
  static Color whiteColor = Colors.white;
  static Color pinkColor = Colors.pink.withOpacity(0.2);
  static Color textColor = const Color(0xFF000000);
  static Color hintTextColor = const Color(0xFF979797);
  static Color dividerColor = const Color(0xFFD9D9D9);
  static Color transparentColor = Colors.transparent;
  static Color blackColor = const Color(0xFF000000);
}
