import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_simple_dependency_injection/injector.dart';
import 'package:flutter_stripe/flutter_stripe.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:nextry_dev/di/module_container.dart';
import 'package:nextry_dev/localization/app_localizations.dart';
import 'package:nextry_dev/localization/localization_manager.dart';
import 'package:nextry_dev/localization/string_keys.dart';
import 'package:nextry_dev/presentation/provider/ad_provider.dart';
import 'package:nextry_dev/presentation/provider/add_category_provider.dart';
import 'package:nextry_dev/presentation/provider/app_provider.dart';
import 'package:nextry_dev/presentation/provider/ask_us_provider.dart';
import 'package:nextry_dev/presentation/provider/business_provider.dart';
import 'package:nextry_dev/presentation/provider/card_provider.dart';
import 'package:nextry_dev/presentation/provider/cart_provider_update.dart';
import 'package:nextry_dev/presentation/provider/category_provider.dart';
import 'package:nextry_dev/presentation/provider/configuration_provider.dart';
import 'package:nextry_dev/presentation/provider/customer_order_provider.dart';
import 'package:nextry_dev/presentation/provider/dashboard_provider.dart';
import 'package:nextry_dev/presentation/provider/delivery_offer_provider.dart';
import 'package:nextry_dev/presentation/provider/delivery_provider.dart';
import 'package:nextry_dev/presentation/provider/drawer_provider.dart';
import 'package:nextry_dev/presentation/provider/feedback_provider.dart';
import 'package:nextry_dev/presentation/provider/home_provider.dart';
import 'package:nextry_dev/presentation/provider/invoice_provider.dart';
import 'package:nextry_dev/presentation/provider/language_provider.dart';
import 'package:nextry_dev/presentation/provider/live_location_provider.dart';
import 'package:nextry_dev/presentation/provider/location_provider.dart';
import 'package:nextry_dev/presentation/provider/notification_provider.dart';
import 'package:nextry_dev/presentation/provider/order_delivery_provider.dart';
import 'package:nextry_dev/presentation/provider/orders_provider.dart';
import 'package:nextry_dev/presentation/provider/payment_provider.dart';
import 'package:nextry_dev/presentation/provider/product_detail_provider.dart';
import 'package:nextry_dev/presentation/provider/product_provider.dart';
import 'package:nextry_dev/presentation/provider/refund_provider.dart';
import 'package:nextry_dev/presentation/provider/selection_business_provider.dart';
import 'package:nextry_dev/presentation/provider/shipper_feedback_provider.dart';
import 'package:nextry_dev/presentation/provider/shipper_order_provider.dart';
import 'package:nextry_dev/presentation/provider/shipper_provider.dart';
import 'package:nextry_dev/presentation/provider/subscription_provider.dart';
import 'package:nextry_dev/presentation/provider/tab_selection_provider.dart';
import 'package:nextry_dev/presentation/provider/transaction_history_provider.dart';
import 'package:nextry_dev/presentation/provider/update_business_status_provider.dart';
import 'package:nextry_dev/presentation/provider/user_provider.dart';
import 'package:nextry_dev/presentation/provider/wallet_provider.dart';
import 'package:nextry_dev/presentation/screens/splash/auto_login_screen.dart';
import 'package:nextry_dev/push/pushnotificationservice.dart';
import 'package:provider/provider.dart';
import 'package:upgrader/upgrader.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  ModuleContainer().initialise(Injector());
  MobileAds.instance.initialize();
  Upgrader.sharedInstance.debugLogging = kDebugMode;
  PushNotificationService.getInstance().init();
  FirebaseMessaging.onBackgroundMessage(_firebaseMessagingBackgroundHandler);
  //TODO update stripe publish key
  Stripe.publishableKey =
      "pk_test_51N1a6mA96WVwXAJrCS15LnSmeJJz1xMqQhQGH3ZrsPRLgDVGHzhXCmbtYg6DwuN6px2pLkH5eq646XHXlIdMww6000Qw4opwlr";

  runApp(const MyApp());
}

Future<void> _firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  // If you're going to use other Firebase services in the background, such as Firestore,
  // make sure you call `initializeApp` before using other Firebase services.
  await Firebase.initializeApp();
  print("Handling a background message: ${message.data}");
  if (message.data.isNotEmpty) {
    PushNotificationService.getInstance().showNotification(
        PushNotificationService.NOTIFICATION_ID,
        message.data[PushNotificationService.NOTIFICATION_TITLE],
        message.data[PushNotificationService.NOTIFICATION_BODY],
        message.data[PushNotificationService.NOTIFICATION_PAYLOAD],
        addNotificationToTray: false);
  }
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  /// To Change Locale of App
  static void setLocale(BuildContext context, Locale newLocale) async {
    _MyAppState? state = context.findAncestorStateOfType<_MyAppState>();

    LocalizationManager.setLocaleLanguage(newLocale.languageCode);

    state?.setState(() {
      state._locale = newLocale;
    });
  }

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  // This widget is the root of your application.

  Locale _locale = const Locale(StringKeys.ENGLISH_LANGUAGE_CODE, '');

  @override
  void initState() {
    super.initState();
    getCurrentLocale().then((locale) {
      setState(() {
        _locale = locale;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
      DeviceOrientation.portraitDown,
    ]);
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (ctx) => WalletProvider()),
        ChangeNotifierProvider(create: (ctx) => TransactionHistoryProvider()),
        ChangeNotifierProvider(create: (ctx) => AppProvider()),
        ChangeNotifierProvider(create: (ctx) => InvoiceProvider()),
        ChangeNotifierProvider(create: (ctx) => CategoryProvider()),
        ChangeNotifierProvider(create: (ctx) => LocationProvider()),
        ChangeNotifierProvider(create: (ctx) => UserProvider()),
        ChangeNotifierProvider(create: (ctx) => LanguageProvider()),
        ChangeNotifierProvider(create: (ctx) => TabSelectionProvider()),
        ChangeNotifierProvider(create: (ctx) => BusinessProvider()),
        ChangeNotifierProvider(create: (ctx) => ProductProvider()),
        ChangeNotifierProvider(create: (ctx) => UpdateBusinessStatusProvider()),
        ChangeNotifierProvider(create: (ctx) => AddCategoryProvider()),
        ChangeNotifierProvider(create: (ctx) => SubscriptionProvider()),
        ChangeNotifierProvider(create: (ctx) => OrdersProvider()),
        ChangeNotifierProvider(create: (ctx) => FeedBackProvider()),
        ChangeNotifierProvider(create: (ctx) => AdProvider()),
        ChangeNotifierProvider(create: (ctx) => DashboardProvider()),
        ChangeNotifierProvider(create: (ctx) => HomeProvider()),
        ChangeNotifierProvider(create: (ctx) => ConfigurationProvider()),
        ChangeNotifierProvider(create: (ctx) => SelectionBusinessProvider()),
        ChangeNotifierProvider(create: (ctx) => CardProvider()),
        ChangeNotifierProvider(create: (ctx) => DeliveryProvider()),
        ChangeNotifierProvider(create: (ctx) => ProductDetailProvider()),
        ChangeNotifierProvider(create: (ctx) => PaymentProvider()),
        ChangeNotifierProvider(create: (ctx) => DrawerProvider()),
        ChangeNotifierProvider(create: (ctx) => NotificationProvider()),
        ChangeNotifierProvider(create: (ctx) => ShipperProvider()),
        ChangeNotifierProvider(create: (ctx) => ShipperOrderProvider()),
        ChangeNotifierProvider(create: (ctx) => LiveLocationProvider()),
        ChangeNotifierProvider(create: (ctx) => ShipperFeedBackProvider()),
        ChangeNotifierProvider(create: (ctx) => DeliveryOfferProvider()),
        ChangeNotifierProvider(create: (ctx) => CustomerOrderProvider()),
        ChangeNotifierProvider(create: (ctx) => AskUsProvider()),
        ChangeNotifierProvider(create: (ctx) => RefundProvider()),
        ChangeNotifierProvider(create: (ctx) => OrderDeliveryProvider()),
        ChangeNotifierProvider(create: (ctx) => CartProviderUpdate()),
      ],
      child: ScreenUtilInit(
        designSize: const Size(408, 798),
        useInheritedMediaQuery: true,
        builder: (context, child) {
          return MaterialApp(
            debugShowCheckedModeBanner: false,
            theme: ThemeData(
              primarySwatch: Colors.blue,
            ),
            supportedLocales: [
              Locale(StringKeys.SUPPORTED_LANGUAGES[StringKeys.ENGLISH], ''),
              Locale(StringKeys.SUPPORTED_LANGUAGES[StringKeys.ARABIC], ''),
              Locale(StringKeys.SUPPORTED_LANGUAGES[StringKeys.HEBREW], ''),
              // ADD MORE LOCALES HERE.
            ],
            locale: _locale,
            localizationsDelegates: const [
              AppLocalizations.delegate,
              GlobalMaterialLocalizations.delegate,
              GlobalCupertinoLocalizations.delegate,
              GlobalWidgetsLocalizations.delegate,
            ],
            home: child,
          );
        },
        child: const AutoLoginScreen(),
      ),
    );
  }

  Future<Locale> getCurrentLocale() async {
    String stringValue = await LocalizationManager.getLocaleLanguage();
    return Locale(stringValue, "");
  }
}
