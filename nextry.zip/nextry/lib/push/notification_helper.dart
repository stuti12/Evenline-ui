import 'package:flutter/cupertino.dart';
import 'package:nextry_dev/domain/entities/notification/fetch_notification_entity.dart';
import 'package:nextry_dev/domain/entities/order/order_entity.dart';
import 'package:nextry_dev/presentation/common/utils/app_constants.dart';
import 'package:nextry_dev/presentation/common/utils/app_extension.dart';
import 'package:nextry_dev/presentation/provider/notification_provider.dart';
import 'package:nextry_dev/presentation/screens/business_profile_owner_customer/business_profile_owner_customer_screen.dart';
import 'package:nextry_dev/presentation/screens/delivery_order_detail/my_delivery_orders_screen.dart';
import 'package:nextry_dev/presentation/screens/my_orders/customer_order_details_screen.dart';
import 'package:nextry_dev/presentation/screens/my_orders/owner_order_details_screen.dart';
import 'package:nextry_dev/presentation/screens/request_details/request_details_screen.dart';
import 'package:nextry_dev/presentation/screens/tracking_order_for_shipper/tracking_order_for_shipper_screen.dart';
import 'package:provider/provider.dart';

void handleNotification(
    BuildContext context, FetchNotificationEntity notificationItem) {
  if (notificationItem.type == AppConstants.NOTIFICATION_TYPE_ORDER_PLACED) {
    context.navigateToNextScreen(OwnerOrderDetailsScreen(
        orderEntity: OrderEntity(
            id: notificationItem.orderId,
            businessId: notificationItem.businessId)));
  } else if (notificationItem.type ==
      AppConstants.NOTIFICATION_TYPE_ORDER_STAUS_CHANGED) {
    context.navigateToNextScreen(CustomerOrderDetailsScreen(
        orderEntity: OrderEntity(
            id: notificationItem.orderId,
            businessId: notificationItem.businessId)));
  } else if (notificationItem.type ==
      AppConstants.NOTIFICATION_TYPE_FEEDBACK_ADDED) {
    Provider.of<NotificationProvider>(context, listen: false).fetchBusinessData(
      notificationItem.businessId ?? '',
      (value) async {
        context.navigateToNextScreen(
          BusinessProfileOwnerCustomerScreen(
            businessEntity: value,
            isOwner: true,
            type: AppConstants.NOTIFICATION_TYPE_FEEDBACK_ADDED,
          ),
        );
      },
    );
  } else if (notificationItem.type == AppConstants.NEW_OFFER) {
    Provider.of<NotificationProvider>(context, listen: false)
        .fetchDeliveryRequestData(
      notificationItem.deliveryRequestId ?? '',
      (value) async {
        context.navigateReplaceToNextScreen(
            RequestDetailsScreen(deliveryRequestEntity: value));
      },
    );
  } else if (notificationItem.type ==
      AppConstants.DELIVERY_ORDER_STATUS_CHANGED) {
    Provider.of<NotificationProvider>(context, listen: false)
        .fetchDeliveryOrdersData(
      notificationItem.deliveryOrderId ?? '',
      (value) async {
        print("test");
        context.navigateReplaceToNextScreen(
            MyDeliveryOrderScreen(orderDetailEntity: value));
      },
    );
  } else if (notificationItem.type == AppConstants.NEW_DELIVERY_ORDER) {
    Provider.of<NotificationProvider>(context, listen: false)
        .fetchDeliveryOrdersData(
      notificationItem.deliveryOrderId ?? '',
      (value) async {
        context.navigateReplaceToNextScreen(
            TrackingOrderForShipperScreen(orderDetailEntity: value));
      },
    );
  }
}
