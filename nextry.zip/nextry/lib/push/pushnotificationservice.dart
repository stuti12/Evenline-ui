import 'dart:io';

import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:nextry_dev/domain/entities/notification/fetch_notification_entity.dart';
import 'dart:convert' show json;
import 'package:http/http.dart' as http;
import 'package:nextry_dev/push/notification_helper.dart';

import 'package:path_provider/path_provider.dart';

class PushNotificationService {
  static const NOTIFICATION_ID = 1234;
  static const NOTIFICATION = 'notification';
  static const NOTIFICATION_TITLE = 'title';
  static const NOTIFICATION_BODY = 'body';
  static const NOTIFICATION_PAYLOAD = 'payload';

  static const NOTIFICATION_CHANNEL_ID = 'nextry_channel';
  static const NOTIFICATION_CHANNEL_TITLE = 'Nextry Channel';

  FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin =
      FlutterLocalNotificationsPlugin();

  BuildContext? _buildContext;
  static PushNotificationService? _pushNotificationService;

  static PushNotificationService getInstance() {
    _pushNotificationService ??= PushNotificationService();
    return _pushNotificationService!;
  }

  init() {
    initializeLocalNotification();
    requestPermission();
  }

  setContext(BuildContext context) {
    _buildContext = context;
    _setNotificationListener();
  }

  /// Initialize Local Notification.
  initializeLocalNotification() {
    try {
      var initializationSettingsAndroid =
          const AndroidInitializationSettings('@mipmap/ic_launcher');
      const DarwinInitializationSettings initializationSettingsDarwin =
          DarwinInitializationSettings();
      var initializationSettings = InitializationSettings(
        android: initializationSettingsAndroid,
        iOS: initializationSettingsDarwin,
      );

      flutterLocalNotificationsPlugin.initialize(initializationSettings,
          onDidReceiveNotificationResponse: onTapNotification);
    } catch (e) {
      print("error: ${e.toString()}");
    }
  }

  /// when app is in the foreground
  Future<void> onTapNotification(
      NotificationResponse? notificationResponse) async {
    if (notificationResponse?.payload != null && _buildContext != null) {
      FetchNotificationEntity notificationEntity =
          FetchNotificationEntity.fromJson(
              json.decode(notificationResponse!.payload!));
      handleNotification(_buildContext!, notificationEntity);
    }
  }

  /// when app is in background
  void onBackgroundTapNotification(String payload) {
    if (_buildContext != null) {
      FetchNotificationEntity notificationEntity =
          FetchNotificationEntity.fromJson(json.decode(payload));
      handleNotification(_buildContext!, notificationEntity);
    }
  }

  /// request required permission
  Future<String?> requestPermission() async {
    if (Platform.isIOS) {
      FirebaseMessaging messaging = FirebaseMessaging.instance;

      NotificationSettings settings = await messaging.requestPermission(
        alert: true,
        announcement: false,
        badge: true,
        carPlay: false,
        criticalAlert: false,
        provisional: false,
        sound: true,
      );
      print('User granted permission: ${settings.authorizationStatus}');
      return _fetchFCMToken();
    } else {
      return _fetchFCMToken();
    }
  }

  Future<String?> _fetchFCMToken() async {
    var token = await FirebaseMessaging.instance.getToken();
    print("push token  $token");
    return token;
  }

  void _setNotificationListener() {
    FirebaseMessaging.onMessage.listen((RemoteMessage message) {
      print("onMessage : ${message.data}");
      if (message.notification != null) {
        showNotification(NOTIFICATION_ID, message.notification?.title,
            message.notification?.body, message.data[NOTIFICATION_PAYLOAD],
            addNotificationToTray: true);
      } else {
        showNotification(NOTIFICATION_ID, message.data[NOTIFICATION_TITLE],
            message.data[NOTIFICATION_BODY], message.data[NOTIFICATION_PAYLOAD],
            addNotificationToTray: true);
      }
    });

    FirebaseMessaging.instance
        .getInitialMessage()
        .then((RemoteMessage? message) {
      if (message != null) {
        if (message.data.isNotEmpty) {
          onBackgroundTapNotification(
              message.data[PushNotificationService.NOTIFICATION_PAYLOAD]);
        }
      }
    });

    FirebaseMessaging.onMessageOpenedApp.listen((RemoteMessage message) {
      if (message.data.isNotEmpty) {
        onBackgroundTapNotification(
            message.data[PushNotificationService.NOTIFICATION_PAYLOAD]);
      }
    });
  }

  /// Show local notification when application on foreground.
  Future<void> showNotification(
    int notificationId,
    String? notificationTitle,
    String? notificationContent,
    String? payload, {
    bool addNotificationToTray = true,
    String channelId = NOTIFICATION_CHANNEL_ID,
    String channelTitle = NOTIFICATION_CHANNEL_TITLE,
    Priority notificationPriority = Priority.high,
    Importance notificationImportance = Importance.max,
  }) async {
    if (payload != null) {
      FetchNotificationEntity notificationEntity =
          FetchNotificationEntity.fromJson(json.decode(payload));

      final String bigPicturePath = await _downloadAndSaveFile(
          notificationEntity.image ?? '', 'bigPicture.jpg');

      final BigPictureStyleInformation bigPictureStyleInformation =
          BigPictureStyleInformation(FilePathAndroidBitmap(bigPicturePath),
              hideExpandedLargeIcon: true);

      var androidPlatformChannelSpecifics = AndroidNotificationDetails(
          channelId, channelTitle,
          playSound: true,
          importance: notificationImportance,
          priority: notificationPriority,
          largeIcon: FilePathAndroidBitmap(bigPicturePath),
          styleInformation: bigPictureStyleInformation);

      final DarwinNotificationDetails iOSPlatformChannelSpecifics =
          DarwinNotificationDetails(
              presentSound: true,
              attachments: <DarwinNotificationAttachment>[
            DarwinNotificationAttachment(
              bigPicturePath,
              hideThumbnail: false,
              thumbnailClippingRect:
                  const DarwinNotificationAttachmentThumbnailClippingRect(
                height: 0.5,
                width: 0.5,
                x: 0.5,
                y: 0.5,
              ),
            ),
          ]);
      var platformChannelSpecifics = NotificationDetails(
          android: androidPlatformChannelSpecifics,
          iOS: iOSPlatformChannelSpecifics);

      try {
        if (addNotificationToTray) {
          await flutterLocalNotificationsPlugin.show(
            notificationId,
            notificationTitle,
            notificationContent,
            platformChannelSpecifics,
            payload: payload,
          );
        }
      } on Exception catch (e) {
        print("Exception" + e.toString());
      }
    } else {
      var androidPlatformChannelSpecifics = AndroidNotificationDetails(
        channelId,
        channelTitle,
        playSound: true,
        importance: notificationImportance,
        priority: notificationPriority,
      );

      var iOSPlatformChannelSpecifics =
          const DarwinNotificationDetails(presentSound: true);
      var platformChannelSpecifics = NotificationDetails(
          android: androidPlatformChannelSpecifics,
          iOS: iOSPlatformChannelSpecifics);
      if (addNotificationToTray) {
        await flutterLocalNotificationsPlugin.show(
          notificationId,
          notificationTitle,
          notificationContent,
          platformChannelSpecifics,
          payload: payload,
        );
      }
    }
  }

  Future<String> _downloadAndSaveFile(String url, String fileName) async {
    final Directory directory = await getApplicationDocumentsDirectory();
    final String filePath = '${directory.path}/$fileName';
    final http.Response response = await http.get(Uri.parse(url));
    final File file = File(filePath);
    await file.writeAsBytes(response.bodyBytes);
    return filePath;
  }
}
