import 'package:nextry_dev/domain/entities/cart/fetch_cart_data_by_businessId_response_entity.dart';
import 'package:nextry_dev/domain/entities/cart/fetch_cart_param.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/domain/interactors/cart/fetch_cart_data_by_businessid_interactor.dart';

class FetchCartDataByBusinessIdInteractorImpl
    extends FetchCartDataByBusinessIdInteractor {
  FetchCartDataByBusinessIdInteractorImpl({required this.gateway});

  final ReadGateWay<FetchCartDataByBusinessIdResponseEntity, FetchCartParam>
      gateway;

  @override
  Future<FetchCartDataByBusinessIdResponseEntity> fetchCartDataByBusinessId(
      FetchCartParam param) {
    return gateway.read(param);
  }
}
