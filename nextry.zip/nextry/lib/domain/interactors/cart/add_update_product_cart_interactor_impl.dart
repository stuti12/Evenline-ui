import 'package:nextry_dev/domain/entities/cart/add_update_cart_response_entity.dart';
import 'package:nextry_dev/domain/entities/cart/cart_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/domain/interactors/cart/add_update_product_cart_interactor.dart';

class AddUpdateProductCartInteractorImpl
    extends AddUpdateProductCartInteractor {
  AddUpdateProductCartInteractorImpl({required this.gateway});

  final ReadGateWay<AddUpdateCartResponseEntity, CartEntity> gateway;

  @override
  Future<AddUpdateCartResponseEntity> addUpdateProductCartData(
      CartEntity cartEntity) {
    return gateway.read(cartEntity);
  }
}
