import 'package:nextry_dev/domain/entities/cart/fetch_cart_data_request_param.dart';
import 'package:nextry_dev/domain/entities/cart/fetch_cart_data_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/domain/interactors/cart/fetch_cart_data_interactor.dart';

class FetchCartDataInteractorImpl extends FetchCartDataInteractor {
  FetchCartDataInteractorImpl({required this.gateway});

  final ReadGateWay<FetchCartDataResponseEntity, FetchCartDataRequestParam>
      gateway;

  @override
  Future<FetchCartDataResponseEntity> fetchCartData(
      FetchCartDataRequestParam param) {
    return gateway.read(param);
  }

  @override
  void unsubscribe() {
    gateway.unsubscribe();
  }
}
