import 'package:nextry_dev/domain/entities/cart/add_update_cart_response_entity.dart';
import 'package:nextry_dev/domain/entities/cart/cart_entity.dart';

abstract class AddUpdateProductCartInteractor {
  Future<AddUpdateCartResponseEntity> addUpdateProductCartData(
      CartEntity cartEntity);
}
