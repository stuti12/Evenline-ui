import 'package:nextry_dev/domain/entities/cart/fetch_cart_data_request_param.dart';
import 'package:nextry_dev/domain/entities/cart/fetch_cart_data_response_entity.dart';

abstract class FetchCartDataInteractor {
  Future<FetchCartDataResponseEntity> fetchCartData(FetchCartDataRequestParam param);
  void unsubscribe();
}
