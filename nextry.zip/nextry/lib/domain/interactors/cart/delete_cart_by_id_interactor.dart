import 'package:nextry_dev/domain/entities/cart/delete_cart_param.dart';
import 'package:nextry_dev/domain/entities/cart/delete_cart_response_entity.dart';

abstract class DeleteCartByIdInteractor {
  Future<DeleteCartResponseEntity> deleteCart(DeleteCartParam deleteCartParam);
}
