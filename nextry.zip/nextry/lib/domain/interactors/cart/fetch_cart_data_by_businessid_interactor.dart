import 'package:nextry_dev/domain/entities/cart/fetch_cart_data_by_businessId_response_entity.dart';
import 'package:nextry_dev/domain/entities/cart/fetch_cart_param.dart';

abstract class FetchCartDataByBusinessIdInteractor {
  Future<FetchCartDataByBusinessIdResponseEntity> fetchCartDataByBusinessId(
      FetchCartParam param);
}
