import 'package:nextry_dev/domain/entities/cart/delete_cart_param.dart';
import 'package:nextry_dev/domain/entities/cart/delete_cart_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/domain/interactors/cart/delete_cart_by_id_interactor.dart';

class DeleteCartByIdInteractorImpl extends DeleteCartByIdInteractor {
  DeleteCartByIdInteractorImpl({required this.gateway});

  final ReadGateWay<DeleteCartResponseEntity, DeleteCartParam> gateway;

  @override
  Future<DeleteCartResponseEntity> deleteCart(DeleteCartParam deleteCartParam) {
    return gateway.read(deleteCartParam);
  }
}
