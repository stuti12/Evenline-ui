abstract class PushNotificationInteractor {
  Future<void> sendPushToken(List<String> pushToken);
}
