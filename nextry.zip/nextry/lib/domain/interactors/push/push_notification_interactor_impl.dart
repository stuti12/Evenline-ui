import 'package:nextry_dev/domain/gateway/write_gateway.dart';
import 'package:nextry_dev/domain/interactors/push/push_notification_interactor.dart';

class PushNotificationInteractorImpl extends PushNotificationInteractor {
  PushNotificationInteractorImpl({required this.gateway});

  final WriteGateWay<List<String>> gateway;

  @override
  Future<void> sendPushToken(List<String> pushToken) {
    return gateway.write(pushToken);
  }
}
