import 'package:nextry_dev/domain/entities/invoice/invoice_param.dart';
import 'package:nextry_dev/domain/entities/invoice/invoice_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/domain/interactors/wallet/invoice_interactor.dart';

class InvoiceInteractorImpl implements InvoiceInteractor {
  final ReadGateWay<InvoiceResponseEntity, InvoiceParam> gateWay;

  InvoiceInteractorImpl({required this.gateWay});

  @override
  Future<InvoiceResponseEntity> fetchInvoiceData(InvoiceParam invoiceParam) {
    return gateWay.read(invoiceParam);
  }
}
