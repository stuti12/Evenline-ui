import 'package:nextry_dev/domain/entities/wallet/total_balance_param.dart';
import 'package:nextry_dev/domain/entities/wallet/transaction_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/domain/interactors/wallet/fetch_all_transactions_interactor.dart';

class FetchAllTransactionsInteractorImpl
    implements FetchAllTransactionsInteractor {
  final ReadGateWay<TransactionResponseEntity, TotalBalanceParam> gateWay;

  FetchAllTransactionsInteractorImpl({required this.gateWay});

  @override
  Future<TransactionResponseEntity> fetchFilterData(
      TotalBalanceParam totalBalanceParam) {
    return gateWay.read(totalBalanceParam);
  }
}
