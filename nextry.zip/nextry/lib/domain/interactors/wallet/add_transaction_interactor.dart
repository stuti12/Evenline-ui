import 'package:nextry_dev/domain/entities/wallet/add_transaction_param.dart';

abstract class AddTransactionInteractor {
  Future<void> addTransaction(AddTransactionParam addTransactionParam);
}
