import 'package:nextry_dev/domain/entities/wallet/transaction_history_param.dart';
import 'package:nextry_dev/domain/entities/wallet/transaction_history_response_entity.dart';

abstract class TransactionsHistoryInteractor {
  Future<TransactionHistoryResponseEntity> fetchHistoryFilterData(
      TransactionHistoryParam transactionHistoryParam);
}
