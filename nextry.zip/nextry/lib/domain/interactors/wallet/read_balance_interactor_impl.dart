import 'package:nextry_dev/domain/entities/wallet/balance_param.dart';
import 'package:nextry_dev/domain/entities/wallet/balance_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/domain/interactors/wallet/read_balance_interactor.dart';

class ReadBalanceInteractorImpl implements ReadBalanceInteractor {
  final ReadGateWay<BalanceResponseEntity, BalanceParam> gateWay;

  ReadBalanceInteractorImpl({required this.gateWay});

  @override
  Future<BalanceResponseEntity> fetchBalance(BalanceParam balanceParam) {
    return gateWay.read(balanceParam);
  }
}
