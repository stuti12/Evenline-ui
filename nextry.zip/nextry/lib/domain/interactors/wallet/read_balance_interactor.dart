import 'package:nextry_dev/domain/entities/wallet/balance_param.dart';
import 'package:nextry_dev/domain/entities/wallet/balance_response_entity.dart';

abstract class ReadBalanceInteractor {
  Future<BalanceResponseEntity> fetchBalance(BalanceParam balanceParam);
}
