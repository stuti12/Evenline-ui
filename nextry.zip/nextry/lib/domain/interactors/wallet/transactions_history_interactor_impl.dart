import 'package:nextry_dev/domain/entities/wallet/transaction_history_param.dart';
import 'package:nextry_dev/domain/entities/wallet/transaction_history_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/domain/interactors/wallet/transactions_history_interactor.dart';

class TransactionsHistoryInteractorImpl
    implements TransactionsHistoryInteractor {
  final ReadGateWay<TransactionHistoryResponseEntity, TransactionHistoryParam>
      gateWay;

  TransactionsHistoryInteractorImpl({required this.gateWay});

  @override
  Future<TransactionHistoryResponseEntity> fetchHistoryFilterData(
      TransactionHistoryParam transactionHistoryParam) {
    return gateWay.read(transactionHistoryParam);
  }
}
