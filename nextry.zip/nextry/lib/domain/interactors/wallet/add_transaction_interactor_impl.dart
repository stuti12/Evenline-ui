import 'package:nextry_dev/domain/entities/wallet/add_transaction_param.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/domain/interactors/wallet/add_transaction_interactor.dart';

class AddTransactionInteractorImpl implements AddTransactionInteractor {
  final ReadGateWay<void, AddTransactionParam> gateWay;

  AddTransactionInteractorImpl({required this.gateWay});

  @override
  Future<void> addTransaction(AddTransactionParam addTransactionParam) {
    return gateWay.read(addTransactionParam);
  }
}
