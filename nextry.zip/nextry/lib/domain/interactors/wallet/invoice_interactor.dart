import 'package:nextry_dev/domain/entities/invoice/invoice_param.dart';
import 'package:nextry_dev/domain/entities/invoice/invoice_response_entity.dart';

abstract class InvoiceInteractor {
  Future<InvoiceResponseEntity> fetchInvoiceData(InvoiceParam invoiceParam);
}
