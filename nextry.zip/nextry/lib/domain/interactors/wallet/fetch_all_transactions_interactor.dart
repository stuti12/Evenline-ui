import 'package:nextry_dev/domain/entities/wallet/total_balance_param.dart';
import 'package:nextry_dev/domain/entities/wallet/transaction_response_entity.dart';

abstract class FetchAllTransactionsInteractor {
  Future<TransactionResponseEntity> fetchFilterData(
      TotalBalanceParam totalBalanceParam);
}
