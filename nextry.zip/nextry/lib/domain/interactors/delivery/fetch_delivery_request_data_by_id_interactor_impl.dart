import 'package:nextry_dev/domain/entities/delivery/fetch_delivery_request_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/domain/interactors/delivery/fetch_delivery_request_data_by_id_interactor.dart';

class FetchDeliveryRequestDataByIdInteractorImpl
    extends FetchDeliveryRequestDataByIdInteractor {
  FetchDeliveryRequestDataByIdInteractorImpl({required this.gateway});

  final ReadGateWay<FetchDeliveryRequestEntity, String> gateway;

  @override
  void unsubscribe() {
    gateway.unsubscribe();
  }

  @override
  Future<FetchDeliveryRequestEntity> fetchDeliveryRequestById(
      String deliveryRequestId) {
    return gateway.read(deliveryRequestId);
  }
}
