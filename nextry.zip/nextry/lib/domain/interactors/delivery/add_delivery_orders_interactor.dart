import 'package:nextry_dev/domain/entities/delivery/add_delivery_orders_param.dart';
import 'package:nextry_dev/domain/entities/delivery/add_delivery_orders_response_entity.dart';

abstract class AddDeliveryOrdersInteractor {
  Future<AddDeliveryOrdersResponseEntity> addDeliveryOrders(
      AddDeliveryOrdersParam param);
}
