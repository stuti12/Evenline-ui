import 'package:nextry_dev/domain/entities/delivery/shipper_feedback_entity.dart';
import 'package:nextry_dev/domain/entities/delivery/fetch_shipper_review_response_entity.dart';
import 'package:nextry_dev/domain/entities/feedback/feedback_entity.dart';

abstract class FetchShipperReviewInteractor {
  Future<FetchShipperReviewResponseEntity> fetchShipperReviews(
      String param);
}
