import 'package:nextry_dev/domain/entities/delivery/update_delivery_order_response_entity.dart';
import 'package:nextry_dev/domain/entities/delivery/update_delivery_order_status_param.dart';

abstract class UpdateDeliveryOrderStatusInteractor {
  Future<UpdateDeliveryOrderResponseEntity> updateDeliveryOrderStatus(
      UpdateDeliveryOrderStatusParam param);
}
