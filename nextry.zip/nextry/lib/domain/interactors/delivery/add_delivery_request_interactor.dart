import 'package:nextry_dev/domain/entities/delivery/add_delivery_request_param.dart';
import 'package:nextry_dev/domain/entities/delivery/add_delivery_request_response_entity.dart';

abstract class AddDeliveryRequestInteractor {
  Future<AddDeliveryRequestResponseEntity> addDeliveryRequest(
      AddDeliveryRequestParam param);
}
