import 'package:nextry_dev/domain/entities/delivery/fetch_delivery_order_by_filter_response_entity.dart';
import 'package:nextry_dev/domain/entities/delivery/fetch_delivery_order_by_shipper_id_param.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/domain/interactors/delivery/fetch_delivery_orders_by_shipper_id_interactor.dart';

class FetchDeliveryOrdersByShipperIdInteractorImpl
    extends FetchDeliveryOrdersByShipperIdInteractor {
  FetchDeliveryOrdersByShipperIdInteractorImpl({required this.gateway});

  final ReadGateWay<FetchDeliveryOrderByFilterResponseEntity,
      FetchDeliveryOrderByShipperIdParam> gateway;

  @override
  Future<FetchDeliveryOrderByFilterResponseEntity>
      fetchDeliveryOrdersByShipperId(FetchDeliveryOrderByShipperIdParam param) {
    return gateway.read(param);
  }

  @override
  void unsubscribe() {
    gateway.unsubscribe();
  }
}
