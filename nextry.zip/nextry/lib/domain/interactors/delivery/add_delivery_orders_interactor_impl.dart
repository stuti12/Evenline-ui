import 'package:nextry_dev/domain/entities/delivery/add_delivery_orders_param.dart';
import 'package:nextry_dev/domain/entities/delivery/add_delivery_orders_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/domain/interactors/delivery/add_delivery_orders_interactor.dart';

class AddDeliveryOrdersInteractorImpl extends AddDeliveryOrdersInteractor {
  AddDeliveryOrdersInteractorImpl({required this.gateway});

  final ReadGateWay<AddDeliveryOrdersResponseEntity, AddDeliveryOrdersParam>
      gateway;

  @override
  Future<AddDeliveryOrdersResponseEntity> addDeliveryOrders(
      AddDeliveryOrdersParam param) {
    return gateway.read(param);
  }
}
