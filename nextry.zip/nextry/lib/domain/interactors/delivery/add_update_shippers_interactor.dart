import 'package:nextry_dev/domain/entities/delivery/add_update_shipper_param.dart';
import 'package:nextry_dev/domain/entities/delivery/add_update_shipper_response_entity.dart';

abstract class AddUpdateShippersInteractor {
  Future<AddUpdateShipperResponseEntity> addUpdateShippers(
      AddUpdateShipperParam param);
}
