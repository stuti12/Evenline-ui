import 'package:nextry_dev/domain/entities/delivery/update_shipper_current_location_param.dart';
import 'package:nextry_dev/domain/entities/delivery/update_shipper_current_location_response_entity.dart';

abstract class UpdateShipperCurrentLocationInteractor {
  Future<UpdateShipperCurrentLocationResponseEntity> updateShipperLocation(
      UpdateShipperCurrentLocationParam param);
}
