import 'package:nextry_dev/domain/entities/delivery/add_report_customers_param.dart';
import 'package:nextry_dev/domain/entities/delivery/add_report_customers_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/domain/interactors/delivery/add_report_customers_interactor.dart';

class AddReportCustomersInteractorImpl extends AddReportCustomersInteractor {
  AddReportCustomersInteractorImpl({required this.gateway});

  final ReadGateWay<AddReportCustomersResponseEntity, AddReportCustomersParam>
      gateway;

  @override
  Future<AddReportCustomersResponseEntity> addReportCustomers(
      AddReportCustomersParam param) {
    return gateway.read(param);
  }
}
