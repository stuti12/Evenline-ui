import 'package:nextry_dev/domain/entities/delivery/add_update_shipper_param.dart';
import 'package:nextry_dev/domain/entities/delivery/add_update_shipper_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';

import 'add_update_shippers_interactor.dart';

class AddUpdateShippersInteractorImpl extends AddUpdateShippersInteractor {
  AddUpdateShippersInteractorImpl({required this.gateway});

  final ReadGateWay<AddUpdateShipperResponseEntity, AddUpdateShipperParam>
      gateway;

  @override
  Future<AddUpdateShipperResponseEntity> addUpdateShippers(
      AddUpdateShipperParam param) {
    return gateway.read(param);
  }
}
