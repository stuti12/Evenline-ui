import 'package:nextry_dev/domain/entities/delivery/fetch_delivery_request_param.dart';
import 'package:nextry_dev/domain/entities/delivery/fetch_delivery_request_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/domain/interactors/delivery/fetch_delivery_request_interactor.dart';

class FetchDeliveryRequestInteractorImpl
    extends FetchDeliveryRequestInteractor {
  FetchDeliveryRequestInteractorImpl({required this.gateway});

  final ReadGateWay<FetchDeliveryRequestResponseEntity, FetchDeliveryRequestParam>
      gateway;

  @override
  Future<FetchDeliveryRequestResponseEntity> fetchDeliveryRequests(
      FetchDeliveryRequestParam param) {
    return gateway.read(param);
  }

  @override
  void unsubscribe() {
    gateway.unsubscribe();
  }
}
