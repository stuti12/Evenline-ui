import 'package:nextry_dev/domain/entities/delivery/fetch_delivery_request_param.dart';
import 'package:nextry_dev/domain/entities/delivery/fetch_delivery_request_response_entity.dart';

abstract class FetchDeliveryRequestByUserIdInteractor {
  Future<FetchDeliveryRequestResponseEntity> fetchDeliveryRequestByUserId(
      FetchDeliveryRequestParam param);

  void unsubscribe();
}
