import 'package:nextry_dev/domain/entities/delivery/add_report_customers_param.dart';
import 'package:nextry_dev/domain/entities/delivery/add_report_customers_response_entity.dart';

abstract class AddReportCustomersInteractor {
  Future<AddReportCustomersResponseEntity> addReportCustomers(
      AddReportCustomersParam param);
}
