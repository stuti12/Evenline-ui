import 'package:nextry_dev/domain/entities/delivery/add_delivery_request_response_entity.dart';
import 'package:nextry_dev/domain/entities/delivery/cancel_delivery_request_param.dart';

abstract class CancelDeliveryRequestInteractor {
  Future<AddDeliveryRequestResponseEntity> cancelDeliveryRequest(
      CancelDeliveryRequestParam param);
}
