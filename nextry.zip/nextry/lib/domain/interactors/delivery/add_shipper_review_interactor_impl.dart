import 'package:nextry_dev/domain/entities/delivery/add_shipper_review_response_entity.dart';
import 'package:nextry_dev/domain/entities/feedback/feedback_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/domain/interactors/delivery/add_shipper_review_interactor.dart';

class AddShipperReviewInteractorImpl extends AddShipperReviewInteractor {
  AddShipperReviewInteractorImpl({required this.gateway});

  final ReadGateWay<AddShipperReviewResponseEntity, FeedbackEntity>
      gateway;

  @override
  Future<AddShipperReviewResponseEntity> addShipperReview(
      FeedbackEntity param) {
    return gateway.read(param);
  }
}
