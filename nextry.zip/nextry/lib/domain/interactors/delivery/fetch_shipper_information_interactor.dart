import 'package:nextry_dev/domain/entities/delivery/fetch_shipper_information_response_entity.dart';

abstract class FetchShipperInformationInteractor {
  Future<FetchShipperInformationResponseEntity> fetchShipperInformation();
}
