import 'package:nextry_dev/domain/entities/delivery/shipper_feedback_report_entity.dart';
import 'package:nextry_dev/domain/entities/feedback/create_feedback_report_response_entity.dart';

abstract class RequestDeleteShipperFeedbackInteractor {
  Future<CreateFeedbackReportResponseEntity> requestDeleteShipperFeedback(
      ShipperFeedbackReportEntity param);
}
