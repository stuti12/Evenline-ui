import 'package:nextry_dev/domain/entities/delivery/shipper_feedback_entity.dart';
import 'package:nextry_dev/domain/entities/delivery/fetch_shipper_review_response_entity.dart';
import 'package:nextry_dev/domain/entities/feedback/feedback_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/domain/interactors/delivery/fetch_shipper_review_interactor.dart';

class FetchShipperReviewInteractorImpl extends FetchShipperReviewInteractor {
  FetchShipperReviewInteractorImpl({required this.gateway});

  final ReadGateWay<FetchShipperReviewResponseEntity, String>
      gateway;

  @override
  Future<FetchShipperReviewResponseEntity> fetchShipperReviews(
      String param) {
    return gateway.read(param);
  }
}
