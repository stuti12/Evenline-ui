import 'package:nextry_dev/domain/entities/delivery/fetch_delivery_request_entity.dart';

abstract class FetchDeliveryRequestDataByIdInteractor {
  Future<FetchDeliveryRequestEntity> fetchDeliveryRequestById(
      String deliveryRequestId);

  void unsubscribe();
}
