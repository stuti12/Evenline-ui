import 'package:nextry_dev/domain/entities/delivery/fetch_delivery_order_by_filter_param.dart';
import 'package:nextry_dev/domain/entities/delivery/fetch_delivery_order_by_filter_response_entity.dart';
import 'package:nextry_dev/domain/entities/delivery/fetch_delivery_order_detail_param.dart';
import 'package:nextry_dev/domain/entities/delivery/fetch_delivery_order_detail_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/domain/interactors/delivery/fetch_delivery_order_detail_interactor.dart';

import 'fetch_delivery_orders_by_filter_interactor.dart';

class FetchDeliveryOrderDetailInteractorImpl
    extends FetchDeliveryOrderDetailInteractor {
  FetchDeliveryOrderDetailInteractorImpl({required this.gateway});

  final ReadGateWay<FetchDeliveryOrderDetailResponseEntity,
      FetchDeliveryOrderDetailParam> gateway;

  @override
  Future<FetchDeliveryOrderDetailResponseEntity> fetchDeliveryOrderDetail(
      FetchDeliveryOrderDetailParam param) {
    return gateway.read(param);
  }
}
