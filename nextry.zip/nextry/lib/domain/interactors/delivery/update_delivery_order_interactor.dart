import 'package:nextry_dev/domain/entities/delivery/update_delivery_order_param.dart';
import 'package:nextry_dev/domain/entities/delivery/update_delivery_order_response_entity.dart';

abstract class UpdateDeliveryOrderInteractor {
  Future<UpdateDeliveryOrderResponseEntity> updateDeliveryOrder(
      UpdateDeliveryOrderParam param);
}
