import 'package:nextry_dev/domain/entities/delivery/shipper_feedback_report_entity.dart';
import 'package:nextry_dev/domain/entities/feedback/create_feedback_report_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/domain/interactors/delivery/request_delete_shipper_feedback_interactor.dart';

class RequestDeleteShipperFeedbackInteractorImpl
    extends RequestDeleteShipperFeedbackInteractor {
  RequestDeleteShipperFeedbackInteractorImpl({required this.gateway});

  final ReadGateWay<CreateFeedbackReportResponseEntity,
      ShipperFeedbackReportEntity> gateway;

  @override
  Future<CreateFeedbackReportResponseEntity> requestDeleteShipperFeedback(
      ShipperFeedbackReportEntity param) {
    return gateway.read(param);
  }
}
