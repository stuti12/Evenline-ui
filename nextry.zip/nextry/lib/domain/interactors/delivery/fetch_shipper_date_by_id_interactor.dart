import 'package:nextry_dev/domain/entities/delivery/fetch_shipper_data_by_id_param.dart';
import 'package:nextry_dev/domain/entities/delivery/fetch_shipper_information_response_entity.dart';

abstract class FetchShipperDataByIdInteractor {
  Future<FetchShipperInformationResponseEntity> fetchShipperDataById(
      FetchShipperDataByIdParam shipperId);
}
