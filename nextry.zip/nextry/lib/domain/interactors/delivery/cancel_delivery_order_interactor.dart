import 'package:nextry_dev/domain/entities/delivery/cancel_delivery_order_param.dart';
import 'package:nextry_dev/domain/entities/delivery/update_delivery_order_response_entity.dart';

abstract class CancelDeliveryOrderInteractor {
  Future<UpdateDeliveryOrderResponseEntity> cancelDeliveryOrder(
      CancelDeliveryOrderParam param);
}
