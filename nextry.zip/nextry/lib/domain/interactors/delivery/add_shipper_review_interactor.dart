import 'package:nextry_dev/domain/entities/delivery/add_shipper_review_response_entity.dart';
import 'package:nextry_dev/domain/entities/feedback/feedback_entity.dart';

abstract class AddShipperReviewInteractor {
  Future<AddShipperReviewResponseEntity> addShipperReview(
      FeedbackEntity param);
}
