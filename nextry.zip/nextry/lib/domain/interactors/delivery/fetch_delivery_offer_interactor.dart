import 'package:nextry_dev/domain/entities/delivery/fetch_delivery_offer_response_entity.dart';
import 'package:nextry_dev/domain/entities/delivery/fetch_delivery_request_param.dart';

abstract class FetchDeliveryOfferInteractor {
  Future<FetchDeliveryOfferResponseEntity> fetchDeliveryOffers(
      FetchDeliveryRequestParam param);
}
