import 'package:nextry_dev/domain/entities/delivery/add_delivery_request_param.dart';
import 'package:nextry_dev/domain/entities/delivery/add_delivery_request_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/domain/interactors/delivery/add_delivery_request_interactor.dart';

class AddDeliveryRequestInteractorImpl extends AddDeliveryRequestInteractor {
  AddDeliveryRequestInteractorImpl({required this.gateway});

  final ReadGateWay<AddDeliveryRequestResponseEntity, AddDeliveryRequestParam>
      gateway;

  @override
  Future<AddDeliveryRequestResponseEntity> addDeliveryRequest(
      AddDeliveryRequestParam param) {
    return gateway.read(param);
  }
}
