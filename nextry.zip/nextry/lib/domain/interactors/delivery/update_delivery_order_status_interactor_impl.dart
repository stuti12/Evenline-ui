import 'package:nextry_dev/domain/entities/delivery/update_delivery_order_response_entity.dart';
import 'package:nextry_dev/domain/entities/delivery/update_delivery_order_status_param.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/domain/interactors/delivery/update_delivery_order_status_interactor.dart';

class UpdateDeliveryOrderStatusInteractorImpl
    extends UpdateDeliveryOrderStatusInteractor {
  UpdateDeliveryOrderStatusInteractorImpl({required this.gateway});

  final ReadGateWay<UpdateDeliveryOrderResponseEntity,
      UpdateDeliveryOrderStatusParam> gateway;

  @override
  Future<UpdateDeliveryOrderResponseEntity> updateDeliveryOrderStatus(
      UpdateDeliveryOrderStatusParam param) {
    return gateway.read(param);
  }
}
