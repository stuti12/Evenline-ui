import 'package:nextry_dev/domain/entities/delivery/fetch_delivery_order_by_filter_response_entity.dart';
import 'package:nextry_dev/domain/entities/delivery/fetch_delivery_order_by_shipper_id_param.dart';

abstract class FetchDeliveryOrdersByShipperIdInteractor {
  Future<FetchDeliveryOrderByFilterResponseEntity>
      fetchDeliveryOrdersByShipperId(FetchDeliveryOrderByShipperIdParam param);

  void unsubscribe();
}
