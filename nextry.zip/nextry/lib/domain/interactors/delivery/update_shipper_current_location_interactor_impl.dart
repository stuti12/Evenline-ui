import 'package:nextry_dev/domain/entities/delivery/update_shipper_current_location_param.dart';
import 'package:nextry_dev/domain/entities/delivery/update_shipper_current_location_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/domain/interactors/delivery/update_shipper_current_location_interactor.dart';

class UpdateShipperCurrentLocationInteractorImpl
    extends UpdateShipperCurrentLocationInteractor {
  UpdateShipperCurrentLocationInteractorImpl({required this.gateway});

  final ReadGateWay<UpdateShipperCurrentLocationResponseEntity,
      UpdateShipperCurrentLocationParam> gateway;

  @override
  Future<UpdateShipperCurrentLocationResponseEntity> updateShipperLocation(
      UpdateShipperCurrentLocationParam param) {
    return gateway.read(param);
  }
}
