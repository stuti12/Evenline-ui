import 'package:nextry_dev/domain/entities/delivery/add_delivery_offer_param.dart';
import 'package:nextry_dev/domain/entities/delivery/add_delivery_offer_response_entity.dart';

abstract class AddDeliveryOfferInteractor {
  Future<AddDeliveryResponseEntity> addDeliveryOffer(
      AddDeliveryOfferParam param);
}
