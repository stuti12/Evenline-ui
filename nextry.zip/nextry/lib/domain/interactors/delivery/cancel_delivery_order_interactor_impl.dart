import 'package:nextry_dev/domain/entities/delivery/cancel_delivery_order_param.dart';
import 'package:nextry_dev/domain/entities/delivery/update_delivery_order_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/domain/interactors/delivery/cancel_delivery_order_interactor.dart';

class CancelDeliveryOrderInteractorImpl extends CancelDeliveryOrderInteractor {
  CancelDeliveryOrderInteractorImpl({required this.gateway});

  final ReadGateWay<UpdateDeliveryOrderResponseEntity, CancelDeliveryOrderParam>
      gateway;

  @override
  Future<UpdateDeliveryOrderResponseEntity> cancelDeliveryOrder(
      CancelDeliveryOrderParam param) {
    return gateway.read(param);
  }
}
