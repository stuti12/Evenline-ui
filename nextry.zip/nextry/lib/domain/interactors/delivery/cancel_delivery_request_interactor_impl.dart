import 'package:nextry_dev/domain/entities/delivery/add_delivery_request_response_entity.dart';
import 'package:nextry_dev/domain/entities/delivery/cancel_delivery_request_param.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/domain/interactors/delivery/cancel_delivery_request_interactor.dart';

class CancelDeliveryRequestInteractorImpl
    extends CancelDeliveryRequestInteractor {
  CancelDeliveryRequestInteractorImpl({required this.gateway});

  final ReadGateWay<AddDeliveryRequestResponseEntity,
      CancelDeliveryRequestParam> gateway;

  @override
  Future<AddDeliveryRequestResponseEntity> cancelDeliveryRequest(
      CancelDeliveryRequestParam param) {
    return gateway.read(param);
  }
}
