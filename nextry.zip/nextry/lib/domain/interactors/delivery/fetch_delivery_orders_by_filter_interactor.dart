import 'package:nextry_dev/domain/entities/delivery/fetch_delivery_order_by_filter_param.dart';
import 'package:nextry_dev/domain/entities/delivery/fetch_delivery_order_by_filter_response_entity.dart';

abstract class FetchDeliveryOrdersByFilterInteractor {
  Future<FetchDeliveryOrderByFilterResponseEntity> fetchDeliveryOrdersByFilter(
      FetchDeliveryOrderByFilterParam param);

  void unsubscribe();
}
