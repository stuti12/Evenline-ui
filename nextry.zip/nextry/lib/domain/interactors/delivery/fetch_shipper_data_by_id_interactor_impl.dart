import 'package:nextry_dev/domain/entities/delivery/fetch_shipper_data_by_id_param.dart';
import 'package:nextry_dev/domain/entities/delivery/fetch_shipper_information_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/domain/interactors/delivery/fetch_shipper_date_by_id_interactor.dart';

class FetchShipperDataByIdInteractorImpl
    extends FetchShipperDataByIdInteractor {
  FetchShipperDataByIdInteractorImpl({required this.gateway});

  final ReadGateWay<FetchShipperInformationResponseEntity, FetchShipperDataByIdParam>
      gateway;

  @override
  Future<FetchShipperInformationResponseEntity> fetchShipperDataById(FetchShipperDataByIdParam shipperId) {
    return gateway.read(shipperId);
  }
}
