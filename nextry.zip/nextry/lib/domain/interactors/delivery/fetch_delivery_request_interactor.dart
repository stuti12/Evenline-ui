import 'package:nextry_dev/domain/entities/delivery/fetch_delivery_request_param.dart';
import 'package:nextry_dev/domain/entities/delivery/fetch_delivery_request_response_entity.dart';

abstract class FetchDeliveryRequestInteractor {
  Future<FetchDeliveryRequestResponseEntity> fetchDeliveryRequests(
      FetchDeliveryRequestParam param);

  void unsubscribe();
}
