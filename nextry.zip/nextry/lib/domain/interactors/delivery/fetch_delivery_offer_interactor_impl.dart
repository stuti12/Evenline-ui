import 'package:nextry_dev/domain/entities/delivery/fetch_delivery_offer_response_entity.dart';
import 'package:nextry_dev/domain/entities/delivery/fetch_delivery_request_param.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/domain/interactors/delivery/fetch_delivery_offer_interactor.dart';

class FetchDeliveryOfferInteractorImpl extends FetchDeliveryOfferInteractor {
  FetchDeliveryOfferInteractorImpl({required this.gateway});

  final ReadGateWay<FetchDeliveryOfferResponseEntity, FetchDeliveryRequestParam>
      gateway;

  @override
  Future<FetchDeliveryOfferResponseEntity> fetchDeliveryOffers(
      FetchDeliveryRequestParam param) {
    return gateway.read(param);
  }
}
