import 'package:nextry_dev/domain/entities/delivery/add_delivery_offer_param.dart';
import 'package:nextry_dev/domain/entities/delivery/add_delivery_offer_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/domain/interactors/delivery/add_delivery_offer_interactor.dart';

class AddDeliveryOfferInteractorImpl extends AddDeliveryOfferInteractor {
  AddDeliveryOfferInteractorImpl({required this.gateway});

  final ReadGateWay<AddDeliveryResponseEntity, AddDeliveryOfferParam> gateway;

  @override
  Future<AddDeliveryResponseEntity> addDeliveryOffer(
      AddDeliveryOfferParam param) {
    return gateway.read(param);
  }
}
