import 'package:nextry_dev/domain/entities/delivery/fetch_shipper_delivery_offer_response_entity.dart';
import 'package:nextry_dev/domain/entities/delivery/fetch_shipper_delivery_request_param.dart';

abstract class FetchShipperDeliveryOfferInteractor {
  Future<FetchShipperDeliveryOfferResponseEntity> fetchShipperDeliveryOffers(
      FetchShipperDeliveryRequestParam param);
}
