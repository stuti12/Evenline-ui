import 'package:nextry_dev/domain/entities/delivery/fetch_delivery_request_param.dart';
import 'package:nextry_dev/domain/entities/delivery/fetch_shipper_delivery_offer_response_entity.dart';
import 'package:nextry_dev/domain/entities/delivery/fetch_shipper_delivery_request_param.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';

import 'fetch_shipper_delivery_offer_interactor.dart';

class FetchShipperDeliveryOfferInteractorImpl
    extends FetchShipperDeliveryOfferInteractor {
  FetchShipperDeliveryOfferInteractorImpl({required this.gateway});

  final ReadGateWay<FetchShipperDeliveryOfferResponseEntity,
      FetchShipperDeliveryRequestParam> gateway;

  @override
  Future<FetchShipperDeliveryOfferResponseEntity> fetchShipperDeliveryOffers(
      FetchShipperDeliveryRequestParam param) {
    return gateway.read(param);
  }
}
