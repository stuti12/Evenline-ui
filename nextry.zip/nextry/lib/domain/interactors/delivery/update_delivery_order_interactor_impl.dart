import 'package:nextry_dev/domain/entities/delivery/update_delivery_order_param.dart';
import 'package:nextry_dev/domain/entities/delivery/update_delivery_order_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/domain/interactors/delivery/update_delivery_order_interactor.dart';

class UpdateDeliveryOrderInteractorImpl extends UpdateDeliveryOrderInteractor {
  UpdateDeliveryOrderInteractorImpl({required this.gateway});

  final ReadGateWay<UpdateDeliveryOrderResponseEntity, UpdateDeliveryOrderParam>
      gateway;

  @override
  Future<UpdateDeliveryOrderResponseEntity> updateDeliveryOrder(
      UpdateDeliveryOrderParam param) {
    return gateway.read(param);
  }
}
