import 'package:nextry_dev/domain/entities/delivery/fetch_delivery_order_by_filter_param.dart';
import 'package:nextry_dev/domain/entities/delivery/fetch_delivery_order_by_filter_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';

import 'fetch_delivery_orders_by_filter_interactor.dart';

class FetchDeliveryOrdersByFilterInteractorImpl
    extends FetchDeliveryOrdersByFilterInteractor {
  FetchDeliveryOrdersByFilterInteractorImpl({required this.gateway});

  final ReadGateWay<FetchDeliveryOrderByFilterResponseEntity,
      FetchDeliveryOrderByFilterParam> gateway;

  @override
  Future<FetchDeliveryOrderByFilterResponseEntity> fetchDeliveryOrdersByFilter(
      FetchDeliveryOrderByFilterParam param) {
    return gateway.read(param);
  }

  @override
  void unsubscribe() {
    gateway.unsubscribe();
  }
}
