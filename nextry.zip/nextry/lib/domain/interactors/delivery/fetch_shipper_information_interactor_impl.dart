import 'package:nextry_dev/domain/entities/delivery/fetch_shipper_information_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway_no_args.dart';
import 'package:nextry_dev/domain/interactors/delivery/fetch_shipper_information_interactor.dart';

class FetchShipperInformationInteractorImpl
    extends FetchShipperInformationInteractor {
  FetchShipperInformationInteractorImpl({required this.gateway});

  final ReadGateWayNoArgs<FetchShipperInformationResponseEntity> gateway;

  @override
  Future<FetchShipperInformationResponseEntity> fetchShipperInformation() {
    return gateway.read();
  }
}
