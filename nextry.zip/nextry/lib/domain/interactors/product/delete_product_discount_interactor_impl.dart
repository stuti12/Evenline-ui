import 'package:nextry_dev/domain/entities/product/delete_product_discount_param.dart';
import 'package:nextry_dev/domain/entities/product/delete_product_discount_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/domain/interactors/product/delete_product_discount_interactor.dart';

class DeleteProductDiscountInteractorImpl
    extends DeleteProductDiscountInteractor {
  DeleteProductDiscountInteractorImpl({required this.gateway});

  final ReadGateWay<DeleteProductDiscountResponseEntity,
      DeleteProductDiscountParam> gateway;

  @override
  Future<DeleteProductDiscountResponseEntity> deleteProductDiscount(
      DeleteProductDiscountParam param) {
    return gateway.read(param);
  }
}
