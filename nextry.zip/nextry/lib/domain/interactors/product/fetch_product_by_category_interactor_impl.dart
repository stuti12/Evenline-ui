import 'package:nextry_dev/domain/entities/product/fetch_product_by_category_param.dart';
import 'package:nextry_dev/domain/entities/product/fetch_product_by_category_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/domain/interactors/product/fetch_product_by_category_interactor.dart';

class FetchProductByCategoryGateWayInteractorImpl
    extends FetchProductByCategoryGateWayInteractor {
  FetchProductByCategoryGateWayInteractorImpl({required this.gateway});

  final ReadGateWay<FetchProductByCategoryResponseEntity,
      FetchProductByCategoryParam> gateway;

  @override
  Future<FetchProductByCategoryResponseEntity>
      fetchBusinessProductByCategory(
          FetchProductByCategoryParam param) {
    return gateway.read(param);
  }

  @override
  void unsubscribe() {
    gateway.unsubscribe();
  }
}
