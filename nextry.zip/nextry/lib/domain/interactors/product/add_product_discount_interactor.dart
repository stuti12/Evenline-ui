import 'package:nextry_dev/domain/entities/product/add_product_discount_param.dart';
import 'package:nextry_dev/domain/entities/product/add_product_discount_response_entity.dart';

abstract class AddProductDiscountInteractor {
  Future<AddProductDiscountResponseEntity> addProductDiscountData(
      AddProductDiscountParam addProductDiscountParam);
}
