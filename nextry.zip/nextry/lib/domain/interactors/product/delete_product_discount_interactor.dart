import 'package:nextry_dev/domain/entities/product/delete_product_discount_param.dart';
import 'package:nextry_dev/domain/entities/product/delete_product_discount_response_entity.dart';

abstract class DeleteProductDiscountInteractor {
  Future<DeleteProductDiscountResponseEntity> deleteProductDiscount(
      DeleteProductDiscountParam param);
}
