import 'package:nextry_dev/domain/entities/product/fetch_relative_product_param.dart';
import 'package:nextry_dev/domain/entities/product/fetch_relative_product_response_entity.dart';

abstract class FetchRelativeProductGateWayInteractor {
  Future<FetchRelativeProductResponseEntity> fetchRelativeProduct(
      FetchRelativeProductParam param);
}
