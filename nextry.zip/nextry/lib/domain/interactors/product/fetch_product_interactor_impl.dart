import 'package:nextry_dev/domain/entities/product/fetch_product_param.dart';
import 'package:nextry_dev/domain/entities/product/fetch_product_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/domain/interactors/product/fetch_product_interactor.dart';

class FetchProductInteractorImpl extends FetchProductInteractor {
  FetchProductInteractorImpl({required this.gateway});

  final ReadGateWay<FetchProductResponseEntity, FetchProductParam> gateway;

  @override
  Future<FetchProductResponseEntity> fetchProduct(FetchProductParam param) {
    return gateway.read(param);
  }

  @override
  void unsubscribe() {
    gateway.unsubscribe();
  }
}
