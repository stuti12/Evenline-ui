import 'package:nextry_dev/domain/entities/product/delete_product_category_param.dart';
import 'package:nextry_dev/domain/entities/product/delete_product_category_response_entity.dart';

abstract class  DeleteProductCategoryInteractor {
  Future<DeleteProductCategoryResponseEntity> deleteProductCategory(
      DeleteProductCategoryParam param);
}
