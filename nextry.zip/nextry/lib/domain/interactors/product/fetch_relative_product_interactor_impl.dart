import 'package:nextry_dev/domain/entities/product/fetch_relative_product_param.dart';
import 'package:nextry_dev/domain/entities/product/fetch_relative_product_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/domain/interactors/product/fetch_relative_product_interactor.dart';

class FetchRelativeProductGateWayInteractorImpl
    extends FetchRelativeProductGateWayInteractor {
  FetchRelativeProductGateWayInteractorImpl({required this.gateway});

  final ReadGateWay<FetchRelativeProductResponseEntity,
      FetchRelativeProductParam> gateway;

  @override
  Future<FetchRelativeProductResponseEntity> fetchRelativeProduct(
      FetchRelativeProductParam param) {
    return gateway.read(param);
  }
}
