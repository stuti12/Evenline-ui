import 'package:nextry_dev/domain/entities/product/delete_product_category_param.dart';
import 'package:nextry_dev/domain/entities/product/delete_product_category_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/domain/interactors/product/delete_product_category_interactor.dart';

class DeleteProductCategoryInteractorImpl
    extends DeleteProductCategoryInteractor {
  DeleteProductCategoryInteractorImpl({required this.gateway});

  final ReadGateWay<DeleteProductCategoryResponseEntity,
      DeleteProductCategoryParam> gateway;

  @override
  Future<DeleteProductCategoryResponseEntity> deleteProductCategory(
      DeleteProductCategoryParam param) {
    return gateway.read(param);
  }
}
