import 'package:nextry_dev/domain/entities/product/add_update_product_param.dart';
import 'package:nextry_dev/domain/entities/product/add_update_product_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/domain/interactors/product/add_update_product_interactor.dart';

class AddUpdateProductInteractorImpl extends AddUpdateProductInteractor {
  AddUpdateProductInteractorImpl({required this.gateway});

  final ReadGateWay<AddUpdateProductResponseEntity, AddUpdateProductParam>
      gateway;

  @override
  Future<AddUpdateProductResponseEntity> addUpdateProductData(
      AddUpdateProductParam addUpdateProductParam) {
    return gateway.read(addUpdateProductParam);
  }
}
