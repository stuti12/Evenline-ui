import 'package:nextry_dev/domain/entities/product/fetch_product_param.dart';
import 'package:nextry_dev/domain/entities/product/fetch_product_response_entity.dart';

abstract class FetchProductInteractor {
  Future<FetchProductResponseEntity> fetchProduct(FetchProductParam param);

  void unsubscribe();
}
