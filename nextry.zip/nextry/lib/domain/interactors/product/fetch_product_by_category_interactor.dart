import 'package:nextry_dev/domain/entities/product/fetch_product_by_category_param.dart';
import 'package:nextry_dev/domain/entities/product/fetch_product_by_category_response_entity.dart';

abstract class FetchProductByCategoryGateWayInteractor {
  Future<FetchProductByCategoryResponseEntity>
      fetchBusinessProductByCategory(FetchProductByCategoryParam param);

  void unsubscribe();
}
