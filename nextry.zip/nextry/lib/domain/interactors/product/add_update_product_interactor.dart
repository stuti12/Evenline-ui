import 'package:nextry_dev/domain/entities/product/add_update_product_param.dart';
import 'package:nextry_dev/domain/entities/product/add_update_product_response_entity.dart';

abstract class AddUpdateProductInteractor {
  Future<AddUpdateProductResponseEntity> addUpdateProductData(
      AddUpdateProductParam addUpdateProductParam);
}
