import 'package:nextry_dev/domain/entities/product/add_product_discount_param.dart';
import 'package:nextry_dev/domain/entities/product/add_product_discount_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/domain/interactors/product/add_product_discount_interactor.dart';

class AddProductDiscountInteractorImpl extends AddProductDiscountInteractor {
  AddProductDiscountInteractorImpl({required this.gateway});

  final ReadGateWay<AddProductDiscountResponseEntity, AddProductDiscountParam>
      gateway;

  @override
  Future<AddProductDiscountResponseEntity> addProductDiscountData(
      AddProductDiscountParam addProductDiscountParam) {
    return gateway.read(addProductDiscountParam);
  }
}
