import 'package:nextry_dev/domain/entities/product/add_update_product_param.dart';
import 'package:nextry_dev/domain/entities/product/add_update_product_response_entity.dart';

abstract class DeleteProductInteractor {
  Future<AddUpdateProductResponseEntity> deleteProduct(
      AddUpdateProductParam param);
}
