import 'package:nextry_dev/domain/entities/product/add_update_product_param.dart';
import 'package:nextry_dev/domain/entities/product/add_update_product_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/domain/interactors/product/delete_product_interactor.dart';

class DeleteProductInteractorImpl extends DeleteProductInteractor {
  DeleteProductInteractorImpl({required this.gateway});

  final ReadGateWay<AddUpdateProductResponseEntity, AddUpdateProductParam>
      gateway;

  @override
  Future<AddUpdateProductResponseEntity> deleteProduct(
      AddUpdateProductParam param) {
    return gateway.read(param);
  }
}
