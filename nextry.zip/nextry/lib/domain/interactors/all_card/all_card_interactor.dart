import 'package:nextry_dev/domain/entities/all_card/fetch_all_card_param.dart';
import 'package:nextry_dev/domain/entities/all_card/fetch_all_card_response_entity.dart';

abstract class AllCardInteractor {
  Future<FetchAllCardResponseEntity> getAllCard(FetchAllCardParam param);
}
