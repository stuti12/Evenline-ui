import 'package:nextry_dev/domain/entities/all_card/fetch_all_card_param.dart';
import 'package:nextry_dev/domain/entities/all_card/fetch_all_card_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';

import 'all_card_interactor.dart';

class AllCardInteractorImpl extends AllCardInteractor {
  AllCardInteractorImpl({required this.gateway});

  final ReadGateWay<FetchAllCardResponseEntity, FetchAllCardParam> gateway;

  @override
  Future<FetchAllCardResponseEntity> getAllCard(FetchAllCardParam param) {
    return gateway.read(param);
  }
}
