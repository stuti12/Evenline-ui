import 'package:nextry_dev/domain/entities/signup/google_sign_in_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway_no_args.dart';
import 'package:nextry_dev/domain/interactors/signup/google_sign_in_interactor.dart';

class GoogleSignInInteractorImpl extends GoogleSignInInteractor {
  GoogleSignInInteractorImpl({required this.gateway});

  final ReadGateWayNoArgs<GoogleSignInResponseEntity> gateway;

  @override
  Future<GoogleSignInResponseEntity> googleSignIn() {
    return gateway.read();
  }
}
