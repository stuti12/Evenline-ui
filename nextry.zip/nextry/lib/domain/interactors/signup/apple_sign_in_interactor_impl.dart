import 'package:nextry_dev/domain/entities/signup/apple_sign_in_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway_no_args.dart';
import 'package:nextry_dev/domain/interactors/signup/apple_sign_in_interactor.dart';

class AppleSignInInteractorImpl extends AppleSignInInteractor {
  AppleSignInInteractorImpl({required this.gateway});

  final ReadGateWayNoArgs<AppleSignInResponseEntity> gateway;

  @override
  Future<AppleSignInResponseEntity> appleSignIn() {
    return gateway.read();
  }
}
