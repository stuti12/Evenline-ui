import 'package:nextry_dev/domain/entities/signup/apple_sign_in_response_entity.dart';

abstract class AppleSignInInteractor {
  Future<AppleSignInResponseEntity> appleSignIn();
}
