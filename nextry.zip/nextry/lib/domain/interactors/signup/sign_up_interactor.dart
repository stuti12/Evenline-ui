import 'package:nextry_dev/domain/entities/signup/sign_up_params.dart';
import 'package:nextry_dev/domain/entities/signup/sign_up_response_entity.dart';

abstract class SignUpInteractor {
  Future<SignUpResponseEntity> doRegister(SignUpParams signUpParams);
}
