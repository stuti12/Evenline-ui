import 'package:nextry_dev/domain/entities/signup/sign_up_params.dart';
import 'package:nextry_dev/domain/entities/signup/sign_up_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/domain/interactors/signup/sign_up_interactor.dart';

class SignUpInteractorImpl extends SignUpInteractor {
  SignUpInteractorImpl({required this.gateway});

  final ReadGateWay<SignUpResponseEntity, SignUpParams> gateway;

  @override
  Future<SignUpResponseEntity> doRegister(SignUpParams signUpParams) {
    return gateway.read(signUpParams);
  }
}
