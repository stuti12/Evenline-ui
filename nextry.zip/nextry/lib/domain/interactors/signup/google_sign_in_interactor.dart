import 'package:nextry_dev/domain/entities/signup/google_sign_in_response_entity.dart';

abstract class GoogleSignInInteractor {
  Future<GoogleSignInResponseEntity> googleSignIn();
}
