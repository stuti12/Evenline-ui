import 'package:nextry_dev/domain/entities/feedback/create_feedback_report_response_entity.dart';
import 'package:nextry_dev/domain/entities/feedback/feedback_report_entity.dart';

abstract class CreateFeedbackReportInteractor {
  Future<CreateFeedbackReportResponseEntity> createFeedbackReport(
      FeedbackReportEntity param);
}
