import 'package:nextry_dev/domain/entities/feedback/create_feedback_report_response_entity.dart';
import 'package:nextry_dev/domain/entities/feedback/feedback_report_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/domain/interactors/feedback/create_feedbac_report_interactor.dart';

class CreateFeedbackReportInteractorImpl
    extends CreateFeedbackReportInteractor {
  CreateFeedbackReportInteractorImpl({required this.gateway});

  final ReadGateWay<CreateFeedbackReportResponseEntity, FeedbackReportEntity>
      gateway;

  @override
  Future<CreateFeedbackReportResponseEntity> createFeedbackReport(
      FeedbackReportEntity param) {
    return gateway.read(param);
  }
}
