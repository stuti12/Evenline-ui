import 'package:nextry_dev/domain/entities/feedback/all_business_feedbacks_response_entity.dart';
import 'package:nextry_dev/domain/entities/feedback/create_customer_feedback_param.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/domain/interactors/feedback/fetch_all_business_feedbacks_interactor.dart';

class FetchAllBusinessFeedbacksInteractorImpl
    extends FetchAllBusinessFeedbacksInteractor {
  FetchAllBusinessFeedbacksInteractorImpl({required this.gateway});

  final ReadGateWay<AllBusinessFeedbacksResponseEntity,
      CreateCustomerFeedbackParam> gateway;

  @override
  Future<AllBusinessFeedbacksResponseEntity> fetchAllBusinessFeedbacks(
      CreateCustomerFeedbackParam param) {
    return gateway.read(param);
  }
}
