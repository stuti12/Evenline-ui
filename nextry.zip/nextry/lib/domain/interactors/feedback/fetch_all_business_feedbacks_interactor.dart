import 'package:nextry_dev/domain/entities/feedback/all_business_feedbacks_response_entity.dart';
import 'package:nextry_dev/domain/entities/feedback/create_customer_feedback_param.dart';

abstract class FetchAllBusinessFeedbacksInteractor {
  Future<AllBusinessFeedbacksResponseEntity> fetchAllBusinessFeedbacks(
      CreateCustomerFeedbackParam param);
}
