import 'package:nextry_dev/domain/entities/feedback/create_customer_feedback_param.dart';
import 'package:nextry_dev/domain/entities/feedback/create_customer_feedback_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/domain/interactors/feedback/create_customer_feedback_interactor.dart';

class CreateCustomerFeedbackInteractorImpl
    extends CreateCustomerFeedbackInteractor {
  CreateCustomerFeedbackInteractorImpl({required this.gateway});

  final ReadGateWay<CreateCustomerFeedbackResponseEntity,
      CreateCustomerFeedbackParam> gateway;

  @override
  Future<CreateCustomerFeedbackResponseEntity> createCustomerFeedback(
      CreateCustomerFeedbackParam param) {
    return gateway.read(param);
  }
}
