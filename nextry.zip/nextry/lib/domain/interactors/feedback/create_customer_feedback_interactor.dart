import 'package:nextry_dev/domain/entities/feedback/create_customer_feedback_param.dart';
import 'package:nextry_dev/domain/entities/feedback/create_customer_feedback_response_entity.dart';

abstract class CreateCustomerFeedbackInteractor {
  Future<CreateCustomerFeedbackResponseEntity> createCustomerFeedback(
      CreateCustomerFeedbackParam param);
}
