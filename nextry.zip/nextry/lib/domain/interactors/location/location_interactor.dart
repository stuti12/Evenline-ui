import 'package:nextry_dev/domain/entities/location/location_info_entity.dart';

abstract class LocationInteractor {
  Future<LocationInfoEntity> getLocationInfoEntity();

  void unsubscribe();
}
