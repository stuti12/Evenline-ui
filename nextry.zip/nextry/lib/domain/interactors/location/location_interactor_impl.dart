import 'package:nextry_dev/domain/entities/location/location_info_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway_no_args.dart';
import 'package:nextry_dev/domain/interactors/location/location_interactor.dart';

class LocationInteractorImpl extends LocationInteractor {
  LocationInteractorImpl({required this.gateway});

  final ReadGateWayNoArgs<LocationInfoEntity> gateway;

  @override
  Future<LocationInfoEntity> getLocationInfoEntity() {
    return gateway.read();
  }

  @override
  void unsubscribe() {}
}
