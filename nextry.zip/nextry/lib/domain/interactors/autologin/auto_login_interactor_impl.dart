import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/domain/gateway/read_gateway_no_args.dart';

import 'auto_login_interactor.dart';

class AutoLoginInteractorImpl extends AutoLoginInteractor {
  AutoLoginInteractorImpl({required this.gateway});

  final ReadGateWayNoArgs<NavigationStatus> gateway;

  @override
  Future<NavigationStatus> isAutoLogged() {
    return gateway.read();
  }
}
