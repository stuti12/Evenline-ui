
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';

abstract class AutoLoginInteractor {
  Future<NavigationStatus> isAutoLogged();
}
