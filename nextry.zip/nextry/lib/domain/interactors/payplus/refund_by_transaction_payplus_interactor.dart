import 'package:nextry_dev/domain/entities/payplus/customer_response_entity.dart';
import 'package:nextry_dev/domain/entities/payplus/payplus_refund_by_transaction_request_param.dart';

abstract class RefundByTransactionIdPayPlusInteractor {
  Future<CustomerResponseEntity> refundByTransactionIdPayPlus(
      PayPlusRefundByTransactionRequest payPlusRefundByTransactionRequest);
}