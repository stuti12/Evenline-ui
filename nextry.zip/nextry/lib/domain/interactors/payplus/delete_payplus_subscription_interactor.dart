import 'package:nextry_dev/domain/entities/payplus/customer_response_entity.dart';
import 'package:nextry_dev/domain/entities/payplus/delete_payplus_subscription_param.dart';

abstract class DeletePayPlusSubscriptionInteractor {
  Future<CustomerResponseEntity> deletePayPlusSubscription(
      DeletePayPlusSubscriptionParam deletePayPlusSubscriptionParam);
}