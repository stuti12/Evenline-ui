import 'package:nextry_dev/domain/entities/payplus/customer_response_entity.dart';
import 'package:nextry_dev/domain/entities/payplus/delete_payplus_subscription_param.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/domain/interactors/payplus/delete_payplus_subscription_interactor.dart';

class DeletePayPlusSubscriptionInteractorImpl
    extends DeletePayPlusSubscriptionInteractor {
  DeletePayPlusSubscriptionInteractorImpl({required this.gateway});

  final ReadGateWay<CustomerResponseEntity, DeletePayPlusSubscriptionParam>
      gateway;

  @override
  Future<CustomerResponseEntity> deletePayPlusSubscription(
      DeletePayPlusSubscriptionParam data) {
    return gateway.read(data);
  }
}
