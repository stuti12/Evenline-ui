import 'package:nextry_dev/domain/entities/payplus/fetch_paplus_subscriptions_response_entity.dart';
import 'package:nextry_dev/domain/entities/payplus/fetch_payplus_subscription_param.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/domain/interactors/payplus/fetch_payplus_customer_subscription_interactor.dart';

class FetchPayPlusCustomerSubscriptionInteractorImpl
    extends FetchPayPlusCustomerSubscriptionInteractor {
  FetchPayPlusCustomerSubscriptionInteractorImpl({required this.gateway});

  final ReadGateWay<FetchPayPlusSubscriptionsResponseEntity,
      FetchPayPlusSubscriptionParam> gateway;

  @override
  Future<FetchPayPlusSubscriptionsResponseEntity>
      fetchPayPlusCustomerSubscription(
          FetchPayPlusSubscriptionParam fetchPayPlusSubscriptionParam) {
    return gateway.read(fetchPayPlusSubscriptionParam);
  }
}
