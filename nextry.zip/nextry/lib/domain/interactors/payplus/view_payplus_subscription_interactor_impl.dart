import 'package:nextry_dev/domain/entities/payplus/view_payplus_subscription_param.dart';
import 'package:nextry_dev/domain/entities/payplus/view_recurring_response_entiry.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/domain/interactors/payplus/view_payplus_subscription_interactor.dart';

class ViewPayPlusSubscriptionInteractorImpl
    extends ViewPayPlusSubscriptionInteractor {
  ViewPayPlusSubscriptionInteractorImpl({required this.gateway});

  final ReadGateWay<ViewRecurringResponseEntity, ViewPayPlusSubscriptionParam>
      gateway;

  @override
  Future<ViewRecurringResponseEntity> viewPayPlusSubscription(
      ViewPayPlusSubscriptionParam data) {
    return gateway.read(data);
  }
}
