import 'package:nextry_dev/domain/entities/payplus/create_payplus_subscription_param.dart';
import 'package:nextry_dev/domain/entities/payplus/customer_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/domain/interactors/payplus/create_payplus_subscription_interactor.dart';

class CreatePayPlusSubscriptionInteractorImpl
    extends CreatePayPlusSubscriptionInteractor {
  CreatePayPlusSubscriptionInteractorImpl({required this.gateway});

  final ReadGateWay<CustomerResponseEntity, CreatePayPlusSubscriptionParam>
      gateway;

  @override
  Future<CustomerResponseEntity> createPayPlusSubscription(
      CreatePayPlusSubscriptionParam data) {
    return gateway.read(data);
  }
}
