import 'package:nextry_dev/domain/entities/payplus/create_payplus_subscription_param.dart';
import 'package:nextry_dev/domain/entities/payplus/customer_response_entity.dart';

abstract class CreatePayPlusSubscriptionInteractor {
  Future<CustomerResponseEntity> createPayPlusSubscription(
      CreatePayPlusSubscriptionParam createPayPlusSubscriptionParam);
}