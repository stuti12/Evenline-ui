import 'package:nextry_dev/domain/entities/payplus/customer_response_entity.dart';
import 'package:nextry_dev/domain/entities/payplus/delete_payplus_subscription_param.dart';
import 'package:nextry_dev/domain/entities/payplus/payplus_refund_by_transaction_request_param.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/domain/interactors/payplus/delete_payplus_subscription_interactor.dart';
import 'package:nextry_dev/domain/interactors/payplus/refund_by_transaction_payplus_interactor.dart';

class RefundByTransactionIdPayPlusInteractorImpl
    extends RefundByTransactionIdPayPlusInteractor {
  RefundByTransactionIdPayPlusInteractorImpl({required this.gateway});

  final ReadGateWay<CustomerResponseEntity, PayPlusRefundByTransactionRequest>
      gateway;

  @override
  Future<CustomerResponseEntity> refundByTransactionIdPayPlus(
      PayPlusRefundByTransactionRequest data) {
    return gateway.read(data);
  }
}
