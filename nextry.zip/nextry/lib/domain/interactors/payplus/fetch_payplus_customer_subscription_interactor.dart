import 'package:nextry_dev/domain/entities/payplus/customer_response_entity.dart';
import 'package:nextry_dev/domain/entities/payplus/fetch_paplus_subscriptions_response_entity.dart';
import 'package:nextry_dev/domain/entities/payplus/fetch_payplus_subscription_param.dart';
import 'package:nextry_dev/domain/entities/payplus/payplus_refund_by_transaction_request_param.dart';

abstract class FetchPayPlusCustomerSubscriptionInteractor {
  Future<FetchPayPlusSubscriptionsResponseEntity> fetchPayPlusCustomerSubscription(
      FetchPayPlusSubscriptionParam fetchPayPlusSubscriptionParam);
}