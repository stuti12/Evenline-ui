import 'package:nextry_dev/domain/entities/payplus/view_payplus_subscription_param.dart';
import 'package:nextry_dev/domain/entities/payplus/view_recurring_response_entiry.dart';

abstract class ViewPayPlusSubscriptionInteractor {
  Future<ViewRecurringResponseEntity> viewPayPlusSubscription(
      ViewPayPlusSubscriptionParam viewPayPlusSubscriptionParam);
}