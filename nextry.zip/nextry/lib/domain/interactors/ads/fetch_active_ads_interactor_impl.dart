import 'package:nextry_dev/domain/entities/ads/fetch_ads_param.dart';
import 'package:nextry_dev/domain/entities/ads/fetch_all_ads_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/domain/interactors/ads/fetch_active_ads_interactor.dart';

class FetchActiveAdsInteractorImpl extends FetchActiveAdsInteractor {
  FetchActiveAdsInteractorImpl({required this.gateway});

  final ReadGateWay<FetchAllAdsResponseEntity, FetchAdsParam> gateway;

  @override
  Future<FetchAllAdsResponseEntity> fetchActiveAds(FetchAdsParam param) {
    return gateway.read(param);
  }
}
