import 'package:nextry_dev/domain/entities/business/fetch_unavailable_dates_param.dart';
import 'package:nextry_dev/domain/entities/business/fetch_unavailable_dates_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/domain/interactors/ads/fetch_unavailable_dates_interactor.dart';

class FetchUnavailableDatesInteractorImpl
    extends FetchUnavailableDatesInteractor {
  FetchUnavailableDatesInteractorImpl({required this.gateway});

  final ReadGateWay<FetchUnavailableDatesResponseEntity,
      FetchUnavailableDatesParam> gateway;

  @override
  Future<FetchUnavailableDatesResponseEntity> fetchAllUnavailableDates(
      FetchUnavailableDatesParam param) {
    return gateway.read(param);
  }
}
