import 'package:nextry_dev/domain/entities/ads/add_update_ads_response_entity.dart';
import 'package:nextry_dev/domain/entities/ads/fetch_ads_param.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/domain/interactors/ads/remove_ad_interactor.dart';

class RemoveAdInteractorImpl extends RemoveAdInteractor {
  RemoveAdInteractorImpl({required this.gateway});

  final ReadGateWay<AddUpdateAdsResponseEntity, FetchAdsParam> gateway;

  @override
  Future<AddUpdateAdsResponseEntity> removeAd(FetchAdsParam param) {
    return gateway.read(param);
  }
}
