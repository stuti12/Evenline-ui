import 'package:nextry_dev/domain/entities/ads/fetch_home_ads_param.dart';
import 'package:nextry_dev/domain/entities/ads/fetch_home_ads_response_entity.dart';

abstract class FetchHomeAdsInteractor {
  Future<FetchHomeAdsResponseEntity> fetchBusinessAds(
      FetchHomeAdsParam param);

  void unsubscribe();
}
