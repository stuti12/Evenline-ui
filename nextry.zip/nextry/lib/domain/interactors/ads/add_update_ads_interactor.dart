import 'package:nextry_dev/domain/entities/ads/add_update_ads_param.dart';
import 'package:nextry_dev/domain/entities/ads/add_update_ads_response_entity.dart';

abstract class AddUpdateAdsInteractor {
  Future<AddUpdateAdsResponseEntity> addUpdateAdsData(AddUpdateAdsParam param);
}
