import 'package:nextry_dev/domain/entities/ads/add_update_ads_param.dart';
import 'package:nextry_dev/domain/entities/ads/add_update_ads_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/domain/interactors/ads/add_update_ads_interactor.dart';

class AddUpdateAdsInteractorImpl extends AddUpdateAdsInteractor {
  AddUpdateAdsInteractorImpl({required this.gateway});

  final ReadGateWay<AddUpdateAdsResponseEntity, AddUpdateAdsParam> gateway;

  @override
  Future<AddUpdateAdsResponseEntity> addUpdateAdsData(AddUpdateAdsParam param) {
    return gateway.read(param);
  }
}
