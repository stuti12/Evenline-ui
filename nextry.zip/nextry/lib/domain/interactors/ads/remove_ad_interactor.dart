import 'package:nextry_dev/domain/entities/ads/add_update_ads_response_entity.dart';
import 'package:nextry_dev/domain/entities/ads/fetch_ads_param.dart';

abstract class RemoveAdInteractor {
  Future<AddUpdateAdsResponseEntity> removeAd(FetchAdsParam param);
}
