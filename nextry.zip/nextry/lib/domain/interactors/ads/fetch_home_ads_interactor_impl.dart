import 'package:nextry_dev/domain/entities/ads/fetch_home_ads_param.dart';
import 'package:nextry_dev/domain/entities/ads/fetch_home_ads_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/domain/interactors/ads/fetch_home_ads_interactor.dart';

class FetchHomeAdsInteractorImpl extends FetchHomeAdsInteractor {
  FetchHomeAdsInteractorImpl({required this.gateway});

  final ReadGateWay<FetchHomeAdsResponseEntity, FetchHomeAdsParam>
      gateway;

  @override
  Future<FetchHomeAdsResponseEntity> fetchBusinessAds(
      FetchHomeAdsParam param) {
    return gateway.read(param);
  }

  @override
  void unsubscribe() {
      gateway.unsubscribe();
  }
}
