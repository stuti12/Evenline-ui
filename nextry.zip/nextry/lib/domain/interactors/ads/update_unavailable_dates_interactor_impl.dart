import 'package:nextry_dev/domain/entities/ads/update_unavailable_dates_response_entity.dart';
import 'package:nextry_dev/domain/entities/business/fetch_unavailable_dates_param.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/domain/interactors/ads/update_unavailable_dates_interactor.dart';

class UpdateUnavailableDatesInteractorImpl
    extends UpdateUnavailableDatesInteractor {
  UpdateUnavailableDatesInteractorImpl({required this.gateway});

  final ReadGateWay<UpdateUnavailableDatesResponseEntity,
      FetchUnavailableDatesParam> gateway;

  @override
  Future<UpdateUnavailableDatesResponseEntity> updateUnavailableDates(
      FetchUnavailableDatesParam param) {
    return gateway.read(param);
  }
}
