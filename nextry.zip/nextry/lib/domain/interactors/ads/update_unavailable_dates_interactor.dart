import 'package:nextry_dev/domain/entities/ads/update_unavailable_dates_response_entity.dart';
import 'package:nextry_dev/domain/entities/business/fetch_unavailable_dates_param.dart';

abstract class UpdateUnavailableDatesInteractor {
  Future<UpdateUnavailableDatesResponseEntity> updateUnavailableDates(
      FetchUnavailableDatesParam param);
}
