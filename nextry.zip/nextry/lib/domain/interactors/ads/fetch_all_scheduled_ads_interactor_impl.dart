import 'package:nextry_dev/domain/entities/ads/fetch_ads_param.dart';
import 'package:nextry_dev/domain/entities/ads/fetch_all_ads_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/domain/interactors/ads/fetch_all_scheduled_ads_interactor.dart';

class FetchAllScheduledAdsInteractorImpl
    extends FetchAllScheduledAdsInteractor {
  FetchAllScheduledAdsInteractorImpl({required this.gateway});

  final ReadGateWay<FetchAllAdsResponseEntity, FetchAdsParam> gateway;

  @override
  Future<FetchAllAdsResponseEntity> fetchAllAds(FetchAdsParam param) {
    return gateway.read(param);
  }
}
