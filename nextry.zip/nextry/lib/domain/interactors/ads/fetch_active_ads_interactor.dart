import 'package:nextry_dev/domain/entities/ads/fetch_ads_param.dart';
import 'package:nextry_dev/domain/entities/ads/fetch_all_ads_response_entity.dart';

abstract class FetchActiveAdsInteractor {
  Future<FetchAllAdsResponseEntity> fetchActiveAds(FetchAdsParam param);
}
