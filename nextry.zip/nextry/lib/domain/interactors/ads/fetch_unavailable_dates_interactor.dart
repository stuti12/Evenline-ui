import 'package:nextry_dev/domain/entities/business/fetch_unavailable_dates_param.dart';
import 'package:nextry_dev/domain/entities/business/fetch_unavailable_dates_response_entity.dart';

abstract class FetchUnavailableDatesInteractor {
  Future<FetchUnavailableDatesResponseEntity> fetchAllUnavailableDates(
      FetchUnavailableDatesParam param);
}
