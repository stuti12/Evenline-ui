import 'package:nextry_dev/domain/entities/payment_link/add_update_request_payment_link_response_entity.dart';
import 'package:nextry_dev/domain/entities/payment_link/request_payment_link_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/domain/interactors/shipper_payment_link/add_update_request_payment_link_interactor.dart';

class AddUpdateShipperRequestPaymentLinkInteractorImpl
    extends AddUpdateShipperRequestPaymentLinkInteractor {
  AddUpdateShipperRequestPaymentLinkInteractorImpl({required this.gateway});

  final ReadGateWay<AddUpdateRequestPaymentLinkResponseEntity,
      RequestPaymentLinkEntity> gateway;

  @override
  Future<AddUpdateRequestPaymentLinkResponseEntity>
      addUpdateShipperRequestPaymentLink(RequestPaymentLinkEntity param) {
    return gateway.read(param);
  }
}
