import 'package:nextry_dev/domain/entities/payment_link/add_update_request_payment_link_response_entity.dart';
import 'package:nextry_dev/domain/entities/payment_link/request_payment_link_entity.dart';

abstract class AddUpdateShipperRequestPaymentLinkInteractor {
  Future<AddUpdateRequestPaymentLinkResponseEntity> addUpdateShipperRequestPaymentLink(
      RequestPaymentLinkEntity param);
}
