import 'package:nextry_dev/domain/interactors/verifyemail/send_email_verification_interactor.dart';
import 'package:nextry_dev/domain/gateway/read_gateway_no_args.dart';

class SendEmailVerificationInteractorImpl
    extends SendEmailVerificationInteractor {
  SendEmailVerificationInteractorImpl({required this.gateway});

  final ReadGateWayNoArgs<void> gateway;

  @override
  Future<void> sendEmailVerification() {
    return gateway.read();
  }
}
