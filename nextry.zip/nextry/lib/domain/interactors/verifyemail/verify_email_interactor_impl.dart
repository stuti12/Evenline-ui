import 'package:nextry_dev/domain/entities/verifyemail/verify_email_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway_no_args.dart';
import 'package:nextry_dev/domain/interactors/verifyemail/verify_email_interactor.dart';

class VerifyEmailInteractorImpl extends VerifyEmailInteractor {
  VerifyEmailInteractorImpl({required this.gateway});

  final ReadGateWayNoArgs<VerifyEmailResponseEntity> gateway;

  @override
  Future<VerifyEmailResponseEntity> verifyEmail() {
    return gateway.read();
  }
}
