abstract class SendEmailVerificationInteractor {
  Future<void> sendEmailVerification();
}
