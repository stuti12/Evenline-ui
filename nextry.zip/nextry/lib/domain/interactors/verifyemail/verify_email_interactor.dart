import 'package:nextry_dev/domain/entities/verifyemail/verify_email_response_entity.dart';

abstract class VerifyEmailInteractor {
  Future<VerifyEmailResponseEntity> verifyEmail();
}
