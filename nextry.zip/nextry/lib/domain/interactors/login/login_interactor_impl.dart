import 'package:nextry_dev/domain/entities/login/login_param.dart';
import 'package:nextry_dev/domain/entities/login/login_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/domain/interactors/login/login_interactor.dart';

class LoginInteractorImpl extends LoginInteractor {
  LoginInteractorImpl({required this.gateway});

  final ReadGateWay<LoginResponseEntity?, LoginParam> gateway;

  @override
  Future<LoginResponseEntity?> doLogin(LoginParam loginParam) {
    return gateway.read(loginParam);
  }
}
