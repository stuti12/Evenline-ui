import 'package:nextry_dev/domain/entities/login/login_param.dart';
import 'package:nextry_dev/domain/entities/login/login_response_entity.dart';

abstract class LoginInteractor {
  Future<LoginResponseEntity?> doLogin(LoginParam loginParam);
}
