import 'package:nextry_dev/domain/entities/subscriptions/fetch_subscription_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway_no_args.dart';
import 'package:nextry_dev/domain/interactors/shipper_subscription/fetch_shipper_subscription_data_interactor.dart';

class FetchShipperSubscriptionDataInteractorImpl
    extends FetchShipperSubscriptionDataInteractor {
  FetchShipperSubscriptionDataInteractorImpl({required this.gateway});

  final ReadGateWayNoArgs<FetchSubscriptionResponseEntity> gateway;

  @override
  Future<FetchSubscriptionResponseEntity> fetchShipperSubscriptionData() {
    return gateway.read();
  }
}
