import 'package:nextry_dev/domain/entities/subscriptions/fetch_subscription_response_entity.dart';

abstract class FetchShipperSubscriptionDataInteractor {
  Future<FetchSubscriptionResponseEntity> fetchShipperSubscriptionData();
}
