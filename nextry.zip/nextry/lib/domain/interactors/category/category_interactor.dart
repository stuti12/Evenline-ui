import 'package:nextry_dev/domain/entities/category/category_response_entity.dart';

abstract class CategoryInteractor {
  Future<CategoryResponseEntity> fetchCategories();
}
