import 'package:nextry_dev/domain/entities/category/category_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway_no_args.dart';
import 'package:nextry_dev/domain/interactors/category/category_interactor.dart';

class CategoryInteractorImpl extends CategoryInteractor {
  CategoryInteractorImpl({required this.gateway});

  final ReadGateWayNoArgs<CategoryResponseEntity> gateway;

  @override
  Future<CategoryResponseEntity> fetchCategories() {
    return gateway.read();
  }
}
