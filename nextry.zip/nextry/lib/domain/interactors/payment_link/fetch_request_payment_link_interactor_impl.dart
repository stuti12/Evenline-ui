import 'package:nextry_dev/domain/entities/payment_link/fetch_request_payment_link_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/domain/interactors/payment_link/fetch_request_payment_link_interactor.dart';

class FetchRequestPaymentLinkInteractorImpl
    extends FetchRequestPaymentLinkInteractor {
  FetchRequestPaymentLinkInteractorImpl({required this.gateway});

  final ReadGateWay<FetchRequestPaymentLinkResponseEntity, bool> gateway;

  @override
  Future<FetchRequestPaymentLinkResponseEntity> fetchRequestPaymentLinks(
      bool isHandled) {
    return gateway.read(isHandled);
  }
}
