import 'package:nextry_dev/domain/entities/payment_link/fetch_request_payment_link_by_business_id_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/domain/interactors/payment_link/fetch_request_payment_link_by_business_id_interactor.dart';

class FetchRequestPaymentLinkByBusinessIdInteractorImpl
    extends FetchRequestPaymentLinkByBusinessIdInteractor {
  FetchRequestPaymentLinkByBusinessIdInteractorImpl({required this.gateway});

  final ReadGateWay<FetchRequestPaymentLinkByBusinessIdResponseEntity, String>
      gateway;

  @override
  Future<FetchRequestPaymentLinkByBusinessIdResponseEntity>
      fetchRequestPaymentLinkByBusinessId(String businessId) {
    return gateway.read(businessId);
  }
}
