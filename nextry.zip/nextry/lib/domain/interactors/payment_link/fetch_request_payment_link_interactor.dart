import 'package:nextry_dev/domain/entities/payment_link/fetch_request_payment_link_response_entity.dart';

abstract class FetchRequestPaymentLinkInteractor {
  Future<FetchRequestPaymentLinkResponseEntity> fetchRequestPaymentLinks(
      bool isHandled);
}
