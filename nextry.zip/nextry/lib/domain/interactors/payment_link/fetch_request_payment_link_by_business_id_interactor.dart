import 'package:nextry_dev/domain/entities/payment_link/fetch_request_payment_link_by_business_id_response_entity.dart';

abstract class FetchRequestPaymentLinkByBusinessIdInteractor {
  Future<FetchRequestPaymentLinkByBusinessIdResponseEntity>
      fetchRequestPaymentLinkByBusinessId(String businessId);
}
