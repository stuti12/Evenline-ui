import 'package:nextry_dev/domain/entities/config/payplus_payment_config_entity.dart';

abstract class FetchPayPlusPaymentConfigInteractor {
  Future<PayPlusPaymentConfigEntity> fetchPayPlusPaymentConfigData();
}
