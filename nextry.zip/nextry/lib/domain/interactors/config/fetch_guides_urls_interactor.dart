import 'package:nextry_dev/domain/entities/config/guides_urls_response_entity.dart';

abstract class FetchGuidesUrlsInteractor {
  Future<GuidesUrlsResponseEntity> fetchGuidesUrls();
}
