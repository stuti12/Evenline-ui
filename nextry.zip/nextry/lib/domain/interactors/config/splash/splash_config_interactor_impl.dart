import 'package:nextry_dev/domain/entities/config/splash/splash_config_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway_no_args.dart';
import 'package:nextry_dev/domain/interactors/config/splash/splash_config_interactor.dart';

class SplashConfigInteractorImpl extends SplashConfigInteractor {
  SplashConfigInteractorImpl({required this.gateway});

  final ReadGateWayNoArgs<SplashConfigResponseEntity> gateway;

  @override
  Future<SplashConfigResponseEntity> fetchSplashConfigData() {
    return gateway.read();
  }
}
