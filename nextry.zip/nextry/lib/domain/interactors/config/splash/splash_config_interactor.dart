import 'package:nextry_dev/domain/entities/config/splash/splash_config_response_entity.dart';

abstract class SplashConfigInteractor {
  Future<SplashConfigResponseEntity> fetchSplashConfigData();
}
