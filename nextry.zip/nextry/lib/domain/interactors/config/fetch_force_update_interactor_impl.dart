import 'package:nextry_dev/domain/entities/config/force_update_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway_no_args.dart';
import 'package:nextry_dev/domain/interactors/config/fetch_force_update_interactor.dart';

class FetchForceUpdateInteractorImpl extends FetchForceUpdateInteractor {
  FetchForceUpdateInteractorImpl({required this.gateway});

  final ReadGateWayNoArgs<ForceUpdateResponseEntity> gateway;

  @override
  Future<ForceUpdateResponseEntity> fetchForceUpdateData() {
    return gateway.read();
  }
}
