import 'package:nextry_dev/domain/entities/config/payplus_payment_config_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway_no_args.dart';
import 'package:nextry_dev/domain/interactors/config/fetch_payplus_payment_config_interactor.dart';

class FetchPayPlusPaymentConfigInteractorImpl
    extends FetchPayPlusPaymentConfigInteractor {
  FetchPayPlusPaymentConfigInteractorImpl({required this.gateway});

  final ReadGateWayNoArgs<PayPlusPaymentConfigEntity> gateway;

  @override
  Future<PayPlusPaymentConfigEntity> fetchPayPlusPaymentConfigData() {
    return gateway.read();
  }
}
