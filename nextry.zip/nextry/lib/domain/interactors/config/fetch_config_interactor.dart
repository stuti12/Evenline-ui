import 'package:nextry_dev/domain/entities/config/config_response_entity.dart';

abstract class FetchConfigInteractor {
  Future<ConfigResponseEntity> fetchConfigurations();
}
