import 'package:nextry_dev/domain/entities/config/force_update_response_entity.dart';

abstract class FetchForceUpdateInteractor {
  Future<ForceUpdateResponseEntity> fetchForceUpdateData();
}
