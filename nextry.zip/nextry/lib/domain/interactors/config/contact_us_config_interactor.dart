import 'package:nextry_dev/domain/entities/config/contact_us_config_response_entity.dart';

abstract class ContactUsConfigInteractor {
  Future<ContactUsConfigResponseEntity> fetchContactUsConfigData();
}
