import 'package:nextry_dev/domain/entities/config/contact_us_config_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway_no_args.dart';
import 'package:nextry_dev/domain/interactors/config/contact_us_config_interactor.dart';

class ContactUsConfigInteractorImpl extends ContactUsConfigInteractor {
  ContactUsConfigInteractorImpl({required this.gateway});

  final ReadGateWayNoArgs<ContactUsConfigResponseEntity> gateway;

  @override
  Future<ContactUsConfigResponseEntity> fetchContactUsConfigData() {
    return gateway.read();
  }
}
