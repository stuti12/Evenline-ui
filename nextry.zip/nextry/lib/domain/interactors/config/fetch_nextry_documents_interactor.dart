import 'package:nextry_dev/domain/entities/config/nextry_documents_response_entity.dart';

abstract class FetchNextryDocumentsInteractor {
  Future<NextryDocumentsResponseEntity> fetchNextryDocuments();
}
