import 'package:nextry_dev/domain/entities/config/config_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway_no_args.dart';
import 'package:nextry_dev/domain/interactors/config/fetch_config_interactor.dart';

class FetchConfigInteractorImpl extends FetchConfigInteractor {
  FetchConfigInteractorImpl({required this.gateway});

  final ReadGateWayNoArgs<ConfigResponseEntity> gateway;

  @override
  Future<ConfigResponseEntity> fetchConfigurations() {
    return gateway.read();
  }
}
