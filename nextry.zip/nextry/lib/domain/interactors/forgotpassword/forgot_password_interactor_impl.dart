import 'package:nextry_dev/domain/entities/forgotpassword/forgot_password_param.dart';
import 'package:nextry_dev/domain/entities/forgotpassword/forgot_password_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';

import 'forgot_password_interactor.dart';

class ForgotPasswordInteractorImpl extends ForgotPasswordInteractor {
  ForgotPasswordInteractorImpl({required this.gateway});

  final ReadGateWay<ForgotPasswordResponseEntity, ForgotPasswordParam> gateway;

  @override
  Future<ForgotPasswordResponseEntity> requestResetLink(
      ForgotPasswordParam forgotPasswordParam) {
    return gateway.read(forgotPasswordParam);
  }
}
