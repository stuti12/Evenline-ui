
import 'package:nextry_dev/domain/entities/forgotpassword/forgot_password_param.dart';
import 'package:nextry_dev/domain/entities/forgotpassword/forgot_password_response_entity.dart';

abstract class ForgotPasswordInteractor {
  Future<ForgotPasswordResponseEntity> requestResetLink(
      ForgotPasswordParam forgotPasswordParam);
}
