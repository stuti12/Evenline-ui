import 'package:nextry_dev/domain/entities/business/update_business_status_response_entity.dart';
import 'package:nextry_dev/domain/entities/business/update_business_subscription_param.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/domain/interactors/business/update_business_subscription_id_interactor.dart';

class UpdateBusinessSubscriptionIdInteractorImpl
    extends UpdateBusinessSubscriptionIdInteractor {
  UpdateBusinessSubscriptionIdInteractorImpl({required this.gateway});

  final ReadGateWay<UpdateBusinessStatusResponseEntity,
      UpdateBusinessSubscriptionParam> gateway;

  @override
  Future<UpdateBusinessStatusResponseEntity> updateSubscriptionId(
      UpdateBusinessSubscriptionParam param) {
    return gateway.read(param);
  }
}
