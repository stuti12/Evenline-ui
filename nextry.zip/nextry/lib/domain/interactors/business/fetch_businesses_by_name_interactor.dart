import 'package:nextry_dev/domain/entities/business/fetch_business_by_name_param.dart';
import 'package:nextry_dev/domain/entities/business/fetch_business_by_name_response_entity.dart';

abstract class FetchBusinessesByNameInteractor {
  Future<FetchBusinessesByNameResponseEntity> fetchBusinessByName(
      FetchBusinessByNameParam param);
}
