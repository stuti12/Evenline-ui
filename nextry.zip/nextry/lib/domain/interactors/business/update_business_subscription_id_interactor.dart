import 'package:nextry_dev/domain/entities/business/update_business_status_response_entity.dart';
import 'package:nextry_dev/domain/entities/business/update_business_subscription_param.dart';

abstract class UpdateBusinessSubscriptionIdInteractor {
  Future<UpdateBusinessStatusResponseEntity> updateSubscriptionId(
      UpdateBusinessSubscriptionParam param);
}
