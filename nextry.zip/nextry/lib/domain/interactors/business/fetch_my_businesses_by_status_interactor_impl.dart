import 'package:nextry_dev/domain/entities/business/fetch_business_param.dart';
import 'package:nextry_dev/domain/entities/business/fetch_my_businesses_by_status_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/domain/interactors/business/fetch_my_businesses_by_status_interactor.dart';

class FetchMyBusinessesByStatusInteractorImpl
    extends FetchMyBusinessesByStatusInteractor {
  FetchMyBusinessesByStatusInteractorImpl({required this.gateway});

  final ReadGateWay<FetchMyBusinessesByStatusResponseEntity, FetchBusinessParam>
      gateway;

  @override
  Future<FetchMyBusinessesByStatusResponseEntity> fetchMyBusinessesByStatus(
      FetchBusinessParam fetchBusinessParam) {
    return gateway.read(fetchBusinessParam);
  }

  @override
  void unsubscribe() {
    gateway.unsubscribe();
  }


}
