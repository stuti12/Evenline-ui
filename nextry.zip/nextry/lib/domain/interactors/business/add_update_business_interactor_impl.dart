import 'package:nextry_dev/domain/entities/business/add_update_business_response_entity.dart';
import 'package:nextry_dev/domain/entities/business/business_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/domain/interactors/business/add_update_business_interactor.dart';

class AddUpdateBusinessInteractorImpl extends AddUpdateBusinessInteractor {
  AddUpdateBusinessInteractorImpl({required this.gateway});

  final ReadGateWay<AddUpdateBusinessResponseEntity, BusinessEntity> gateway;

  @override
  Future<AddUpdateBusinessResponseEntity> addUpdateBusinessData(
      BusinessEntity businessEntity) {
    return gateway.read(businessEntity);
  }
}
