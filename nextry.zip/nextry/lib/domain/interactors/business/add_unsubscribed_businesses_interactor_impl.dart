import 'package:nextry_dev/domain/entities/business/add_unsubscribed_businesses_response_entity.dart';
import 'package:nextry_dev/domain/entities/business/unsubscribed_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/domain/interactors/business/add_unsubscribed_businesses_interactor.dart';

class AddUnSubscribedBusinessesInteractorImpl
    extends AddUnSubscribedBusinessesInteractor {
  AddUnSubscribedBusinessesInteractorImpl({required this.gateway});

  final ReadGateWay<AddUnSubscribedBusinessesResponseEntity, UnSubscribedEntity>
      gateway;

  @override
  Future<AddUnSubscribedBusinessesResponseEntity> addUnSubscribedBusinesses(
      UnSubscribedEntity param) {
    return gateway.read(param);
  }
}
