import 'package:nextry_dev/domain/entities/business/add_update_business_response_entity.dart';
import 'package:nextry_dev/domain/entities/business/business_entity.dart';

abstract class AddUpdateBusinessInteractor {
  Future<AddUpdateBusinessResponseEntity> addUpdateBusinessData(
      BusinessEntity businessEntity);
}
