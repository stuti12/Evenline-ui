import 'package:nextry_dev/domain/entities/business/fetch_business_by_name_param.dart';
import 'package:nextry_dev/domain/entities/business/fetch_business_by_name_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/domain/interactors/business/fetch_businesses_by_name_interactor.dart';

class FetchBusinessesByNameInteractorImpl extends FetchBusinessesByNameInteractor {
  FetchBusinessesByNameInteractorImpl({required this.gateway});

  final ReadGateWay<FetchBusinessesByNameResponseEntity,
      FetchBusinessByNameParam> gateway;

  @override
  Future<FetchBusinessesByNameResponseEntity> fetchBusinessByName(
      FetchBusinessByNameParam param) {
    return gateway.read(param);
  }
}
