import 'package:nextry_dev/domain/entities/business/fetch_business_param.dart';
import 'package:nextry_dev/domain/entities/business/fetch_business_response_entity.dart';

abstract class FetchBusinessDataInteractor {
  Future<FetchBusinessResponseEntity> fetchBusinessData(
      FetchBusinessParam fetchBusinessParam);

  void unsubscribe();
}
