import 'package:nextry_dev/domain/entities/business/business_entity.dart';
import 'package:nextry_dev/domain/entities/business/fetch_business_param.dart';
import 'package:nextry_dev/domain/entities/business/fetch_my_businesses_by_status_response_entity.dart';

abstract class FetchMyBusinessesByStatusInteractor {
  Future<FetchMyBusinessesByStatusResponseEntity> fetchMyBusinessesByStatus(
      FetchBusinessParam fetchBusinessParam);

  void unsubscribe();
}
