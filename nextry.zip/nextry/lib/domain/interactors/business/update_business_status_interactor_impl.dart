import 'package:nextry_dev/domain/entities/business/update_business_status_param.dart';
import 'package:nextry_dev/domain/entities/business/update_business_status_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/domain/interactors/business/update_business_status_interactor.dart';

class UpdateBusinessStatusInteractorImpl
    extends UpdateBusinessStatusInteractor {
  UpdateBusinessStatusInteractorImpl({required this.gateway});

  final ReadGateWay<UpdateBusinessStatusResponseEntity,
      UpdateBusinessStatusParam> gateway;

  @override
  Future<UpdateBusinessStatusResponseEntity> updateBusinessStatus(
      UpdateBusinessStatusParam updateBusinessStatusParam) {
    return gateway.read(updateBusinessStatusParam);
  }
}
