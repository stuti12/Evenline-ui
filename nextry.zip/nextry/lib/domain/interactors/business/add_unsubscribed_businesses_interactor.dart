import 'package:nextry_dev/domain/entities/business/add_unsubscribed_businesses_response_entity.dart';
import 'package:nextry_dev/domain/entities/business/unsubscribed_entity.dart';

abstract class AddUnSubscribedBusinessesInteractor {
  Future<AddUnSubscribedBusinessesResponseEntity> addUnSubscribedBusinesses(
      UnSubscribedEntity param);
}
