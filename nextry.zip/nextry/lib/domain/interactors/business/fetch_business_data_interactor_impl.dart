import 'package:nextry_dev/domain/entities/business/fetch_business_param.dart';
import 'package:nextry_dev/domain/entities/business/fetch_business_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/domain/interactors/business/fetch_business_data_interactor.dart';

class FetchBusinessDataInteractorImpl extends FetchBusinessDataInteractor {
  FetchBusinessDataInteractorImpl({required this.gateway});

  final ReadGateWay<FetchBusinessResponseEntity, FetchBusinessParam> gateway;

  @override
  Future<FetchBusinessResponseEntity> fetchBusinessData(
      FetchBusinessParam fetchBusinessParam) {
    return gateway.read(fetchBusinessParam);
  }

  @override
  void unsubscribe() {
    gateway.unsubscribe();
  }
}
