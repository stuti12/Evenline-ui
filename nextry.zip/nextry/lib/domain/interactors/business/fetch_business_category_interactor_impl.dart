import 'package:nextry_dev/domain/entities/business/fetch_business_category_param.dart';
import 'package:nextry_dev/domain/entities/business/fetch_business_category_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/domain/interactors/business/fetch_business_category_interactor.dart';

class FetchBusinessCategoryInteractorImpl
    extends FetchBusinessCategoryInteractor {
  FetchBusinessCategoryInteractorImpl({required this.gateway});

  final ReadGateWay<FetchBusinessCategoryResponseEntity,
      FetchBusinessCategoryParam> gateway;

  @override
  Future<FetchBusinessCategoryResponseEntity> fetchBusinessCategories(
      FetchBusinessCategoryParam data) {
    return gateway.read(data);
  }

  @override
  void unsubscribe() {
    gateway.unsubscribe();
  }
}
