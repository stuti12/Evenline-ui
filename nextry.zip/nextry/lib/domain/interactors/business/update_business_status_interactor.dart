import 'package:nextry_dev/domain/entities/business/update_business_status_param.dart';
import 'package:nextry_dev/domain/entities/business/update_business_status_response_entity.dart';

abstract class UpdateBusinessStatusInteractor {
  Future<UpdateBusinessStatusResponseEntity> updateBusinessStatus(
      UpdateBusinessStatusParam updateBusinessStatusParam);
}
