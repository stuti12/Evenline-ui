import 'package:nextry_dev/domain/entities/business/add_business_category_param.dart';
import 'package:nextry_dev/domain/entities/business/add_business_category_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/domain/interactors/business/add_business_category_interactor.dart';

class AddBusinessCategoryInteractorImpl extends AddBusinessCategoryInteractor {
  AddBusinessCategoryInteractorImpl({required this.gateway});

  final ReadGateWay<AddBusinessCategoryResponseEntity, AddBusinessCategoryParam>
      gateway;

  @override
  Future<AddBusinessCategoryResponseEntity> addBusinessCategory(
      AddBusinessCategoryParam addBusinessCategoryParam) {
    return gateway.read(addBusinessCategoryParam);
  }
}
