import 'package:nextry_dev/domain/entities/business/add_business_category_param.dart';
import 'package:nextry_dev/domain/entities/business/add_business_category_response_entity.dart';

abstract class AddBusinessCategoryInteractor {
  Future<AddBusinessCategoryResponseEntity> addBusinessCategory(
      AddBusinessCategoryParam addBusinessCategoryParam);
}
