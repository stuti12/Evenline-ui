import 'package:nextry_dev/domain/entities/business/fetch_business_category_param.dart';
import 'package:nextry_dev/domain/entities/business/fetch_business_category_response_entity.dart';

abstract class FetchBusinessCategoryInteractor {
  Future<FetchBusinessCategoryResponseEntity> fetchBusinessCategories(
      FetchBusinessCategoryParam data);

  void unsubscribe();
}
