import 'package:nextry_dev/domain/entities/hotdeal/make_hot_deal_ad_param.dart';
import 'package:nextry_dev/domain/entities/hotdeal/make_hot_deal_ad_response_entity.dart';

abstract class MakeHotDealAdInteractor {
  Future<MakeHotDealAdResponseEntity> makeHotDeal(MakeHotDealAdParam param);
}
