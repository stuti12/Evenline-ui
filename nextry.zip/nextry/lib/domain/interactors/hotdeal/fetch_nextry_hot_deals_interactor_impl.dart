import 'package:nextry_dev/domain/entities/hotdeal/fetch_all_scheduled_hot_deal_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway_no_args.dart';
import 'package:nextry_dev/domain/interactors/hotdeal/fetch_nextry_hot_deals_interactor.dart';

class FetchNextryHotDealsInteractorImpl extends FetchNextryHotDealsInteractor {
  FetchNextryHotDealsInteractorImpl({required this.gateway});

  final ReadGateWayNoArgs<FetchAllScheduledHotDealResponseEntity> gateway;

  @override
  Future<FetchAllScheduledHotDealResponseEntity> fetchNextryHotDeals() {
    return gateway.read();
  }
}
