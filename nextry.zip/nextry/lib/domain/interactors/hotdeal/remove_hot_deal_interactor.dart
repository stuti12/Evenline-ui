import 'package:nextry_dev/domain/entities/hotdeal/make_hot_deal_ad_response_entity.dart';
import 'package:nextry_dev/domain/entities/hotdeal/remove_hot_deal_param.dart';

abstract class RemoveHotDealInteractor {
  Future<MakeHotDealAdResponseEntity> deleteHotDeal(RemoveHotDealParam param);
}
