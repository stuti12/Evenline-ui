import 'package:nextry_dev/domain/entities/hotdeal/fetch_all_scheduled_hot_deal_response_entity.dart';

abstract class FetchNextryHotDealsInteractor {
  Future<FetchAllScheduledHotDealResponseEntity> fetchNextryHotDeals();
}
