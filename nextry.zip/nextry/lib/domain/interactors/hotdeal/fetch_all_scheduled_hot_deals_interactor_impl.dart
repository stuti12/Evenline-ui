import 'package:nextry_dev/domain/entities/hotdeal/fetch_all_scheduled_hot_deal_response_entity.dart';
import 'package:nextry_dev/domain/entities/hotdeal/make_hot_deal_ad_param.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/domain/interactors/hotdeal/fetch_all_scheduled_hot_deals_interactor.dart';

class FetchAllScheduledHotDealsInteractorImpl
    extends FetchAllScheduledHotDealsInteractor {
  FetchAllScheduledHotDealsInteractorImpl({required this.gateway});

  final ReadGateWay<FetchAllScheduledHotDealResponseEntity, MakeHotDealAdParam>
      gateway;

  @override
  Future<FetchAllScheduledHotDealResponseEntity> fetchHotDeals(
      MakeHotDealAdParam param) {
    return gateway.read(param);
  }
}
