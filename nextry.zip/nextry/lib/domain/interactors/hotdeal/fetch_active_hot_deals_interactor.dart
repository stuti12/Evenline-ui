import 'package:nextry_dev/domain/entities/hotdeal/fetch_all_scheduled_hot_deal_response_entity.dart';
import 'package:nextry_dev/domain/entities/hotdeal/fetch_active_hot_deal_param.dart';

abstract class FetchActiveHotDealsInteractor {
  Future<FetchAllScheduledHotDealResponseEntity> fetchActiveHotDeals(
      FetchActiveHotDealParam param);
}
