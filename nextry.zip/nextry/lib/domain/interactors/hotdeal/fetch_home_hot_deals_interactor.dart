import 'package:nextry_dev/domain/entities/hotdeal/fetch_all_scheduled_hot_deal_response_entity.dart';
import 'package:nextry_dev/domain/entities/hotdeal/fetch_home_hot_deals_param.dart';

abstract class FetchHomeHotDealsInteractor {
  Future<FetchAllScheduledHotDealResponseEntity> fetchHotDeals(
      FetchHomeHotDealsParam param);

  void unsubscribe();
}
