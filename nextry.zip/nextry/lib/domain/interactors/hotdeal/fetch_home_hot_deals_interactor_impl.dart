import 'package:nextry_dev/domain/entities/hotdeal/fetch_all_scheduled_hot_deal_response_entity.dart';
import 'package:nextry_dev/domain/entities/hotdeal/fetch_home_hot_deals_param.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/domain/interactors/hotdeal/fetch_home_hot_deals_interactor.dart';

class FetchHomeHotDealsInteractorImpl extends FetchHomeHotDealsInteractor {
  FetchHomeHotDealsInteractorImpl({required this.gateway});

  final ReadGateWay<FetchAllScheduledHotDealResponseEntity,
      FetchHomeHotDealsParam> gateway;

  @override
  Future<FetchAllScheduledHotDealResponseEntity> fetchHotDeals(
      FetchHomeHotDealsParam param) {
    return gateway.read(param);
  }

  @override
  void unsubscribe() {
    gateway.unsubscribe();
  }
}
