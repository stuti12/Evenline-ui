import 'package:nextry_dev/domain/entities/hotdeal/make_hot_deal_ad_param.dart';
import 'package:nextry_dev/domain/entities/hotdeal/make_hot_deal_ad_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/domain/interactors/hotdeal/make_hot_deal_ad_interactor.dart';

class MakeHotDealAdInteractorImpl extends MakeHotDealAdInteractor {
  MakeHotDealAdInteractorImpl({required this.gateway});

  final ReadGateWay<MakeHotDealAdResponseEntity, MakeHotDealAdParam> gateway;

  @override
  Future<MakeHotDealAdResponseEntity> makeHotDeal(MakeHotDealAdParam param) {
    return gateway.read(param);
  }
}
