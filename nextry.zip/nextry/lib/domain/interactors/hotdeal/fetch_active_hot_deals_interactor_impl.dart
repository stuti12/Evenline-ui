import 'package:nextry_dev/domain/entities/hotdeal/fetch_all_scheduled_hot_deal_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/domain/entities/hotdeal/fetch_active_hot_deal_param.dart';
import 'package:nextry_dev/domain/interactors/hotdeal/fetch_active_hot_deals_interactor.dart';

class FetchActiveHotDealsInteractorImpl extends FetchActiveHotDealsInteractor {
  FetchActiveHotDealsInteractorImpl({required this.gateway});

  final ReadGateWay<FetchAllScheduledHotDealResponseEntity,
      FetchActiveHotDealParam> gateway;

  @override
  Future<FetchAllScheduledHotDealResponseEntity> fetchActiveHotDeals(
      FetchActiveHotDealParam param) {
    return gateway.read(param);
  }
}
