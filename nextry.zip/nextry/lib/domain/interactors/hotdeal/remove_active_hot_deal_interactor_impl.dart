import 'package:nextry_dev/domain/entities/hotdeal/make_hot_deal_ad_response_entity.dart';
import 'package:nextry_dev/domain/entities/hotdeal/remove_hot_deal_param.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/domain/interactors/hotdeal/remove_active_hot_deal_interactor.dart';

class RemoveActiveHotDealInteractorImpl extends RemoveActiveHotDealInteractor {
  RemoveActiveHotDealInteractorImpl({required this.gateway});

  final ReadGateWay<MakeHotDealAdResponseEntity, RemoveHotDealParam> gateway;

  @override
  Future<MakeHotDealAdResponseEntity> deleteActiveHotDeal(
      RemoveHotDealParam param) {
    return gateway.read(param);
  }
}
