import 'package:nextry_dev/domain/entities/order/make_order_param.dart';
import 'package:nextry_dev/domain/entities/order/make_order_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/domain/interactors/order/make_order_interactor.dart';

class MakeOrderInteractorImpl extends MakeOrderInteractor {
  MakeOrderInteractorImpl({required this.gateway});

  final ReadGateWay<MakeOrderResponseEntity, MakeOrderParam> gateway;

  @override
  Future<MakeOrderResponseEntity> makeOrder(MakeOrderParam param) {
    return gateway.read(param);
  }
}
