import 'package:nextry_dev/domain/entities/order/make_order_param.dart';
import 'package:nextry_dev/domain/entities/order/make_order_response_entity.dart';

abstract class MakeOrderInteractor {
  Future<MakeOrderResponseEntity> makeOrder(MakeOrderParam param);
}
