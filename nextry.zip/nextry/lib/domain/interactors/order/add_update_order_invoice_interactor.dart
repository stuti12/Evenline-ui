import 'package:nextry_dev/domain/entities/order/add_update_order_invoice_param.dart';
import 'package:nextry_dev/domain/entities/order/add_update_order_invoice_response_entity.dart';

abstract class AddUpdateOrderInvoiceInteractor {
  Future<AddUpdateOrderInvoiceResponseEntity> addUpdateOrderInvoiceFile(
      AddUpdateOrderInvoiceParam data);
}
