import 'package:nextry_dev/domain/entities/order/canel_order_param.dart';
import 'package:nextry_dev/domain/entities/order/update_order_status_response_entity.dart';

abstract class CancelOrderStatusInteractor {
  Future<UpdateOrderStatusResponseEntity> cancelOrder(
      CancelOrderParam cancelOrderParam);
}
