import 'package:nextry_dev/domain/entities/order/fetch_orders_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/domain/interactors/order/fetch_customer_orders_interactor.dart';

class FetchCustomerOrdersInteractorImpl extends FetchCustomerOrdersInteractor {
  FetchCustomerOrdersInteractorImpl({required this.gateway});

  final ReadGateWay<FetchOrdersResponseEntity, Function> gateway;

  @override
  Future<FetchOrdersResponseEntity> fetchCustomerOrders(Function function) {
    return gateway.read(function);
  }

  @override
  void unsubscribe() {
    gateway.unsubscribe();
  }
}
