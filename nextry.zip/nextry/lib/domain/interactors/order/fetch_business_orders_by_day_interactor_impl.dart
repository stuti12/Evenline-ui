import 'package:nextry_dev/domain/entities/order/fetch_business_orders_by_day_response_entity.dart';
import 'package:nextry_dev/domain/entities/order/fetch_orders_param.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/domain/interactors/order/fetch_business_orders_by_day_interactor.dart';

class FetchBusinessOrdersByDayInteractorImpl
    extends FetchBusinessOrdersByDayInteractor {
  FetchBusinessOrdersByDayInteractorImpl({required this.gateway});

  final ReadGateWay<FetchBusinessOrdersByDayResponseEntity, FetchOrdersParam>
      gateway;

  @override
  Future<FetchBusinessOrdersByDayResponseEntity> fetchBusinessOrdersByDay(
      FetchOrdersParam fetchOrdersParam) {
    return gateway.read(fetchOrdersParam);
  }
}
