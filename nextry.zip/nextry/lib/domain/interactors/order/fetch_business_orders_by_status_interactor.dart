import 'package:nextry_dev/domain/entities/order/fetch_orders_param.dart';
import 'package:nextry_dev/domain/entities/order/fetch_orders_response_entity.dart';

abstract class FetchBusinessOrdersByStatusInteractor {
  Future<FetchOrdersResponseEntity> fetchBusinessOrders(
      FetchOrdersParam fetchOrdersParam);

  void unsubscribe();
}
