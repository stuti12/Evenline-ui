import 'package:nextry_dev/domain/entities/order/update_order_status_param.dart';
import 'package:nextry_dev/domain/entities/order/update_order_status_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/domain/interactors/order/update_order_status_interactor.dart';

class UpdateOrderStatusInteractorImpl extends UpdateOrderStatusInteractor {
  UpdateOrderStatusInteractorImpl({required this.gateway});

  final ReadGateWay<UpdateOrderStatusResponseEntity, UpdateOrderStatusParam>
      gateway;

  @override
  Future<UpdateOrderStatusResponseEntity> updateOrderStatus(
      UpdateOrderStatusParam updateOrderStatusParam) {
    return gateway.read(updateOrderStatusParam);
  }
}
