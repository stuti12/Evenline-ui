import 'package:nextry_dev/domain/entities/order/fetch_business_orders_by_day_response_entity.dart';
import 'package:nextry_dev/domain/entities/order/fetch_orders_param.dart';

abstract class FetchBusinessOrdersByDayInteractor {
  Future<FetchBusinessOrdersByDayResponseEntity> fetchBusinessOrdersByDay(
      FetchOrdersParam fetchOrdersParam);
}
