import 'package:nextry_dev/domain/entities/order/update_order_status_param.dart';
import 'package:nextry_dev/domain/entities/order/update_order_status_response_entity.dart';

abstract class UpdateOrderStatusInteractor {
  Future<UpdateOrderStatusResponseEntity> updateOrderStatus(
      UpdateOrderStatusParam updateOrderStatusParam);
}
