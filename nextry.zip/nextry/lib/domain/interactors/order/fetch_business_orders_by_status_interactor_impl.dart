import 'package:nextry_dev/domain/entities/order/fetch_orders_param.dart';
import 'package:nextry_dev/domain/entities/order/fetch_orders_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/domain/interactors/order/fetch_business_orders_by_status_interactor.dart';

class FetchBusinessOrdersByStatusInteractorImpl extends FetchBusinessOrdersByStatusInteractor {
  FetchBusinessOrdersByStatusInteractorImpl({required this.gateway});

  final ReadGateWay<FetchOrdersResponseEntity, FetchOrdersParam> gateway;

  @override
  Future<FetchOrdersResponseEntity> fetchBusinessOrders(
      FetchOrdersParam fetchOrdersParam) {
    return gateway.read(fetchOrdersParam);
  }

  @override
  void unsubscribe() {
    gateway.unsubscribe();
  }
}
