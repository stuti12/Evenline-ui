import 'package:nextry_dev/domain/entities/order/canel_order_param.dart';
import 'package:nextry_dev/domain/entities/order/update_order_status_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/domain/interactors/order/cancel_order_status_interactor.dart';

class CancelOrderStatusInteractorImpl extends CancelOrderStatusInteractor {
  CancelOrderStatusInteractorImpl({required this.gateway});

  final ReadGateWay<UpdateOrderStatusResponseEntity,
      CancelOrderParam> gateway;

  @override
  Future<UpdateOrderStatusResponseEntity> cancelOrder(
      CancelOrderParam cancelOrderParam) {
    return gateway.read(cancelOrderParam);
  }
}
