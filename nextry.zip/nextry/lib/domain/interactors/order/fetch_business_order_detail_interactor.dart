import 'package:nextry_dev/domain/entities/order/fetch_order_detail_param.dart';
import 'package:nextry_dev/domain/entities/order/fetch_order_detail_response_entity.dart';

abstract class FetchBusinessOrderDetailInteractor {
  Future<FetchOrderDetailResponseEntity> fetchBusinessOrderDetail(
      FetchOrderDetailParam fetchCustomerOrderDetailParam);
}
