import 'package:nextry_dev/domain/entities/order/add_update_order_invoice_param.dart';
import 'package:nextry_dev/domain/entities/order/add_update_order_invoice_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/domain/interactors/order/add_update_order_invoice_interactor.dart';

class AddUpdateOrderInvoiceInteractorImpl
    extends AddUpdateOrderInvoiceInteractor {
  AddUpdateOrderInvoiceInteractorImpl({required this.gateway});

  final ReadGateWay<AddUpdateOrderInvoiceResponseEntity,
      AddUpdateOrderInvoiceParam> gateway;

  @override
  Future<AddUpdateOrderInvoiceResponseEntity> addUpdateOrderInvoiceFile(
      AddUpdateOrderInvoiceParam data) {
    return gateway.read(data);
  }
}
