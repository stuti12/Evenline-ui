import 'package:nextry_dev/domain/entities/order/fetch_order_detail_param.dart';
import 'package:nextry_dev/domain/entities/order/fetch_order_detail_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/domain/interactors/order/fetch_customer_order_detail_interactor.dart';

class FetchCustomerOrderDetailInteractorImpl
    extends FetchCustomerOrderDetailInteractor {
  FetchCustomerOrderDetailInteractorImpl({required this.gateway});

  final ReadGateWay<FetchOrderDetailResponseEntity,
      FetchOrderDetailParam> gateway;

  @override
  Future<FetchOrderDetailResponseEntity> fetchCustomerOrderDetail(
      FetchOrderDetailParam fetchCustomerOrderDetailParam) {
    return gateway.read(fetchCustomerOrderDetailParam);
  }
}
