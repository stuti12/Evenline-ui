import 'package:nextry_dev/domain/entities/order/fetch_order_detail_param.dart';
import 'package:nextry_dev/domain/entities/order/fetch_order_detail_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/domain/interactors/order/fetch_business_order_detail_interactor.dart';

class FetchBusinessOrderDetailInteractorImpl
    extends FetchBusinessOrderDetailInteractor {
  FetchBusinessOrderDetailInteractorImpl({required this.gateway});

  final ReadGateWay<FetchOrderDetailResponseEntity, FetchOrderDetailParam>
      gateway;

  @override
  Future<FetchOrderDetailResponseEntity> fetchBusinessOrderDetail(
      FetchOrderDetailParam fetchCustomerOrderDetailParam) {
    return gateway.read(fetchCustomerOrderDetailParam);
  }
}
