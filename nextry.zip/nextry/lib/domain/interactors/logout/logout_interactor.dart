abstract class LogoutInteractor {
  Future<void> logout();
}
