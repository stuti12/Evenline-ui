import 'package:nextry_dev/domain/gateway/read_gateway_no_args.dart';

import 'logout_interactor.dart';

class LogoutInteractorImpl extends LogoutInteractor {
  LogoutInteractorImpl({required this.gateway});

  final ReadGateWayNoArgs<void> gateway;

  @override
  Future<void> logout() {
    return gateway.read();
  }
}
