import 'package:nextry_dev/domain/entities/subscriptions/fetch_my_subscriptions_param.dart';
import 'package:nextry_dev/domain/entities/subscriptions/fetch_my_subscriptions_response_entity.dart';

abstract class FetchMySubscriptionsInteractor {
  Future<FetchMySubscriptionsResponseEntity> fetchUserSubscriptions(
      FetchMySubscriptionsParam param);
}
