import 'package:nextry_dev/domain/entities/subscriptions/cancel_my_subscription_param.dart';
import 'package:nextry_dev/domain/entities/subscriptions/cancel_my_subscription_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/domain/interactors/subscriptions/cancel_my_subscription_interactor.dart';

class CancelMySubscriptionInteractorImpl
    extends CancelMySubscriptionInteractor {
  CancelMySubscriptionInteractorImpl({required this.gateway});

  final ReadGateWay<CancelMySubscriptionResponseEntity,
      CancelMySubscriptionParam> gateway;

  @override
  Future<CancelMySubscriptionResponseEntity> cancelMySubscriptions(
      CancelMySubscriptionParam param) {
    return gateway.read(param);
  }
}
