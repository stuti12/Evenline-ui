import 'package:nextry_dev/domain/entities/subscriptions/create_subscription_param.dart';
import 'package:nextry_dev/domain/entities/subscriptions/create_subscription_response_entity.dart';

abstract class CreateSubscriptionInteractor {
  Future<CreateSubscriptionResponseEntity> createSubscription(
      CreateSubscriptionParam param);
}
