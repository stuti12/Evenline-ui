import 'package:nextry_dev/domain/entities/subscriptions/fetch_subscription_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway_no_args.dart';
import 'package:nextry_dev/domain/interactors/subscriptions/fetch_subscription_data_interactor.dart';

class FetchSubscriptionDataInteractorImpl
    extends FetchSubscriptionDataInteractor {
  FetchSubscriptionDataInteractorImpl({required this.gateway});

  final ReadGateWayNoArgs<FetchSubscriptionResponseEntity> gateway;

  @override
  Future<FetchSubscriptionResponseEntity> fetchSubscriptionData() {
    return gateway.read();
  }
}
