import 'package:nextry_dev/domain/entities/subscriptions/create_subscription_param.dart';
import 'package:nextry_dev/domain/entities/subscriptions/create_subscription_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/domain/interactors/subscriptions/create_subscription_interactor.dart';

class CreateSubscriptionInteractorImpl extends CreateSubscriptionInteractor {
  CreateSubscriptionInteractorImpl({required this.gateway});

  final ReadGateWay<CreateSubscriptionResponseEntity, CreateSubscriptionParam>
      gateway;

  @override
  Future<CreateSubscriptionResponseEntity> createSubscription(
      CreateSubscriptionParam param) {
    return gateway.read(param);
  }
}
