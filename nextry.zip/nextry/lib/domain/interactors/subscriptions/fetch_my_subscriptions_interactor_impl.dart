import 'package:nextry_dev/domain/entities/subscriptions/fetch_my_subscriptions_param.dart';
import 'package:nextry_dev/domain/entities/subscriptions/fetch_my_subscriptions_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/domain/interactors/subscriptions/fetch_my_subscriptions_interactor.dart';

class FetchMySubscriptionsInteractorImpl
    extends FetchMySubscriptionsInteractor {
  FetchMySubscriptionsInteractorImpl({required this.gateway});

  final ReadGateWay<FetchMySubscriptionsResponseEntity,
      FetchMySubscriptionsParam> gateway;

  @override
  Future<FetchMySubscriptionsResponseEntity> fetchUserSubscriptions(
      FetchMySubscriptionsParam param) {
    return gateway.read(param);
  }
}
