import 'package:nextry_dev/domain/entities/subscriptions/cancel_my_subscription_param.dart';
import 'package:nextry_dev/domain/entities/subscriptions/cancel_my_subscription_response_entity.dart';

abstract class CancelMySubscriptionInteractor {
  Future<CancelMySubscriptionResponseEntity> cancelMySubscriptions(
      CancelMySubscriptionParam param);
}
