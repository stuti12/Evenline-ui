import 'package:nextry_dev/domain/entities/subscriptions/fetch_subscription_response_entity.dart';

abstract class FetchSubscriptionDataInteractor {
  Future<FetchSubscriptionResponseEntity> fetchSubscriptionData();
}
