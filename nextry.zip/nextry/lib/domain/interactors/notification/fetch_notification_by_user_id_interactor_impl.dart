import 'package:nextry_dev/domain/entities/notification/fetch_notification_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/domain/gateway/read_gateway_no_args.dart';
import 'package:nextry_dev/domain/interactors/notification/fetch_notification_by_user_id_interactor.dart';

class FetchNotificationByUserIdInteractorImpl
    extends FetchNotificationByUserIdInteractor {
  FetchNotificationByUserIdInteractorImpl({required this.gateway});

  final ReadGateWay<FetchNotificationResponseEntity, Function> gateway;

  @override
  Future<FetchNotificationResponseEntity> fetchNotificationByUserId(
      Function function) {
    return gateway.read(function);
  }
}
