import 'package:nextry_dev/domain/entities/notification/fetch_notification_response_entity.dart';

abstract class FetchNotificationByUserIdInteractor {
  Future<FetchNotificationResponseEntity> fetchNotificationByUserId(
      Function function);
}
