abstract class AddSubscriptionIdInteractor {
  Future<void> addSubscriptionId(String subscriptionId);
}
