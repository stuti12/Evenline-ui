import 'package:nextry_dev/domain/entities/user/fetch_user_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway_no_args.dart';
import 'package:nextry_dev/domain/interactors/user/fetch_user_interactor.dart';

class FetchUserInteractorImpl extends FetchUserInteractor {
  FetchUserInteractorImpl({required this.gateway});

  final ReadGateWayNoArgs<FetchUserResponseEntity> gateway;

  @override
  Future<FetchUserResponseEntity> fetchUser() {
    return gateway.read();
  }
}
