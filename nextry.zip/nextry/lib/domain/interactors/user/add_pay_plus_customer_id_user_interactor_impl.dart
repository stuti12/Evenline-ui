import 'package:nextry_dev/domain/entities/user/add_user_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/domain/interactors/user/add_pay_plus_customer_id_user_interactor.dart';

class AddPayPlusCustomerIdUserInteractorImpl
    extends AddPayPlusCustomerIdUserInteractor {
  AddPayPlusCustomerIdUserInteractorImpl({required this.gateway});

  final ReadGateWay<AddUserResponseEntity, String> gateway;

  @override
  Future<AddUserResponseEntity> addPayPlusCustomerId(String payPlusCustomerId) {
    return gateway.read(payPlusCustomerId);
  }
}
