import 'package:nextry_dev/domain/entities/user/delete_file_param.dart';
import 'package:nextry_dev/domain/entities/user/delete_file_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/domain/interactors/user/delete_file_interactor.dart';

class DeleteFileInteractorImpl extends DeleteFileInteractor {
  DeleteFileInteractorImpl({required this.gateway});

  final ReadGateWay<DeleteFileResponseEntity, DeleteFileParam> gateway;

  @override
  Future<DeleteFileResponseEntity> deleteFile(DeleteFileParam param) {
    return gateway.read(param);
  }
}
