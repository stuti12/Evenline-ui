import 'package:nextry_dev/domain/gateway/write_gateway.dart';
import 'package:nextry_dev/domain/interactors/user/add_subscription_id_interactor.dart';

class AddSubscriptionIdInteractorImpl extends AddSubscriptionIdInteractor {
  AddSubscriptionIdInteractorImpl({required this.gateway});

  final WriteGateWay<String> gateway;

  @override
  Future<void> addSubscriptionId(String subscriptionId) {
    return gateway.write(subscriptionId);
  }
}
