import 'package:nextry_dev/domain/entities/profile/user_entity.dart';
import 'package:nextry_dev/domain/entities/user/add_user_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/domain/interactors/user/add_user_interactor.dart';

class AddUserInteractorImpl extends AddUserInteractor {
  AddUserInteractorImpl({required this.gateway});

  final ReadGateWay<AddUserResponseEntity, UserEntity> gateway;

  @override
  Future<AddUserResponseEntity> addUser(UserEntity userEntity) {
    return gateway.read(userEntity);
  }
}
