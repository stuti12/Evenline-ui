import 'package:nextry_dev/domain/entities/profile/user_entity.dart';
import 'package:nextry_dev/domain/entities/user/add_user_response_entity.dart';

abstract class AddUserInteractor {
  Future<AddUserResponseEntity> addUser(UserEntity userEntity);
}
