import 'package:nextry_dev/domain/entities/user/fetch_user_response_entity.dart';

abstract class FetchUserDataByIdInteractor {
  Future<FetchUserResponseEntity> fetchUserDataById(String userId);
}
