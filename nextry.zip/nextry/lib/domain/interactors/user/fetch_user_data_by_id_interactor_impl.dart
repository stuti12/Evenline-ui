import 'package:nextry_dev/domain/entities/user/fetch_user_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/domain/interactors/user/fetch_user_data_id_interactor.dart';

class FetchUserDataByIdInteractorImpl extends FetchUserDataByIdInteractor {
  FetchUserDataByIdInteractorImpl({required this.gateway});
  final ReadGateWay<FetchUserResponseEntity, String> gateway;

  @override
  Future<FetchUserResponseEntity> fetchUserDataById(String userId) {
    return gateway.read(userId);
  }

}
