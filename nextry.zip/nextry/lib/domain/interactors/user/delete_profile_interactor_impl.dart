import 'package:nextry_dev/domain/entities/user/delete_account_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway_no_args.dart';
import 'package:nextry_dev/domain/interactors/user/delete_profile_interactor.dart';

class DeleteProfileInteractorImpl extends DeleteProfileInteractor {
  DeleteProfileInteractorImpl({required this.gateway});

  final ReadGateWayNoArgs<DeleteAccountResponseEntity> gateway;

  @override
  Future<DeleteAccountResponseEntity> deleteProfile() {
    return gateway.read();
  }
}
