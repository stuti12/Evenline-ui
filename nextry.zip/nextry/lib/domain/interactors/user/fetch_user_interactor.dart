import 'package:nextry_dev/domain/entities/user/fetch_user_response_entity.dart';

abstract class FetchUserInteractor {
  Future<FetchUserResponseEntity> fetchUser();
}
