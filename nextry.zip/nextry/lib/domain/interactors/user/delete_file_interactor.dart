import 'package:nextry_dev/domain/entities/user/delete_file_param.dart';
import 'package:nextry_dev/domain/entities/user/delete_file_response_entity.dart';

abstract class DeleteFileInteractor {
  Future<DeleteFileResponseEntity> deleteFile(DeleteFileParam param);
}
