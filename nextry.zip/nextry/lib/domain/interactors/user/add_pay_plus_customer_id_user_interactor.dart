import 'package:nextry_dev/domain/entities/user/add_user_response_entity.dart';

abstract class AddPayPlusCustomerIdUserInteractor {
  Future<AddUserResponseEntity> addPayPlusCustomerId(String payPlusCustomerId);
}
