import 'package:nextry_dev/domain/entities/askme/add_ask_me_response_entity.dart';
import 'package:nextry_dev/domain/entities/askme/ask_me_entity.dart';

abstract class AddAskMeInteractor {
  Future<AddAskMeResponseEntity> addAskMeData(AskMeEntity askMeEntity);
}
