import 'package:nextry_dev/domain/entities/askme/add_ask_me_response_entity.dart';
import 'package:nextry_dev/domain/entities/askme/ask_me_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';

import 'add_ask_me_interactor.dart';

class AddAskMeInteractorImpl extends AddAskMeInteractor {
  AddAskMeInteractorImpl({required this.gateway});

  final ReadGateWay<AddAskMeResponseEntity, AskMeEntity> gateway;

  @override
  Future<AddAskMeResponseEntity> addAskMeData(AskMeEntity askMeEntity) {
    return gateway.read(askMeEntity);
  }
}
