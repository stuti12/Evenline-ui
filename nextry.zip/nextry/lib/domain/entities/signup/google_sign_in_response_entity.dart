import 'package:firebase_auth/firebase_auth.dart';
import 'package:nextry_dev/domain/entities/error/common_errors.dart';

/// Google sign in response entity. If get success then return with [UserCredential] data.
class GoogleSignInResponseEntity {
  UserCredential? userCredential;
  CommonErrors? error;

  GoogleSignInResponseEntity({required this.userCredential, required this.error});
}
