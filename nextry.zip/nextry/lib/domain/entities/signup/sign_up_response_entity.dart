import 'package:firebase_auth/firebase_auth.dart';
import 'package:nextry_dev/domain/entities/error/common_errors.dart';

/// Email & Password signup response model. If get success then return with [UserCredential] data.
class SignUpResponseEntity {
  UserCredential? userCredential;
  CommonErrors? error;

  SignUpResponseEntity({required this.userCredential, required this.error});
}
