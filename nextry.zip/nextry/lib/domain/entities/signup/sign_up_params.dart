///Signup param model to send enter email & password to Gateway.
class SignUpParams {
  String email;
  String password;
  String fullName;

  SignUpParams({
    required this.email,
    required this.password,
    required this.fullName,
  });
}
