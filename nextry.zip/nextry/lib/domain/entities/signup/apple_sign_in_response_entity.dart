import 'package:firebase_auth/firebase_auth.dart';
import 'package:nextry_dev/domain/entities/error/common_errors.dart';

/// Apple sign in response entity. If get success then return with [UserCredential] data.
class AppleSignInResponseEntity {
  UserCredential? userCredential;
  CommonErrors? error;

  AppleSignInResponseEntity(
      {required this.userCredential, required this.error});
}
