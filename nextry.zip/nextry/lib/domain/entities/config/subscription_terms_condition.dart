import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';

class SubscriptionTermsConditionEntity {
  String? en;
  String? ar;
  String? he;

  SubscriptionTermsConditionEntity({this.en, this.ar, this.he});

  SubscriptionTermsConditionEntity.fromJson(Map<String, dynamic> json) {
    en = json[GateWayConstants.FIELD_EN_LANGUAGE_CODE];
    he = json[GateWayConstants.FIELD_HE_LANGUAGE_CODE];
    ar = json[GateWayConstants.FIELD_AR_LANGUAGE_CODE];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data[GateWayConstants.FIELD_EN_LANGUAGE_CODE] = en;
    data[GateWayConstants.FIELD_HE_LANGUAGE_CODE] = he;
    data[GateWayConstants.FIELD_AR_LANGUAGE_CODE] = ar;
    return data;
  }
}
