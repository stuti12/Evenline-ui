import 'package:nextry_dev/domain/entities/error/common_errors.dart';

class SplashConfigResponseEntity {
  String? videoURL;
  CommonErrors? error;

  SplashConfigResponseEntity({this.videoURL, this.error});
}
