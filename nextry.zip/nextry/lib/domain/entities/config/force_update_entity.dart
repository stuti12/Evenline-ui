import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/domain/entities/config/subscription_terms_condition.dart';

class ForceUpdateEntity {
  SubscriptionTermsConditionEntity? message;
  bool? isForce = false;
  String? version;
  String? appUrl;

  ForceUpdateEntity({this.message, this.isForce, this.version, this.appUrl});

  ForceUpdateEntity.fromJson(Map<String, dynamic> json) {
    if (json[GateWayConstants.FIELD_FORCE_UPDATE_MESSAGE] != null) {
      message = SubscriptionTermsConditionEntity.fromJson(
          json[GateWayConstants.FIELD_FORCE_UPDATE_MESSAGE]);
    }
    isForce = json[GateWayConstants.FIELD_IS_FORCE];
    version = json[GateWayConstants.FIELD_VERSION];
    appUrl = json[GateWayConstants.FIELD_APP_URL];
  }
}
