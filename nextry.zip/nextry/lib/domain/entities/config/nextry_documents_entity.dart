import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/domain/entities/config/subscription_terms_condition.dart';

class NextryDocumentsEntity {
  SubscriptionTermsConditionEntity? subscriptionTermsConditionEntity;
  SubscriptionTermsConditionEntity? termsCondition;
  SubscriptionTermsConditionEntity? accessibilityStatement;
  SubscriptionTermsConditionEntity? privacyAndPolicy;

  NextryDocumentsEntity(
      {this.subscriptionTermsConditionEntity, this.termsCondition});

  NextryDocumentsEntity.fromJson(Map<String, dynamic> json) {
    if (json[GateWayConstants.FIELD_SUBSCRITPION_TERMS_CONDITION] != null) {
      subscriptionTermsConditionEntity =
          SubscriptionTermsConditionEntity.fromJson(
              json[GateWayConstants.FIELD_SUBSCRITPION_TERMS_CONDITION]);
    }

    if (json[GateWayConstants.FIELD_CONFIG_TERM_AND_CONDITION] != null) {
      termsCondition = SubscriptionTermsConditionEntity.fromJson(
          json[GateWayConstants.FIELD_CONFIG_TERM_AND_CONDITION]);
    }
    if (json[GateWayConstants.FIELD_CONFIG_ACCESSIBILITY_STATEMENT] != null) {
      accessibilityStatement = SubscriptionTermsConditionEntity.fromJson(
          json[GateWayConstants.FIELD_CONFIG_ACCESSIBILITY_STATEMENT]);
    }
    if (json[GateWayConstants.FIELD_CONFIG_PRIVACY_AND_POLICY] != null) {
      privacyAndPolicy = SubscriptionTermsConditionEntity.fromJson(
          json[GateWayConstants.FIELD_CONFIG_PRIVACY_AND_POLICY]);
    }
  }
}
