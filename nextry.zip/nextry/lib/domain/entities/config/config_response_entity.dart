import 'package:nextry_dev/domain/entities/error/common_errors.dart';

class ConfigResponseEntity {
  bool isLocked;
  CommonErrors? error;

  ConfigResponseEntity({required this.isLocked, this.error});
}
