import 'package:nextry_dev/domain/entities/config/nextry_documents_entity.dart';
import 'package:nextry_dev/domain/entities/error/common_errors.dart';

class NextryDocumentsResponseEntity {
  NextryDocumentsEntity? nextryDocumentsEntity;
  CommonErrors? error;

  NextryDocumentsResponseEntity({this.nextryDocumentsEntity, this.error});
}
