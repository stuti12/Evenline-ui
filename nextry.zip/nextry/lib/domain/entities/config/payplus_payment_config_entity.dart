import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/presentation/common/utils/app_extension.dart';

class PayPlusPaymentConfigEntity {
  String? apiKey;
  String? pageUid;
  String? secretKey;

  PayPlusPaymentConfigEntity({this.apiKey, this.pageUid, this.secretKey});

  PayPlusPaymentConfigEntity.fromJSON(dynamic json) {
    apiKey = json[GateWayConstants.FIELD_API_KEY]?.toString().decryptedData();
    pageUid = json[GateWayConstants.FIELD_PAGE_UID]?.toString().decryptedData();
    secretKey =
        json[GateWayConstants.FIELD_SECRET_KEY]?.toString().decryptedData();
  }
}
