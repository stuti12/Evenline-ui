import 'package:nextry_dev/domain/entities/config/force_update_entity.dart';
import 'package:nextry_dev/domain/entities/error/common_errors.dart';

class ForceUpdateResponseEntity {
  ForceUpdateEntity? forceUpdateEntity;
  CommonErrors? error;

  ForceUpdateResponseEntity({this.forceUpdateEntity, this.error});
}
