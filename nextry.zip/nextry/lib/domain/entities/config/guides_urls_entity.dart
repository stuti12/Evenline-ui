import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/domain/entities/config/subscription_terms_condition.dart';

class GuidesUrlsEntity {
  SubscriptionTermsConditionEntity? addListOfProducts;
  SubscriptionTermsConditionEntity? nextryAppWebsite;

  GuidesUrlsEntity({
    this.addListOfProducts,
    this.nextryAppWebsite
  });

  GuidesUrlsEntity.fromJson(Map<String, dynamic> json) {
    if (json[GateWayConstants.FIELD_CONFIG_ADD_LIST_OF_PRODUCTS] != null) {
      addListOfProducts = SubscriptionTermsConditionEntity.fromJson(
          json[GateWayConstants.FIELD_CONFIG_ADD_LIST_OF_PRODUCTS]);
    }
    if (json[GateWayConstants.FIELD_CONFIG_NEXTRY_APP_WEBSITE] != null) {
      nextryAppWebsite = SubscriptionTermsConditionEntity.fromJson(
          json[GateWayConstants.FIELD_CONFIG_NEXTRY_APP_WEBSITE]);
    }
  }
}
