/// Check Verify email response model with status user [isVerified] the email or not.
class VerifyEmailResponseEntity {
  bool isVerified;

  VerifyEmailResponseEntity({this.isVerified = false});
}
