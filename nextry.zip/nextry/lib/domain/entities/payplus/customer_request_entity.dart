class CustomerRequestEntity {
  String? customerName;
  String? email;
  bool? payingVat;
  int? vatNumber;
  String? phone;
  String? businessAddress;
  String? businessCountryIso;

  CustomerRequestEntity(
      {this.customerName,
      this.email,
      this.payingVat,
      this.vatNumber,
      this.phone,
      this.businessAddress,
      this.businessCountryIso});

  CustomerRequestEntity.fromJson(Map<String, dynamic> json) {
    customerName = json['customer_name'];
    email = json['email'];
    payingVat = json['paying_vat'];
    vatNumber = json['vat_number'];
    phone = json['phone'];
    businessAddress = json['business_address'];
    businessCountryIso = json['business_country_iso'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['customer_name'] = customerName;
    data['email'] = email;
    if(payingVat != null) {
      data['paying_vat'] = payingVat;
      data['vat_number'] = vatNumber;
    }
    data['phone'] = phone;
    data['business_address'] = businessAddress;
    data['business_country_iso'] = businessCountryIso;
    return data;
  }
}
