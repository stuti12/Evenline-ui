import 'dart:convert';

class PayPlusExtraInfoEntity {
  String? businessId;

  PayPlusExtraInfoEntity({this.businessId});

  PayPlusExtraInfoEntity.fromJson(String extraInfo) {
    try {
      Map<String, dynamic> jsonExtraInfo = jsonDecode(extraInfo);
      businessId = jsonExtraInfo['business_id'];
    } catch (e) {
      print(e);
    }
  }

  String toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['business_id'] = businessId;
    try {
      String extraInfoString = json.encode(data);
      return extraInfoString;
    } catch (e) {
      return '';
    }
  }
}
