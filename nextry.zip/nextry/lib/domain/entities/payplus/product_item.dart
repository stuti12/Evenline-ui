class ProductItem {
  String? productuid;
  String? name;
  int? quantity;
  num? price;

  ProductItem({this.productuid,this.name, this.quantity, this.price});

  ProductItem.fromJson(Map<String, dynamic> json) {
    productuid = json['product_uid'];
    quantity = json['quantity'];
    price = json['price'];
    name = json['name'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['product_uid'] = productuid;
    data['quantity'] = quantity;
    data['price'] = price;
    data['name'] = name;
    return data;
  }
}