import 'package:nextry_dev/domain/entities/config/payplus_payment_config_entity.dart';

class FetchPayPlusSubscriptionParam {
  String? customerUid;
  String? terminalUid;
  PayPlusPaymentConfigEntity? payPlusPaymentConfigEntity;

  FetchPayPlusSubscriptionParam(
      {this.customerUid, this.terminalUid, this.payPlusPaymentConfigEntity});
}
