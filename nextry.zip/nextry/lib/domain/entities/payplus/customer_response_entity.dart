import 'package:nextry_dev/domain/entities/payplus/result_data_entity.dart';
import 'package:nextry_dev/domain/entities/payplus/result_entity.dart';

class CustomerResponseEntity {
  ResultEntity? results;
  ResultDataEntity? data;

  CustomerResponseEntity({this.results, this.data});

  CustomerResponseEntity.fromJson(Map<String, dynamic> json) {
    results = ResultEntity.fromJson(json['results']);
    data = ResultDataEntity.fromJson(json['data']);
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['results'] = results?.toJson();
    data['data'] = this.data?.toJson();
    return data;
  }
}
