class RecurringSettings {
  bool? instantfirstpayment;
  int? recurringtype;
  int? recurringrange;
  int? numberofcharges;
  int? jumppayments;
  bool? successfulinvoice;
  bool? customerfailureemail;
  bool? sendcustomersuccessemail;

  RecurringSettings(
      {this.instantfirstpayment,
      this.recurringtype,
      this.recurringrange,
      this.numberofcharges,
      this.jumppayments,
      this.successfulinvoice,
      this.customerfailureemail,
      this.sendcustomersuccessemail});

  RecurringSettings.fromJson(Map<String, dynamic> json) {
    instantfirstpayment = json['instant_first_payment'];
    recurringtype = json['recurring_type'];
    recurringrange = json['recurring_range'];
    numberofcharges = json['number_of_charges'];
    jumppayments = json['jump_payments'];
    successfulinvoice = json['successful_invoice'];
    customerfailureemail = json['customer_failure_email'];
    sendcustomersuccessemail = json['send_customer_success_email'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = Map<String, dynamic>();
    data['instant_first_payment'] = instantfirstpayment;
    data['recurring_type'] = recurringtype;
    data['recurring_range'] = recurringrange;
    data['number_of_charges'] = numberofcharges;
    data['jump_payments'] = jumppayments;
    data['successful_invoice'] = successfulinvoice;
    data['customer_failure_email'] = customerfailureemail;
    data['send_customer_success_email'] = sendcustomersuccessemail;
    data['start_date_on_payment_date'] = true;
    data['jump_payments'] = 30;
    return data;
  }
}