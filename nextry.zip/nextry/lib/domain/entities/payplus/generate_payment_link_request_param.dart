import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/domain/entities/payplus/product_item.dart';
import 'package:nextry_dev/domain/entities/payplus/recurring_settings.dart';

class PaymentLinkRequestParam {
  String? paymentpageuid;
  String? expirydatetime;
  int? chargeMethod;
  num? amount;
  String? currencycode;
  String? languageCode;
  bool? sendEmailApproval = false;
  bool? sendEmailFailure = false;
  bool? createToken = false;
  String? refURLsuccess;
  String? refURLfailure;
  String? refURLcallback;
  CustomerReq? customer;
  RecurringSettings? recurringSettings;
  List<ProductItem?>? items;
  String? moreInfo;

  PaymentLinkRequestParam(
      {this.paymentpageuid,
      this.expirydatetime,
      this.chargeMethod,
      this.refURLsuccess,
      this.refURLfailure,
      this.refURLcallback,
      this.customer,
      this.recurringSettings,
      this.items,
      this.amount,
      this.currencycode = 'ILS',
      this.sendEmailApproval = false,
      this.createToken = false,
      this.sendEmailFailure = false,
      this.languageCode,
      this.moreInfo});

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['payment_page_uid'] = paymentpageuid;
    data['expiry_datetime'] = expirydatetime;
    data['charge_method'] = chargeMethod;
    data['refURL_success'] = refURLsuccess;
    data['refURL_failure'] = refURLfailure;
    data['refURL_callback'] = refURLcallback;
    data['customer'] = customer?.toJson();
    if(chargeMethod != GateWayConstants.PAYPLUS_P2P_CHARGE_METHOD) {
      data['recurring_settings'] = recurringSettings?.toJson();
    }
    data['items'] =
        items != null ? items!.map((v) => v?.toJson()).toList() : null;
    data['amount'] = amount;
    data['currency_code'] = currencycode;
    data['sendEmailApproval'] = sendEmailApproval;
    data['sendEmailFailure'] = sendEmailFailure;
    data['create_token'] = createToken;
    data['language_code'] = languageCode;
    data['payments'] = 1;
    data['more_info'] = moreInfo;
    return data;
  }
}
class CustomerReq {
  String uID;

  CustomerReq({required this.uID});


  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['uid'] = uID;
    return data;
  }
}


