import 'package:nextry_dev/domain/entities/config/payplus_payment_config_entity.dart';

class ViewPayPlusSubscriptionParam {
  String? recurringUid;
  String? terminalUid;
  PayPlusPaymentConfigEntity? payPlusPaymentConfigEntity;

  ViewPayPlusSubscriptionParam(
      {this.recurringUid, this.terminalUid, this.payPlusPaymentConfigEntity});
}
