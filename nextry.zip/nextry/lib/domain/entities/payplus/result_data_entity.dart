class ResultDataEntity {
  String? customerUid;
  String? cardUid;
  String? recurringPaymentUid;
  String? pageRequestUid;
  String? paymentPageLink;
  String? qrCodeImage;

  ResultDataEntity(
      {this.customerUid,
      this.cardUid,
      this.pageRequestUid,
      this.paymentPageLink,
      this.qrCodeImage});

  ResultDataEntity.fromJson(Map<String, dynamic> json) {
    customerUid = json['customer_uid'];
    cardUid = json['card_uid'];
    recurringPaymentUid = json['recurring_payment_uid'];
    pageRequestUid = json['page_request_uid'];
    paymentPageLink = json['payment_page_link'];
    qrCodeImage = json['qr_code_image'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['customer_uid'] = customerUid;
    data['card_uid'] = cardUid;
    data['recurring_payment_uid'] = recurringPaymentUid;
    data['page_request_uid'] = pageRequestUid;
    data['payment_page_link'] = paymentPageLink;
    data['qr_code_image'] = qrCodeImage;
    return data;
  }
}
