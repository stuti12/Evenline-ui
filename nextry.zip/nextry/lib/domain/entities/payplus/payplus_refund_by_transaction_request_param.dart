import 'package:nextry_dev/domain/entities/config/payplus_payment_config_entity.dart';

class PayPlusRefundByTransactionRequest {
  String? transactionUid;
  num? amount;
  PayPlusPaymentConfigEntity? payPlusPaymentConfigEntity;

  PayPlusRefundByTransactionRequest(
      {this.transactionUid, this.amount, this.payPlusPaymentConfigEntity});

  PayPlusRefundByTransactionRequest.fromJson(Map<String, dynamic> json) {
    transactionUid = json['transaction_uid'];
    amount = json['amount'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['transaction_uid'] = transactionUid;
    data['amount'] = amount;
    return data;
  }
}
