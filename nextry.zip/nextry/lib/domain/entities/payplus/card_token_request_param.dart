class CardTokenRequestParam {
  String? terminalUid;
  String? customerUid;
  String? creditCardNumber;
  String? cardDateMmyy;
  String? identificationNumber;
  String? name;
  String? previousUid;

  CardTokenRequestParam(
      {this.terminalUid,
      this.customerUid,
      this.creditCardNumber,
      this.cardDateMmyy,
      this.identificationNumber,
      this.name,
      this.previousUid});

  CardTokenRequestParam.fromJson(Map<String, dynamic> json) {
    terminalUid = json['terminal_uid'];
    customerUid = json['customer_uid'];
    creditCardNumber = json['credit_card_number'];
    cardDateMmyy = json['card_date_mmyy'];
    identificationNumber = json['identification_number'];
    name = json['name'];
    previousUid = json['previous_uid'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['terminal_uid'] = terminalUid;
    data['customer_uid'] = customerUid;
    data['credit_card_number'] = creditCardNumber;
    data['card_date_mmyy'] = cardDateMmyy;
    data['identification_number'] = identificationNumber;
    data['name'] = name;
    data['previous_uid'] = previousUid;
    return data;
  }
}
