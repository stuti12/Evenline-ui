class DeletePayPlusRequest {
  String? terminalUid;

  DeletePayPlusRequest({this.terminalUid});

  DeletePayPlusRequest.fromJson(Map<String, dynamic> json) {
    terminalUid = json['terminal_uid'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['terminal_uid'] = terminalUid;
    return data;
  }
}