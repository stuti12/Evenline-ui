import 'package:nextry_dev/domain/entities/config/payplus_payment_config_entity.dart';
import 'package:nextry_dev/domain/entities/payplus/customer_request_entity.dart';
import 'package:nextry_dev/domain/entities/payplus/generate_payment_link_request_param.dart';

class CreatePayPlusSubscriptionParam {
  CustomerRequestEntity? customerRequestEntity;
  PaymentLinkRequestParam? paymentLinkRequestParam;
  String? customerId;
  PayPlusPaymentConfigEntity? payPlusPaymentConfigEntity;

  CreatePayPlusSubscriptionParam(
      {this.customerRequestEntity,
      this.paymentLinkRequestParam,
      this.customerId,
      this.payPlusPaymentConfigEntity});
}
