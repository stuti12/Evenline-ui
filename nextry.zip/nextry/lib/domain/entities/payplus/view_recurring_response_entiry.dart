class ViewRecurringResponseEntity {
  String? customerUid;
  String? cashierUid;
  String? cardToken;
  String? currencyCode;
  bool? instantFirstPayment;
  bool? customerFailureEmail;
  bool? successfulInvoice;
  bool? sendCustomerSuccessEmail;
  num? recurringType;
  num? recurringRange;
  String? startDate;
  num? numberOfCharges;
  num? amount;
  List<Items>? items;
  String? oneTimeChargeDate;
  String? number;
  String? extraInfo;
  String? uid;

  ViewRecurringResponseEntity(
      {this.customerUid,
      this.cashierUid,
      this.cardToken,
      this.currencyCode,
      this.instantFirstPayment,
      this.customerFailureEmail,
      this.successfulInvoice,
      this.sendCustomerSuccessEmail,
      this.recurringType,
      this.recurringRange,
      this.startDate,
      this.numberOfCharges,
      this.amount,
      this.items,
      this.oneTimeChargeDate,
      this.number,
      this.extraInfo,
      this.uid});

  ViewRecurringResponseEntity.fromJson(Map<String, dynamic> json) {
    customerUid = json['customer_uid'];
    cashierUid = json['cashier_uid'];
    cardToken = json['card_token'];
    currencyCode = json['currency_code'];
    instantFirstPayment = json['instant_first_payment'];
    customerFailureEmail = json['customer_failure_email'];
    successfulInvoice = json['successful_invoice'];
    sendCustomerSuccessEmail = json['send_customer_success_email'];
    recurringType = json['recurring_type'];
    recurringRange = json['recurring_range'];
    startDate = json['start_date'];
    numberOfCharges = json['number_of_charges'];
    amount = json['amount'];
    if (json['items'] != null) {
      items = <Items>[];
      json['items'].forEach((v) {
        items!.add(Items.fromJson(v));
      });
    }

    oneTimeChargeDate = json['one_time_charge_date'];
    number = json['number'];
    extraInfo = json['extra_info'];
    uid = json['uid'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['customer_uid'] = customerUid;
    data['cashier_uid'] = cashierUid;
    data['card_token'] = cardToken;
    data['currency_code'] = currencyCode;
    data['instant_first_payment'] = instantFirstPayment;
    data['customer_failure_email'] = customerFailureEmail;
    data['successful_invoice'] = successfulInvoice;
    data['send_customer_success_email'] = sendCustomerSuccessEmail;
    data['recurring_type'] = recurringType;
    data['recurring_range'] = recurringRange;
    data['start_date'] = startDate;
    data['number_of_charges'] = numberOfCharges;
    data['amount'] = amount;
    if (items != null) {
      data['items'] = items!.map((v) => v.toJson()).toList();
    }
    data['one_time_charge_date'] = oneTimeChargeDate;
    data['number'] = number;
    data['extra_info'] = extraInfo;
    data['uid'] = uid;
    return data;
  }
}

class Items {
  String? productUid;
  String? name;
  num? quantity;
  String? currencyCode;
  num? quantityPrice;
  num? amountPay;
  String? productInvoiceExtraDetails;
  String? discountType;
  num? discountAmount;
  num? discountValue;
  num? quantityPriceIncludingVat;
  num? productId;
  num? vatType;
  num? vatPercentage;

  Items(
      {this.productUid,
      this.name,
      this.quantity,
      this.currencyCode,
      this.quantityPrice,
      this.amountPay,
      // this.vat,
      this.productInvoiceExtraDetails,
      this.discountType,
      this.discountAmount,
      // this.discountValue,
      this.quantityPriceIncludingVat,
      this.productId,
      this.vatType,
      this.vatPercentage});

  Items.fromJson(Map<String, dynamic> json) {
    productUid = json['product_uid'];
    name = json['name'];
    quantity = json['quantity'];
    currencyCode = json['currency_code'];
    quantityPrice = json['quantity_price'];
    amountPay = json['amount_pay'];
    // vat = json['vat'];
    productInvoiceExtraDetails = json['product_invoice_extra_details'];
    discountType = json['discount_type'];
    discountAmount = json['discount_amount'];
    discountValue = json['discount_value'];
    quantityPriceIncludingVat = json['quantity_price_including_vat'];
    productId = json['product_id'];
    vatType = json['vat_type'];
    vatPercentage = json['vat_percentage'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['product_uid'] = productUid;
    data['name'] = name;
    data['quantity'] = quantity;
    data['currency_code'] = currencyCode;
    data['quantity_price'] = quantityPrice;
    data['amount_pay'] = amountPay;
    // data['vat'] = vat;
    data['product_invoice_extra_details'] = productInvoiceExtraDetails;
    data['discount_type'] = discountType;
    data['discount_amount'] = discountAmount;
    data['discount_value'] = discountValue;
    data['quantity_price_including_vat'] = quantityPriceIncludingVat;
    data['product_id'] = productId;
    data['vat_type'] = vatType;
    data['vat_percentage'] = vatPercentage;
    return data;
  }
}
