import 'package:nextry_dev/domain/entities/error/common_errors.dart';
import 'package:nextry_dev/domain/entities/payplus/payplus_subscription_entity.dart';

class FetchPayPlusSubscriptionsResponseEntity {
  CommonErrors? commonErrors;
  List<PayPlusSubscriptionEntity>? payPlusSubscriptionList;

  FetchPayPlusSubscriptionsResponseEntity({
    this.commonErrors,
    this.payPlusSubscriptionList,
  });

}
