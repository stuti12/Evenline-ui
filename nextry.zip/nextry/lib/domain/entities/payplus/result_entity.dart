class ResultEntity {
  String? status;
  int? code;
  String? description;

  ResultEntity({this.status, this.code, this.description});

  ResultEntity.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    code = json['code'];
    description = json['description'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['status'] = status;
    data['code'] = code;
    data['description'] = description;
    return data;
  }
}