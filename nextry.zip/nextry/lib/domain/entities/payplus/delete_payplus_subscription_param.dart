import 'package:nextry_dev/domain/entities/config/payplus_payment_config_entity.dart';
import 'package:nextry_dev/domain/entities/payplus/delete_payplus_request.dart';

class DeletePayPlusSubscriptionParam {
  String? recurringUid;
  DeletePayPlusRequest? deletePayPlusRequest;
  PayPlusPaymentConfigEntity? payPlusPaymentConfigEntity;

  DeletePayPlusSubscriptionParam(
      {this.recurringUid, this.deletePayPlusRequest, this.payPlusPaymentConfigEntity});
}
