import 'package:nextry_dev/domain/entities/payplus/product_item.dart';

class RecurringPaymentRequestParam {
  String? terminaluid;
  String? customeruid;
  String? cardtoken;
  String? cashieruid;
  String? currencycode;
  bool? instantfirstpayment;
  bool? customerfailureemail;
  bool? successfulinvoice;
  bool? sendcustomersuccessemail;
  int? recurringtype;
  int? recurringrange;
  int? numberofcharges;
  String? startdate;
  List<ProductItem?>? items;
  List<ProductItem?>? onetimeitems;
  String? onetimechargedate;
  String? extrainfo;

  RecurringPaymentRequestParam(
      {this.terminaluid,
      this.customeruid,
      this.cardtoken,
      this.cashieruid,
      this.currencycode,
      this.instantfirstpayment,
      this.successfulinvoice,
      this.recurringtype,
      this.recurringrange,
      this.numberofcharges, // 0 for unlimited charges
      this.startdate,
      this.items,
      this.onetimeitems,
      this.onetimechargedate,
      this.extrainfo});

  RecurringPaymentRequestParam.fromJson(Map<String, dynamic> json) {
    terminaluid = json['terminal_uid'];
    customeruid = json['customer_uid'];
    cardtoken = json['card_token'];
    cashieruid = json['cashier_uid'];
    currencycode = json['currency_code'];
    instantfirstpayment = json['instant_first_payment'];
    customerfailureemail = json['customer_failure_email'];
    successfulinvoice = json['successful_invoice'];
    sendcustomersuccessemail = json['send_customer_success_email'];
    recurringtype = json['recurring_type'];
    recurringrange = json['recurring_range'];
    numberofcharges = json['number_of_charges'];
    startdate = json['start_date'];
    if (json['items'] != null) {
      items = <ProductItem>[];
      json['items'].forEach((v) {
        items!.add(ProductItem.fromJson(v));
      });
    }
    if (json['one_time_items'] != null) {
      onetimeitems = <ProductItem>[];
      json['one_time_items'].forEach((v) {
        onetimeitems!.add(ProductItem.fromJson(v));
      });
    }
    onetimechargedate = json['one_time_charge_date'];
    extrainfo = json['extra_info'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['terminal_uid'] = terminaluid;
    data['customer_uid'] = customeruid;
    data['card_token'] = cardtoken;
    data['cashier_uid'] = cashieruid;
    data['currency_code'] = currencycode;
    data['instant_first_payment'] = instantfirstpayment;
    data['customer_failure_email'] = customerfailureemail;
    data['successful_invoice'] = successfulinvoice;
    data['send_customer_success_email'] = sendcustomersuccessemail;
    data['recurring_type'] = recurringtype;
    data['recurring_range'] = recurringrange;
    data['number_of_charges'] = numberofcharges;
    data['start_date'] = startdate;
    data['items'] =
        items != null ? items!.map((v) => v?.toJson()).toList() : null;
    data['one_time_items'] = onetimeitems != null
        ? onetimeitems!.map((v) => v?.toJson()).toList()
        : null;
    data['one_time_charge_date'] = onetimechargedate;
    data['extra_info'] = extrainfo;
    return data;
  }
}

