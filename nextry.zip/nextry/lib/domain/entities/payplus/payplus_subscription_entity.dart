import 'package:nextry_dev/domain/entities/business/business_entity.dart';

class PayPlusSubscriptionEntity {
  String? uid;
  String? number;
  String? paymentPageRequestUid;
  String? createdAt;
  String? customerName;
  String? customerEmail;
  String? customerPhone;
  String? customerUid;
  num? eachPaymentAmount;
  num? failureCharges;
  num? failureAmount;
  num? alreadyChargedTransfers;
  num? alreadyChargedAmount;
  String? numberOfCharges;
  String? cardNumber;
  String? cardExpiry;
  String? bankCode;
  String? branchCode;
  String? accountNumber;
  String? startDate;
  String? endDate;
  String? firstChargeDate;
  bool? valid;
  String? recurringType;
  String? extraInfo;
  String? cashierName;
  String? currencyCode;
  num? recurringRange;
  bool? systemRecurringPayment;
  String? productName;
  BusinessEntity? businessEntity;

  PayPlusSubscriptionEntity(
      {this.uid,
      this.number,
      this.paymentPageRequestUid,
      this.createdAt,
      this.customerName,
      this.customerEmail,
      this.customerPhone,
      this.customerUid,
      this.eachPaymentAmount,
      this.failureCharges,
      this.failureAmount,
      this.alreadyChargedTransfers,
      this.alreadyChargedAmount,
      this.numberOfCharges,
      this.cardNumber,
      this.cardExpiry,
      this.bankCode,
      this.branchCode,
      this.accountNumber,
      this.startDate,
      this.endDate,
      this.firstChargeDate,
      this.valid,
      this.recurringType,
      this.extraInfo,
      this.cashierName,
      this.currencyCode,
      this.recurringRange,
      this.systemRecurringPayment});

  PayPlusSubscriptionEntity.fromJson(Map<String, dynamic> json,String this.productName, this.businessEntity) {
    uid = json['uid'];
    number = json['number'];
    paymentPageRequestUid = json['payment_page_request_uid'];
    createdAt = json['created_at'];
    customerName = json['customer_name'];
    customerEmail = json['customer_email'];
    customerPhone = json['customer_phone'];
    customerUid = json['customer_uid'];
    eachPaymentAmount = json['each_payment_amount'];
    failureCharges = json['failure_charges'];
    failureAmount = json['failure_amount'];
    alreadyChargedTransfers = json['already_charged_transfers'];
    alreadyChargedAmount = json['already_charged_amount'];
    numberOfCharges = json['number_of_charges'];
    cardNumber = json['card_number'];
    cardExpiry = json['card_expiry'];
    bankCode = json['bank_code'];
    branchCode = json['branch_code'];
    accountNumber = json['account_number'];
    startDate = json['start_date'];
    endDate = json['end_date'];
    firstChargeDate = json['first_charge_date'];
    valid = json['valid'];
    recurringType = json['recurring_type'];
    extraInfo = json['extra_info'];
    cashierName = json['cashier_name'];
    currencyCode = json['currency_code'];
    recurringRange = json['recurring_range'];
    systemRecurringPayment = json['system_recurring_payment'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['uid'] = uid;
    data['number'] = number;
    data['payment_page_request_uid'] = paymentPageRequestUid;
    data['created_at'] = createdAt;
    data['customer_name'] = customerName;
    data['customer_email'] = customerEmail;
    data['customer_phone'] = customerPhone;
    data['customer_uid'] = customerUid;
    data['each_payment_amount'] = eachPaymentAmount;
    data['failure_charges'] = failureCharges;
    data['failure_amount'] = failureAmount;
    data['already_charged_transfers'] = alreadyChargedTransfers;
    data['already_charged_amount'] = alreadyChargedAmount;
    data['number_of_charges'] = numberOfCharges;
    data['card_number'] = cardNumber;
    data['card_expiry'] = cardExpiry;
    data['bank_code'] = bankCode;
    data['branch_code'] = branchCode;
    data['account_number'] = accountNumber;
    data['start_date'] = startDate;
    data['end_date'] = endDate;
    data['first_charge_date'] = firstChargeDate;
    data['valid'] = valid;
    data['recurring_type'] = recurringType;
    data['extra_info'] = extraInfo;
    data['cashier_name'] = cashierName;
    data['currency_code'] = currencyCode;
    data['recurring_range'] = recurringRange;
    data['system_recurring_payment'] = systemRecurringPayment;
    return data;
  }
}
