class FetchBusinessCategoryParam {
  String businessId;
  Function? function;

  FetchBusinessCategoryParam(this.businessId, {this.function});
}
