import 'package:nextry_dev/domain/entities/error/common_errors.dart';

class AddUpdateBusinessResponseEntity {
  bool? isSuccess;
  String? businessId;
  CommonErrors? commonErrors;

  AddUpdateBusinessResponseEntity(
      {this.isSuccess, this.commonErrors, this.businessId});
}
