import 'package:nextry_dev/domain/entities/business/business_category_entity.dart';
import 'package:nextry_dev/domain/entities/error/common_errors.dart';

class FetchBusinessCategoryResponseEntity {
  CommonErrors? commonErrors;
  List<BusinessCategoryEntity>? businessCategoriesEntity;

  FetchBusinessCategoryResponseEntity(
      {this.commonErrors, this.businessCategoriesEntity});
}
