import 'package:nextry_dev/domain/entities/business/business_category_entity.dart';

class AddBusinessCategoryParam {
  String businessId;
  BusinessCategoryEntity businessCategoryEntity;
  Function? onUpdate;

  AddBusinessCategoryParam(this.businessId, this.businessCategoryEntity,
      {required this.onUpdate});
}
