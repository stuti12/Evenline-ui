import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';

class WorkTimeEntity {
  int? key;
  Timestamp? startTime;
  Timestamp? endTime;

  WorkTimeEntity({this.startTime, this.endTime, this.key});

  /// Convert city object to map object.
  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map[GateWayConstants.FIELD_START_TIME] = startTime;
    map[GateWayConstants.FIELD_END_TIME] = endTime;
    return map;
  }

  WorkTimeEntity copyWith({
    Timestamp? startTime,
    Timestamp? endTime,
  }) {
    WorkTimeEntity cloneObject = WorkTimeEntity();
    cloneObject.startTime = startTime ?? this.startTime;
    cloneObject.endTime = endTime ?? this.endTime;
    return cloneObject;
  }
}
