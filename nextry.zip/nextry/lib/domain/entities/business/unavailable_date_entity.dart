import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';

class UnavailableDateEntity {
  String? id;
  Timestamp? startDate;
  Timestamp? endDate;

  UnavailableDateEntity({this.startDate, this.endDate});

  UnavailableDateEntity.fromJson(Map<String, dynamic> json, String docId) {
    id = docId;
    startDate = json[GateWayConstants.FIELD_UNAVAILABLE_DATES_START_DATE];
    endDate = json[GateWayConstants.FIELD_UNAVAILABLE_DATES_END_DATE];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data[GateWayConstants.FIELD_UNAVAILABLE_DATES_START_DATE] = startDate;
    data[GateWayConstants.FIELD_UNAVAILABLE_DATES_END_DATE] = endDate;
    return data;
  }
}
