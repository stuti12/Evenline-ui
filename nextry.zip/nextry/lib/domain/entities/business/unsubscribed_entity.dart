import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';

class UnSubscribedEntity {
  String? businessId;
  Timestamp? expiredDate;

  UnSubscribedEntity({this.businessId, this.expiredDate});

  Map<String, dynamic> toJson() {
    return {
      GateWayConstants.FIELD_BUSINESS_ID: businessId,
      GateWayConstants.FIELD_EXPIRED_DATE: expiredDate,
    };
  }
}
