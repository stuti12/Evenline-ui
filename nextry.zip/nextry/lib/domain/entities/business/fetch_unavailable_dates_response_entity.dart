import 'package:nextry_dev/domain/entities/business/unavailable_date_entity.dart';
import 'package:nextry_dev/domain/entities/error/common_errors.dart';

class FetchUnavailableDatesResponseEntity {
  CommonErrors? commonErrors;
  List<UnavailableDateEntity>? unavailableDateEntities;

  FetchUnavailableDatesResponseEntity(
      {this.commonErrors, this.unavailableDateEntities});
}
