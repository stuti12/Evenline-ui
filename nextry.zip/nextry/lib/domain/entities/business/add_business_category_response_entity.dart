import 'package:nextry_dev/domain/entities/error/common_errors.dart';

class AddBusinessCategoryResponseEntity {
  bool? isSuccess;
  CommonErrors? commonErrors;

  AddBusinessCategoryResponseEntity({this.isSuccess, this.commonErrors});
}
