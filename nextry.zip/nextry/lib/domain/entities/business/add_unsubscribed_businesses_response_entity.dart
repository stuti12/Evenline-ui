import 'package:nextry_dev/domain/entities/error/common_errors.dart';

class AddUnSubscribedBusinessesResponseEntity {
  bool? isSuccess;
  CommonErrors? commonErrors;

  AddUnSubscribedBusinessesResponseEntity({this.isSuccess, this.commonErrors});
}
