import 'package:nextry_dev/domain/entities/business/business_entity.dart';
import 'package:nextry_dev/domain/entities/error/common_errors.dart';

class FetchBusinessResponseEntity {
  CommonErrors? commonErrors;
  BusinessEntity? businessEntity;

  FetchBusinessResponseEntity({this.commonErrors, this.businessEntity});
}
