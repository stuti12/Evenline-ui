class FetchBusinessByNameParam {
  String searchName;

  FetchBusinessByNameParam(this.searchName);
}
