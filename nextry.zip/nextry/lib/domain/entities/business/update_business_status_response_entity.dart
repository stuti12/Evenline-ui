import 'package:nextry_dev/domain/entities/error/common_errors.dart';

class UpdateBusinessStatusResponseEntity {
  bool isUpdate;
  CommonErrors? error;

  UpdateBusinessStatusResponseEntity(
      {this.isUpdate = false, required this.error});
}
