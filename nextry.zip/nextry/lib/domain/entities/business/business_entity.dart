import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:geodesy/geodesy.dart';
import 'package:geoflutterfire2/geoflutterfire2.dart';
import 'package:intl/intl.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/domain/entities/business/business_coupon_entity.dart';
import 'package:nextry_dev/domain/entities/business/work_time_entity.dart';
import 'package:nextry_dev/domain/entities/config/payplus_payment_config_entity.dart';
import 'package:nextry_dev/domain/entities/config/subscription_terms_condition.dart';
import 'package:nextry_dev/presentation/common/utils/app_constants.dart';
import 'package:nextry_dev/presentation/common/utils/app_extension.dart';
import 'package:nextry_dev/presentation/common/utils/business_shifts_validator.dart';

import 'payplus_subscription_response_entity.dart';

class BusinessEntity {
  String? id;
  String? categoryId;
  String? name;
  String? profileImage;
  String? status;
  String? phone;
  LatLng? location;
  Map<String, List<WorkTimeEntity>> workTime = {};
  Timestamp? createdAt;
  String? subscriptionId;
  int? hotDealCounts;
  int? adsCounts;
  String? userId;
  double? rating;
  String? currency;
  Map<String, bool> deliveryOptions = {};
  Map<String, bool> paymentMethods = {};
  bool isCreditCardOptionAvailable = false;
  String? address;
  String? isoCode;
  String? profileLink;
  BusinessCouponEntity? coupon;
  num? shippingPrice;
  PayPlusSubscriptionResponseEntity? payPlusSubscriptionResponseEntity;
  PayPlusPaymentConfigEntity? payPlusPaymentConfigEntity;
  SubscriptionTermsConditionEntity? termsConditionEntity;
  SubscriptionTermsConditionEntity? privacyPolicyEntity;
  SubscriptionTermsConditionEntity? returnRefundEntity;
  bool orderOnlyIfOpen = true;

  BusinessEntity(
      {this.id,
      this.categoryId,
      this.name,
      this.profileImage,
      this.status,
      this.phone,
      this.location,
      this.createdAt,
      this.rating});

  BusinessEntity.fromJSON(dynamic json, String docId) {
    id = docId;
    createdAt = json[GateWayConstants.FIELD_CREATED_AT];
    categoryId = json[GateWayConstants.FIELD_CATEGORY_ID];
    name = json[GateWayConstants.FIELD_NAME];
    profileImage = json[GateWayConstants.FIELD_PROFILE_IMAGE];
    status = json[GateWayConstants.FIELD_BUSINESS_STATUS];
    phone = json[GateWayConstants.FIELD_BUSINESS_PHONE];
    try {
      if (json[GateWayConstants.FIELD_LOCATION] != null) {
        var geoPoint = json[GateWayConstants.FIELD_LOCATION]
            [GateWayConstants.FIELD_GEOPOINT];
        if (geoPoint != null) {
          location = LatLng(geoPoint.latitude, geoPoint.longitude);
        }
      }
    } catch (e) {
      print("error Location $e");
    }
    subscriptionId = json[GateWayConstants.FIELD_SUBSCRIPTION_ID];
    hotDealCounts = json[GateWayConstants.FIELD_HOT_DEAL_COUNT] ?? 0;
    adsCounts = json[GateWayConstants.FIELD_ADS_COUNT] ?? 0;
    userId = json[GateWayConstants.FIELD_USER_ID];
    rating = json[GateWayConstants.FIELD_RATING];
    if (json[GateWayConstants.FIELD_WORKTIME] != null) {
      final workTimeJson =
          json[GateWayConstants.FIELD_WORKTIME] as Map<String, dynamic>;
      workTimeJson.forEach((key, value) {
        List<WorkTimeEntity> workTimeList = [];
        if (value is List) {
          for (var element in value) {
            workTimeList.add(WorkTimeEntity(
                startTime: element[GateWayConstants.FIELD_START_TIME],
                endTime: element[GateWayConstants.FIELD_END_TIME]));
          }
          workTime[key] = workTimeList;
        }
      });
    }
    currency = json[GateWayConstants.FIELD_CURRENCY];
    if (json[GateWayConstants.FIELD_DELIVERY_OPTIONS] != null) {
      final deliveryOptionsJson =
          json[GateWayConstants.FIELD_DELIVERY_OPTIONS] as Map<String, dynamic>;
      deliveryOptionsJson.forEach((key, value) {
        deliveryOptions[key] = value;
      });
    }
    if (json[GateWayConstants.FIELD_PAYPLUS_PAYMENT] != null) {
      payPlusPaymentConfigEntity = PayPlusPaymentConfigEntity.fromJSON(
          json[GateWayConstants.FIELD_PAYPLUS_PAYMENT]);
    }
    if (json[GateWayConstants.FIELD_PAYMENT_METHODS] != null) {
      final paymentMethodsJson =
          json[GateWayConstants.FIELD_PAYMENT_METHODS] as Map<String, dynamic>;
      paymentMethodsJson.forEach((key, value) {
        if (key == PaymentMethods.creditCard.name) {
          isCreditCardOptionAvailable = checkPayPlusPaymentConfig();
          paymentMethods[key] = value;
        } else {
          paymentMethods[key] = value;
        }
      });
    }
    address = json[GateWayConstants.FIELD_ADDRESS];
    isoCode = json[GateWayConstants.FIELD_ISOCODE];
    profileLink = json[GateWayConstants.FIELD_PROFILE_LINK];
    coupon = json[GateWayConstants.FIELD_COUPON] != null
        ? BusinessCouponEntity.fromJson(json[GateWayConstants.FIELD_COUPON])
        : null;
    shippingPrice = json[GateWayConstants.FIELD_SHIPPING_PRICE];
    if (json[GateWayConstants.FIELD_PAYPLUS_SUBSCRIPTION] != null) {
      payPlusSubscriptionResponseEntity =
          PayPlusSubscriptionResponseEntity.fromJson(
              json[GateWayConstants.FIELD_PAYPLUS_SUBSCRIPTION]);
    }
    if (json[GateWayConstants.FIELD_BUSINESS_TERMS_CONDITION] != null) {
      termsConditionEntity = SubscriptionTermsConditionEntity.fromJson(
          json[GateWayConstants.FIELD_BUSINESS_TERMS_CONDITION]);
    }
    if (json[GateWayConstants.FIELD_BUSINESS_PRIVACY_POLICY] != null) {
      privacyPolicyEntity = SubscriptionTermsConditionEntity.fromJson(
          json[GateWayConstants.FIELD_BUSINESS_PRIVACY_POLICY]);
    }
    if (json[GateWayConstants.FIELD_BUSINESS_RETURN_REFUND] != null) {
      returnRefundEntity = SubscriptionTermsConditionEntity.fromJson(
          json[GateWayConstants.FIELD_BUSINESS_RETURN_REFUND]);
    }
    orderOnlyIfOpen = json[GateWayConstants.FIELD_ORDER_ONLY_IF_OPEN] ?? true;
  }

  Map<String, dynamic> toJson(String? userId, {bool isCreateRequest = true}) {
    final workTimeData = <String, dynamic>{};
    workTime.forEach((key, value) {
      workTimeData[key] = value.map((e) => e.toJson()).toList();
    });
    return {
      GateWayConstants.FIELD_USER_ID: userId,
      GateWayConstants.FIELD_CATEGORY_ID: categoryId,
      GateWayConstants.FIELD_NAME: name,
      GateWayConstants.FIELD_PROFILE_IMAGE: profileImage,
      GateWayConstants.FIELD_BUSINESS_STATUS: status,
      GateWayConstants.FIELD_BUSINESS_PHONE: phone,
      GateWayConstants.FIELD_LOCATION: GeoFlutterFire()
          .point(
              latitude: location?.latitude ?? 0.0,
              longitude: location?.longitude ?? 0.0)
          .data,
      GateWayConstants.FIELD_WORKTIME: workTimeData,
      GateWayConstants.FIELD_SUBSCRIPTION_ID: subscriptionId,
      GateWayConstants.FIELD_HOT_DEAL_COUNT: hotDealCounts ?? 0,
      GateWayConstants.FIELD_ADS_COUNT: adsCounts ?? 0,
      if (isCreateRequest) GateWayConstants.FIELD_CREATED_AT: Timestamp.now(),
      GateWayConstants.FIELD_CURRENCY: currency,
      GateWayConstants.FIELD_DELIVERY_OPTIONS: deliveryOptions,
      GateWayConstants.FIELD_PAYMENT_METHODS: paymentMethods,
      GateWayConstants.FIELD_ADDRESS: address,
      GateWayConstants.FIELD_ISOCODE: isoCode,
      GateWayConstants.FIELD_PROFILE_LINK: profileLink,
      GateWayConstants.FIELD_SEARCH_BUSINESS_NAME: name.createSearchKeys(),
      GateWayConstants.FIELD_COUPON: coupon?.toJson(),
      GateWayConstants.FIELD_SHIPPING_PRICE: shippingPrice,
      GateWayConstants.FIELD_BUSINESS_TERMS_CONDITION:
          termsConditionEntity?.toJson(),
      GateWayConstants.FIELD_BUSINESS_PRIVACY_POLICY:
          privacyPolicyEntity?.toJson(),
      GateWayConstants.FIELD_BUSINESS_RETURN_REFUND:
          returnRefundEntity?.toJson(),
      GateWayConstants.FIELD_ORDER_ONLY_IF_OPEN: orderOnlyIfOpen
    };
  }

  String? getBusinessDateFormat() {
    if (createdAt != null) {
      var businessDate = createdAt!.toDate();
      return DateFormat(AppConstants.MY_BUSINESSES_DATE_FORMAT)
          .format(businessDate);
    }
    return null;
  }

  updateWorkTime(int rootIndex, List<WorkTimeEntity> workList) {
    workTime[AppConstants.weekDays[rootIndex]] = workList;
  }

  String? getAddress() {
    return address != null && address!.isNotEmpty ? address : '';
  }

  bool checkWorkTime() {
    bool isEmpty = false;
    workTime.forEach((key, value) {
      if (value.isNotEmpty) {
        for (var element in value) {
          if (element.startTime == null || element.endTime == null) {
            isEmpty = true;
            break;
          }
        }
      }
    });
    return isEmpty;
  }

  /// Clone of whole model entity.
  BusinessEntity copyWith(
      {String? id,
      String? categoryId,
      String? name,
      String? profileImage,
      String? status,
      String? phone,
      LatLng? location,
      Map<String, List<WorkTimeEntity>>? workTime,
      Timestamp? createdAt,
      String? subscriptionId,
      int? hotDealCounts,
      int? adsCounts,
      String? userId,
      double? rating,
      String? currency,
      Map<String, bool>? deliveryOptions,
      Map<String, bool>? paymentMethods,
      String? address,
      String? isoCode,
      String? profileLink,
      String? onlinePaymentLink}) {
    BusinessEntity cloneObject = BusinessEntity();
    cloneObject.id = id ?? this.id;
    cloneObject.categoryId = categoryId ?? this.categoryId;
    cloneObject.name = name ?? this.name;
    cloneObject.profileImage = profileImage ?? this.profileImage;
    cloneObject.categoryId = categoryId ?? this.categoryId;
    cloneObject.status = status ?? this.status;
    cloneObject.phone = phone ?? this.phone;
    cloneObject.location = location ?? this.location;
    Map<String, List<WorkTimeEntity>> workTimeClone = {};
    for (var element in this.workTime.keys) {
      List<WorkTimeEntity> items = [];
      this.workTime[element]?.forEach((workItem) {
        items.add(workItem.copyWith());
      });
      workTimeClone[element] = items;
    }
    cloneObject.workTime = workTimeClone;
    cloneObject.createdAt = createdAt ?? this.createdAt;
    cloneObject.subscriptionId = subscriptionId ?? this.subscriptionId;
    cloneObject.hotDealCounts = hotDealCounts ?? this.hotDealCounts;
    cloneObject.adsCounts = adsCounts ?? this.adsCounts;
    cloneObject.userId = userId ?? this.userId;
    cloneObject.rating = rating ?? this.rating;
    cloneObject.currency = currency ?? this.currency;
    cloneObject.deliveryOptions =
        deliveryOptions ?? Map<String, bool>.of(this.deliveryOptions);
    cloneObject.paymentMethods =
        paymentMethods ?? Map<String, bool>.of(this.paymentMethods);
    cloneObject.address = address ?? this.address;
    cloneObject.isoCode = isoCode ?? this.isoCode;
    cloneObject.profileLink = profileLink ?? this.profileLink;
    cloneObject.termsConditionEntity = termsConditionEntity;
    cloneObject.privacyPolicyEntity = privacyPolicyEntity;
    cloneObject.returnRefundEntity = returnRefundEntity;
    cloneObject.orderOnlyIfOpen = orderOnlyIfOpen;
    return cloneObject;
  }

  bool checkBusinessStatus() {
    // New Logic --- Start
    var day = DateFormat(AppConstants.DAY_FORMAT)
        .format(DateTime.now())
        .toLowerCase();
    var listOfWorkTime = workTime[day];
    if (listOfWorkTime != null && listOfWorkTime.isNotEmpty) {
      var currentTime = DateTime.now();
      for (var element in listOfWorkTime) {
        var startDate = element.startTime?.toDate();
        var endDate = element.endTime?.toDate();
        if (startDate != null && endDate != null) {
          if (BusinessShiftsValidator.isBusinessOpen(
            start: startDate.toTimeOfDay(),
            end: endDate.toTimeOfDay(),
            current: currentTime.toTimeOfDay(),
          )) {
            return true;
          }
        }
      }
    }
    return false;
    // New Logic --- End

    // var day = DateFormat(AppConstants.DAY_FORMAT)
    //     .format(DateTime.now())
    //     .toLowerCase();
    // var listOfWorkTime = workTime[day];
    // if (listOfWorkTime != null && listOfWorkTime.isNotEmpty) {
    //   var currentTime = DateTime.now();
    //   for (var element in listOfWorkTime) {
    //     var startDate = element.startTime?.toDate();
    //     var endDate = element.endTime?.toDate();
    //     if (startDate != null && endDate != null) {
    //       var convertStartDate = DateTime(currentTime.year, currentTime.month,
    //           currentTime.day, startDate.hour, startDate.minute);
    //       var convertEndDate = DateTime(currentTime.year, currentTime.month,
    //           currentTime.day, endDate.hour, endDate.minute);
    //       if (convertStartDate.isBefore(currentTime) &&
    //           convertEndDate.isAfter(currentTime)) {
    //         return true;
    //       }
    //     }
    //   }
    // }
    // return false;
  }

  checkPayPlusPaymentConfig() {
    return payPlusPaymentConfigEntity?.apiKey.isNullOrEmpty() == false &&
        payPlusPaymentConfigEntity?.pageUid.isNullOrEmpty() == false &&
        payPlusPaymentConfigEntity?.secretKey.isNullOrEmpty() == false;
  }
}
