class FetchUnavailableDatesParam {
  String? businessId;
  String? productId;

  FetchUnavailableDatesParam({this.businessId, this.productId});
}
