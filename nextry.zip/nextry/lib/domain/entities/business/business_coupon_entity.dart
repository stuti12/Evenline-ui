import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';

class BusinessCouponEntity {
  String? code;
  bool? isForever;
  Timestamp? startDate;
  Timestamp? endDate;

  BusinessCouponEntity({
    this.code,
    this.isForever,
    this.startDate,
    this.endDate,
  });

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data[GateWayConstants.FIELD_COUPON_CODE] = code;
    data[GateWayConstants.FIELD_IS_FOREVER] = isForever;
    data[GateWayConstants.FIELD_COUPON_START_DATE] = startDate;
    data[GateWayConstants.FIELD_COUPON_END_DATE] = endDate;

    return data;
  }

  BusinessCouponEntity.fromJson(Map<String, dynamic> json) {
    startDate = json[GateWayConstants.FIELD_COUPON_START_DATE];
    endDate = json[GateWayConstants.FIELD_COUPON_END_DATE];
    code = json[GateWayConstants.FIELD_COUPON_CODE];
    isForever = json[GateWayConstants.FIELD_IS_FOREVER];
  }
}
