import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';

class BusinessDeliveryOrdersEntity {
  String? orderId;
  String? shipperId;

  BusinessDeliveryOrdersEntity({this.orderId, this.shipperId});

  BusinessDeliveryOrdersEntity.fromJSON(dynamic json) {
    orderId = json[GateWayConstants.FIELD_ID];
    shipperId = json[GateWayConstants.FIELD_OFFER_REQUEST_SHIPPER_ID];
  }
}
