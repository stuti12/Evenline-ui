import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/presentation/common/utils/app_extension.dart';

class PayPlusSubscriptionResponseEntity {
  String? terminalUid;
  String? recurringPaymentId;

  PayPlusSubscriptionResponseEntity(
      {this.terminalUid, this.recurringPaymentId});

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data[GateWayConstants.PAYPLUS_FIELD_TERMINAL_ID] = terminalUid.encryptedData();
    data[GateWayConstants.PAYPLUS_FIELD_RECURRING_ID] = recurringPaymentId.encryptedData();
    return data;
  }

  PayPlusSubscriptionResponseEntity.fromJson(dynamic json){
    terminalUid = json[GateWayConstants.PAYPLUS_FIELD_TERMINAL_ID]?.toString().decryptedData();
    recurringPaymentId = json[GateWayConstants.PAYPLUS_FIELD_RECURRING_ID]?.toString().decryptedData();
  }
}
