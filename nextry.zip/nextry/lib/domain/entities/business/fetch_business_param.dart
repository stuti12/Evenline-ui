class FetchBusinessParam {
  String? businessId;
  String? status;
  Function? function;

  FetchBusinessParam({this.businessId, this.status, this.function});
}
