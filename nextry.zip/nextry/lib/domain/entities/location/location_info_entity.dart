/// Location Information model. Along with lat-long it will store other details of location as well.
class LocationInfoEntity {
  double latitude; // Latitude, in degrees
  double longitude; // Longitude, in degrees
  double
      accuracy; // Estimated horizontal accuracy of this location, radial, in meters
  double altitude; // In meters above the WGS 84 reference ellipsoid
  double speed; // In meters/second
  double speedAccuracy; // In meters/second, always 0 on iOS
  double
      heading; // Heading is the horizontal direction of travel of this device, in degrees
  double time; // timestamp of the LocationData
  bool isMock; // Is the location currently mocked
  bool isLocationServiceEnabled; // use it to show enable service UI
  bool isUserGrantedLocationPermission;
  bool isUserDeniedForeverLocationPermission;
  String address;
  String name;

  LocationInfoEntity(
      {this.latitude = 0.0,
      this.longitude = 0.0,
      this.accuracy = 0.0,
      this.altitude = 0.0,
      this.speed = 0.0,
      this.speedAccuracy = 0.0,
      this.heading = 0.0,
      this.time = 0.0,
      this.isMock = false,
      this.isLocationServiceEnabled = false,
      this.isUserGrantedLocationPermission = false,
      this.isUserDeniedForeverLocationPermission = false,
      this.address = '',
      this.name = ''}); // use it to show grant permission UI.
}
