class AddUpdateOrderInvoiceParam {
  String businessId;
  String orderId;
  String invoice;

  AddUpdateOrderInvoiceParam(
      {required this.businessId, required this.orderId, required this.invoice});
}
