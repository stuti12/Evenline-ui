class UpdateOrderStatusParam {
  String? businessId;
  String? orderId;
  String? status;
  String? deliveryOrderId;

  UpdateOrderStatusParam(this.businessId, this.status, this.orderId, {this.deliveryOrderId});
}
