class OrderStatusEntity {
  int key;
  String value;

  OrderStatusEntity({
    required this.key,
    required this.value,
  });
}
