import 'package:nextry_dev/domain/entities/order/order_entity.dart';

class MakeOrderParam {
  final String? cartId;
  final OrderEntity? orderEntity;

  MakeOrderParam({this.cartId, this.orderEntity});
}
