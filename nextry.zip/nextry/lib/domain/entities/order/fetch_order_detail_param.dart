class FetchOrderDetailParam {
  String? orderId;
  String? businessId;
  Function? function;

  FetchOrderDetailParam({this.orderId, this.businessId, this.function});
}
