class FetchOrdersParam {
  String? businessId;
  int? noOfDays;
  String? status;
  Function? function;

  FetchOrdersParam(
      {this.businessId, this.status, this.noOfDays, this.function});
}
