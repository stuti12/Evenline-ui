import 'package:nextry_dev/domain/entities/error/common_errors.dart';
import 'package:nextry_dev/domain/entities/order/order_entity.dart';

class FetchOrdersResponseEntity {
  List<OrderEntity>? orders;
  CommonErrors? commonErrors;

  FetchOrdersResponseEntity({this.orders, this.commonErrors});
}
