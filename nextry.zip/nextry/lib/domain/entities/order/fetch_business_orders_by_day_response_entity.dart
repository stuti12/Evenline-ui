import 'package:nextry_dev/domain/entities/error/common_errors.dart';

class FetchBusinessOrdersByDayResponseEntity {
  num? numberOfOrders;
  CommonErrors? commonErrors;

  FetchBusinessOrdersByDayResponseEntity(
      {this.numberOfOrders = 0, this.commonErrors});
}
