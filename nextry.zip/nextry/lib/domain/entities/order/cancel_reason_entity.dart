import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/presentation/common/utils/app_constants.dart';

class CancelReasonEntity {
  Timestamp? createdAt;
  String? reason;

  CancelReasonEntity({this.createdAt, this.reason});

  CancelReasonEntity.fromJson(Map<String, dynamic> json) {
    createdAt = json[GateWayConstants.FIELD_CREATED_AT];
    reason = json[GateWayConstants.FIELD_ORDER_REASON];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};

    data[GateWayConstants.FIELD_CREATED_AT] = Timestamp.now();
    data[GateWayConstants.FIELD_ORDER_REASON] = reason ?? CancelOrderReason.refund.value;
    return data;
  }
}
