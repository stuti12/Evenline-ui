import 'package:nextry_dev/domain/entities/error/common_errors.dart';
import 'package:nextry_dev/domain/entities/order/order_entity.dart';

class FetchOrderDetailResponseEntity {
  OrderEntity? orderEntity;
  CommonErrors? commonErrors;

  FetchOrderDetailResponseEntity({this.orderEntity, this.commonErrors});
}
