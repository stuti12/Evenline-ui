import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/domain/entities/order/cancel_reason_entity.dart';

class CancelOrderParam {
  String? businessId;
  String? orderId;
  CancelReasonEntity? cancelReasonEntity;
  String? status;

  CancelOrderParam(
      {this.businessId, this.orderId, this.cancelReasonEntity, this.status});

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};

    data[GateWayConstants.FIELD_ORDER_CANCEL_REASON] =
        cancelReasonEntity?.toJson();
    data[GateWayConstants.FIELD_ORDER_STAUS] = status;
    return data;
  }
}
