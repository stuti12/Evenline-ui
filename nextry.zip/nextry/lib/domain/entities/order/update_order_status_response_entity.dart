import 'package:nextry_dev/domain/entities/error/common_errors.dart';

class UpdateOrderStatusResponseEntity {
  bool? isSuccess;
  CommonErrors? commonErrors;

  UpdateOrderStatusResponseEntity({this.isSuccess, this.commonErrors});
}
