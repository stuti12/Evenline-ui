import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/domain/entities/business/business_delivery_orders_entity.dart';
import 'package:nextry_dev/domain/entities/business/business_entity.dart';
import 'package:nextry_dev/domain/entities/cart/cart_product_entity.dart';
import 'package:nextry_dev/domain/entities/order/cancel_reason_entity.dart';
import 'package:nextry_dev/domain/entities/profile/address_entity.dart';
import 'package:nextry_dev/domain/entities/profile/user_entity.dart';
import 'package:nextry_dev/presentation/common/utils/app_constants.dart';
import 'package:nextry_dev/presentation/common/utils/app_extension.dart';

class OrderEntity {
  String? id;
  String? businessId;
  BusinessEntity? businessEntity;
  List<CartProductEntity>? products;
  String? transactionId;
  num? totalAmount;
  String? paymentType;
  String? status;
  bool? isLeaveFeedback;
  AddressEntity? address;
  Timestamp? createdAt;
  UserEntity? userEntity;
  String? invoice; // it can be either file or image.
  String? deliveryMethod;
  CancelReasonEntity? cancelReasonEntity;
  BusinessDeliveryOrdersEntity? businessDeliveryOrdersEntity;

  OrderEntity({
    this.id,
    this.businessId,
    this.products,
    this.transactionId,
    this.totalAmount,
    this.paymentType,
    this.status,
    this.isLeaveFeedback,
    this.address,
    this.deliveryMethod,
  });

  OrderEntity.fromJson(Map<String, dynamic> json, String docId,
      {UserEntity? user}) {
    id = docId;
    businessId = json[GateWayConstants.FIELD_BUSINESS_ID];
    userEntity = user;
    transactionId = json[GateWayConstants.FIELD_ORDER_TRANSACTION_ID]?.toString().decryptedData();
    totalAmount = json[GateWayConstants.FIELD_ORDER_TOTAL_AMOUNT];
    paymentType = json[GateWayConstants.FIELD_ORDER_PAYMENT_TYPE];
    status = json[GateWayConstants.FIELD_ORDER_STAUS];
    isLeaveFeedback = json[GateWayConstants.FIELD_ORDER_IS_LEAVE_FEEDBACK];
    invoice = json[GateWayConstants.FIELD_ORDER_INVOICE];
    if (json[GateWayConstants.FIELD_ADDRESS] != null) {
      address = AddressEntity.fromJson(json[GateWayConstants.FIELD_ADDRESS]);
    }
    createdAt = json[GateWayConstants.FIELD_CREATED_AT];
    if (json[GateWayConstants.FIELD_PRODUCTS] != null) {
      products = <CartProductEntity>[];
      json[GateWayConstants.FIELD_PRODUCTS].forEach((v) {
        products!.add(CartProductEntity.fromJson(v));
      });
    }
    deliveryMethod = json[GateWayConstants.FIELD_ORDER_DELIVERY_METHOD];
    if (json[GateWayConstants.FIELD_ORDER_CANCEL_REASON] != null) {
      cancelReasonEntity = CancelReasonEntity.fromJson(json[GateWayConstants.FIELD_ORDER_CANCEL_REASON]);
    }

    if (json[GateWayConstants.FIELD_BUSINESS_DELIVERY_ORDER] != null) {
      businessDeliveryOrdersEntity = BusinessDeliveryOrdersEntity.fromJSON(
          json[GateWayConstants.FIELD_BUSINESS_DELIVERY_ORDER]);
    }
  }

  Map<String, dynamic> toJson({String? userId}) {
    final Map<String, dynamic> data = <String, dynamic>{};
    data[GateWayConstants.FIELD_BUSINESS_ID] = businessId;
    data[GateWayConstants.FIELD_USER_ID] = userId ?? userEntity?.docId;
    data[GateWayConstants.FIELD_ORDER_TRANSACTION_ID] = transactionId?.encryptedData();
    data[GateWayConstants.FIELD_ORDER_TOTAL_AMOUNT] = totalAmount;
    data[GateWayConstants.FIELD_ORDER_PAYMENT_TYPE] = paymentType;
    data[GateWayConstants.FIELD_ORDER_STAUS] =
        status ?? OrderStatus.received.name;
    data[GateWayConstants.FIELD_ORDER_IS_LEAVE_FEEDBACK] =
        isLeaveFeedback ?? false;
    data[GateWayConstants.FIELD_ADDRESS] = address?.toJson();
    data[GateWayConstants.FIELD_CREATED_AT] = Timestamp.now();
    data[GateWayConstants.FIELD_ORDER_INVOICE] = invoice;
    if (products != null) {
      data[GateWayConstants.FIELD_PRODUCTS] =
          products!.map((v) => v.toJson()).toList();
    }
    data[GateWayConstants.FIELD_ORDER_DELIVERY_METHOD] = deliveryMethod;
    return data;
  }

  String? getOrdersDateFormat() {
    if (createdAt != null) {
      var date = createdAt!.toDate();
      return DateFormat(AppConstants.MY_BUSINESSES_DATE_FORMAT).format(date);
    }
    return null;
  }

  String? getOrdersTimeFormat() {
    if (createdAt != null) {
      var date = createdAt!.toDate();
      return DateFormat(AppConstants.MY_ORDERS_TIME_FORMAT).format(date);
    }
    return null;
  }

  getTotalPrice() {
    num totalPrice = 0;
    products?.forEach((e) {
      if (e.price != null && e.quantity != null) {
        num difference = 0;
        if (e.discount != null) {
          difference = e.price! - (e.discount ?? 0);
        }
        totalPrice = totalPrice + (((e.price! - difference) * e.quantity!));
      }
    });
    return totalPrice.convertToString();
  }

  String? getCancelOrderDateFormat() {
    if (cancelReasonEntity?.createdAt != null) {
      var date = cancelReasonEntity?.createdAt?.toDate();
      return DateFormat(AppConstants.MY_BUSINESSES_DATE_FORMAT).format(date!);
    }
    return null;
  }
}
