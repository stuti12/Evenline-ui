import 'package:nextry_dev/domain/entities/error/common_errors.dart';

class MakeOrderResponseEntity {
  String? orderId;
  bool? isSuccess;
  CommonErrors? commonErrors;

  MakeOrderResponseEntity({this.orderId, this.isSuccess, this.commonErrors});
}
