import 'package:nextry_dev/domain/entities/error/common_errors.dart';

class AddUpdateOrderInvoiceResponseEntity {
  bool? isSuccess;
  CommonErrors? commonErrors;

  AddUpdateOrderInvoiceResponseEntity({this.isSuccess, this.commonErrors});
}
