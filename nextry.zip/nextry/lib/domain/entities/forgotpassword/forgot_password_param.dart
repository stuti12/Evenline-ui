/// Forgot password param which send email to gateway.
class ForgotPasswordParam {
  String email;

  ForgotPasswordParam({required this.email});
}
