
import 'package:nextry_dev/domain/entities/error/common_errors.dart';

/// Different error type which exist during forgot password flow.
enum SignInMethodsStatus { NOT_USER_EXIST, NOT_PASSWORD_EXIST, EXIST_PASSWORD }

/// Forgot password response entity. If [SignInMethodsStatus] & [CommonErrors] are null then
/// user successfully reset the password.
class ForgotPasswordResponseEntity {
  SignInMethodsStatus? signInMethodsStatus;
  CommonErrors? error;

  ForgotPasswordResponseEntity(
      {required this.signInMethodsStatus, required this.error});
}
