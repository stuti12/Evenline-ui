import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/presentation/common/utils/app_constants.dart';

class FetchNotificationEntity {
  String? type;
  String? businessId;
  String? deliveryRequestId;
  String? deliveryOrderId;
  String? orderId;
  String? productId;
  Timestamp? createdAt;
  String? title;
  String? message;
  String? image;

  FetchNotificationEntity({
    this.type,
    this.businessId,
    this.orderId,
    this.productId,
    this.createdAt,
    this.title,
    this.message,
    this.image,
    this.deliveryOrderId,
    this.deliveryRequestId,
  });

  FetchNotificationEntity.fromJson(Map<String, dynamic> json) {
    type = json[GateWayConstants.FIELD_TYPE];
    businessId = json[GateWayConstants.FIELD_BUSINESS_ID];
    orderId = json[GateWayConstants.FIELD_ORDER_ID];
    productId = json[GateWayConstants.FIELD_PRODUCT_ID];
    createdAt = json[GateWayConstants.FIELD_CREATED_AT];
    title = json[GateWayConstants.FIELD_TITLE];
    message = json[GateWayConstants.FIELD_MESSAGE];
    image = json[GateWayConstants.FIELD_PRODUCT_IMAGE];
    deliveryOrderId = json[GateWayConstants.FIELD_DELIVERY_ORDER_ID];
    deliveryRequestId = json[GateWayConstants.FIELD_DELIVERY_REQUEST_ID];
  }

  String? getDateFormat() {
    if (createdAt != null) {
      var date = createdAt!.toDate();
      return DateFormat(AppConstants.TRANSACTION_DATE_FORMAT).format(date);
    }
    return null;
  }
}
