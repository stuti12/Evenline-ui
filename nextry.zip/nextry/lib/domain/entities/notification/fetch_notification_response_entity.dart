import 'package:nextry_dev/domain/entities/error/common_errors.dart';
import 'package:nextry_dev/domain/entities/notification/fetch_notification_entity.dart';

class FetchNotificationResponseEntity {
  CommonErrors? commonErrors;
  List<FetchNotificationEntity>? notificationList;

  FetchNotificationResponseEntity({this.commonErrors, this.notificationList});
}
