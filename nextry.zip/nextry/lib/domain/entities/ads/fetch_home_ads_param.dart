import 'package:geodesy/geodesy.dart';
import 'package:nextry_dev/domain/entities/ads/ads_entity.dart';

class FetchHomeAdsParam {
  AdsEntity? adsEntity;
  String? categoryId;
  LatLng? location;
  double? radius;
  Function function;

  FetchHomeAdsParam({
    this.adsEntity,
    this.location,
    this.categoryId,
    this.radius,
    required this.function,
  });
}
