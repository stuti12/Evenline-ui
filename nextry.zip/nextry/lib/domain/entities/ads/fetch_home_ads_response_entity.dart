import 'package:nextry_dev/domain/entities/ads/ads_entity.dart';
import 'package:nextry_dev/domain/entities/error/common_errors.dart';

class FetchHomeAdsResponseEntity {
  CommonErrors? commonErrors;
  Map<String, List<AdsEntity>>? adsMapList;

  FetchHomeAdsResponseEntity({this.commonErrors, this.adsMapList});
}
