import 'package:geodesy/geodesy.dart';
import 'package:nextry_dev/domain/entities/ads/ads_entity.dart';

class FetchAdsParam {
  String businessId;
  String productId;
  AdsEntity? adsEntity;
  String? categoryId;
  LatLng? location;
  double? radius;
  String? searchName;

  FetchAdsParam({
    required this.businessId,
    required this.productId,
    this.adsEntity,
    this.location,
    this.categoryId,
    this.radius,
    this.searchName,
  });
}
