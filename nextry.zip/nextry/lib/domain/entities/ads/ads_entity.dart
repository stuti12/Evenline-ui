import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/domain/entities/business/business_entity.dart';
import 'package:nextry_dev/domain/entities/product/product_entity.dart';
import 'package:nextry_dev/presentation/common/utils/app_constants.dart';

class AdsEntity {
  String? docId;
  String? image;
  num? productPrice;
  Timestamp? startDate;
  Timestamp? endDate;
  String? businessId;
  String? productId;
  String? adId;
  ProductEntity? productEntity;
  String? businessName;
  BusinessEntity? businessEntity;

  AdsEntity({this.image, this.productPrice, this.startDate, this.endDate});

  AdsEntity.fromJson(Map<String, dynamic> json, String id) {
    docId = id;
    image = json[GateWayConstants.FIELD_PRODUCT_IMAGE];
    productPrice = json[GateWayConstants.FIELD_PRODUCT_PRICE];
    startDate = json[GateWayConstants.FIELD_PRODUCT_DISCOUNT_START_DATE];
    endDate = json[GateWayConstants.FIELD_PRODUCT_DISCOUNT_END_DATE];
    businessId = json[GateWayConstants.FIELD_BUSINESS_ID];
    productId = json[GateWayConstants.FIELD_PRODUCT_ID];
    adId = json[GateWayConstants.FIELD_AD_ID];
    businessName = json[GateWayConstants.FIELD_BUSINESS_NAMES];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data[GateWayConstants.FIELD_PRODUCT_IMAGE] = image;
    data[GateWayConstants.FIELD_PRODUCT_PRICE] = productPrice;
    data[GateWayConstants.FIELD_PRODUCT_DISCOUNT_START_DATE] = startDate;
    data[GateWayConstants.FIELD_PRODUCT_DISCOUNT_END_DATE] = endDate;
    return data;
  }

  getEndTime() {
    if (endDate != null) {
      var date = endDate!.toDate();
      return _dateFormat(date);
    }
    return null;
  }

  getStartTime() {
    if (startDate != null) {
      var date = startDate!.toDate();
      return _dateFormat(date);
    }
    return null;
  }

  _dateFormat(DateTime dateTime) {
    return DateFormat(AppConstants.HOT_DEALS_TIME_FORMAT).format(dateTime);
  }

  int dayLeftToStart() {
    if (startDate != null) {
      final startDate = this.startDate?.toDate();
      final current = DateTime.now();
      return startDate
          ?.difference(DateTime(current.year, current.month, current.day))
          .inDays ??
          0;
    }
    return 0;
  }
}
