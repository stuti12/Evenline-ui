import 'package:geodesy/geodesy.dart';
import 'package:nextry_dev/domain/entities/ads/ads_entity.dart';

class AddUpdateAdsParam {
  String businessId;
  String productId;
  String? categoryId;
  LatLng? location;
  AdsEntity adsEntity;
  String? businessName;

  AddUpdateAdsParam({
    required this.businessId,
    required this.productId,
    required this.adsEntity,
    this.categoryId,
    this.location,
    this.businessName,
  });
}
