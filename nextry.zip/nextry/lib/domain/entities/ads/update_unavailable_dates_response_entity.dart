import 'package:nextry_dev/domain/entities/error/common_errors.dart';

class UpdateUnavailableDatesResponseEntity {
  bool? isSuccess;
  CommonErrors? commonErrors;

  UpdateUnavailableDatesResponseEntity({this.isSuccess, this.commonErrors});
}
