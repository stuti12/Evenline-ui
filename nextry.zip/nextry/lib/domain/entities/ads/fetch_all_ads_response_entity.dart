import 'package:nextry_dev/domain/entities/ads/ads_entity.dart';
import 'package:nextry_dev/domain/entities/error/common_errors.dart';

class FetchAllAdsResponseEntity {
  CommonErrors? commonErrors;
  List<AdsEntity>? adsList;

  FetchAllAdsResponseEntity({this.commonErrors, this.adsList});
}
