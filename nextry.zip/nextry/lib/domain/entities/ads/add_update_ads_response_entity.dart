import 'package:nextry_dev/domain/entities/error/common_errors.dart';

class AddUpdateAdsResponseEntity {
  bool? isSuccess;
  CommonErrors? commonErrors;

  AddUpdateAdsResponseEntity({this.isSuccess, this.commonErrors});
}
