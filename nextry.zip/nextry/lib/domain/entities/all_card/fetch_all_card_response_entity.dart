import 'package:nextry_dev/domain/entities/all_card/card_entity.dart';
import 'package:nextry_dev/domain/entities/error/common_errors.dart';

class FetchAllCardResponseEntity {
  CommonErrors? commonErrors;
  List<CardEntity>? allCardList;

  FetchAllCardResponseEntity({
    this.commonErrors,
    this.allCardList,
  });
}
