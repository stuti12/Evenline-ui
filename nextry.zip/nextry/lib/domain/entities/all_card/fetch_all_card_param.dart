class FetchAllCardParam {
  String? customerId;

  FetchAllCardParam({this.customerId});
}
