import 'package:nextry_dev/domain/entities/generic_dropdown_item.dart';

class CustomerPlaceOrderEntity extends GenericDropdownItem {
  String? docId;
  String? name;
  bool? isVisible;
  Map<String,String> placeOrderName = {};

  CustomerPlaceOrderEntity({this.docId, this.name, this.isVisible});

  @override
  String get displayName => name ?? '';

  @override
  String get id => docId ?? '';
}