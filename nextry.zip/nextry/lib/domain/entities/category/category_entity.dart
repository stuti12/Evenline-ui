import 'package:nextry_dev/domain/entities/generic_dropdown_item.dart';

class CategoryEntity extends GenericDropdownItem {
  String? docId;
  String? name;
  String? logo;
  bool? isVisible;
  Map<String,String> catName = {};

  CategoryEntity({this.docId, this.name, this.logo, this.isVisible});

  @override
  String get displayName => name ?? '';

  @override
  String get id => docId ?? '';
}
