import 'package:nextry_dev/domain/entities/category/category_entity.dart';
import 'package:nextry_dev/domain/entities/error/common_errors.dart';

class CategoryResponseEntity {
  List<CategoryEntity>? categories;
  CommonErrors? error;

  CategoryResponseEntity({this.categories, this.error});
}
