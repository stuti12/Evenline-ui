import 'dart:convert';

import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter_stripe/flutter_stripe.dart';

Dio dio = Dio();

Map<String, String> headers = {
  'Authorization':
  'Bearer sk_test_51N1a6mA96WVwXAJrRDPQOZfaWi2pIJklFPKxK0rNHsAOIKY35aPRMAJpzw0i4OO9CWzSbAv4UHdrffjUBS7UxjCo00z13xrxYx',
  'Content-Type': 'application/x-www-form-urlencoded'
};

init() {
  BaseOptions options = BaseOptions(
      baseUrl: "https://api.stripe.com",
      receiveDataWhenStatusError: true,
      connectTimeout: const Duration(milliseconds: 60000),
      // 60 seconds
      receiveTimeout: const Duration(milliseconds: 60000) // 60 seconds
  );

  dio = Dio(options);
}

/// This method the create customer
Future<Map<String, dynamic>> _createCustomer() async {
  //TODO add customer detail dynamically
  const String url = '/v1/customers';
  var body = {
    'name': 'Keyuri Thakkar',
    'email': 'thakkar.keyuri@nextryapp.com',
    'description': 'Daily Recurring'
  };
  var response = await dio.post(
    url,
    options: Options(
      headers: headers,
    ),
    data: body,
  );
  if (response.statusCode == 200) {
    print(response.data);
    return response.data;
  } else {
    print(json.decode(response.data));
    throw 'Failed to register as a customer.';
  }
}

/// This method the create the payment intent for specified customer
Future<Map<String, dynamic>> _createPaymentIntents(
    String customerID, String amount) async {
  const String url = 'https://api.stripe.com/v1/payment_intents';

  Map<String, dynamic> body = {
    'customer': customerID,
    'amount': amount,
    'currency': 'usd',
    'payment_method_types[]': 'card',
    'setup_future_usage': 'off_session',
  };

  var response = await dio.post(url,
      options: Options(
        headers: headers,
      ),
      data: body);
  if (response.statusCode == 200) {
    print(response.data);
    return response.data;
  } else {
    print(json.decode(response.data));
    throw 'Failed to create PaymentIntents.';
  }
}

/// This method the create the subscription
Future<Map<String, dynamic>> _createSubscriptions(
    String customerId, String priceId, String description,
    {bool withFreeTrial = false}) async {
  const String url = 'https://api.stripe.com/v1/subscriptions';

  Map<String, dynamic> body = {
    'customer': customerId,
    'items[0][price]': priceId,
    "currency": "usd",
    "off_session": "true",
    'description': description,
    if (withFreeTrial == true) "trial_period_days": "1",
  };

  var response = await dio.post(url,
      options: Options(
        headers: headers,
      ),
      data: body);
  if (response.statusCode == 200) {
    print(response.data);
    return response.data;
  } else {
    print(json.decode(response.data));
    throw 'Failed to register as a subscriber.';
  }
}

/// This method the cancel the subscribtion till the period end.
Future<String> _updateSubscriptions(
    String customerId, String subscriptionId, String priceId) async {
  String url = 'https://api.stripe.com/v1/subscriptions/$subscriptionId';

  Map<String, dynamic> body = {
    // 'items[0][price]': priceId,
    'cancel_at_period_end': true
  };

  var response = await dio.post(url,
      options: Options(
        headers: headers,
      ),
      data: body);
  if (response.statusCode == 200) {
    print(response.data);
    // // final test = response.data['items']['data'];
    // // final data = test.firstWhere((element) =>
    // //     element['price']['id'] != priceId,
    // //       orElse: () {
    // //         return "";
    // //       });
    // print(data);
    return response.data;
  } else {
    print(json.decode(response.data));
    throw 'Failed to register as a subscriber.';
  }
}

/// This method retrieve list of subscription of the user
Future<Map<String, dynamic>> _getSubscriptionsByCustomer(
    String customerId) async {
  const String url = 'https://api.stripe.com/v1/subscriptions';

  var response = await dio.get(url,
      options: Options(
        headers: headers,
      ),
      data: {'customer': customerId});
  if (response.statusCode == 200) {
    print(response.data['data'][0]['items']['data']);
    final allProductData = response.data['data'];
    print("allProductData ==> ${allProductData.length}");
    for (var o in allProductData) {
      final test  = await  _getSubscriptionDetailsOfCustomer(o['items']['data'][0]['price']['product']);
      print("${test['name']}");
    }

    // final test = await _getSubscriptionDetailsOfCustomer(response.data['data'][0]['items']['data'][0]['price']['product']);
    // print("${test['name']}");
    return response.data;
  } else {
    print(json.decode(response.data));
    throw 'Failed to register as a subscriber.';
  }
}

/// This method retrieve list of subscription of the user
Future<Map<String, dynamic>> _getSubscriptionDetailsOfCustomer(
    String productId) async {
  String url = 'https://api.stripe.com/v1/products/$productId';

  var response = await dio.get(url,
    options: Options(
      headers: headers,
    ),
  );
  if (response.statusCode == 200) {
    print(response.data);
    return response.data;
  } else {
    print(json.decode(response.data));
    throw 'Failed to register as a subscriber.';
  }
}

Future<void> createTokenFromCardId(String cardId) async {
  try {

  } catch (error) {
    print('Error creating token: ${error.toString()}');
  }
}

/// This method retrieve list of subscription of the user
Future<Map<String, dynamic>> _getAllCards(
    String customerId) async {
  String url = 'https://api.stripe.com/v1/customers/$customerId/sources';
  var response = await dio.get(url,
    options: Options(
      headers: headers,
    ),
  );
  if (response.statusCode == 200) {
    print(response.data);
    return response.data;
  } else {
    print(json.decode(response.data));
    throw 'Failed to register as a subscriber.';
  }
}


/// This method retrieve all detail of the subscriptions
Future<Map<String, dynamic>> _getSubscriptions(
    String customerId, String paymentMethodId) async {
  const String url =
      'https://api.stripe.com/v1/subscriptions/sub_1N3ee2A96WVwXAJrM6oAqbAF';

  var response = await dio.get(url,
      options: Options(
        headers: headers,
      ));
  if (response.statusCode == 200) {
    print(response.data);
    return response.data;
  } else {
    print(json.decode(response.data));
    throw 'Failed to register as a subscriber.';
  }
}

/// This method delete the subscription item
Future<Map<String, dynamic>> _deleteSubscriptionsItem(
    String subscriptionId) async {
  String url = 'https://api.stripe.com/v1/subscription_items/$subscriptionId';
  var response = await dio.delete(url,
      options: Options(
        headers: headers,
      ));
  if (response.statusCode == 200) {
    print(response.data);
    return response.data;
  } else {
    print(json.decode(response.data));
    throw 'Failed to register as a subscriber.';
  }
}

/// This method delete the created subscription
Future<Map<String, dynamic>> _deleteSubscriptions(String subscriptionId) async {
  String url = 'https://api.stripe.com/v1/subscriptions/$subscriptionId';

  var response = await dio.delete(url,
      options: Options(
        headers: headers,
      ));
  if (response.statusCode == 200) {
    print(response.data);
    return response.data;
  } else {
    print(json.decode(response.data));
    throw 'Failed to register as a subscriber.';
  }
}

Future<PaymentIntent?> _createCreditCard(
    String customerId, Map<String, dynamic> paymentIntent) async {
  try {
    await Stripe.instance.initPaymentSheet(
        paymentSheetParameters: SetupPaymentSheetParameters(
          style: ThemeMode.dark,
          merchantDisplayName: 'Nextry !!',
          customerId: customerId,
          customerEphemeralKeySecret: paymentIntent['ephemeralKey'],
          paymentIntentClientSecret: paymentIntent['client_secret'],
          appearance: const PaymentSheetAppearance(
            colors: PaymentSheetAppearanceColors(
              background: Colors.lightBlue,
              primary: Colors.blue,
              componentBorder: Colors.red,
            ),
            shapes: PaymentSheetShape(
              shadow: PaymentSheetShadowParams(color: Colors.red),
            ),
            primaryButton: PaymentSheetPrimaryButtonAppearance(
              colors: PaymentSheetPrimaryButtonTheme(
                light: PaymentSheetPrimaryButtonThemeColors(
                  background: Color.fromARGB(255, 231, 235, 30),
                  text: Color.fromARGB(255, 235, 92, 30),
                  border: Color.fromARGB(255, 235, 92, 30),
                ),
              ),
            ),
          ),
        ));

    await Stripe.instance.presentPaymentSheet();

    var finalpaymentIntent = await Stripe.instance
        .retrievePaymentIntent(paymentIntent['client_secret']);
    print(finalpaymentIntent);
    return finalpaymentIntent;
  } catch (e) {
    if (e is StripeException) {
      print("Stripe error $e");
    }
    print("Stripe error $e");
    return null;
  }
}

Future<Map<String, dynamic>> _attachPaymentMethodCustomer(
    String paymentMethodId, String customerId) async {
  final String url =
      'https://api.stripe.com/v1/payment_methods/$paymentMethodId/attach';

  var response = await dio.post(url,
      options: Options(
        headers: headers,
      ),
      data: {
        'customer': customerId,
      });
  if (response.statusCode == 200) {
    return response.data;
  } else {
    print(json.decode(response.data));
    throw 'Failed to update Customer.';
  }
}

Future<Map<String, dynamic>> _updateCustomer(
    String paymentMethodId, String customerId) async {
  final String url = 'https://api.stripe.com/v1/customers/$customerId';

  var response = await dio.post(url,
      options: Options(
        headers: headers,
      ),
      data: {
        'invoice_settings[default_payment_method]': paymentMethodId,
      });
  if (response.statusCode == 200) {
    return response.data;
  } else {
    print(json.decode(response.data));
    throw 'Failed to update Customer.';
  }
}

Future<void> subscriptions() async {
  init();
  const customerId = 'cus_NrBhLevU8v6ZLo';
  final cardData = await _getAllCardsDetails(customerId);
  print('Card Date id ===> ${cardData['data'][0]['id']}');
  final intent = await _deleteCards(customerId,cardData['data'][0]['id']);
  print('Card Date id ===> ${intent}');
  // _createSubscriptions(customerId,"price_1N2pfPA96WVwXAJrl9WQf7mv","Standarad plan to test ",withFreeTrial: true);

  // final tokenId = await setCardDetail();
  // _getSubscriptionsByCustomer('cus_NrBhLevU8v6ZLo');
  // _updateSubscriptions(
  //     'cus_NpI157FuIKIiJw', 'sub_1N3dVHA96WVwXAJrUaXIsMR7', '');
  //TODO code of creating customer and add the default card for that customer and create subscription
  // final _customer = await _createCustomer();
  // final tokenId = await setCardDetail();
  // final cardData = await _createACard(_customer['id'], tokenId.id);
  // print(cardData);
  // if(tokenId.card != null) {
  //   final intent = await _setupIntent(_customer['id'], tokenId.card?.id ?? "");
  //   print(intent);
  //   _createSubscriptions(_customer['id'],"price_1N41jJA96WVwXAJrp0Q9qHzC","Grocery Soap Daily",withFreeTrial: true);
  // }

  //TODO code of creating payment intent / add card detail attach payment to customer and create subscription (it will directly pay for the subscription)
  // final _paymentIntent = await _createPaymentIntents("cus_NpJGEoFGGTC4Ub", "2499");
  // final finalPaymentIntent  = await _createCreditCard("cus_NpJGEoFGGTC4Ub", _paymentIntent);
  // final paymentId = finalPaymentIntent?.paymentMethodId; //await setCardDetail(); //finalPaymentIntent?.paymentMethodId;
  // await _attachPaymentMethodCustomer(paymentId ?? "","cus_NpJGEoFGGTC4Ub");
  // await _updateCustomer(paymentId ?? "","cus_NpJGEoFGGTC4Ub");
  // final subscriptionData = await _createSubscriptions("cus_NpJGEoFGGTC4Ub", "price_1N2pfsA96WVwXAJrbMe86YTF , "Zudio", withFreeTrial: false);
  // print("Subscription Id : ${subscriptionData['id']}");

  //TODO code of to upgrade / downgrade plan of an subscription
  // final subscriptionPriceId = await _updateSubscriptions("cus_NpJGEoFGGTC4Ub", "sub_1N3ee2A96WVwXAJrM6oAqbAF", "price_1N2pfPA96WVwXAJrl9WQf7mv");
  // _deleteSubscriptionsItem(subscriptionPriceId ?? "");
}

/// this method add a card into the specified user
Future<Map<String, dynamic>> _createACard(
    String customerId, String tokenId) async {
  final String url = 'https://api.stripe.com/v1/customers/$customerId/sources';

  var response = await dio.post(url,
      options: Options(
        headers: headers,
      ),
      data: {"validate": "false", "source": tokenId});
  if (response.statusCode == 200) {
    return response.data;
  } else {
    print(json.decode(response.data));
    throw 'Failed to update Customer.';
  }
}

/// this method set up intent to pay latter
Future<Map<String, dynamic>> _setupIntent(
    String customerId, String cardID) async {
  const String url = 'https://api.stripe.com/v1/setup_intents';

  var response = await dio.post(url,
      options: Options(
        headers: headers,
      ),
      data: {
        'payment_method_types[]': 'card',
        'payment_method': cardID,
        'confirm': "true",
        'customer': customerId
      });
  if (response.statusCode == 200) {
    return response.data;
  } else {
    print(json.decode(response.data));
    throw 'Failed to update Customer.';
  }
}

Future<TokenData> setCardDetail() async {

  final cardDetail = CardDetails(
    number: "4242424242424242",
    expirationMonth: 12,
    expirationYear: 28,
    cvc: "100",
  );

  Stripe.instance.dangerouslyUpdateCardDetails(cardDetail);

  final tokenData = await Stripe.instance
      .createToken(const CreateTokenParams.card(params: CardTokenParams()));
  print("tokendata ===> ${tokenData}");
  return tokenData;
}

/// This method retrieve all invoices of the customer.
Future<Map<String, dynamic>> _getInvoices(String customerId) async {
  const String url = 'https://api.stripe.com/v1/invoices';

  var response = await dio.get(url,
      options: Options(
        headers: headers,
      ),
      data: {'customer': customerId});
  if (response.statusCode == 200) {
    print(response.data);
    print(response.data['data'][0]['invoice_pdf']);
    return response.data;
  } else {
    print(json.decode(response.data));
    throw 'Failed to register as a subscriber.';
  }
}

Future<Map<String, dynamic>> _getAllCardsDetails(String customerId) async {
  String url = 'https://api.stripe.com/v1/customers/$customerId/sources';

  var response = await dio.get(url,
      options: Options(
        headers: headers,
      ));
  if (response.statusCode == 200) {
    print(response.data);
    print(response.data['data'][0]['last4']);
    return response.data;
  } else {
    print(json.decode(response.data));
    throw 'Failed to register as a subscriber.';
  }
}

Future<Map<String, dynamic>> _deleteCards(String customerId, String cardId) async {
  String url = 'https://api.stripe.com/v1/customers/$customerId/sources/$cardId';

  var response = await dio.delete(url,
      options: Options(
        headers: headers,
      ));
  if (response.statusCode == 200) {
    print(response.data);
    return response.data;
  } else {
    print(json.decode(response.data));
    throw 'Failed to register as a subscriber.';
  }
}