import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/domain/entities/error/common_errors.dart';
import 'package:nextry_dev/domain/entities/product/delete_product_category_param.dart';
import 'package:nextry_dev/domain/entities/product/delete_product_category_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';

class DeleteProductCategoryGateway
    implements
        ReadGateWay<DeleteProductCategoryResponseEntity,
            DeleteProductCategoryParam> {
  @override
  Future<DeleteProductCategoryResponseEntity> read(
      DeleteProductCategoryParam data) async {
    try {
      await FirebaseFirestore.instance
          .collection(GateWayConstants.TABLE_BUSINESSES)
          .doc(data.businessId)
          .collection(GateWayConstants.TABLE_CATEGORY)
          .doc(data.categoryDocId)
          .delete();
      return DeleteProductCategoryResponseEntity(isSuccess: true);
    } catch (e) {
      print(e);
      return DeleteProductCategoryResponseEntity(
          commonErrors: CommonErrors.fromJson({}));
    }
  }

  @override
  void unsubscribe() {}
}
