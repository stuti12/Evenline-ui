import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/domain/entities/error/common_errors.dart';
import 'package:nextry_dev/domain/entities/product/fetch_relative_product_param.dart';
import 'package:nextry_dev/domain/entities/product/fetch_relative_product_response_entity.dart';
import 'package:nextry_dev/domain/entities/product/product_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';

class FetchRelativeProductGateWay
    implements
        ReadGateWay<FetchRelativeProductResponseEntity,
            FetchRelativeProductParam> {
  @override
  Future<FetchRelativeProductResponseEntity> read(
      FetchRelativeProductParam param) async {
    try {
      var snapshot = await FirebaseFirestore.instance
          .collection(GateWayConstants.TABLE_BUSINESSES)
          .doc(param.businessId)
          .collection(GateWayConstants.TABLE_PRODUCT)
          .where(GateWayConstants.FIELD_CATEGORY_ID,
              isEqualTo: param.categoryDocId)
          .get();

      final entity = FetchRelativeProductResponseEntity();
      entity.productList = [];
      for (var element in snapshot.docs) {
        if (element.exists && element.id != param.productDocId) {
          var data = element.data();
          var productEntity =
              ProductEntity.fromJson(data, element.id, param.businessId);
          entity.productList?.add(productEntity);
        }
      }

      return entity;
    } catch (e) {
      print(e);
      return FetchRelativeProductResponseEntity(
          commonErrors: CommonErrors.fromJson({}));
    }
  }

  @override
  void unsubscribe() {}
}
