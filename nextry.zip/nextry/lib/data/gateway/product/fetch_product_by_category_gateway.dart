import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/domain/entities/error/common_errors.dart';
import 'package:nextry_dev/domain/entities/product/fetch_product_by_category_param.dart';
import 'package:nextry_dev/domain/entities/product/fetch_product_by_category_response_entity.dart';
import 'package:nextry_dev/domain/entities/product/product_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';

class FetchProductByCategoryGateWay
    implements
        ReadGateWay<FetchProductByCategoryResponseEntity,
            FetchProductByCategoryParam> {
  StreamSubscription<QuerySnapshot<Map<String, dynamic>>>? streamSubscription;

  @override
  Future<FetchProductByCategoryResponseEntity> read(
      FetchProductByCategoryParam param) async {
    try {
      final productRef = FirebaseFirestore.instance
          .collection(GateWayConstants.TABLE_BUSINESSES)
          .doc(param.businessId)
          .collection(GateWayConstants.TABLE_PRODUCT)
          .where(GateWayConstants.FIELD_CATEGORY_ID,
              isEqualTo: param.categoryDocId);

      final snapshot = await productRef.get();

      streamSubscription?.cancel();
      streamSubscription = productRef.snapshots().listen((event) async {
        if (param.function != null) {
          param.function!(_parseProductByCategory(event, param.businessId));
        }
      });

      final entity = FetchProductByCategoryResponseEntity();
      entity.productList = _parseProductByCategory(snapshot, param.businessId);
      return entity;
    } catch (e) {
      print(e);
      return FetchProductByCategoryResponseEntity(
          commonErrors: CommonErrors.fromJson({}));
    }
  }

  List<ProductEntity> _parseProductByCategory(
      QuerySnapshot<Map<String, dynamic>> snapshot, String businessId) {
    List<ProductEntity>? productList = [];
    for (var element in snapshot.docs) {
      if (element.exists) {
        var data = element.data();
        var productEntity =
            ProductEntity.fromJson(data, element.id, businessId);
        productList.add(productEntity);
      }
    }
    return productList;
  }

  @override
  void unsubscribe() {
    streamSubscription?.cancel();
  }
}
