import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/domain/entities/error/common_errors.dart';
import 'package:nextry_dev/domain/entities/product/delete_product_discount_param.dart';
import 'package:nextry_dev/domain/entities/product/delete_product_discount_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';

class DeleteProductDiscountGateway
    implements
        ReadGateWay<DeleteProductDiscountResponseEntity,
            DeleteProductDiscountParam> {
  @override
  Future<DeleteProductDiscountResponseEntity> read(
      DeleteProductDiscountParam data) async {
    try {
      final param = <String, dynamic>{};
      param[GateWayConstants.FIELD_PRODUCT_DISCOUNT] = null;

      await FirebaseFirestore.instance
          .collection(GateWayConstants.TABLE_BUSINESSES)
          .doc(data.businessId)
          .collection(GateWayConstants.TABLE_PRODUCT)
          .doc(data.productId)
          .set(param, SetOptions(merge: true));

      var snapshot = await FirebaseFirestore.instance
          .collection(GateWayConstants.TABLE_BUSINESSES)
          .doc(data.businessId)
          .collection(GateWayConstants.TABLE_PRODUCT)
          .doc(data.productId)
          .collection(GateWayConstants.TABLE_UNAVAILABLE_DATES)
          .where(GateWayConstants.FIELD_UNAVAILABLE_DATES_START_DATE,
              isEqualTo: data.startDate)
          .where(GateWayConstants.FIELD_UNAVAILABLE_DATES_END_DATE,
              isEqualTo: data.endDate)
          .get();

      for (var element in snapshot.docs) {
        if (element.exists) {
          await FirebaseFirestore.instance
              .collection(GateWayConstants.TABLE_BUSINESSES)
              .doc(data.businessId)
              .collection(GateWayConstants.TABLE_PRODUCT)
              .doc(data.productId)
              .collection(GateWayConstants.TABLE_UNAVAILABLE_DATES)
              .doc(element.id)
              .delete();
        }
      }

      final standardAdsRef = await FirebaseFirestore.instance
          .collection(GateWayConstants.TABLE_ACTIVE_STANDARD_AD)
          .where(GateWayConstants.FIELD_BUSINESS_ID, isEqualTo: data.businessId)
          .where(GateWayConstants.FIELD_PRODUCT_ID, isEqualTo: data.productId)
          .get();

      for (var element in standardAdsRef.docs) {
        if (element.exists) {
          await FirebaseFirestore.instance
              .collection(GateWayConstants.TABLE_ACTIVE_STANDARD_AD)
              .doc(element.id)
              .delete();
        }
      }

      return DeleteProductDiscountResponseEntity(isSuccess: true);
    } catch (e) {
      print(e);
      return DeleteProductDiscountResponseEntity(
          isSuccess: false, commonErrors: CommonErrors.fromJson({}));
    }
  }

  @override
  void unsubscribe() {}
}
