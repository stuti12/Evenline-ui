import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/data/gateway/common/upload_file_helper.dart';
import 'package:nextry_dev/domain/entities/error/common_errors.dart';
import 'package:nextry_dev/domain/entities/product/add_update_product_param.dart';
import 'package:nextry_dev/domain/entities/product/add_update_product_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/presentation/common/utils/app_constants.dart';

class AddUpdateProductGateway
    implements
        ReadGateWay<AddUpdateProductResponseEntity, AddUpdateProductParam> {
  @override
  Future<AddUpdateProductResponseEntity> read(
      AddUpdateProductParam data) async {
    try {
      if (data.productEntity.medias != null &&
          data.productEntity.medias!.isNotEmpty) {
        for (var i = 0; i < data.productEntity.medias!.length; i++) {
          String mediaFile = data.productEntity.medias![i];
          if (mediaFile.isNotEmpty &&
              !mediaFile.startsWith(AppConstants.SERVER_FILE)) {
            final serverURL =
                await UploadFileHelper().uploadFileToFireStore(mediaFile);
            data.productEntity.medias![i] = serverURL;
          }
          _updateCount(data.onUpdate,
              (((i + 1) / data.productEntity.medias!.length) * 100).toInt());
        }
      } else {
        _updateCount(data.onUpdate, 100);
      }

      if (data.productEntity.id != null && data.productEntity.id!.isNotEmpty) {
        await FirebaseFirestore.instance
            .collection(GateWayConstants.TABLE_BUSINESSES)
            .doc(data.businessId)
            .collection(GateWayConstants.TABLE_PRODUCT)
            .doc(data.productEntity.id)
            .set(data.productEntity.toJson());
      } else {
        await FirebaseFirestore.instance
            .collection(GateWayConstants.TABLE_BUSINESSES)
            .doc(data.businessId)
            .collection(GateWayConstants.TABLE_PRODUCT)
            .add(data.productEntity.toJson());
      }

      return AddUpdateProductResponseEntity(isSuccess: true);
    } catch (e) {
      print(e);
      return AddUpdateProductResponseEntity(
          isSuccess: false, commonErrors: CommonErrors.fromJson({}));
    }
  }

  _updateCount(Function? onUpdate, int progress) {
    if (onUpdate != null) {
      onUpdate(progress);
    }
  }

  @override
  void unsubscribe() {}
}
