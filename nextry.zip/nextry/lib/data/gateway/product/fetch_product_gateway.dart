import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/domain/entities/error/common_errors.dart';
import 'package:nextry_dev/domain/entities/product/fetch_product_param.dart';
import 'package:nextry_dev/domain/entities/product/fetch_product_response_entity.dart';
import 'package:nextry_dev/domain/entities/product/product_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';

class FetchProductGateWay
    implements ReadGateWay<FetchProductResponseEntity, FetchProductParam> {
  StreamSubscription<DocumentSnapshot<Map<String, dynamic>>>?
      streamSubscription;

  @override
  Future<FetchProductResponseEntity> read(FetchProductParam param) async {
    try {
      final productRef = FirebaseFirestore.instance
          .collection(GateWayConstants.TABLE_BUSINESSES)
          .doc(param.businessId)
          .collection(GateWayConstants.TABLE_PRODUCT)
          .doc(param.productId);

      streamSubscription?.cancel();
      streamSubscription = productRef.snapshots().listen((event) async {
        if (param.function != null) {
          param.function!(_parseProductData(event, param.businessId));
        }
      });

      var snapshot = await productRef.get();

      final entity = FetchProductResponseEntity();
      entity.productEntity = _parseProductData(snapshot, param.businessId);

      return entity;
    } catch (e) {
      print(e);
      return FetchProductResponseEntity(
          commonErrors: CommonErrors.fromJson({}));
    }
  }

  @override
  void unsubscribe() {
    streamSubscription?.cancel();
  }

  ProductEntity? _parseProductData(
      DocumentSnapshot<Map<String, dynamic>> snapshot, String businessId) {
    if (snapshot.exists) {
      var data = snapshot.data();
      if (data != null) {
        return ProductEntity.fromJson(data, snapshot.id, businessId);
      }
    }
    return null;
  }
}
