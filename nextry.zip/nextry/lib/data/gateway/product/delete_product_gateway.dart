import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/domain/entities/error/common_errors.dart';
import 'package:nextry_dev/domain/entities/product/add_update_product_param.dart';
import 'package:nextry_dev/domain/entities/product/add_update_product_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';

class DeleteProductGateway
    implements
        ReadGateWay<AddUpdateProductResponseEntity, AddUpdateProductParam> {
  @override
  Future<AddUpdateProductResponseEntity> read(
      AddUpdateProductParam data) async {
    try {
      await FirebaseFirestore.instance
          .collection(GateWayConstants.TABLE_BUSINESSES)
          .doc(data.businessId)
          .collection(GateWayConstants.TABLE_PRODUCT)
          .doc(data.productEntity.id)
          .delete();

      return AddUpdateProductResponseEntity(isSuccess: true);
    } catch (e) {
      print(e);
      return AddUpdateProductResponseEntity(
          isSuccess: false, commonErrors: CommonErrors.fromJson({}));
    }
  }

  @override
  void unsubscribe() {}
}
