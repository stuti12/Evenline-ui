import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/domain/entities/error/common_errors.dart';
import 'package:nextry_dev/domain/entities/product/add_product_discount_param.dart';
import 'package:nextry_dev/domain/entities/product/add_product_discount_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';

class AddProductDiscountGateway
    implements
        ReadGateWay<AddProductDiscountResponseEntity, AddProductDiscountParam> {
  @override
  Future<AddProductDiscountResponseEntity> read(
      AddProductDiscountParam data) async {
    try {
      final discountParam = <String, dynamic>{};
      discountParam[GateWayConstants.FIELD_PRODUCT_DISCOUNT_PRICE] =
          data.discountPrice;
      discountParam[GateWayConstants.FIELD_PRODUCT_DISCOUNT_START_DATE] =
          data.startDate;
      discountParam[GateWayConstants.FIELD_PRODUCT_DISCOUNT_END_DATE] =
          data.endDate;

      final param = <String, dynamic>{};
      param[GateWayConstants.FIELD_PRODUCT_DISCOUNT] = discountParam;

      await FirebaseFirestore.instance
          .collection(GateWayConstants.TABLE_BUSINESSES)
          .doc(data.businessId)
          .collection(GateWayConstants.TABLE_PRODUCT)
          .doc(data.productId)
          .set(param, SetOptions(merge: true));

      final unavailableDateParam = <String, dynamic>{};
      unavailableDateParam[
          GateWayConstants.FIELD_UNAVAILABLE_DATES_START_DATE] = data.startDate;
      unavailableDateParam[GateWayConstants.FIELD_UNAVAILABLE_DATES_END_DATE] =
          data.endDate;

      await FirebaseFirestore.instance
          .collection(GateWayConstants.TABLE_BUSINESSES)
          .doc(data.businessId)
          .collection(GateWayConstants.TABLE_PRODUCT)
          .doc(data.productId)
          .collection(GateWayConstants.TABLE_UNAVAILABLE_DATES)
          .add(unavailableDateParam);

      return AddProductDiscountResponseEntity(isSuccess: true);
    } catch (e) {
      print(e);
      return AddProductDiscountResponseEntity(
          isSuccess: false, commonErrors: CommonErrors.fromJson({}));
    }
  }

  @override
  void unsubscribe() {}
}
