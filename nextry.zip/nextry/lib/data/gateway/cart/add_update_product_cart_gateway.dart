import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/domain/entities/cart/add_update_cart_response_entity.dart';
import 'package:nextry_dev/domain/entities/cart/cart_entity.dart';
import 'package:nextry_dev/domain/entities/error/common_errors.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';

class AddUpdateProductCartGateway
    implements ReadGateWay<AddUpdateCartResponseEntity, CartEntity> {
  @override
  Future<AddUpdateCartResponseEntity> read(CartEntity data) async {
    try {
      final profileDocId = FirebaseAuth.instance.currentUser?.uid;
      String refDocId = '';
      if (data.cartDocId != null && data.cartDocId!.isNotEmpty) {
        refDocId = data.cartDocId!;
        await FirebaseFirestore.instance
            .collection(GateWayConstants.TABLE_USERS)
            .doc(profileDocId)
            .collection(GateWayConstants.TABLE_CART)
            .doc(data.cartDocId)
            .set(data.toJson(), SetOptions(merge: true));
      } else {
        final refId = await FirebaseFirestore.instance
            .collection(GateWayConstants.TABLE_USERS)
            .doc(profileDocId)
            .collection(GateWayConstants.TABLE_CART)
            .add(data.toJson());
        refDocId = refId.id;
      }

      return AddUpdateCartResponseEntity(isSuccess: true, refDocId: refDocId);
    } catch (e) {
      print(e);
      return AddUpdateCartResponseEntity(
          commonErrors: CommonErrors.fromJson({}));
    }
  }

  @override
  void unsubscribe() {}
}
