import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/domain/entities/cart/delete_cart_param.dart';
import 'package:nextry_dev/domain/entities/cart/delete_cart_response_entity.dart';
import 'package:nextry_dev/domain/entities/error/common_errors.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';

class DeleteCartByIdGateway
    implements ReadGateWay<DeleteCartResponseEntity, DeleteCartParam> {
  @override
  Future<DeleteCartResponseEntity> read(DeleteCartParam data) async {
    try {
      final userId = FirebaseAuth.instance.currentUser?.uid;

      await FirebaseFirestore.instance
          .collection(GateWayConstants.TABLE_USERS)
          .doc(userId)
          .collection(GateWayConstants.TABLE_CART)
          .doc(data.cartId)
          .delete();

      return DeleteCartResponseEntity(isSuccess: true);
    } catch (e) {
      print(e);
      return DeleteCartResponseEntity(commonErrors: CommonErrors.fromJson({}));
    }
  }

  @override
  void unsubscribe() {}
}
