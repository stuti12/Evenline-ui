import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/domain/entities/business/business_entity.dart';
import 'package:nextry_dev/domain/entities/cart/cart_entity.dart';
import 'package:nextry_dev/domain/entities/cart/fetch_cart_data_request_param.dart';
import 'package:nextry_dev/domain/entities/cart/fetch_cart_data_response_entity.dart';
import 'package:nextry_dev/domain/entities/error/common_errors.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';

class FetchCartDataGateWay
    implements
        ReadGateWay<FetchCartDataResponseEntity, FetchCartDataRequestParam> {
  StreamSubscription<QuerySnapshot<Map<String, dynamic>>>? streamSubscription;

  @override
  Future<FetchCartDataResponseEntity> read(
      FetchCartDataRequestParam param) async {
    try {
      final userId = FirebaseAuth.instance.currentUser?.uid;

      final cartRef = FirebaseFirestore.instance
          .collection(GateWayConstants.TABLE_USERS)
          .doc(userId)
          .collection(GateWayConstants.TABLE_CART);

      streamSubscription?.cancel();
      streamSubscription = cartRef.snapshots().listen((event) async {
        List<CartEntity> cartEntities = [];
        await Future.wait(event.docs.map((element) async {
          if (element.exists) {
            var data = element.data();
            final cartEntity = CartEntity.fromJson(data, element.id);
            cartEntity.businessEntity =
                await _fetchBusinessData(cartEntity.businessId);
            cartEntities.add(cartEntity);
          }
        }));
        if (param.function != null) param.function!(cartEntities);
      });

      return FetchCartDataResponseEntity(cartEntities: [], error: null);
    } catch (e) {
      print(e);
      return FetchCartDataResponseEntity(error: CommonErrors.fromJson({}));
    }
  }

  Future<BusinessEntity?> _fetchBusinessData(String? businessId) async {
    var snapshot = await FirebaseFirestore.instance
        .collection(GateWayConstants.TABLE_BUSINESSES)
        .doc(businessId)
        .get();
    if (snapshot.exists) {
      var data = snapshot.data();
      if (data != null) {
        return BusinessEntity.fromJSON(data, businessId ?? '');
      }
    }
    return null;
  }

  @override
  void unsubscribe() {
    streamSubscription?.cancel();
  }
}
