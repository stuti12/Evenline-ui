import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/domain/entities/business/business_entity.dart';
import 'package:nextry_dev/domain/entities/cart/cart_entity.dart';
import 'package:nextry_dev/domain/entities/cart/fetch_cart_data_by_businessId_response_entity.dart';
import 'package:nextry_dev/domain/entities/cart/fetch_cart_param.dart';
import 'package:nextry_dev/domain/entities/error/common_errors.dart';
import 'package:nextry_dev/domain/entities/product/product_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';

class FetchCartDataByBusinessIdDataGateWay
    implements
        ReadGateWay<FetchCartDataByBusinessIdResponseEntity, FetchCartParam> {
  @override
  Future<FetchCartDataByBusinessIdResponseEntity> read(
      FetchCartParam param) async {
    try {
      final userId = FirebaseAuth.instance.currentUser?.uid;

      CartEntity cartEntity = CartEntity();
      final snapShot = await FirebaseFirestore.instance
          .collection(GateWayConstants.TABLE_USERS)
          .doc(userId)
          .collection(GateWayConstants.TABLE_CART)
          .doc(param.cartDocId)
          .get();
      if (snapShot.exists) {
        var data = snapShot.data();
        if (data != null) {
          cartEntity = CartEntity.fromJson(data, snapShot.id);
          cartEntity.businessEntity =
              await _fetchBusinessData(cartEntity.businessId);
        }
      }
      print("==== cartentity ${cartEntity.cartDocId}");
      if (cartEntity.products != null && cartEntity.products!.isNotEmpty) {
        await Future.wait(cartEntity.products!.map((element) async {
          element.productEntity = await _fetchProductData(
              businessId: cartEntity.businessId, productId: element.productId);
        }));
      }
      return FetchCartDataByBusinessIdResponseEntity(
          cartEntity: cartEntity, error: null);
    } catch (e) {
      print(e);
      return FetchCartDataByBusinessIdResponseEntity(
          error: CommonErrors.fromJson({}));
    }
  }

  @override
  void unsubscribe() {}

  Future<BusinessEntity?> _fetchBusinessData(String? businessId) async {
    var snapshot = await FirebaseFirestore.instance
        .collection(GateWayConstants.TABLE_BUSINESSES)
        .doc(businessId)
        .get();
    if (snapshot.exists) {
      var data = snapshot.data();
      if (data != null) {
        return BusinessEntity.fromJSON(data, businessId ?? '');
      }
    }
    return null;
  }

  Future<ProductEntity?> _fetchProductData(
      {String? businessId, String? productId}) async {
    var snapshot = await FirebaseFirestore.instance
        .collection(GateWayConstants.TABLE_BUSINESSES)
        .doc(businessId)
        .collection(GateWayConstants.TABLE_PRODUCT)
        .doc(productId)
        .get();
    if (snapshot.exists) {
      var data = snapshot.data();
      if (data != null) {
        return ProductEntity.fromJson(data, snapshot.id, businessId ?? '');
      }
    }
    return null;
  }
}
