import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/data/gateway/common/upload_file_helper.dart';
import 'package:nextry_dev/domain/entities/askme/add_ask_me_response_entity.dart';
import 'package:nextry_dev/domain/entities/askme/ask_me_entity.dart';
import 'package:nextry_dev/domain/entities/error/common_errors.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/presentation/common/utils/app_constants.dart';

class AddAskMeGateway
    implements ReadGateWay<AddAskMeResponseEntity, AskMeEntity> {
  @override
  Future<AddAskMeResponseEntity> read(AskMeEntity data) async {
    try {
      final userId = FirebaseAuth.instance.currentUser?.uid;
      if (data.attachments != null && data.attachments!.isNotEmpty) {
        for (var i = 0; i < data.attachments!.length; i++) {
          String mediaFile = data.attachments![i];
          if (mediaFile.isNotEmpty &&
              !mediaFile.startsWith(AppConstants.SERVER_FILE)) {
            final serverURL = await UploadFileHelper()
                .uploadFileToFireStoreForAskMe(mediaFile);
            data.attachments![i] = serverURL;
          }
          _updateCount(data.onUpdate,
              (((i + 1) / data.attachments!.length) * 100).toInt());
        }
      } else {
        _updateCount(data.onUpdate, 100);
      }

      await FirebaseFirestore.instance
          .collection(GateWayConstants.TABLE_ASK_ME)
          .add(data.toJson(userId));

      return AddAskMeResponseEntity(isSuccess: true);
    } catch (e) {
      print(e);
      return AddAskMeResponseEntity(
          isSuccess: false, commonErrors: CommonErrors.fromJson({}));
    }
  }

  _updateCount(Function? onUpdate, int progress) {
    if (onUpdate != null) {
      onUpdate(progress);
    }
  }

  @override
  void unsubscribe() {}
}
