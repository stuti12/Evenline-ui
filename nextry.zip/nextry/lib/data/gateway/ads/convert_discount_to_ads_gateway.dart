import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:geoflutterfire2/geoflutterfire2.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/data/gateway/common/upload_file_helper.dart';
import 'package:nextry_dev/domain/entities/ads/ads_entity.dart';
import 'package:nextry_dev/domain/entities/error/common_errors.dart';
import 'package:nextry_dev/domain/entities/product/delete_product_discount_param.dart';
import 'package:nextry_dev/domain/entities/product/delete_product_discount_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/presentation/common/utils/app_constants.dart';

class ConvertDiscountToAdsGateWay
    implements
        ReadGateWay<DeleteProductDiscountResponseEntity,
            DeleteProductDiscountParam> {
  @override
  Future<DeleteProductDiscountResponseEntity> read(
      DeleteProductDiscountParam data) async {
    try {
      final param = <String, dynamic>{};
      param[GateWayConstants.FIELD_PRODUCT_DISCOUNT] = null;

      await FirebaseFirestore.instance
          .collection(GateWayConstants.TABLE_BUSINESSES)
          .doc(data.businessId)
          .collection(GateWayConstants.TABLE_PRODUCT)
          .doc(data.productId)
          .set(param, SetOptions(merge: true));

      AdsEntity adsEntity = AdsEntity(
          startDate: data.startDate,
          endDate: data.endDate,
          productPrice: data.discountPrice);

      if (data.imageUrl != null && data.imageUrl!.isNotEmpty) {
        if (data.imageUrl!.startsWith(AppConstants.SERVER_FILE)) {
          adsEntity.image = data.imageUrl;
        } else {
          adsEntity.image = await UploadFileHelper()
              .uploadFileToFireStore(data.imageUrl ?? '');
        }
      }

      var adRef = await FirebaseFirestore.instance
          .collection(GateWayConstants.TABLE_BUSINESSES)
          .doc(data.businessId)
          .collection(GateWayConstants.TABLE_PRODUCT)
          .doc(data.productId)
          .collection(GateWayConstants.TABLE_ADS)
          .add(adsEntity.toJson());

      final unavailableDateParam = <String, dynamic>{};
      unavailableDateParam[GateWayConstants
          .FIELD_UNAVAILABLE_DATES_START_DATE] = adsEntity.startDate;
      unavailableDateParam[GateWayConstants.FIELD_UNAVAILABLE_DATES_END_DATE] =
          adsEntity.endDate;

      await FirebaseFirestore.instance
          .collection(GateWayConstants.TABLE_BUSINESSES)
          .doc(data.businessId)
          .collection(GateWayConstants.TABLE_PRODUCT)
          .doc(data.productId)
          .collection(GateWayConstants.TABLE_UNAVAILABLE_DATES)
          .add(unavailableDateParam);

      final businessRef = FirebaseFirestore.instance
          .collection(GateWayConstants.TABLE_BUSINESSES)
          .doc(data.businessId);

      businessRef
          .update({GateWayConstants.FIELD_ADS_COUNT: FieldValue.increment(1)});

      Map<String, dynamic> paramData = adsEntity.toJson();
      paramData[GateWayConstants.FIELD_BUSINESS_ID] = data.businessId;
      paramData[GateWayConstants.FIELD_PRODUCT_ID] = data.productId;
      paramData[GateWayConstants.FIELD_STANDARD_AD_ID] = adRef.id;
      paramData[GateWayConstants.FIELD_CATEGORY_ID] = data.categoryId;
      paramData[GateWayConstants.FIELD_LOCATION] = GeoFlutterFire()
          .point(
          latitude: data.location?.latitude ?? 0.0,
          longitude: data.location?.longitude ?? 0.0)
          .data;
      if (data.businessName != null && data.businessName!.isNotEmpty) {
        paramData[GateWayConstants.FIELD_BUSINESS_NAMES] = data.businessName ?? '';
      }
      await FirebaseFirestore.instance
          .collection(GateWayConstants.TABLE_CLOUD_STANDARD_ADS)
          .add(paramData);

      return DeleteProductDiscountResponseEntity(isSuccess: true);
    } catch (e) {
      print(e);
      return DeleteProductDiscountResponseEntity(
          isSuccess: false, commonErrors: CommonErrors.fromJson({}));
    }
  }

  @override
  void unsubscribe() {}
}
