import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/domain/entities/ads/add_update_ads_response_entity.dart';
import 'package:nextry_dev/domain/entities/ads/fetch_ads_param.dart';
import 'package:nextry_dev/domain/entities/error/common_errors.dart';
import 'package:nextry_dev/domain/entities/product/product_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';

class RemoveActiveAdsGateWay
    implements ReadGateWay<AddUpdateAdsResponseEntity, FetchAdsParam> {
  @override
  Future<AddUpdateAdsResponseEntity> read(FetchAdsParam data) async {
    try {
      final param = <String, dynamic>{};
      param[GateWayConstants.FIELD_PRODUCT_DISCOUNT] = null;

      await FirebaseFirestore.instance
          .collection(GateWayConstants.TABLE_BUSINESSES)
          .doc(data.businessId)
          .collection(GateWayConstants.TABLE_PRODUCT)
          .doc(data.productId)
          .set(param, SetOptions(merge: true));

      await FirebaseFirestore.instance
          .collection(GateWayConstants.TABLE_BUSINESSES)
          .doc(data.businessId)
          .collection(GateWayConstants.TABLE_PRODUCT)
          .doc(data.productId)
          .collection(GateWayConstants.TABLE_ADS)
          .doc(data.adsEntity?.adId)
          .delete();

      await FirebaseFirestore.instance
          .collection(GateWayConstants.TABLE_ACTIVE_STANDARD_AD)
          .doc(data.adsEntity?.docId)
          .delete();

      var snapshot = await FirebaseFirestore.instance
          .collection(GateWayConstants.TABLE_BUSINESSES)
          .doc(data.businessId)
          .collection(GateWayConstants.TABLE_PRODUCT)
          .doc(data.productId)
          .collection(GateWayConstants.TABLE_UNAVAILABLE_DATES)
          .where(GateWayConstants.FIELD_UNAVAILABLE_DATES_START_DATE,
              isEqualTo: data.adsEntity?.startDate)
          .where(GateWayConstants.FIELD_UNAVAILABLE_DATES_END_DATE,
              isEqualTo: data.adsEntity?.endDate)
          .get();

      for (var element in snapshot.docs) {
        if (element.exists) {
          await FirebaseFirestore.instance
              .collection(GateWayConstants.TABLE_BUSINESSES)
              .doc(data.businessId)
              .collection(GateWayConstants.TABLE_PRODUCT)
              .doc(data.productId)
              .collection(GateWayConstants.TABLE_UNAVAILABLE_DATES)
              .doc(element.id)
              .delete();
        }
      }

      return AddUpdateAdsResponseEntity(isSuccess: true);
    } catch (e) {
      print(e);
      return AddUpdateAdsResponseEntity(
          commonErrors: CommonErrors.fromJson({}));
    }
  }

  @override
  void unsubscribe() {}

  Future<ProductEntity?> _fetchProductData(
      {String? businessId, String? productId}) async {
    var snapshot = await FirebaseFirestore.instance
        .collection(GateWayConstants.TABLE_BUSINESSES)
        .doc(businessId)
        .collection(GateWayConstants.TABLE_PRODUCT)
        .doc(productId)
        .get();
    if (snapshot.exists) {
      var data = snapshot.data();
      if (data != null) {
        return ProductEntity.fromJson(data, snapshot.id, businessId ?? '');
      }
    }
    return null;
  }
}
