import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/domain/entities/ads/ads_entity.dart';
import 'package:nextry_dev/domain/entities/ads/fetch_ads_param.dart';
import 'package:nextry_dev/domain/entities/ads/fetch_all_ads_response_entity.dart';
import 'package:nextry_dev/domain/entities/business/business_entity.dart';
import 'package:nextry_dev/domain/entities/error/common_errors.dart';
import 'package:nextry_dev/domain/entities/product/product_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';

class FetchActiveAdsGateWay
    implements ReadGateWay<FetchAllAdsResponseEntity, FetchAdsParam> {
  @override
  Future<FetchAllAdsResponseEntity> read(FetchAdsParam data) async {
    try {
      final snapshot = await FirebaseFirestore.instance
          .collection(GateWayConstants.TABLE_ACTIVE_STANDARD_AD)
          .where(GateWayConstants.FIELD_BUSINESS_ID, isEqualTo: data.businessId)
          .get();

      List<AdsEntity> adsList = [];
      for (var element in snapshot.docs) {
        if (element.exists) {
          var data = element.data();
          adsList.add(AdsEntity.fromJson(data, element.id));
        }
      }

      if (adsList.isNotEmpty) {
        await Future.wait(adsList.map((element) async {
          element.productEntity = await _fetchProductData(
              businessId: data.businessId, productId: element.productId);
        }));

        final businessEntity = await _fetchBusinessData(data.businessId);

        for (var item in adsList) {
          item.businessEntity = businessEntity;
        }
      }

      return FetchAllAdsResponseEntity(adsList: adsList);
    } catch (e) {
      print(e);
      return FetchAllAdsResponseEntity(commonErrors: CommonErrors.fromJson({}));
    }
  }

  @override
  void unsubscribe() {}

  Future<ProductEntity?> _fetchProductData(
      {String? businessId, String? productId}) async {
    var snapshot = await FirebaseFirestore.instance
        .collection(GateWayConstants.TABLE_BUSINESSES)
        .doc(businessId)
        .collection(GateWayConstants.TABLE_PRODUCT)
        .doc(productId)
        .get();
    if (snapshot.exists) {
      var data = snapshot.data();
      if (data != null) {
        return ProductEntity.fromJson(data, snapshot.id, businessId ?? '');
      }
    }
    return null;
  }

  Future<BusinessEntity?> _fetchBusinessData(String? businessId) async {
    var snapshot = await FirebaseFirestore.instance
        .collection(GateWayConstants.TABLE_BUSINESSES)
        .doc(businessId)
        .get();
    if (snapshot.exists) {
      var data = snapshot.data();
      if (data != null) {
        return BusinessEntity.fromJSON(data, businessId ?? '');
      }
    }
    return null;
  }
}
