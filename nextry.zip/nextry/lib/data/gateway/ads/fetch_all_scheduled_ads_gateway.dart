import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/domain/entities/ads/ads_entity.dart';
import 'package:nextry_dev/domain/entities/ads/fetch_ads_param.dart';
import 'package:nextry_dev/domain/entities/ads/fetch_all_ads_response_entity.dart';
import 'package:nextry_dev/domain/entities/error/common_errors.dart';
import 'package:nextry_dev/domain/entities/product/product_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';

class FetchAllScheduledAdsGateWay
    implements ReadGateWay<FetchAllAdsResponseEntity, FetchAdsParam> {
  @override
  Future<FetchAllAdsResponseEntity> read(FetchAdsParam data) async {
    try {
      final snapshot = await FirebaseFirestore.instance
          .collection(GateWayConstants.TABLE_BUSINESSES)
          .doc(data.businessId)
          .collection(GateWayConstants.TABLE_PRODUCT)
          .doc(data.productId)
          .collection(GateWayConstants.TABLE_ADS)
          .where(GateWayConstants.FIELD_PRODUCT_DISCOUNT_START_DATE,
              isGreaterThan: Timestamp.now())
          .orderBy(GateWayConstants.FIELD_PRODUCT_DISCOUNT_START_DATE)
          .get();

      ProductEntity? productEntity = await _fetchProductData(
          businessId: data.businessId, productId: data.productId);

      List<AdsEntity> adsList = [];
      for (var element in snapshot.docs) {
        if (element.exists) {
          var data = element.data();
          AdsEntity adsEntity = AdsEntity.fromJson(data, element.id);
          adsEntity.productEntity = productEntity;
          adsList.add(adsEntity);
        }
      }

      return FetchAllAdsResponseEntity(adsList: adsList);
    } catch (e) {
      print(e);
      return FetchAllAdsResponseEntity(commonErrors: CommonErrors.fromJson({}));
    }
  }

  @override
  void unsubscribe() {}

  Future<ProductEntity?> _fetchProductData(
      {String? businessId, String? productId}) async {
    var snapshot = await FirebaseFirestore.instance
        .collection(GateWayConstants.TABLE_BUSINESSES)
        .doc(businessId)
        .collection(GateWayConstants.TABLE_PRODUCT)
        .doc(productId)
        .get();
    if (snapshot.exists) {
      var data = snapshot.data();
      if (data != null) {
        return ProductEntity.fromJson(data, snapshot.id, businessId ?? '');
      }
    }
    return null;
  }
}
