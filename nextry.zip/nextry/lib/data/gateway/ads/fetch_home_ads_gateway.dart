import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:geoflutterfire2/geoflutterfire2.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/domain/entities/ads/ads_entity.dart';
import 'package:nextry_dev/domain/entities/ads/fetch_home_ads_param.dart';
import 'package:nextry_dev/domain/entities/ads/fetch_home_ads_response_entity.dart';
import 'package:nextry_dev/domain/entities/business/business_entity.dart';
import 'package:nextry_dev/domain/entities/error/common_errors.dart';
import 'package:nextry_dev/domain/entities/product/product_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/presentation/common/utils/app_constants.dart';
import 'package:rxdart/subjects.dart';
import 'package:rxdart/transformers.dart';

class FetchHomeAdsGateWay
    implements ReadGateWay<FetchHomeAdsResponseEntity, FetchHomeAdsParam> {
  StreamSubscription? subscription;

  @override
  Future<FetchHomeAdsResponseEntity> read(FetchHomeAdsParam data) async {
    try {
      var businessAdsRef = FirebaseFirestore.instance
          .collection(GateWayConstants.TABLE_ACTIVE_STANDARD_AD)
          .where(GateWayConstants.FIELD_CATEGORY_ID,
              isEqualTo: data.categoryId);

      if (data.location != null) {
        final radius = BehaviorSubject<double>.seeded(data.radius ??
            AppConstants.DEFAULT_LOCATION_RADIUS); // radius is in KM
        GeoFirePoint center = GeoFlutterFire().point(
            latitude: data.location?.latitude ?? 0.0,
            longitude: data.location?.longitude ?? 0.0);
        Stream<List<DocumentSnapshot>> stream = radius.switchMap((rad) {
          return GeoFlutterFire()
              .collection(collectionRef: businessAdsRef)
              .within(
                center: center,
                radius: rad,
                field: GateWayConstants.FIELD_LOCATION,
                strictMode: true,
              );
        });

        subscription?.cancel();
        subscription =
            stream.listen((List<DocumentSnapshot> documentList) async {
          List<AdsEntity> list = [];
          if (documentList.isNotEmpty) {
            for (int i = 0; i < documentList.length; i++) {
              if (documentList[i].exists) {
                var json = documentList[i].data() as Map<String, dynamic>;
                list.add(AdsEntity.fromJson(json, documentList[i].id));
              }
            }
            if (list.isNotEmpty) {
              await Future.wait(list.map((element) async {
                element.productEntity = await _fetchProductData(
                    businessId: element.businessId,
                    productId: element.productId);
              }));
            }
            Map<String, List<AdsEntity>> adsMapList = {};
            for (var element in list) {
              if (element.productEntity != null) {
                if (adsMapList.containsKey(element.businessName)) {
                  adsMapList[element.businessName]?.add(element);
                } else {
                  adsMapList[element.businessName ?? ''] = [element];
                }
              }
            }
            for (var element in adsMapList.keys) {
              var businessEntity =
                  await _fetchBusinessData(adsMapList[element]?[0].businessId);
              if (businessEntity == null) {
                adsMapList.remove(element);
                break;
              }
              adsMapList[element]?.forEach((element) {
                element.businessEntity = businessEntity;
              });
            }
            data.function(adsMapList);
          }
        });
      }
      return FetchHomeAdsResponseEntity(adsMapList: {});
    } catch (e) {
      print(e);
      return FetchHomeAdsResponseEntity(
          commonErrors: CommonErrors.fromJson({}));
    }
  }

  Future<ProductEntity?> _fetchProductData(
      {String? businessId, String? productId}) async {
    var snapshot = await FirebaseFirestore.instance
        .collection(GateWayConstants.TABLE_BUSINESSES)
        .doc(businessId)
        .collection(GateWayConstants.TABLE_PRODUCT)
        .doc(productId)
        .get();
    if (snapshot.exists) {
      var data = snapshot.data();
      if (data != null) {
        return ProductEntity.fromJson(data, snapshot.id, businessId ?? '');
      }
    }
    return null;
  }

  Future<BusinessEntity?> _fetchBusinessData(String? businessId) async {
    var snapshot = await FirebaseFirestore.instance
        .collection(GateWayConstants.TABLE_BUSINESSES)
        .doc(businessId)
        .get();
    if (snapshot.exists) {
      var data = snapshot.data();
      if (data != null) {
        return BusinessEntity.fromJSON(data, businessId ?? '');
      }
    }
    return null;
  }

  @override
  void unsubscribe() {
    subscription?.cancel();
  }
}
