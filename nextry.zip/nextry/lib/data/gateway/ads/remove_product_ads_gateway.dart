import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/domain/entities/ads/add_update_ads_response_entity.dart';
import 'package:nextry_dev/domain/entities/ads/fetch_ads_param.dart';
import 'package:nextry_dev/domain/entities/error/common_errors.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';

class RemoveProductAdsGateway
    implements ReadGateWay<AddUpdateAdsResponseEntity, FetchAdsParam> {
  @override
  Future<AddUpdateAdsResponseEntity> read(FetchAdsParam data) async {
    try {

      final param = <String, dynamic>{};
      param[GateWayConstants.FIELD_PRODUCT_DISCOUNT] = null;

      await FirebaseFirestore.instance
          .collection(GateWayConstants.TABLE_BUSINESSES)
          .doc(data.businessId)
          .collection(GateWayConstants.TABLE_PRODUCT)
          .doc(data.productId)
          .set(param, SetOptions(merge: true));

      await FirebaseFirestore.instance
          .collection(GateWayConstants.TABLE_BUSINESSES)
          .doc(data.businessId)
          .collection(GateWayConstants.TABLE_PRODUCT)
          .doc(data.productId)
          .collection(GateWayConstants.TABLE_ADS)
          .doc(data.adsEntity?.docId)
          .delete();

      var snapshot = await FirebaseFirestore.instance
          .collection(GateWayConstants.TABLE_BUSINESSES)
          .doc(data.businessId)
          .collection(GateWayConstants.TABLE_PRODUCT)
          .doc(data.productId)
          .collection(GateWayConstants.TABLE_UNAVAILABLE_DATES)
          .where(GateWayConstants.FIELD_UNAVAILABLE_DATES_START_DATE,
              isEqualTo: data.adsEntity?.startDate)
          .where(GateWayConstants.FIELD_UNAVAILABLE_DATES_END_DATE,
              isEqualTo: data.adsEntity?.endDate)
          .get();

      for (var element in snapshot.docs) {
        if (element.exists) {
          await FirebaseFirestore.instance
              .collection(GateWayConstants.TABLE_BUSINESSES)
              .doc(data.businessId)
              .collection(GateWayConstants.TABLE_PRODUCT)
              .doc(data.productId)
              .collection(GateWayConstants.TABLE_UNAVAILABLE_DATES)
              .doc(element.id)
              .delete();
        }
      }

      var adsDealRef = await FirebaseFirestore.instance
          .collection(GateWayConstants.TABLE_CLOUD_STANDARD_ADS)
          .where(GateWayConstants.FIELD_STANDARD_AD_ID,
              isEqualTo: data.adsEntity?.docId)
          .limit(1)
          .get();

      for (var element in adsDealRef.docs) {
        if (element.exists) {
          await FirebaseFirestore.instance
              .collection(GateWayConstants.TABLE_CLOUD_STANDARD_ADS)
              .doc(element.id)
              .delete();
        }
      }

      var activeAdsDealRef = await FirebaseFirestore.instance
          .collection(GateWayConstants.TABLE_ACTIVE_STANDARD_AD)
          .where(GateWayConstants.FIELD_STANDARD_AD_ID,
              isEqualTo: data.adsEntity?.docId)
          .limit(1)
          .get();

      for (var element in activeAdsDealRef.docs) {
        if (element.exists) {
          await FirebaseFirestore.instance
              .collection(GateWayConstants.TABLE_ACTIVE_STANDARD_AD)
              .doc(element.id)
              .delete();
        }
      }

      return AddUpdateAdsResponseEntity(isSuccess: true);
    } catch (e) {
      print(e);
      return AddUpdateAdsResponseEntity(
          isSuccess: false, commonErrors: CommonErrors.fromJson({}));
    }
  }

  @override
  void unsubscribe() {}
}
