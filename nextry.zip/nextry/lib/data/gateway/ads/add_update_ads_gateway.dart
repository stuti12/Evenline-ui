import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:geoflutterfire2/geoflutterfire2.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/data/gateway/common/upload_file_helper.dart';
import 'package:nextry_dev/domain/entities/ads/add_update_ads_param.dart';
import 'package:nextry_dev/domain/entities/ads/add_update_ads_response_entity.dart';
import 'package:nextry_dev/domain/entities/error/common_errors.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/presentation/common/utils/app_constants.dart';
import 'package:nextry_dev/presentation/common/utils/app_extension.dart';

class AddUpdateAdsGateway
    implements ReadGateWay<AddUpdateAdsResponseEntity, AddUpdateAdsParam> {
  @override
  Future<AddUpdateAdsResponseEntity> read(AddUpdateAdsParam data) async {
    try {
      if (data.adsEntity.image != null &&
          data.adsEntity.image!.isNotEmpty &&
          !data.adsEntity.image!.startsWith(AppConstants.SERVER_FILE)) {
        data.adsEntity.image = await UploadFileHelper()
            .uploadFileToFireStore(data.adsEntity.image ?? '');
      }

      var adRef = await FirebaseFirestore.instance
          .collection(GateWayConstants.TABLE_BUSINESSES)
          .doc(data.businessId)
          .collection(GateWayConstants.TABLE_PRODUCT)
          .doc(data.productId)
          .collection(GateWayConstants.TABLE_ADS)
          .add(data.adsEntity.toJson());

      final unavailableDateParam = <String, dynamic>{};
      unavailableDateParam[GateWayConstants
          .FIELD_UNAVAILABLE_DATES_START_DATE] = data.adsEntity.startDate;
      unavailableDateParam[GateWayConstants.FIELD_UNAVAILABLE_DATES_END_DATE] =
          data.adsEntity.endDate;

      await FirebaseFirestore.instance
          .collection(GateWayConstants.TABLE_BUSINESSES)
          .doc(data.businessId)
          .collection(GateWayConstants.TABLE_PRODUCT)
          .doc(data.productId)
          .collection(GateWayConstants.TABLE_UNAVAILABLE_DATES)
          .add(unavailableDateParam);

      final businessRef = FirebaseFirestore.instance
          .collection(GateWayConstants.TABLE_BUSINESSES)
          .doc(data.businessId);

      businessRef
          .update({GateWayConstants.FIELD_ADS_COUNT: FieldValue.increment(1)});

      Map<String, dynamic> param = data.adsEntity.toJson();
      param[GateWayConstants.FIELD_BUSINESS_ID] = data.businessId;
      param[GateWayConstants.FIELD_PRODUCT_ID] = data.productId;
      param[GateWayConstants.FIELD_STANDARD_AD_ID] = adRef.id;
      param[GateWayConstants.FIELD_CATEGORY_ID] = data.categoryId;
      param[GateWayConstants.FIELD_LOCATION] = GeoFlutterFire()
          .point(
              latitude: data.location?.latitude ?? 0.0,
              longitude: data.location?.longitude ?? 0.0)
          .data;
      if (data.businessName != null && data.businessName!.isNotEmpty) {
        param[GateWayConstants.FIELD_BUSINESS_NAMES] = data.businessName ?? '';
      }
      await FirebaseFirestore.instance
          .collection(GateWayConstants.TABLE_CLOUD_STANDARD_ADS)
          .add(param);

      return AddUpdateAdsResponseEntity(isSuccess: true);
    } catch (e) {
      print(e);
      return AddUpdateAdsResponseEntity(
          isSuccess: false, commonErrors: CommonErrors.fromJson({}));
    }
  }

  @override
  void unsubscribe() {}
}
