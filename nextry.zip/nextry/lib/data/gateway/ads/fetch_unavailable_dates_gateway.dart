import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/domain/entities/business/fetch_unavailable_dates_param.dart';
import 'package:nextry_dev/domain/entities/business/fetch_unavailable_dates_response_entity.dart';
import 'package:nextry_dev/domain/entities/business/unavailable_date_entity.dart';
import 'package:nextry_dev/domain/entities/error/common_errors.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';

class FetchUnavailableDatesGateWay
    implements
        ReadGateWay<FetchUnavailableDatesResponseEntity,
            FetchUnavailableDatesParam> {
  @override
  Future<FetchUnavailableDatesResponseEntity> read(
      FetchUnavailableDatesParam param) async {
    try {
      List<UnavailableDateEntity> unavailableDateEntity = [];
      final snapShot = await FirebaseFirestore.instance
          .collection(GateWayConstants.TABLE_BUSINESSES)
          .doc(param.businessId)
          .collection(GateWayConstants.TABLE_PRODUCT)
          .doc(param.productId)
          .collection(GateWayConstants.TABLE_UNAVAILABLE_DATES)
          .get();

      for (var element in snapShot.docs) {
        if (element.exists) {
          var data = element.data();
          unavailableDateEntity
              .add(UnavailableDateEntity.fromJson(data, element.id));
        }
      }
      print(" item size ${unavailableDateEntity.length}");
      return FetchUnavailableDatesResponseEntity(
          unavailableDateEntities: unavailableDateEntity);
    } catch (e) {
      print(e);
      return FetchUnavailableDatesResponseEntity(
          commonErrors: CommonErrors.fromJson({}));
    }
  }

  @override
  void unsubscribe() {}
}
