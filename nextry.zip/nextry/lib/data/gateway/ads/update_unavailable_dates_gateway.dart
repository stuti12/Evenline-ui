import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/data/gateway/common/preferences.dart';
import 'package:nextry_dev/domain/entities/ads/update_unavailable_dates_response_entity.dart';
import 'package:nextry_dev/domain/entities/business/fetch_unavailable_dates_param.dart';
import 'package:nextry_dev/domain/entities/error/common_errors.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/presentation/common/utils/app_constants.dart';

class UpdateUnavailableDatesGateWay
    implements
        ReadGateWay<UpdateUnavailableDatesResponseEntity,
            FetchUnavailableDatesParam> {
  @override
  Future<UpdateUnavailableDatesResponseEntity> read(
      FetchUnavailableDatesParam param) async {
    final Preferences prefs = Preferences();
    try {
      var currentDate = DateTime.now();
      var lastDeletedDate =
          await prefs.getLastRemoveUnavailableDates(param.businessId ?? '');
      if (lastDeletedDate != null && lastDeletedDate.isNotEmpty) {
        var date = DateFormat(AppConstants.MY_BUSINESSES_DATE_FORMAT)
            .parse(lastDeletedDate ?? '');
        var days = currentDate.difference(date).inDays;
        if (days > AppConstants.UNAVAILABLE_DATES_LIST_LIMIT) {
          final snapShot = await FirebaseFirestore.instance
              .collection(GateWayConstants.TABLE_BUSINESSES)
              .doc(param.businessId)
              .collection(GateWayConstants.TABLE_PRODUCT)
              .get();

          for (var element in snapShot.docs) {
            if (element.exists) {
              _checkUnavailableDates(param.businessId, element.id, prefs);
            }
          }
        }
      }
      return UpdateUnavailableDatesResponseEntity(isSuccess: true);
    } catch (e) {
      print(e);
      return UpdateUnavailableDatesResponseEntity(
          commonErrors: CommonErrors.fromJson({}));
    }
  }

  _checkUnavailableDates(
      String? businessId, String productId, Preferences prefs) async {
    var currentDate = DateTime.now();
    final snapShot = await FirebaseFirestore.instance
        .collection(GateWayConstants.TABLE_BUSINESSES)
        .doc(businessId)
        .collection(GateWayConstants.TABLE_PRODUCT)
        .doc(productId)
        .collection(GateWayConstants.TABLE_UNAVAILABLE_DATES)
        .where(GateWayConstants.FIELD_UNAVAILABLE_DATES_END_DATE,
            isLessThan:
                DateTime(currentDate.year, currentDate.month, currentDate.day))
        .get();
    for (var element in snapShot.docs) {
      if (element.exists) {
        await FirebaseFirestore.instance
            .collection(GateWayConstants.TABLE_BUSINESSES)
            .doc(businessId)
            .collection(GateWayConstants.TABLE_PRODUCT)
            .doc(productId)
            .collection(GateWayConstants.TABLE_UNAVAILABLE_DATES)
            .doc(element.id)
            .delete();
      }
    }
    prefs.storeLastRemoveUnavailableDates(
      businessId ?? '',
      getDateFormat(currentDate.subtract(const Duration(days: 10))),
    );
  }

  String getDateFormat(DateTime? date) {
    if (date != null) {
      return DateFormat(AppConstants.MY_BUSINESSES_DATE_FORMAT).format(date);
    }
    return "";
  }

  @override
  void unsubscribe() {}
}
