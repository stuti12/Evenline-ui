import 'dart:async';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:nextry_dev/domain/entities/error/common_errors.dart';
import 'package:nextry_dev/domain/entities/forgotpassword/forgot_password_param.dart';
import 'package:nextry_dev/domain/entities/forgotpassword/forgot_password_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';

/// If user click on forgot password option then
/// it will open default screen and complete the flow.
class ForgotPasswordGateWay
    implements ReadGateWay<ForgotPasswordResponseEntity, ForgotPasswordParam> {
  @override
  Future<ForgotPasswordResponseEntity> read(
      ForgotPasswordParam forgotPasswordParam) async {
    try {
      SignInMethodsStatus signInMethodsStatus;
      List<String> userSignInMethods = await FirebaseAuth.instance
          .fetchSignInMethodsForEmail(forgotPasswordParam.email);
      print("user sign in methods ${userSignInMethods.toString()}");
      if (userSignInMethods.isEmpty) {
        signInMethodsStatus = SignInMethodsStatus.NOT_USER_EXIST;
      } else if (!userSignInMethods.contains("password")) {
        signInMethodsStatus = SignInMethodsStatus.NOT_PASSWORD_EXIST;
      } else {
        signInMethodsStatus = SignInMethodsStatus.EXIST_PASSWORD;
        await FirebaseAuth.instance
            .sendPasswordResetEmail(email: forgotPasswordParam.email);
      }
      return ForgotPasswordResponseEntity(
          signInMethodsStatus: signInMethodsStatus, error: null);
    } on FirebaseAuthException catch (e) {
      return ForgotPasswordResponseEntity(
          signInMethodsStatus: null,
          error: CommonErrors(errorCode: e.code, message: e.message!));
    }
  }

  @override
  void unsubscribe() {}
}
