import 'dart:async';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:nextry_dev/domain/entities/error/common_errors.dart';
import 'package:nextry_dev/domain/entities/signup/google_sign_in_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway_no_args.dart';

/// It will open default Google login screen to validate the user.
///
/// Based on success/failure, it will return to [UserCredential] presentation layer.
class GoogleSignInGateWay
    implements ReadGateWayNoArgs<GoogleSignInResponseEntity> {

  @override
  Future<GoogleSignInResponseEntity> read() async {
    try {
      FirebaseAuth auth = FirebaseAuth.instance;

      // Trigger the authentication flow
      final GoogleSignInAccount? googleUser = await GoogleSignIn().signIn();

      // Obtain the auth details from the request
      final GoogleSignInAuthentication googleAuth =
          await googleUser!.authentication;

      // Create a new credential
      final credential = GoogleAuthProvider.credential(
        accessToken: googleAuth.accessToken,
        idToken: googleAuth.idToken,
      );

      // Once signed in, return the UserCredential
      var userCredential = await auth.signInWithCredential(credential);
      return GoogleSignInResponseEntity(
          userCredential: userCredential, error: null);
    } on FirebaseAuthException catch (e) {
      return GoogleSignInResponseEntity(
          userCredential: null,
          error: CommonErrors(errorCode: e.code, message: e.message!));
    } catch (e) {
      print(e);
      return GoogleSignInResponseEntity(userCredential: null, error: null);
    }
  }

  @override
  void dispose() {}
}
