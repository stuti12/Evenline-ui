import 'dart:async';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:nextry_dev/domain/entities/error/common_errors.dart';
import 'package:nextry_dev/domain/entities/signup/apple_sign_in_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway_no_args.dart';
import 'package:sign_in_with_apple/sign_in_with_apple.dart';

class AppleSignInGateWay
    implements ReadGateWayNoArgs<AppleSignInResponseEntity> {
  @override
  Future<AppleSignInResponseEntity> read() async {
    try {
      FirebaseAuth auth = FirebaseAuth.instance;

      final credential = await SignInWithApple.getAppleIDCredential(
        scopes: [
          AppleIDAuthorizationScopes.email,
          AppleIDAuthorizationScopes.fullName,
        ],
      );

      OAuthProvider oAuthProvider = OAuthProvider("apple.com");
      OAuthCredential authCredential = oAuthProvider.credential(
          idToken: credential.identityToken,
          accessToken: credential.authorizationCode);

      final UserCredential userCredential =
          await auth.signInWithCredential(authCredential);

      return AppleSignInResponseEntity(
          userCredential: userCredential, error: null);
    } on FirebaseAuthException catch (e) {
      return AppleSignInResponseEntity(
          userCredential: null,
          error: CommonErrors(errorCode: e.code, message: e.message!));
    } catch (e) {
      print(e);
      return AppleSignInResponseEntity(userCredential: null, error: null);
    }
  }

  @override
  void dispose() {}
}
