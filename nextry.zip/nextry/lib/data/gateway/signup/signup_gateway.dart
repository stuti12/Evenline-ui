import 'dart:async';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:nextry_dev/data/gateway/common/preferences.dart';
import 'package:nextry_dev/domain/entities/error/common_errors.dart';
import 'package:nextry_dev/domain/entities/signup/sign_up_params.dart';
import 'package:nextry_dev/domain/entities/signup/sign_up_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';

class SignUpGateWay implements ReadGateWay<SignUpResponseEntity, SignUpParams> {
  @override
  Future<SignUpResponseEntity> read(SignUpParams signUpParams) async {
    final Preferences _prefs = Preferences();
    try {
      UserCredential userCredential =
          await FirebaseAuth.instance.createUserWithEmailAndPassword(
        email: signUpParams.email,
        password: signUpParams.password,
      );
      _prefs.setUserEmail(signUpParams.email);
      return SignUpResponseEntity(userCredential: userCredential, error: null);
    } on FirebaseAuthException catch (e) {
      return SignUpResponseEntity(
        userCredential: null,
        error: CommonErrors(errorCode: e.code, message: e.message!),
      );
    } catch (e) {
      print(e);
      return SignUpResponseEntity(userCredential: null, error: null);
    }
  }

  @override
  void unsubscribe() {}
}
