import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/data/gateway/common/http_service.dart';
import 'package:nextry_dev/domain/entities/all_card/card_entity.dart';
import 'package:nextry_dev/domain/entities/all_card/fetch_all_card_param.dart';
import 'package:nextry_dev/domain/entities/all_card/fetch_all_card_response_entity.dart';
import 'package:nextry_dev/domain/entities/error/common_errors.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';

class FetchAllCardGateway
    implements ReadGateWay<FetchAllCardResponseEntity, FetchAllCardParam> {
  @override
  Future<FetchAllCardResponseEntity> read(FetchAllCardParam param) async {
    try {
      List<CardEntity> allCardList = [];
      var response = await HttpService.getHttp(
          "${GateWayConstants.CUSTOMER}/${param.customerId}${GateWayConstants.SOURCES}");
      if (response != null) {
        var cardList = response[GateWayConstants.FIELD_DATA] as List;
        if (cardList.isNotEmpty) {
          for (var element in cardList) {
            allCardList.add(CardEntity.fromJson(element));
          }
        }
      }
      return FetchAllCardResponseEntity(allCardList: allCardList);
    } catch (e) {
      print(e);
    }
    return FetchAllCardResponseEntity(commonErrors: CommonErrors.fromJson({}));
  }

  @override
  void unsubscribe() {}
}
