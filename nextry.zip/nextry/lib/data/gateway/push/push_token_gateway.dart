import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/domain/gateway/write_gateway.dart';

class PushTokenGateway extends WriteGateWay<List<String>> {
  @override
  Future<void> write(List<String> data) async {
    try {
      String? profileDocId = FirebaseAuth.instance.currentUser?.uid;
      if(profileDocId != null) {
        final updateData = <String, dynamic>{};
        updateData[GateWayConstants.FIELD_FCM_TOKEN] = data;
        await FirebaseFirestore.instance
            .collection(GateWayConstants.TABLE_USERS)
            .doc(profileDocId)
            .set(updateData, SetOptions(merge: true));
      }
    } on FirebaseAuthException catch (e) {
      print(e.toString());
    }
    return;
  }
}
