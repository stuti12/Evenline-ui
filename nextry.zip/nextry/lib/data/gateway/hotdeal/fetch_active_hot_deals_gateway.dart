import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/domain/entities/error/common_errors.dart';
import 'package:nextry_dev/domain/entities/hotdeal/fetch_all_scheduled_hot_deal_response_entity.dart';
import 'package:nextry_dev/domain/entities/hotdeal/hot_deal_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/domain/entities/hotdeal/fetch_active_hot_deal_param.dart';

class FetchActiveHotDealsGateWay
    implements
        ReadGateWay<FetchAllScheduledHotDealResponseEntity,
            FetchActiveHotDealParam> {
  @override
  Future<FetchAllScheduledHotDealResponseEntity> read(
      FetchActiveHotDealParam data) async {
    try {
      final snapshot = await FirebaseFirestore.instance
          .collection(GateWayConstants.TABLE_ACTIVE_HOT_DEAL)
          .where(GateWayConstants.FIELD_BUSINESS_ID, isEqualTo: data.businessId)
          .get();

      List<HotDealEntity>? hotDealList = [];
      for (var element in snapshot.docs) {
        if (element.exists) {
          var data = element.data();
          hotDealList.add(HotDealEntity.fromJson(data, element.id));
        }
      }
      return FetchAllScheduledHotDealResponseEntity(hotDealList: hotDealList);
    } catch (e) {
      print(e);
      return FetchAllScheduledHotDealResponseEntity(
          commonErrors: CommonErrors.fromJson({}));
    }
  }

  @override
  void unsubscribe() {}
}
