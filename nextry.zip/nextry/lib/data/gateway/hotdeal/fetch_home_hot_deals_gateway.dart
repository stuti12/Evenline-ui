import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:geoflutterfire2/geoflutterfire2.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/domain/entities/business/business_entity.dart';
import 'package:nextry_dev/domain/entities/error/common_errors.dart';
import 'package:nextry_dev/domain/entities/hotdeal/fetch_all_scheduled_hot_deal_response_entity.dart';
import 'package:nextry_dev/domain/entities/hotdeal/fetch_home_hot_deals_param.dart';
import 'package:nextry_dev/domain/entities/hotdeal/hot_deal_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/presentation/common/utils/app_constants.dart';
import 'package:rxdart/subjects.dart';
import 'package:rxdart/transformers.dart';

class FetchHomeHotDealsGateWay
    implements
        ReadGateWay<FetchAllScheduledHotDealResponseEntity,
            FetchHomeHotDealsParam> {
  StreamSubscription? subscription;

  @override
  Future<FetchAllScheduledHotDealResponseEntity> read(
      FetchHomeHotDealsParam param) async {
    try {
      final businessAdsRef = FirebaseFirestore.instance
          .collection(GateWayConstants.TABLE_ACTIVE_HOT_DEAL)
          .where(GateWayConstants.FIELD_CATEGORY_ID,
              isEqualTo: param.categoryId);

      if (param.location != null) {
        final radius = BehaviorSubject<double>.seeded(param.radius ??
            AppConstants.DEFAULT_LOCATION_RADIUS); // radius is in KM
        GeoFirePoint center = GeoFlutterFire().point(
            latitude: param.location?.latitude ?? 0.0,
            longitude: param.location?.longitude ?? 0.0);
        Stream<List<DocumentSnapshot>> stream = radius.switchMap((rad) {
          return GeoFlutterFire()
              .collection(collectionRef: businessAdsRef)
              .within(
                center: center,
                radius: rad,
                field: GateWayConstants.FIELD_LOCATION,
                strictMode: true,
              );
        });

        subscription?.cancel();
        subscription =
            stream.listen((List<DocumentSnapshot> documentList) async {
          List<HotDealEntity>? hotDealList = [];
          if (documentList.isNotEmpty) {
            for (var element in documentList) {
              if (element.exists) {
                var data = element.data();
                if (data != null) {
                  final hotDealEntity = HotDealEntity.fromJson(
                      data as Map<String, dynamic>, element.id);
                  var businessEntity =
                      await _fetchBusinessData(hotDealEntity.businessId);
                  if (hotDealEntity.imageUrl != null &&
                      hotDealEntity.imageUrl!.isNotEmpty &&
                      businessEntity != null) {
                    hotDealList.add(hotDealEntity);
                  }
                }
              }
            }
          }
          if (param.onUpdate != null) param.onUpdate!(hotDealList);
        });
      }
      return FetchAllScheduledHotDealResponseEntity();
    } catch (e) {
      print(e);
      return FetchAllScheduledHotDealResponseEntity(
          commonErrors: CommonErrors.fromJson({}));
    }
  }

  Future<BusinessEntity?> _fetchBusinessData(String? businessId) async {
    var snapshot = await FirebaseFirestore.instance
        .collection(GateWayConstants.TABLE_BUSINESSES)
        .doc(businessId)
        .get();
    if (snapshot.exists) {
      var data = snapshot.data();
      if (data != null) {
        return BusinessEntity.fromJSON(data, businessId ?? '');
      }
    }
    return null;
  }

  @override
  void unsubscribe() {
    subscription?.cancel();
  }
}
