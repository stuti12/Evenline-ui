import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:geoflutterfire2/geoflutterfire2.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/data/gateway/common/upload_file_helper.dart';
import 'package:nextry_dev/domain/entities/error/common_errors.dart';
import 'package:nextry_dev/domain/entities/hotdeal/make_hot_deal_ad_param.dart';
import 'package:nextry_dev/domain/entities/hotdeal/make_hot_deal_ad_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/presentation/common/utils/app_constants.dart';

class MakeHotDealAdGateway
    implements ReadGateWay<MakeHotDealAdResponseEntity, MakeHotDealAdParam> {
  @override
  Future<MakeHotDealAdResponseEntity> read(MakeHotDealAdParam data) async {
    try {
      if (data.hotDealEntity?.imageUrl != null &&
          data.hotDealEntity!.imageUrl!.isNotEmpty &&
          !data.hotDealEntity!.imageUrl!.startsWith(AppConstants.SERVER_FILE)) {
        data.hotDealEntity?.imageUrl = await UploadFileHelper()
            .uploadFileToFireStore(data.hotDealEntity!.imageUrl!);
      }

      var hotDealRef = await FirebaseFirestore.instance
          .collection(GateWayConstants.TABLE_BUSINESSES)
          .doc(data.businessId)
          .collection(GateWayConstants.TABLE_HOT_DEAL)
          .add(data.hotDealEntity?.toJson() ?? {});

      final businessRef = FirebaseFirestore.instance
          .collection(GateWayConstants.TABLE_BUSINESSES)
          .doc(data.businessId);

      businessRef.update(
          {GateWayConstants.FIELD_HOT_DEAL_COUNT: FieldValue.increment(1)});

      Map<String, dynamic> param = data.hotDealEntity?.toJson() ?? {};
      param[GateWayConstants.FIELD_BUSINESS_ID] = data.businessId;
      param[GateWayConstants.FIELD_HOT_DEAL_ID] = hotDealRef.id;
      param[GateWayConstants.FIELD_CATEGORY_ID] = data.categoryId;
      param[GateWayConstants.FIELD_LOCATION] = GeoFlutterFire()
          .point(
              latitude: data.location?.latitude ?? 0.0,
              longitude: data.location?.longitude ?? 0.0)
          .data;
      await FirebaseFirestore.instance
          .collection(GateWayConstants.TABLE_CLOUD_HOT_DEAL)
          .add(param);

      return MakeHotDealAdResponseEntity(isSuccess: true);
    } catch (e) {
      print(e);
      return MakeHotDealAdResponseEntity(
          isSuccess: false, commonErrors: CommonErrors.fromJson({}));
    }
  }

  @override
  void unsubscribe() {}
}
