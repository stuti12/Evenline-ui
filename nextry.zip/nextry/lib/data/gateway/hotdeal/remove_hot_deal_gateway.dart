import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/domain/entities/error/common_errors.dart';
import 'package:nextry_dev/domain/entities/hotdeal/make_hot_deal_ad_response_entity.dart';
import 'package:nextry_dev/domain/entities/hotdeal/remove_hot_deal_param.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';

class RemoveHotDealGateway
    implements ReadGateWay<MakeHotDealAdResponseEntity, RemoveHotDealParam> {
  @override
  Future<MakeHotDealAdResponseEntity> read(RemoveHotDealParam data) async {
    try {
      await FirebaseFirestore.instance
          .collection(GateWayConstants.TABLE_BUSINESSES)
          .doc(data.businessId)
          .collection(GateWayConstants.TABLE_HOT_DEAL)
          .doc(data.hotDealDocId)
          .delete();

      var hotDealRef = await FirebaseFirestore.instance
          .collection(GateWayConstants.TABLE_CLOUD_HOT_DEAL)
          .where(GateWayConstants.FIELD_HOT_DEAL_ID,
              isEqualTo: data.hotDealDocId)
          .limit(1)
          .get();

      for (var element in hotDealRef.docs) {
        if (element.exists) {
          await FirebaseFirestore.instance
              .collection(GateWayConstants.TABLE_CLOUD_HOT_DEAL)
              .doc(element.id)
              .delete();
        }
      }

      var activeHotDealRef = await FirebaseFirestore.instance
          .collection(GateWayConstants.TABLE_ACTIVE_HOT_DEAL)
          .where(GateWayConstants.FIELD_HOT_DEAL_ID,
              isEqualTo: data.hotDealDocId)
          .limit(1)
          .get();

      for (var element in activeHotDealRef.docs) {
        if (element.exists) {
          await FirebaseFirestore.instance
              .collection(GateWayConstants.TABLE_ACTIVE_HOT_DEAL)
              .doc(element.id)
              .delete();
        }
      }
      return MakeHotDealAdResponseEntity(isSuccess: true);
    } catch (e) {
      print(e);
      return MakeHotDealAdResponseEntity(
          isSuccess: false, commonErrors: CommonErrors.fromJson({}));
    }
  }

  @override
  void unsubscribe() {}
}
