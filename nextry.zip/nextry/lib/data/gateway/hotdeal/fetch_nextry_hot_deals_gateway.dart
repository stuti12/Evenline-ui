import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/domain/entities/error/common_errors.dart';
import 'package:nextry_dev/domain/entities/hotdeal/fetch_all_scheduled_hot_deal_response_entity.dart';
import 'package:nextry_dev/domain/entities/hotdeal/hot_deal_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway_no_args.dart';

class FetchNextryHotDealsGateWay
    implements ReadGateWayNoArgs<FetchAllScheduledHotDealResponseEntity> {
  @override
  Future<FetchAllScheduledHotDealResponseEntity> read() async {
    try {
      final snapshot = await FirebaseFirestore.instance
          .collection(GateWayConstants.TABLE_NEXTRY_HOT_DEALS)
          .get();

      List<HotDealEntity>? hotDealList = [];
      for (var element in snapshot.docs) {
        if (element.exists) {
          var data = element.data();
          final hotDealEntity = HotDealEntity.fromJson(data, element.id);
          if (hotDealEntity.imageUrl != null &&
              hotDealEntity.imageUrl!.isNotEmpty) {
            hotDealList.add(hotDealEntity);
          }
        }
      }
      return FetchAllScheduledHotDealResponseEntity(hotDealList: hotDealList);
    } catch (e) {
      print(e);
      return FetchAllScheduledHotDealResponseEntity(
          commonErrors: CommonErrors.fromJson({}));
    }
  }

  @override
  void dispose() {}
}
