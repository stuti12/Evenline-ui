import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/domain/entities/error/common_errors.dart';
import 'package:nextry_dev/domain/entities/hotdeal/fetch_all_scheduled_hot_deal_response_entity.dart';
import 'package:nextry_dev/domain/entities/hotdeal/hot_deal_entity.dart';
import 'package:nextry_dev/domain/entities/hotdeal/make_hot_deal_ad_param.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';

class FetchAllScheduledHotDealsGateWay
    implements
        ReadGateWay<FetchAllScheduledHotDealResponseEntity,
            MakeHotDealAdParam> {
  @override
  Future<FetchAllScheduledHotDealResponseEntity> read(
      MakeHotDealAdParam data) async {
    try {
      var currentTime = DateTime.now();
      final snapshot = await FirebaseFirestore.instance
          .collection(GateWayConstants.TABLE_BUSINESSES)
          .doc(data.businessId)
          .collection(GateWayConstants.TABLE_HOT_DEAL)
          .where(GateWayConstants.FIELD_START_TIME,
              isGreaterThan: Timestamp.now())
          .orderBy(GateWayConstants.FIELD_START_TIME, descending: false)
          .get();

      List<HotDealEntity>? hotDealList = [];
      for (var element in snapshot.docs) {
        if (element.exists) {
          var data = element.data();
          hotDealList.add(HotDealEntity.fromJson(data, element.id));
        }
      }
      return FetchAllScheduledHotDealResponseEntity(hotDealList: hotDealList);
    } catch (e) {
      print(e);
      return FetchAllScheduledHotDealResponseEntity(
          commonErrors: CommonErrors.fromJson({}));
    }
  }

  @override
  void unsubscribe() {}
}
