import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/domain/entities/config/force_update_entity.dart';
import 'package:nextry_dev/domain/entities/config/force_update_response_entity.dart';
import 'package:nextry_dev/domain/entities/error/common_errors.dart';
import 'package:nextry_dev/domain/gateway/read_gateway_no_args.dart';

class FetchAppUpdateGateWay
    implements ReadGateWayNoArgs<ForceUpdateResponseEntity> {
  @override
  Future<ForceUpdateResponseEntity> read() async {
    try {
      var snapshot = await FirebaseFirestore.instance
          .collection(GateWayConstants.TABLE_CONFIGURATIONS)
          .doc(Platform.isAndroid ? "app_update_android" : "app_update_ios")
          .get();

      var entity = ForceUpdateResponseEntity();
      if (snapshot.exists) {
        var data = snapshot.data();
        if (data != null) {
          entity = ForceUpdateResponseEntity(
              forceUpdateEntity: ForceUpdateEntity.fromJson(data));
        }
      }
      return entity;
    } catch (e) {
      print(e);
      return ForceUpdateResponseEntity(error: CommonErrors.fromJson({}));
    }
  }

  @override
  void dispose() {}
}
