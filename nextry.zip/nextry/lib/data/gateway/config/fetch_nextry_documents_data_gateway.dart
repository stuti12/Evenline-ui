import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/domain/entities/config/nextry_documents_entity.dart';
import 'package:nextry_dev/domain/entities/config/nextry_documents_response_entity.dart';
import 'package:nextry_dev/domain/entities/error/common_errors.dart';
import 'package:nextry_dev/domain/gateway/read_gateway_no_args.dart';

class FetchNextryDocumentsDataGateWay
    implements ReadGateWayNoArgs<NextryDocumentsResponseEntity> {
  @override
  Future<NextryDocumentsResponseEntity> read() async {
    try {
      var snapshot = await FirebaseFirestore.instance
          .collection(GateWayConstants.TABLE_CONFIGURATIONS)
          .doc("nextry_documents")
          .get();

      var entity = NextryDocumentsResponseEntity();
      if (snapshot.exists) {
        var data = snapshot.data();
        if (data != null) {
          entity = NextryDocumentsResponseEntity(
              nextryDocumentsEntity: NextryDocumentsEntity.fromJson(data));
        }
      }
      return entity;
    } catch (e) {
      print(e);
      return NextryDocumentsResponseEntity(error: CommonErrors.fromJson({}));
    }
  }

  @override
  void dispose() {}
}
