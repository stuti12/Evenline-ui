import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/domain/entities/config/payplus_payment_config_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway_no_args.dart';

class FetchPayPlusPaymentConfigGateWay
    implements ReadGateWayNoArgs<PayPlusPaymentConfigEntity> {
  @override
  Future<PayPlusPaymentConfigEntity> read() async {
    try {
      var snapshot = await FirebaseFirestore.instance
          .collection(GateWayConstants.TABLE_CONFIGURATIONS)
          .doc(GateWayConstants.CONFIG_PAYPLUS_PAYMENT_DOC_ID)
          .get();

      var entity = PayPlusPaymentConfigEntity();
      if (snapshot.exists) {
        var data = snapshot.data();
        if (data != null &&
            data[GateWayConstants.FIELD_PAYPLUS_SUBSCRIPTION_PAYMENT] != null) {
          entity = PayPlusPaymentConfigEntity.fromJSON(
              data[GateWayConstants.FIELD_PAYPLUS_SUBSCRIPTION_PAYMENT]);
        }
      }
      return entity;
    } catch (e) {
      print(e);
      return PayPlusPaymentConfigEntity();
    }
  }

  @override
  void dispose() {}
}
