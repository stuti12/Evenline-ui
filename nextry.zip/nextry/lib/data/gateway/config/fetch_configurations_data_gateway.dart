import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/domain/entities/config/config_response_entity.dart';
import 'package:nextry_dev/domain/entities/error/common_errors.dart';
import 'package:nextry_dev/domain/gateway/read_gateway_no_args.dart';

class FetchConfigurationsDataGateWay
    implements ReadGateWayNoArgs<ConfigResponseEntity> {
  @override
  Future<ConfigResponseEntity> read() async {
    try {
      var snapshot = await FirebaseFirestore.instance
          .collection(GateWayConstants.TABLE_CONFIGURATIONS)
          .doc("signup_screen")
          .get();

      final entity = ConfigResponseEntity(isLocked: false);
      if (snapshot.exists) {
        var data = snapshot.data();
        if (data != null) {
          entity.isLocked = data[GateWayConstants.FIELD_IS_LOCKED];
        }
      }
      print("==="+entity.isLocked.toString());
      return entity;
    } catch (e) {
      print(e);
      return ConfigResponseEntity(error: CommonErrors.fromJson({}), isLocked: false);
    }
  }

  @override
  void dispose() {}
}
