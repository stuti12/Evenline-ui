import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/domain/entities/config/contact_us_config_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway_no_args.dart';

class ContactUsConfigGateway
    implements ReadGateWayNoArgs<ContactUsConfigResponseEntity> {
  @override
  Future<ContactUsConfigResponseEntity> read() async {
    try {
      var snapshot = await FirebaseFirestore.instance
          .collection(GateWayConstants.TABLE_CONFIGURATIONS)
          .doc(GateWayConstants.FIELD_CU_PHONE)
          .get();

      final entity = ContactUsConfigResponseEntity();

      if (snapshot.exists) {
        var data = snapshot.data();

        if (data != null) {
          entity.contactNumber = data[GateWayConstants.FIELD_CU_PHONE];
        }
      }
      return entity;
    } catch (e) {
      print(e);
      return ContactUsConfigResponseEntity();
    }
  }

  @override
  void dispose() {}
}
