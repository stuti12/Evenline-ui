import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/domain/entities/error/common_errors.dart';
import 'package:nextry_dev/domain/entities/feedback/all_business_feedbacks_response_entity.dart';
import 'package:nextry_dev/domain/entities/feedback/create_customer_feedback_param.dart';
import 'package:nextry_dev/domain/entities/feedback/feedback_entity.dart';
import 'package:nextry_dev/domain/entities/profile/user_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';

class FetchAllBusinessFeedbacksGateway
    implements
        ReadGateWay<AllBusinessFeedbacksResponseEntity,
            CreateCustomerFeedbackParam> {
  @override
  Future<AllBusinessFeedbacksResponseEntity> read(
      CreateCustomerFeedbackParam param) async {
    try {
      var snapshot = await FirebaseFirestore.instance
          .collection(GateWayConstants.TABLE_BUSINESSES)
          .doc(param.businessId)
          .collection(GateWayConstants.TABLE_FEEDBACK)
          .orderBy(GateWayConstants.FIELD_CREATED_AT, descending: true)
          .get();

      List<FeedbackEntity> feedBacksList = [];
      double totalRating = 0.0;
      if (snapshot.docs.isNotEmpty) {
        for (var element in snapshot.docs) {
          if (element.exists) {
            var data = element.data();
            var snapshot = await FirebaseFirestore.instance
                .collection(GateWayConstants.TABLE_FEEDBACK_REPORTED)
                .where(GateWayConstants.FIELD_ORDER_ID,
                    isEqualTo: data[GateWayConstants.FIELD_ORDER_ID])
                .count()
                .get();
            final userEntity =
                await _fetchCustomerData(data[GateWayConstants.FIELD_USER_ID]);
            totalRating = totalRating + data[GateWayConstants.FIELD_RATING];
            feedBacksList.add(FeedbackEntity.fromJson(
                data, element.id, snapshot.count > 0 ? true : false,
                user: userEntity));
          }
        }
      }
      if (snapshot.docs.isNotEmpty) {
        totalRating = totalRating / snapshot.docs.length;
      }
      return AllBusinessFeedbacksResponseEntity(
          feedbackList: feedBacksList, totalRating: totalRating);
    } catch (e) {
      print(e);
      return AllBusinessFeedbacksResponseEntity(
          commonErrors: CommonErrors.fromJson({}));
    }
  }

  Future<UserEntity?> _fetchCustomerData(String? customerId) async {
    var snapshot = await FirebaseFirestore.instance
        .collection(GateWayConstants.TABLE_USERS)
        .doc(customerId)
        .get();
    if (snapshot.exists) {
      var data = snapshot.data();
      if (data != null) {
        return UserEntity.fromJson(data, snapshot.id);
      }
    }
    return null;
  }

  @override
  void unsubscribe() {}
}
