import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/data/gateway/common/upload_file_helper.dart';
import 'package:nextry_dev/domain/entities/error/common_errors.dart';
import 'package:nextry_dev/domain/entities/feedback/create_feedback_report_response_entity.dart';
import 'package:nextry_dev/domain/entities/feedback/feedback_report_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/presentation/common/utils/app_constants.dart';

class CreateFeedbackReportGateway
    implements
        ReadGateWay<CreateFeedbackReportResponseEntity, FeedbackReportEntity> {
  @override
  Future<CreateFeedbackReportResponseEntity> read(
      FeedbackReportEntity param) async {
    try {
      if (param.files != null && param.files!.isNotEmpty) {
        for (var i = 0; i < param.files!.length; i++) {
          String mediaFile = param.files![i];
          if (mediaFile.isNotEmpty &&
              !mediaFile.startsWith(AppConstants.SERVER_FILE)) {
            final serverURL =
                await UploadFileHelper().uploadFileToFireStore(mediaFile);
            param.files![i] = serverURL;
          }
        }
      }

      bool isFromBusiness = param.businessId != null;
      param.createdAt = Timestamp.now();
      await FirebaseFirestore.instance
          .collection(isFromBusiness ? GateWayConstants.TABLE_FEEDBACK_REPORTED : GateWayConstants.TABLE_SHIPPER_FEEDBACK_REPORTED)
          .add(param.toJson());

      return CreateFeedbackReportResponseEntity(isSuccess: true);
    } catch (e) {
      print(e);
      return CreateFeedbackReportResponseEntity(
          isSuccess: false, commonErrors: CommonErrors.fromJson({}));
    }
  }

  @override
  void unsubscribe() {}
}
