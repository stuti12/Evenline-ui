import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/domain/entities/error/common_errors.dart';
import 'package:nextry_dev/domain/entities/feedback/create_customer_feedback_param.dart';
import 'package:nextry_dev/domain/entities/feedback/create_customer_feedback_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';

class CreateCustomerFeedbackGateway
    implements
        ReadGateWay<CreateCustomerFeedbackResponseEntity,
            CreateCustomerFeedbackParam> {
  @override
  Future<CreateCustomerFeedbackResponseEntity> read(
      CreateCustomerFeedbackParam param) async {
    try {
      final userId = FirebaseAuth.instance.currentUser?.uid;
      param.feedbackEntity?.userId = userId;
      param.feedbackEntity?.createdAt = Timestamp.now();

      await FirebaseFirestore.instance
          .collection(GateWayConstants.TABLE_BUSINESSES)
          .doc(param.businessId)
          .collection(GateWayConstants.TABLE_FEEDBACK)
          .add(param.feedbackEntity?.toJson() ?? {});

      final data = <String, dynamic>{};
      data[GateWayConstants.FIELD_ORDER_IS_LEAVE_FEEDBACK] = true;

      await FirebaseFirestore.instance
          .collection(GateWayConstants.TABLE_BUSINESSES)
          .doc(param.businessId)
          .collection(GateWayConstants.TABLE_ORDERS)
          .doc(param.feedbackEntity?.orderId)
          .set(data, SetOptions(merge: true));

      return CreateCustomerFeedbackResponseEntity(isSuccess: true);
    } catch (e) {
      print(e);
      return CreateCustomerFeedbackResponseEntity(
          isSuccess: false, commonErrors: CommonErrors.fromJson({}));
    }
  }

  @override
  void unsubscribe() {}
}
