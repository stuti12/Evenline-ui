import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/domain/entities/wallet/balance_param.dart';
import 'package:nextry_dev/domain/entities/wallet/balance_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';

class FetchBalanceGateway
    implements ReadGateWay<BalanceResponseEntity, BalanceParam> {
  @override
  Future<BalanceResponseEntity> read(BalanceParam balanceParam) async {
    try {
      var snap = await FirebaseFirestore.instance
          .collection(balanceParam.isBusiness
              ? GateWayConstants.TABLE_BUSINESSES
              : GateWayConstants.TABLE_USERS)
          .doc(balanceParam.userUID)
          .collection(GateWayConstants.TABLE_WALLET)
          .doc(balanceParam.type)
          .get();
      BalanceResponseEntity balanceResponseEntity = BalanceResponseEntity();
      if (snap.exists) {
        var data = snap.data();
        if (data != null) {
          balanceResponseEntity.balance = data[GateWayConstants.FIELD_BALLANCE];
        }
      }
      return balanceResponseEntity;
    } catch (error) {
      print(error);
      return BalanceResponseEntity();
    }
  }

  @override
  void unsubscribe() {}
}
