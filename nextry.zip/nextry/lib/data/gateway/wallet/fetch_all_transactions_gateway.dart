import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/domain/entities/wallet/total_balance_param.dart';
import 'package:nextry_dev/domain/entities/wallet/transaction_entity.dart';
import 'package:nextry_dev/domain/entities/wallet/transaction_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';

class FetchAllTransactionsGateway
    implements ReadGateWay<TransactionResponseEntity, TotalBalanceParam> {
  @override
  Future<TransactionResponseEntity> read(
      TotalBalanceParam totalBalanceParam) async {
    try {
      var now = DateTime.now();
      var todayDate = DateTime(now.year, now.month, now.day);
      if (totalBalanceParam.noOfDays != 1) {
        todayDate =
            todayDate.subtract(Duration(days: totalBalanceParam.noOfDays ?? 1));
      }

      var snapshot = await FirebaseFirestore.instance
          .collection(totalBalanceParam.isBusiness
              ? GateWayConstants.TABLE_BUSINESSES
              : GateWayConstants.TABLE_USERS)
          .doc(totalBalanceParam.userUID)
          .collection(GateWayConstants.TABLE_WALLET)
          .doc(totalBalanceParam.type)
          .collection(GateWayConstants.TABLE_TRANSACTIONS)
          .where(GateWayConstants.FIELD_CREATED_AT,
              isGreaterThanOrEqualTo: todayDate)
          .orderBy(GateWayConstants.FIELD_CREATED_AT, descending: true)
          .get();

      List<TransactionEntity> transactionList = [];

      for (var element in snapshot.docs) {
        if (element.exists) {
          var data = element.data();
          transactionList.add(TransactionEntity(
              amount: data[GateWayConstants.FIELD_AMOUNT],
              date: data[GateWayConstants.FIELD_CREATED_AT],
              transactionType: data[GateWayConstants.FIELD_TYPE],
              userName: data[GateWayConstants.FIELD_USER_NAME]));
        }
      }
      return TransactionResponseEntity(transactionList: transactionList);
    } catch (error) {
      print(error);
      return TransactionResponseEntity();
    }
  }

  @override
  void unsubscribe() {}
}
