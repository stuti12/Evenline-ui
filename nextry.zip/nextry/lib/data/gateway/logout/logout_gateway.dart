import 'dart:async';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:nextry_dev/data/gateway/common/preferences.dart';
import 'package:nextry_dev/domain/gateway/read_gateway_no_args.dart';

/// When user tried to logout in the application then
/// it will clear the local data and user's session.
class LogoutGateWay extends ReadGateWayNoArgs<void> {
  final Preferences _prefs = Preferences();

  @override
  Future<void> read() async {
    final profileDocId = FirebaseAuth.instance.currentUser?.uid;
    // TODO: Remove the device for push notification.
    await FirebaseAuth.instance.signOut();
    final user = await GoogleSignIn().isSignedIn();
    if (user) {
      await GoogleSignIn().signOut();
    }
    await _prefs.clearData();
  }

  @override
  void dispose() {}
}
