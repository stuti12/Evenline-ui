import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/domain/entities/delivery/fetch_shipper_delivery_offer_response_entity.dart';
import 'package:nextry_dev/domain/entities/delivery/fetch_shipper_delivery_request_param.dart';
import 'package:nextry_dev/domain/entities/delivery/offer_entity.dart';
import 'package:nextry_dev/domain/entities/delivery/shipper_entity.dart';
import 'package:nextry_dev/domain/entities/error/common_errors.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';

class FetchShipperDeliveryOfferGateWay
    implements
        ReadGateWay<FetchShipperDeliveryOfferResponseEntity,
            FetchShipperDeliveryRequestParam> {
  @override
  Future<FetchShipperDeliveryOfferResponseEntity> read(
      FetchShipperDeliveryRequestParam param) async {
    try {
      var offerRef = FirebaseFirestore.instance
          .collection(GateWayConstants.TABLE_DELIVERY_REQUEST)
          .doc(param.requestId)
          .collection(GateWayConstants.TABLE_DELIVERY_OFFER)
          .where(GateWayConstants.FIELD_OFFER_REQUEST_SHIPPER_ID,
              isEqualTo: param.shipperId);

      final snapshot = await offerRef.get();
      List<OfferEntity> offerEntityList = [];
      for (var element in snapshot.docs) {
        if (element.exists) {
          offerEntityList.add(OfferEntity.fromJSON(
              element.data(), element.id, ShipperEntity()));
        }
      }

      return FetchShipperDeliveryOfferResponseEntity(
          offersEntity: offerEntityList[0]);
    } catch (e) {
      print(e);
      return FetchShipperDeliveryOfferResponseEntity(
          commonErrors: CommonErrors.fromJson({}));
    }
  }

  @override
  void unsubscribe() {
    // TODO: implement unsubscribe
  }
}
