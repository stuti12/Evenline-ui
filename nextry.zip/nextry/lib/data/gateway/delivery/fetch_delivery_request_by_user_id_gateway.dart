import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/domain/entities/delivery/delivery_request_entity.dart';
import 'package:nextry_dev/domain/entities/delivery/fetch_delivery_request_param.dart';
import 'package:nextry_dev/domain/entities/delivery/fetch_delivery_request_response_entity.dart';
import 'package:nextry_dev/domain/entities/error/common_errors.dart';
import 'package:nextry_dev/domain/entities/profile/user_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';

class FetchDeliveryRequestByUserIdGateWay
    implements
        ReadGateWay<FetchDeliveryRequestResponseEntity,
            FetchDeliveryRequestParam> {
  StreamSubscription<QuerySnapshot<Map<String, dynamic>>>? streamSubscription;

  @override
  Future<FetchDeliveryRequestResponseEntity> read(
      FetchDeliveryRequestParam param) async {
    try {
      final userId = FirebaseAuth.instance.currentUser?.uid;
      var deliveryRequestRef = FirebaseFirestore.instance
          .collection(GateWayConstants.TABLE_DELIVERY_REQUEST)
          .where(GateWayConstants.FIELD_USER_ID, isEqualTo: userId)
          .orderBy(GateWayConstants.FIELD_CREATED_AT, descending: true);

      final snapshots = await deliveryRequestRef.get();
      streamSubscription?.cancel();
      streamSubscription = deliveryRequestRef.snapshots().listen((event) async {
        if (param.function != null) {
          param.function!(await _fetchDeliveryRequests(event));
        }
      });
      return FetchDeliveryRequestResponseEntity(
          deliveryRequestList: await _fetchDeliveryRequests(snapshots));
    } catch (e) {
      print(e);
      return FetchDeliveryRequestResponseEntity(
          commonErrors: CommonErrors.fromJson({}));
    }
  }

  Future<List<DeliveryRequestEntity>> _fetchDeliveryRequests(
      QuerySnapshot<Map<String, dynamic>> snapshot) async {
    List<DeliveryRequestEntity> deliveryRequestList = [];
    for (var element in snapshot.docs) {
      if (element.exists) {
        var data = element.data();
        final userEntity =
            await _fetchUserData(data[GateWayConstants.FIELD_USER_ID]);
        deliveryRequestList
            .add(DeliveryRequestEntity.fromJSON(data, element.id, userEntity));
      }
    }
    return deliveryRequestList;
  }

  Future<UserEntity?> _fetchUserData(String? userId) async {
    var snapshot = await FirebaseFirestore.instance
        .collection(GateWayConstants.TABLE_USERS)
        .doc(userId)
        .get();
    if (snapshot.exists) {
      var data = snapshot.data();
      if (data != null) {
        return UserEntity.fromJson(data, snapshot.id);
      }
    }
    return null;
  }

  @override
  void unsubscribe() {
    streamSubscription?.cancel();
  }
}
