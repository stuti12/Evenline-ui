import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/data/gateway/common/upload_file_helper.dart';
import 'package:nextry_dev/domain/entities/delivery/add_report_customers_param.dart';
import 'package:nextry_dev/domain/entities/delivery/add_report_customers_response_entity.dart';
import 'package:nextry_dev/domain/entities/error/common_errors.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/presentation/common/utils/app_constants.dart';

class AddReportCustomersGateway
    implements
        ReadGateWay<AddReportCustomersResponseEntity, AddReportCustomersParam> {
  @override
  Future<AddReportCustomersResponseEntity> read(
      AddReportCustomersParam data) async {
    try {
      final profileDocId = FirebaseAuth.instance.currentUser?.uid;
      if (data.attachedFiles != null && data.attachedFiles!.isNotEmpty) {
        for (var i = 0; i < data.attachedFiles!.length; i++) {
          String mediaFile = data.attachedFiles![i];
          if (mediaFile.isNotEmpty &&
              !mediaFile.startsWith(AppConstants.SERVER_FILE)) {
            final serverURL =
                await UploadFileHelper().uploadFileToFireStore(mediaFile);
            data.attachedFiles![i] = serverURL;
          }
        }
      }
      await FirebaseFirestore.instance
          .collection(GateWayConstants.TABLE_REPORT_CUSTOMERS)
          .add(data.toJson(userId: profileDocId));

      return AddReportCustomersResponseEntity(isSuccess: true);
    } catch (e) {
      print(e);
      return AddReportCustomersResponseEntity(
          commonErrors: CommonErrors.fromJson({}));
    }
  }

  @override
  void unsubscribe() {}
}
