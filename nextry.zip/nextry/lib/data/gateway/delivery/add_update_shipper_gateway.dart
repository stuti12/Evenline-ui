import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/data/gateway/common/upload_file_helper.dart';
import 'package:nextry_dev/domain/entities/delivery/add_update_shipper_param.dart';
import 'package:nextry_dev/domain/entities/delivery/add_update_shipper_response_entity.dart';
import 'package:nextry_dev/domain/entities/error/common_errors.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/presentation/common/utils/app_constants.dart';

class AddUpdateShipperGateway
    implements
        ReadGateWay<AddUpdateShipperResponseEntity, AddUpdateShipperParam> {
  @override
  Future<AddUpdateShipperResponseEntity> read(
      AddUpdateShipperParam data) async {
    try {
      if (data.shipperEntity.profileUrl != null &&
          data.shipperEntity.profileUrl!.isNotEmpty) {
        String mediaFile = data.shipperEntity.profileUrl!;
        if (mediaFile.isNotEmpty &&
            !mediaFile.startsWith(AppConstants.SERVER_FILE)) {
          final serverURL =
              await UploadFileHelper().uploadFileToFireStore(mediaFile);
          data.shipperEntity.profileUrl = serverURL;
        }
      }
      final userId = FirebaseAuth.instance.currentUser?.uid;
      await FirebaseFirestore.instance
          .collection(GateWayConstants.TABLE_SHIPPERS)
          .doc(userId)
          .set(data.shipperEntity.toJson(), SetOptions(merge: true));

      return AddUpdateShipperResponseEntity(isSuccess: true, shipperId: userId);
    } catch (e) {
      print(e);
      return AddUpdateShipperResponseEntity(
          commonErrors: CommonErrors.fromJson({}));
    }
  }

  @override
  void unsubscribe() {}
}
