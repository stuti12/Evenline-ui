import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/domain/entities/delivery/fetch_delivery_offer_response_entity.dart';
import 'package:nextry_dev/domain/entities/delivery/fetch_delivery_request_param.dart';
import 'package:nextry_dev/domain/entities/delivery/offer_entity.dart';
import 'package:nextry_dev/domain/entities/delivery/shipper_entity.dart';
import 'package:nextry_dev/domain/entities/delivery/shipper_feedback_entity.dart';
import 'package:nextry_dev/domain/entities/error/common_errors.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';

class FetchDeliveryOfferGateWay
    implements
        ReadGateWay<FetchDeliveryOfferResponseEntity,
            FetchDeliveryRequestParam> {
  StreamSubscription<QuerySnapshot<Map<String, dynamic>>>? streamSubscription;

  @override
  Future<FetchDeliveryOfferResponseEntity> read(
      FetchDeliveryRequestParam param) async {
    try {
      var offerRef = FirebaseFirestore.instance
          .collection(GateWayConstants.TABLE_DELIVERY_REQUEST)
          .doc(param.requestId)
          .collection(GateWayConstants.TABLE_DELIVERY_OFFER);

      streamSubscription?.cancel();
      streamSubscription = offerRef.snapshots().listen((event) async {
        if (param.function != null) {
          param.function!(await _parseOfferData(event));
        }
      });
      final snapshot = await offerRef.get();
      List<OfferEntity> offersList = await _parseOfferData(snapshot);

      return FetchDeliveryOfferResponseEntity(offersList: offersList);
    } catch (e) {
      print(e);
      return FetchDeliveryOfferResponseEntity(
          commonErrors: CommonErrors.fromJson({}));
    }
  }

  _parseOfferData(QuerySnapshot<Map<String, dynamic>> snapshot) async {
    List<OfferEntity> offersList = [];
    for (var element in snapshot.docs) {
      if (element.exists) {
        var data = element.data();
        final shipperEntity = await _fetchShipperData(
            data[GateWayConstants.FIELD_DELIVERY_OFFER_SHIPPER_ID]);
        offersList.add(OfferEntity.fromJSON(data, element.id, shipperEntity));
      }
    }
    return offersList;
  }


  Future<ShipperEntity?> _fetchShipperData(String? shipperId) async {
    var snapshot = await FirebaseFirestore.instance
        .collection(GateWayConstants.TABLE_SHIPPERS)
        .doc(shipperId)
        .get();
    if (snapshot.exists) {
      var data = snapshot.data();
      if (data != null) {
        ShipperEntity? shipperEntity = ShipperEntity.fromJSON(data, snapshot.id);
        shipperEntity = await _fetchShipperFeedbackData(shipperEntity);
        return shipperEntity;
      }
    }
    return null;
  }

  @override
  void unsubscribe() {}

  Future<ShipperEntity?> _fetchShipperFeedbackData(ShipperEntity? shipperEntity) async {
    var snapshot = await FirebaseFirestore.instance
        .collection(GateWayConstants.TABLE_SHIPPERS)
        .doc(shipperEntity?.id)
        .collection(GateWayConstants.TABLE_REVIEWS)
        .get();
    double totalRating = 0.0;
    for (var element in snapshot.docs) {
      if (element.exists) {
        var data = element.data();
        totalRating = totalRating + data[GateWayConstants.FIELD_RATING];
      }
    }
    if (snapshot.docs.isNotEmpty) {
      totalRating = totalRating / snapshot.docs.length;
    }
    shipperEntity?.totalRating = double.parse(totalRating.toStringAsFixed(1));
    shipperEntity?.ratingCount = snapshot.docs.length;
    return shipperEntity;
  }
}
