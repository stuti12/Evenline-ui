import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/domain/entities/delivery/fetch_shipper_data_by_id_param.dart';
import 'package:nextry_dev/domain/entities/delivery/fetch_shipper_information_response_entity.dart';
import 'package:nextry_dev/domain/entities/delivery/shipper_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';

class FetchShipperDataByIdGateway
    implements ReadGateWay<FetchShipperInformationResponseEntity, FetchShipperDataByIdParam> {

  StreamSubscription<DocumentSnapshot<Map<String, dynamic>>>? streamSubscription;

  @override
  Future<FetchShipperInformationResponseEntity> read(FetchShipperDataByIdParam param) async {
    try {
      var shipperRef = FirebaseFirestore.instance
          .collection(GateWayConstants.TABLE_SHIPPERS)
          .doc(param.shipperId);

      streamSubscription?.cancel();
      streamSubscription = shipperRef.snapshots().listen((event) async {
        if (param.function != null) {
          param.function!(_parseShipperData(event));
        }
      });

      var snapshot = await shipperRef.get();
      if (snapshot.exists) {
        var data = snapshot.data();
        if (data != null) {
          return FetchShipperInformationResponseEntity(shipperEntity: ShipperEntity.fromJSON(data, snapshot.id), commonErrors: null);
        }
      }
      return FetchShipperInformationResponseEntity(shipperEntity: ShipperEntity(), commonErrors: null);
    } catch (e) {
      print(e);
      return FetchShipperInformationResponseEntity(shipperEntity: null, commonErrors: null);
    }
  }

  @override
  void unsubscribe() {}

  ShipperEntity? _parseShipperData(
      DocumentSnapshot<Map<String, dynamic>> snapshot) {
    if (snapshot.exists) {
      var data = snapshot.data();
      if (data != null) {
        return ShipperEntity.fromJSON(data, snapshot.id);
      }
    }
    return null;
  }
}
