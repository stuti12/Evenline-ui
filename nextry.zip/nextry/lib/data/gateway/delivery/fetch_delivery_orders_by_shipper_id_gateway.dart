import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/domain/entities/delivery/fetch_delivery_order_by_filter_response_entity.dart';
import 'package:nextry_dev/domain/entities/delivery/fetch_delivery_order_by_shipper_id_param.dart';
import 'package:nextry_dev/domain/entities/delivery/order_detail_entity.dart';
import 'package:nextry_dev/domain/entities/error/common_errors.dart';
import 'package:nextry_dev/domain/entities/profile/user_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';

class FetchDeliveryOrdersByShipperIdGateWay
    implements
        ReadGateWay<FetchDeliveryOrderByFilterResponseEntity,
            FetchDeliveryOrderByShipperIdParam> {
  StreamSubscription<QuerySnapshot<Map<String, dynamic>>>? streamSubscription;

  @override
  Future<FetchDeliveryOrderByFilterResponseEntity> read(
      FetchDeliveryOrderByShipperIdParam param) async {
    try {
      final userId = FirebaseAuth.instance.currentUser?.uid;
      var orderRequestRef = FirebaseFirestore.instance
          .collection(GateWayConstants.TABLE_DELIVERY_ORDERS)
          .where(GateWayConstants.FIELD_OFFER_REQUEST_SHIPPER_ID,
              isEqualTo: userId)
          .where(GateWayConstants.FIELD_DELIVERY_ORDERS_CURRENT_STATUS,
              isEqualTo: param.status);

      // streamSubscription?.cancel();
      streamSubscription = orderRequestRef.snapshots().listen((event) async {
        if (param.function != null) {
          param.function!(await _parseDeliveryOrderData(event));
        }
      });
      var snapshot = await orderRequestRef.get();
      var orderDetailsList = await _parseDeliveryOrderData(snapshot);

      return FetchDeliveryOrderByFilterResponseEntity(
          orderDetails: orderDetailsList);
    } catch (e) {
      print(e);
      return FetchDeliveryOrderByFilterResponseEntity(
          commonErrors: CommonErrors.fromJson({}));
    }
  }

  Future<List<OrderDetailEntity>> _parseDeliveryOrderData(
      QuerySnapshot<Map<String, dynamic>> event) async {
    List<OrderDetailEntity> orderDetailsList = [];
    for (var element in event.docs) {
      if (element.exists) {
        var data = element.data();
        final orderDetailEntity = OrderDetailEntity.fromJSON(data, element.id);
        if(orderDetailEntity.customerId != null && orderDetailEntity.customerId?.isNotEmpty == true) {
          orderDetailEntity.customerEntity =
          await _fetchUserData(orderDetailEntity.customerId);
        }
        orderDetailsList.add(orderDetailEntity);
      }
    }
    if (orderDetailsList.isNotEmpty) {
      orderDetailsList.sort((a, b) => a.offerCreatedAt == null
          ? 1
          : b.offerCreatedAt == null
              ? -1
              : b.offerCreatedAt!.compareTo(a.offerCreatedAt!));
    }
    return orderDetailsList;
  }

  Future<UserEntity?> _fetchUserData(String? userId) async {
    var snapshot = await FirebaseFirestore.instance
        .collection(GateWayConstants.TABLE_USERS)
        .doc(userId)
        .get();
    if (snapshot.exists) {
      var data = snapshot.data();
      if (data != null) {
        return UserEntity.fromJson(data, snapshot.id);
      }
    }
    return null;
  }

  @override
  void unsubscribe() {
    streamSubscription?.cancel();
  }
}
