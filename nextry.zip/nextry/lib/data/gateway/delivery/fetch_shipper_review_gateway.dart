import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/domain/entities/delivery/fetch_shipper_review_response_entity.dart';
import 'package:nextry_dev/domain/entities/delivery/shipper_feedback_entity.dart';
import 'package:nextry_dev/domain/entities/error/common_errors.dart';
import 'package:nextry_dev/domain/entities/feedback/feedback_entity.dart';
import 'package:nextry_dev/domain/entities/profile/user_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';

class FetchShipperReviewGateway
    implements
        ReadGateWay<FetchShipperReviewResponseEntity, String> {
  @override
  Future<FetchShipperReviewResponseEntity> read(
      String shipperId) async {
    try {
      var snapshot = await FirebaseFirestore.instance
          .collection(GateWayConstants.TABLE_SHIPPERS)
          .doc(shipperId)
          .collection(GateWayConstants.TABLE_REVIEWS)
          .get();
      List<FeedbackEntity> shipperReviewList = [];
      double totalRating = 0.0;
      for (var element in snapshot.docs) {
        if (element.exists) {
          var data = element.data();
          totalRating = totalRating + data[GateWayConstants.FIELD_RATING];
          var snapshot = await FirebaseFirestore.instance
              .collection(GateWayConstants.TABLE_SHIPPER_FEEDBACK_REPORTED)
              .where(GateWayConstants.FIELD_ORDER_ID,
              isEqualTo: data[GateWayConstants.FIELD_ORDER_ID])
              .count()
              .get();
          final shipperEntity = FeedbackEntity.fromJson(data, element.id, snapshot.count > 0 ? true : false);
          shipperEntity.userEntity =
              await _fetchUserData(data[GateWayConstants.FIELD_CUSTOMER_ID]);
          shipperReviewList.add(shipperEntity);
        }
      }


      return FetchShipperReviewResponseEntity(
          shipperReviewList: shipperReviewList);
    } catch (e) {
      print(e);
      return FetchShipperReviewResponseEntity(
          commonErrors: CommonErrors.fromJson({}));
    }
  }

  Future<UserEntity?> _fetchUserData(String? userId) async {
    var snapshot = await FirebaseFirestore.instance
        .collection(GateWayConstants.TABLE_USERS)
        .doc(userId)
        .get();
    if (snapshot.exists) {
      var data = snapshot.data();
      if (data != null) {
        return UserEntity.fromJson(data, snapshot.id);
      }
    }
    return null;
  }

  @override
  void unsubscribe() {}
}
