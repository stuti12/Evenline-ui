import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/domain/entities/delivery/shipper_feedback_report_entity.dart';
import 'package:nextry_dev/domain/entities/error/common_errors.dart';
import 'package:nextry_dev/domain/entities/feedback/create_feedback_report_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';

class RequestDeleteShipperFeedbackFeedbackGateway
    implements
        ReadGateWay<CreateFeedbackReportResponseEntity,
            ShipperFeedbackReportEntity> {
  @override
  Future<CreateFeedbackReportResponseEntity> read(
      ShipperFeedbackReportEntity param) async {
    try {
      await FirebaseFirestore.instance
          .collection(GateWayConstants.TABLE_SHIPPER_FEEDBACK_REPORTED)
          .add(param.toJson());

      return CreateFeedbackReportResponseEntity(isSuccess: true);
    } catch (e) {
      print(e);
      return CreateFeedbackReportResponseEntity(
          isSuccess: false, commonErrors: CommonErrors.fromJson({}));
    }
  }

  @override
  void unsubscribe() {}
}
