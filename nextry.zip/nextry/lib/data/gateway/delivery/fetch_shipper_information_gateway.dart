import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/domain/entities/delivery/fetch_shipper_information_response_entity.dart';
import 'package:nextry_dev/domain/entities/delivery/shipper_entity.dart';
import 'package:nextry_dev/domain/entities/error/common_errors.dart';
import 'package:nextry_dev/domain/gateway/read_gateway_no_args.dart';

class FetchShipperInformationGateway
    implements ReadGateWayNoArgs<FetchShipperInformationResponseEntity> {
  @override
  Future<FetchShipperInformationResponseEntity> read() async {
    try {
      final userId = FirebaseAuth.instance.currentUser?.uid;
      var snapshot = await FirebaseFirestore.instance
          .collection(GateWayConstants.TABLE_SHIPPERS)
          .doc(userId)
          .get();
      ShipperEntity? shipperEntity;
      if (snapshot.exists) {
        var data = snapshot.data();
        if (data != null) {
          shipperEntity = ShipperEntity.fromJSON(data, snapshot.id);
        }
      }
      return FetchShipperInformationResponseEntity(
          shipperEntity: shipperEntity);
    } catch (e) {
      print(e);
      return FetchShipperInformationResponseEntity(
          commonErrors: CommonErrors.fromJson({}));
    }
  }

  @override
  void dispose() {}
}
