import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:geoflutterfire2/geoflutterfire2.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/domain/entities/delivery/update_shipper_current_location_param.dart';
import 'package:nextry_dev/domain/entities/delivery/update_shipper_current_location_response_entity.dart';
import 'package:nextry_dev/domain/entities/error/common_errors.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';

class UpdateShipperCurrentLocationGateway
    implements
        ReadGateWay<UpdateShipperCurrentLocationResponseEntity,
            UpdateShipperCurrentLocationParam> {
  @override
  Future<UpdateShipperCurrentLocationResponseEntity> read(
      UpdateShipperCurrentLocationParam data) async {
    try {
      final Map<String, dynamic> param = <String, dynamic>{};
      param[GateWayConstants.FIELD_TABLE_SHIPPERS_CURRENT_LOCATION] =
          GeoFlutterFire()
              .point(
                  latitude: data.currentLocation.latitude,
                  longitude: data.currentLocation.longitude)
              .data;

      final userId = FirebaseAuth.instance.currentUser?.uid;
      await FirebaseFirestore.instance
          .collection(GateWayConstants.TABLE_SHIPPERS)
          .doc(userId)
          .set(param, SetOptions(merge: true));

      return UpdateShipperCurrentLocationResponseEntity(isSuccess: true);
    } catch (e) {
      print(e);
      return UpdateShipperCurrentLocationResponseEntity(
          commonErrors: CommonErrors.fromJson({}));
    }
  }

  @override
  void unsubscribe() {}
}
