import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/domain/entities/delivery/fetch_delivery_order_by_filter_param.dart';
import 'package:nextry_dev/domain/entities/delivery/fetch_delivery_order_by_filter_response_entity.dart';
import 'package:nextry_dev/domain/entities/delivery/order_detail_entity.dart';
import 'package:nextry_dev/domain/entities/delivery/shipper_entity.dart';
import 'package:nextry_dev/domain/entities/error/common_errors.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/presentation/common/utils/app_extension.dart';

class FetchDeliveryOrdersByFilterGateWay
    implements
        ReadGateWay<FetchDeliveryOrderByFilterResponseEntity,
            FetchDeliveryOrderByFilterParam> {
  StreamSubscription<QuerySnapshot<Map<String, dynamic>>>? streamSubscription;

  @override
  Future<FetchDeliveryOrderByFilterResponseEntity> read(
      FetchDeliveryOrderByFilterParam param) async {
    try {
      final userId = FirebaseAuth.instance.currentUser?.uid;
      var orderRequestRef = FirebaseFirestore.instance
          .collection(GateWayConstants.TABLE_DELIVERY_ORDERS)
          .where(GateWayConstants.FIELD_CUSTOMER_ID, isEqualTo: userId)
          .where(GateWayConstants.FIELD_DELIVERY_ORDERS_CURRENT_STATUS,
              isEqualTo: param.status);

      final snapshots = await orderRequestRef.get();

      streamSubscription?.cancel();
      streamSubscription = orderRequestRef.snapshots().listen((event) async {
        if (param.function != null) {
          param.function!(await _fetchDeliveryOrders(event));
        }
      });

      return FetchDeliveryOrderByFilterResponseEntity(
          orderDetails: await _fetchDeliveryOrders(snapshots));
    } catch (e) {
      print(e);
      return FetchDeliveryOrderByFilterResponseEntity(
          commonErrors: CommonErrors.fromJson({}));
    }
  }

  Future<List<OrderDetailEntity>> _fetchDeliveryOrders(
      QuerySnapshot<Map<String, dynamic>> snapshots) async {
    List<OrderDetailEntity> orderDetailsList = [];
    for (var element in snapshots.docs) {
      if (element.exists) {
        var data = element.data();
        final orderEntity = OrderDetailEntity.fromJSON(data, element.id);
        if(orderEntity.shipperId.isNullOrEmpty() == false) {
          orderEntity.shipperEntity =
          await _fetchShipperData(orderEntity.shipperId);
        }
        orderDetailsList.add(orderEntity);
      }
    }
    return orderDetailsList;
  }

  Future<ShipperEntity?> _fetchShipperData(String? shipperId) async {
    var snapshot = await FirebaseFirestore.instance
        .collection(GateWayConstants.TABLE_SHIPPERS)
        .doc(shipperId)
        .get();
    if (snapshot.exists) {
      var data = snapshot.data();
      if (data != null) {
        return ShipperEntity.fromJSON(data, snapshot.id);
      }
    }
    return null;
  }

  @override
  void unsubscribe() {
    streamSubscription?.cancel();
  }
}
