import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/data/gateway/common/upload_file_helper.dart';
import 'package:nextry_dev/domain/entities/delivery/add_delivery_request_param.dart';
import 'package:nextry_dev/domain/entities/delivery/add_delivery_request_response_entity.dart';
import 'package:nextry_dev/domain/entities/error/common_errors.dart';
import 'package:nextry_dev/domain/entities/profile/user_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/presentation/common/utils/app_constants.dart';

class AddDeliveryRequestGateway
    implements
        ReadGateWay<AddDeliveryRequestResponseEntity, AddDeliveryRequestParam> {
  @override
  Future<AddDeliveryRequestResponseEntity> read(
      AddDeliveryRequestParam data) async {
    try {
      final profileDocId = FirebaseAuth.instance.currentUser?.uid;

      data.deliveryRequestEntity.userEntity ??= UserEntity(docId: profileDocId);

      if (data.deliveryRequestEntity.image != null &&
          data.deliveryRequestEntity.image!.isNotEmpty &&
          !data.deliveryRequestEntity.image!
              .startsWith(AppConstants.SERVER_FILE)) {
        data.deliveryRequestEntity.image = await UploadFileHelper()
            .uploadFileToFireStore(data.deliveryRequestEntity.image!);
      }

      final refId = await FirebaseFirestore.instance
          .collection(GateWayConstants.TABLE_DELIVERY_REQUEST)
          .add(data.deliveryRequestEntity.toJson());

      return AddDeliveryRequestResponseEntity(isSuccess: true, docId: refId.id);
    } catch (e) {
      print(e);
      return AddDeliveryRequestResponseEntity(
          commonErrors: CommonErrors.fromJson({}));
    }
  }

  @override
  void unsubscribe() {}
}
