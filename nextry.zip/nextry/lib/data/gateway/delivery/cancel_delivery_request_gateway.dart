import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/domain/entities/delivery/add_delivery_request_response_entity.dart';
import 'package:nextry_dev/domain/entities/delivery/cancel_delivery_request_param.dart';
import 'package:nextry_dev/domain/entities/error/common_errors.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';

class CancelDeliveryRequestGateway
    implements
        ReadGateWay<AddDeliveryRequestResponseEntity,
            CancelDeliveryRequestParam> {
  @override
  Future<AddDeliveryRequestResponseEntity> read(
      CancelDeliveryRequestParam data) async {
    try {
      await FirebaseFirestore.instance
          .collection(GateWayConstants.TABLE_DELIVERY_REQUEST)
          .doc(data.requestedId)
          .delete();
      return AddDeliveryRequestResponseEntity(isSuccess: true);
    } catch (e) {
      print(e);
      return AddDeliveryRequestResponseEntity(
          commonErrors: CommonErrors.fromJson({}));
    }
  }

  @override
  void unsubscribe() {}
}
