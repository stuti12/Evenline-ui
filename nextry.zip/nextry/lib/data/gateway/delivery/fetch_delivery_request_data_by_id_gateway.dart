import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/domain/entities/delivery/delivery_request_entity.dart';
import 'package:nextry_dev/domain/entities/delivery/fetch_delivery_request_entity.dart';
import 'package:nextry_dev/domain/entities/delivery/fetch_shipper_data_by_id_param.dart';
import 'package:nextry_dev/domain/entities/delivery/fetch_shipper_information_response_entity.dart';
import 'package:nextry_dev/domain/entities/delivery/shipper_entity.dart';
import 'package:nextry_dev/domain/entities/profile/user_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';

class FetchDeliveryRequestDataByIdGateway
    implements ReadGateWay<FetchDeliveryRequestEntity, String> {
  @override
  Future<FetchDeliveryRequestEntity> read(String deliveryRequestId) async {
    try {
      var shipperRef = FirebaseFirestore.instance
          .collection(GateWayConstants.TABLE_DELIVERY_REQUEST)
          .doc(deliveryRequestId);

      var snapshot = await shipperRef.get();
      var deliveryRequestEntity = await _fetchDeliveryRequests(snapshot);
      return FetchDeliveryRequestEntity(
          deliveryRequestList: deliveryRequestEntity, commonErrors: null);
    } catch (e) {
      print(e);
      return FetchDeliveryRequestEntity(
          deliveryRequestList: null, commonErrors: null);
    }
  }

  Future<DeliveryRequestEntity?> _fetchDeliveryRequests(
      DocumentSnapshot<Map<String, dynamic>> snapshot) async {
    DeliveryRequestEntity? deliveryRequestList;
    if (snapshot.exists) {
      var data = snapshot.data();
      final userEntity =
          await _fetchUserData(data?[GateWayConstants.FIELD_USER_ID]);
      deliveryRequestList =
          DeliveryRequestEntity.fromJSON(data!, snapshot.id, userEntity);
    }

    return deliveryRequestList;
  }

  Future<UserEntity?> _fetchUserData(String? userId) async {
    var snapshot = await FirebaseFirestore.instance
        .collection(GateWayConstants.TABLE_USERS)
        .doc(userId)
        .get();
    if (snapshot.exists) {
      var data = snapshot.data();
      if (data != null) {
        return UserEntity.fromJson(data, snapshot.id);
      }
    }
    return null;
  }

  @override
  void unsubscribe() {}
}
