import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/domain/entities/delivery/add_delivery_orders_param.dart';
import 'package:nextry_dev/domain/entities/delivery/add_delivery_orders_response_entity.dart';
import 'package:nextry_dev/domain/entities/error/common_errors.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';

class AddDeliveryOrdersGateway
    implements
        ReadGateWay<AddDeliveryOrdersResponseEntity, AddDeliveryOrdersParam> {
  @override
  Future<AddDeliveryOrdersResponseEntity> read(
      AddDeliveryOrdersParam data) async {
    try {
      final profileDocId = FirebaseAuth.instance.currentUser?.uid;
      final shipperId = data.orderDetailEntity?.shipperId;

      final deliveryOrdersRef = await FirebaseFirestore.instance
          .collection(GateWayConstants.TABLE_DELIVERY_ORDERS)
          .add(data.orderDetailEntity?.toJson(userId: profileDocId) ?? {});

      await Future.wait([
        _addMyDeliveryOrdersForShipper(
            profileDocId, deliveryOrdersRef.id, shipperId),
        _addMyDeliveryOrdersForUser(
            profileDocId, deliveryOrdersRef.id, shipperId),
        _removeDeliveryRequest(
            data.orderDetailEntity?.deliveryRequestEntity?.id ?? ''),
      ]);

      return AddDeliveryOrdersResponseEntity(
          isSuccess: true, docId: deliveryOrdersRef.id);
    } catch (e) {
      print(e);
      return AddDeliveryOrdersResponseEntity(
          commonErrors: CommonErrors.fromJson({}));
    }
  }

  Future<void> _addMyDeliveryOrdersForShipper(
      String? customerId, String orderId, String? shipperId) async {
    final Map<String, dynamic> param = <String, dynamic>{};
    param[GateWayConstants.FIELD_CUSTOMER_ID] = customerId;
    param[GateWayConstants.FIELD_ORDER_ID] = orderId;
    await FirebaseFirestore.instance
        .collection(GateWayConstants.TABLE_SHIPPERS)
        .doc(shipperId)
        .collection(GateWayConstants.TABLE_MY_DELIVERY_ORDERS)
        .add(param);
  }

  Future<void> _addMyDeliveryOrdersForUser(
      String? customerId, String orderId, String? shipperId) async {
    final Map<String, dynamic> param = <String, dynamic>{};
    param[GateWayConstants.FIELD_DELIVERY_OFFER_SHIPPER_ID] = shipperId;
    param[GateWayConstants.FIELD_ORDER_ID] = orderId;
    await FirebaseFirestore.instance
        .collection(GateWayConstants.TABLE_USERS)
        .doc(customerId)
        .collection(GateWayConstants.TABLE_MY_DELIVERY_ORDERS)
        .add(param);
  }

  Future<void> _removeDeliveryRequest(String requestId) async {
    await FirebaseFirestore.instance
        .collection(GateWayConstants.TABLE_DELIVERY_REQUEST)
        .doc(requestId)
        .delete();
  }

  @override
  void unsubscribe() {}
}
