import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:geoflutterfire2/geoflutterfire2.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/domain/entities/delivery/delivery_request_entity.dart';
import 'package:nextry_dev/domain/entities/delivery/fetch_delivery_request_param.dart';
import 'package:nextry_dev/domain/entities/delivery/fetch_delivery_request_response_entity.dart';
import 'package:nextry_dev/domain/entities/delivery/offer_entity.dart';
import 'package:nextry_dev/domain/entities/error/common_errors.dart';
import 'package:nextry_dev/domain/entities/profile/user_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:rxdart/subjects.dart';
import 'package:rxdart/transformers.dart';

///  Its for Supplier to fetch request which is exist on their radius.
class FetchDeliveryRequestGateWay
    implements
        ReadGateWay<FetchDeliveryRequestResponseEntity,
            FetchDeliveryRequestParam> {

  StreamSubscription? subscription;

  @override
  Future<FetchDeliveryRequestResponseEntity> read(
      FetchDeliveryRequestParam param) async {
    try {
      final loginUserId = FirebaseAuth.instance.currentUser?.uid;
      var deliveryOfferRef = FirebaseFirestore.instance
          .collection(GateWayConstants.TABLE_DELIVERY_REQUEST);

      final radius = BehaviorSubject<double>.seeded(param.radius.toDouble());
      GeoFirePoint center = GeoFlutterFire().point(
          latitude: param.location?.latitude ?? 0.0,
          longitude: param.location?.longitude ?? 0.0);
      Stream<List<DocumentSnapshot>> stream = radius.switchMap((rad) {
        return GeoFlutterFire()
            .collection(collectionRef: deliveryOfferRef)
            .within(
              center: center,
              radius: rad,
              field: GateWayConstants.FIELD_DELIVERY_REQUEST_SOURCE_LOCATION,
              strictMode: true,
            );
      });

      await subscription?.cancel();

      subscription = stream.listen((List<DocumentSnapshot> documentList) async {
        List<DeliveryRequestEntity> deliveryRequestList = [];
        for (var element in documentList) {
          if (element.exists) {
            var data = element.data() as Map<String, dynamic>;
            final userEntity =
                await _fetchUserData(data[GateWayConstants.FIELD_USER_ID]);
            final deliveryRequestEntity =
                DeliveryRequestEntity.fromJSON(data, element.id, userEntity);
            deliveryRequestEntity.offerEntity =
                await _fetchMyOfferByRequest(loginUserId, element.id);

            if (deliveryRequestEntity.shipperIds
                    ?.contains(FirebaseAuth.instance.currentUser?.uid) ==
                null) {
              deliveryRequestEntity.isOfferSent = false;
            } else {
              deliveryRequestEntity.isOfferSent = deliveryRequestEntity
                  .shipperIds
                  ?.contains(FirebaseAuth.instance.currentUser?.uid);
            }
            deliveryRequestList.add(deliveryRequestEntity);
          }
        }
        deliveryRequestList.sort((a, b) => a.createdAt == null
            ? 1
            : b.createdAt == null
            ? -1
            : b.createdAt!.compareTo(a.createdAt!));
        if (param.function != null) param.function!(deliveryRequestList);
      });

      return FetchDeliveryRequestResponseEntity(deliveryRequestList: []);
    } catch (e) {
      print(e);
      return FetchDeliveryRequestResponseEntity(
          commonErrors: CommonErrors.fromJson({}));
    }
  }

  Future<UserEntity?> _fetchUserData(String? userId) async {
    var snapshot = await FirebaseFirestore.instance
        .collection(GateWayConstants.TABLE_USERS)
        .doc(userId)
        .get();
    if (snapshot.exists) {
      var data = snapshot.data();
      if (data != null) {
        return UserEntity.fromJson(data, snapshot.id);
      }
    }
    return null;
  }

  Future<OfferEntity?> _fetchMyOfferByRequest(
      String? userId, String? requestId) async {
    OfferEntity? offerEntity;
    final snapshots = await FirebaseFirestore.instance
        .collection(GateWayConstants.TABLE_DELIVERY_REQUEST)
        .doc(requestId)
        .collection(GateWayConstants.TABLE_DELIVERY_OFFER)
        .where(GateWayConstants.FIELD_USER_ID, isEqualTo: userId)
        .limit(1)
        .get();
    for (var element in snapshots.docs) {
      if (element.exists) {
        var data = element.data();
        offerEntity = OfferEntity.fromJSON(data, element.id, null);
      }
    }

    return offerEntity;
  }

  @override
  void unsubscribe() {
    subscription?.cancel();
  }
}
