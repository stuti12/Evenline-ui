import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/domain/entities/delivery/fetch_delivery_order_detail_param.dart';
import 'package:nextry_dev/domain/entities/delivery/fetch_delivery_order_detail_response_entity.dart';
import 'package:nextry_dev/domain/entities/delivery/order_detail_entity.dart';
import 'package:nextry_dev/domain/entities/delivery/shipper_entity.dart';
import 'package:nextry_dev/domain/entities/error/common_errors.dart';
import 'package:nextry_dev/domain/entities/profile/user_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';

class FetchDeliveryOrderDetailGateWay
    implements
        ReadGateWay<FetchDeliveryOrderDetailResponseEntity,
            FetchDeliveryOrderDetailParam> {
  StreamSubscription<DocumentSnapshot<Map<String, dynamic>>>?
      streamSubscription;

  @override
  Future<FetchDeliveryOrderDetailResponseEntity> read(
      FetchDeliveryOrderDetailParam param) async {
    try {
      var orderRequestRef = FirebaseFirestore.instance
          .collection(GateWayConstants.TABLE_DELIVERY_ORDERS)
          .doc(param.orderId);
      // .get();

      streamSubscription?.cancel();
      streamSubscription = orderRequestRef.snapshots().listen((event) async {
        if (param.function != null) {
          param.function!(await _parseOrdersData(event));
        }
      });

      var snapshot = await orderRequestRef.get();

      OrderDetailEntity? orderDetailEntity;
      if (snapshot.exists) {
        var data = snapshot.data();
        if (data != null) {
          orderDetailEntity = OrderDetailEntity.fromJSON(data, param.orderId);
          orderDetailEntity.shipperEntity =
              await _fetchShipperData(orderDetailEntity.shipperId);
          orderDetailEntity.customerEntity =
              await _fetchUserData(orderDetailEntity.customerId);
        }
      }
      return FetchDeliveryOrderDetailResponseEntity(
          orderDetailEntity: orderDetailEntity);
    } catch (e) {
      print(e);
      return FetchDeliveryOrderDetailResponseEntity(
          commonErrors: CommonErrors.fromJson({}));
    }
  }

  Future<ShipperEntity?> _fetchShipperData(String? shipperId) async {
    var snapshot = await FirebaseFirestore.instance
        .collection(GateWayConstants.TABLE_SHIPPERS)
        .doc(shipperId)
        .get();
    if (snapshot.exists) {
      var data = snapshot.data();
      if (data != null) {
        return ShipperEntity.fromJSON(data, snapshot.id);
      }
    }
    return null;
  }

  Future<UserEntity?> _fetchUserData(String? userId) async {
    var snapshot = await FirebaseFirestore.instance
        .collection(GateWayConstants.TABLE_USERS)
        .doc(userId)
        .get();
    if (snapshot.exists) {
      var data = snapshot.data();
      if (data != null) {
        return UserEntity.fromJson(data, snapshot.id);
      }
    }
    return null;
  }

  @override
  void unsubscribe() {}

  Future<OrderDetailEntity?> _parseOrdersData(
      DocumentSnapshot<Map<String, dynamic>> snapshot) async {
    if (snapshot.exists) {
      var data = snapshot.data();
      if (data != null) {
        OrderDetailEntity orderDetailEntity =
            OrderDetailEntity.fromJSON(data, snapshot.id);
        orderDetailEntity.shipperEntity =
            await _fetchShipperData(orderDetailEntity.shipperId);
        return orderDetailEntity;
      }
    }
    return null;
  }
}
