import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/domain/entities/delivery/add_shipper_review_response_entity.dart';
import 'package:nextry_dev/domain/entities/error/common_errors.dart';
import 'package:nextry_dev/domain/entities/feedback/feedback_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';

class AddShipperReviewGateway
    implements ReadGateWay<AddShipperReviewResponseEntity, FeedbackEntity> {
  @override
  Future<AddShipperReviewResponseEntity> read(FeedbackEntity data) async {
    try {
      final customerId = FirebaseAuth.instance.currentUser?.uid;
      data.createdAt = Timestamp.now();
      await FirebaseFirestore.instance
          .collection(GateWayConstants.TABLE_SHIPPERS)
          .doc(data.shipperId)
          .collection(GateWayConstants.TABLE_REVIEWS)
          .add(data.toJson(userId: customerId));

      final feedbackData = <String, dynamic>{};
      feedbackData[GateWayConstants.FIELD_ORDER_IS_LEAVE_FEEDBACK] = true;

      await FirebaseFirestore.instance
          .collection(GateWayConstants.TABLE_DELIVERY_ORDERS)
          .doc(data.orderId)
          .set(feedbackData, SetOptions(merge: true));

      return AddShipperReviewResponseEntity(isSuccess: true);
    } catch (e) {
      print(e);
      return AddShipperReviewResponseEntity(
          commonErrors: CommonErrors.fromJson({}));
    }
  }

  @override
  void unsubscribe() {}
}
