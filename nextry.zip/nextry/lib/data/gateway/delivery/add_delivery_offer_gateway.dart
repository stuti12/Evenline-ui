import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/domain/entities/delivery/add_delivery_offer_param.dart';
import 'package:nextry_dev/domain/entities/delivery/add_delivery_offer_response_entity.dart';
import 'package:nextry_dev/domain/entities/error/common_errors.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';

class AddOfferRequestGateway
    implements ReadGateWay<AddDeliveryResponseEntity, AddDeliveryOfferParam> {
  @override
  Future<AddDeliveryResponseEntity> read(AddDeliveryOfferParam data) async {
    try {
      final userId = FirebaseAuth.instance.currentUser?.uid;
      data.offerEntity.userId = userId;

      ///TODO did this change because delivery request deleted and still its not removed from the shipper request screen at that time if shipper tries to send offer for that request it will not allowed
      final response = await FirebaseFirestore.instance
          .collection(GateWayConstants.TABLE_DELIVERY_REQUEST)
          .doc(data.requestId)
          .get();
      if (response.exists) {
        final refId = await FirebaseFirestore.instance
            .collection(GateWayConstants.TABLE_DELIVERY_REQUEST)
            .doc(data.requestId)
            .collection(GateWayConstants.TABLE_DELIVERY_OFFER)
            .add(data.offerEntity.toJson());

        final shipperIds = <String, dynamic>{};
        var shipperList = data.shipperIds ?? [];
        shipperList.add(userId!);
        shipperIds[GateWayConstants.FIELD_NEXTRY_DELIVERY_ORDER_SHIPPER_IDS] =
            shipperList;

        await FirebaseFirestore.instance
            .collection(GateWayConstants.TABLE_DELIVERY_REQUEST)
            .doc(data.requestId)
            .set(shipperIds, SetOptions(merge: true));

        return AddDeliveryResponseEntity(isSuccess: true, docId: refId.id);
      } else {
        return AddDeliveryResponseEntity(
            commonErrors: CommonErrors.fromJson({}));
      }
    } catch (e) {
      print(e);
      return AddDeliveryResponseEntity(commonErrors: CommonErrors.fromJson({}));
    }
  }

  @override
  void unsubscribe() {}
}
