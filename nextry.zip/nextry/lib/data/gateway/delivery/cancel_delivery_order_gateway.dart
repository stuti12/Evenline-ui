import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/domain/entities/delivery/cancel_delivery_order_param.dart';
import 'package:nextry_dev/domain/entities/delivery/update_delivery_order_response_entity.dart';
import 'package:nextry_dev/domain/entities/error/common_errors.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';

class CancelDeliveryOrderGateway
    implements
        ReadGateWay<UpdateDeliveryOrderResponseEntity,
            CancelDeliveryOrderParam> {
  @override
  Future<UpdateDeliveryOrderResponseEntity> read(
      CancelDeliveryOrderParam param) async {
    try {
      final data = <String, dynamic>{};
      data[GateWayConstants.FIELD_DELIVERY_ORDERS_CURRENT_STATUS] =
          param.status;
      data[GateWayConstants.FIELD_DELIVERY_ORDERS_STATUSES] = {
        param.status: Timestamp.now()
      };
      await FirebaseFirestore.instance
          .collection(GateWayConstants.TABLE_DELIVERY_ORDERS)
          .doc(param.orderId)
          .set(data, SetOptions(merge: true));

      return UpdateDeliveryOrderResponseEntity(isSuccess: true);
    } catch (e) {
      print(e);
      return UpdateDeliveryOrderResponseEntity(
          commonErrors: CommonErrors.fromJson({}));
    }
  }

  @override
  void unsubscribe() {}
}
