import 'package:nextry_dev/data/gateway/common/custom_exception.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/data/gateway/common/http_service.dart';
import 'package:nextry_dev/domain/entities/error/common_errors.dart';
import 'package:nextry_dev/domain/entities/subscriptions/cancel_my_subscription_param.dart';
import 'package:nextry_dev/domain/entities/subscriptions/cancel_my_subscription_response_entity.dart';
import 'package:nextry_dev/domain/entities/subscriptions/my_subscriptions_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';

class CancelMySubscriptionGateway
    implements
        ReadGateWay<CancelMySubscriptionResponseEntity,
            CancelMySubscriptionParam> {
  @override
  Future<CancelMySubscriptionResponseEntity> read(
      CancelMySubscriptionParam param) async {
    try {
      var response = await HttpService.postHttp(
          "${GateWayConstants.SUBSCRIPTIONS}/${param.subscriptionId}", {
        GateWayConstants.FIELD_CANCEL_AT_PERIOD_END: "true",
      });
      MySubscriptionEntity? mySubscriptionEntity;
      if (response != null) {
        mySubscriptionEntity =
            MySubscriptionEntity.fromJson(response, "", null);
      }
      return CancelMySubscriptionResponseEntity(
          mySubscriptionEntity: mySubscriptionEntity);
    } on CustomException catch (e) {
      return CancelMySubscriptionResponseEntity(
          commonErrors: CommonErrors.fromJson(
              {'errorMessage': e.message, 'errorCode': '21332'}));
    } catch (e) {
      print(e);
      return CancelMySubscriptionResponseEntity(
          commonErrors: CommonErrors.fromJson({}));
    }
  }

  @override
  void unsubscribe() {}
}
