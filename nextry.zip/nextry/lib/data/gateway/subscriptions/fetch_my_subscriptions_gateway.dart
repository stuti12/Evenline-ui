import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:nextry_dev/data/gateway/common/custom_exception.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/data/gateway/common/http_service.dart';
import 'package:nextry_dev/domain/entities/business/business_entity.dart';
import 'package:nextry_dev/domain/entities/error/common_errors.dart';
import 'package:nextry_dev/domain/entities/subscriptions/fetch_my_subscriptions_param.dart';
import 'package:nextry_dev/domain/entities/subscriptions/fetch_my_subscriptions_response_entity.dart';
import 'package:nextry_dev/domain/entities/subscriptions/my_subscriptions_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';

class FetchMySubscriptionsGateWay
    implements
        ReadGateWay<FetchMySubscriptionsResponseEntity,
            FetchMySubscriptionsParam> {
  @override
  Future<FetchMySubscriptionsResponseEntity> read(
      FetchMySubscriptionsParam param) async {
    try {
      List<MySubscriptionEntity> mySubscriptionList = [];
      var response = await HttpService.getHttp(
        GateWayConstants.SUBSCRIPTIONS,
        queryParameters: {GateWayConstants.FIELD_CUSTOMER: param.customerId},
      );
      if (response != null) {
        var subscriptionsList = response[GateWayConstants.FIELD_DATA] as List;
        if (subscriptionsList.isNotEmpty) {
          for (var element in subscriptionsList) {
            BusinessEntity? businessEntity;
            var productDetails = await _getSubscriptionDetailsOfCustomer(
              element[GateWayConstants.FIELD_ITEMS][GateWayConstants.FIELD_DATA]
                      [0][GateWayConstants.FIELD_PRICE]
                  [GateWayConstants.FIELD_PRODUCT],
            );
            if (element[GateWayConstants.FIELD_DESCRIPTION] != null) {
              businessEntity = await _fetchBusinessById(
                  element[GateWayConstants.FIELD_DESCRIPTION]);
            }
            mySubscriptionList.add(
              MySubscriptionEntity.fromJson(element,
                  productDetails[GateWayConstants.FIELD_NAME], businessEntity),
            );
          }
        }
      }
      print("Response Subscriptions ${mySubscriptionList.length}");
      return FetchMySubscriptionsResponseEntity(
          mySubscriptionList: mySubscriptionList);
    } on CustomException catch (e) {
      return FetchMySubscriptionsResponseEntity(
          commonErrors: CommonErrors.fromJson(
              {'errorMessage': e.message, 'errorCode': '21332'}));
    } catch (e) {
      print(e);
      return FetchMySubscriptionsResponseEntity(
          commonErrors: CommonErrors.fromJson({}));
    }
  }

  /// This method retrieve list of subscription of the user
  Future<Map<String, dynamic>> _getSubscriptionDetailsOfCustomer(
      String productId) async {
    return await HttpService.getHttp("${GateWayConstants.PRODUCTS}/$productId");
  }

  Future<BusinessEntity> _fetchBusinessById(String businessId) async {
    var snapshot = await FirebaseFirestore.instance
        .collection(GateWayConstants.TABLE_BUSINESSES)
        .doc(businessId)
        .get();

    var entity = BusinessEntity();
    if (snapshot.exists) {
      var data = snapshot.data();
      if (data != null) {
        entity = BusinessEntity.fromJSON(data, businessId);
      }
    }
    return entity;
  }

  @override
  void unsubscribe() {}
}
