import 'package:flutter_stripe/flutter_stripe.dart';
import 'package:nextry_dev/data/gateway/common/custom_exception.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/data/gateway/common/http_service.dart';
import 'package:nextry_dev/domain/entities/error/common_errors.dart';
import 'package:nextry_dev/domain/entities/subscriptions/create_subscription_entity.dart';
import 'package:nextry_dev/domain/entities/subscriptions/create_subscription_param.dart';
import 'package:nextry_dev/domain/entities/subscriptions/create_subscription_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/presentation/common/utils/app_extension.dart';

class CreateSubscriptionGateway
    implements
        ReadGateWay<CreateSubscriptionResponseEntity, CreateSubscriptionParam> {
  @override
  Future<CreateSubscriptionResponseEntity> read(
      CreateSubscriptionParam data) async {
    try {
      CreateSubscriptionEntity createSubscriptionEntity =
          CreateSubscriptionEntity();
      var customerId = data.customerId ?? "";
      var cardId = data.cardId ?? "";
      if (customerId.isNullOrEmpty()) {
        final customer =
            await _createCustomer(data.createCustomerParam?.toJson());
        print("customer added $customer");
        customerId = customer[GateWayConstants.FIELD_ID];
      }
      if (cardId.isNullOrEmpty()) {
        final token = await setCardDetail();
        print("Card Detail $token");
        final cardData = await _createACard(customerId, token.id);
        print("Create Ac Card $cardData");
        if (token.card != null) {
          cardId = token.card?.id ?? "";
        }
      }
      final intent = await _setupIntent(customerId, cardId);
      print("intent $intent");
      if (data.isSubscription) {
        var json = await _createSubscriptions(
          customerId,
          data.subscriptionId ?? "",
          data.businessId ?? "",
          data.trialDays ?? '',
          withFreeTrial:
              data.trialDays != null && data.trialDays?.isNotEmpty == true
                  ? true
                  : false,
        );
        createSubscriptionEntity = CreateSubscriptionEntity.fromJson(json);
      }
      return CreateSubscriptionResponseEntity(
          createSubscriptionEntity: createSubscriptionEntity);
    } on CustomException catch (e) {
      return CreateSubscriptionResponseEntity(
          commonErrors: CommonErrors.fromJson(
              {'errorMessage': e.message, 'errorCode': '21332'}));
    } catch (e) {
      print(e);
      return CreateSubscriptionResponseEntity(
          commonErrors: CommonErrors.fromJson({}));
    }
  }

  /// This method the create customer
  Future<Map<String, dynamic>> _createCustomer(
      Map<String, dynamic>? body) async {
    try {
      var response =
          await HttpService.postHttp(GateWayConstants.CUSTOMER, body ?? {});
      return response;
    } catch (e) {
      print(e);
      return {};
    }
  }

  Future<TokenData> setCardDetail() async {
    final tokenData = await Stripe.instance
        .createToken(const CreateTokenParams.card(params: CardTokenParams()));
    return tokenData;
  }

  /// this method add a card into the specified user
  Future<Map<String, dynamic>> _createACard(
      String customerId, String tokenId) async {
    var response = await HttpService.postHttp(
        "${GateWayConstants.CUSTOMER}/$customerId${GateWayConstants.SOURCES}", {
      GateWayConstants.FIELD_VALIDATE: "false",
      GateWayConstants.FIELD_SOURCE: tokenId
    });
    return response;
  }

  /// this method set up intent to pay latter
  Future<Map<String, dynamic>> _setupIntent(
      String customerId, String cardID) async {
    var response = await HttpService.postHttp(GateWayConstants.SET_UP_INTENTS, {
      GateWayConstants.FIELD_PAYMENT_METHOD_TYPES: 'card',
      GateWayConstants.FIELD_PAYMENT_METHOD: cardID,
      GateWayConstants.FIELD_CONFIRM: "true",
      GateWayConstants.FIELD_CUSTOMER: customerId
    });
    return response;
  }

  /// This method the create the subscription
  Future<Map<String, dynamic>> _createSubscriptions(
      String customerId, String priceId, String description, String trialDays,
      {bool withFreeTrial = false}) async {
    Map<String, dynamic> body = {
      GateWayConstants.FIELD_CUSTOMER: customerId,
      GateWayConstants.FIELD_ITEMS_PRICE: priceId,
      GateWayConstants.FIELD_CURRENCY: "usd",
      GateWayConstants.FIELD_OFF_SESSION: "true",
      GateWayConstants.FIELD_DESCRIPTION: description,
      if (withFreeTrial == true)
        GateWayConstants.FIELD_TRIAL_PERIOD_DAYS: trialDays,
    };

    var response =
        await HttpService.postHttp(GateWayConstants.SUBSCRIPTIONS, body);
    return response;
  }

  @override
  void unsubscribe() {}
}
