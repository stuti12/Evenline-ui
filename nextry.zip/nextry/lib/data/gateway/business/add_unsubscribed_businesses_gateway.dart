import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/domain/entities/business/add_unsubscribed_businesses_response_entity.dart';
import 'package:nextry_dev/domain/entities/business/unsubscribed_entity.dart';
import 'package:nextry_dev/domain/entities/error/common_errors.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';

class AddUnSubscribedBusinessesGateway
    implements
        ReadGateWay<AddUnSubscribedBusinessesResponseEntity,
            UnSubscribedEntity> {
  @override
  Future<AddUnSubscribedBusinessesResponseEntity> read(
      UnSubscribedEntity data) async {
    try {
      await FirebaseFirestore.instance
          .collection(GateWayConstants.TABLE_UNSUBSCRIBED_BUSINESSES)
          .add(data.toJson());

      return AddUnSubscribedBusinessesResponseEntity(isSuccess: true);
    } catch (e) {
      print(e);
      return AddUnSubscribedBusinessesResponseEntity(
          commonErrors: CommonErrors.fromJson({}));
    }
  }

  @override
  void unsubscribe() {}
}
