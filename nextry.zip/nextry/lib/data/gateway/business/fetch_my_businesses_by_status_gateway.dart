import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/domain/entities/business/business_entity.dart';
import 'package:nextry_dev/domain/entities/business/fetch_business_param.dart';
import 'package:nextry_dev/domain/entities/business/fetch_my_businesses_by_status_response_entity.dart';
import 'package:nextry_dev/domain/entities/error/common_errors.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';

class FetchMyBusinessesByStatusGateWay
    implements
        ReadGateWay<FetchMyBusinessesByStatusResponseEntity,
            FetchBusinessParam> {
  StreamSubscription<QuerySnapshot<Map<String, dynamic>>>? streamSubscription;

  @override
  Future<FetchMyBusinessesByStatusResponseEntity> read(
      FetchBusinessParam fetchBusinessParam) async {
    try {
      final userId = FirebaseAuth.instance.currentUser?.uid;

      if(userId != null && userId.isNotEmpty) {
        final businessRef = FirebaseFirestore.instance
            .collection(GateWayConstants.TABLE_BUSINESSES)
            .where(GateWayConstants.FIELD_BUSINESS_STATUS,
            isEqualTo: fetchBusinessParam.status)
            .where(GateWayConstants.FIELD_USER_ID, isEqualTo: userId);

        final snapShot = await businessRef.get();

        streamSubscription = businessRef.snapshots().listen((event) async {
          print("==== FetchMyBusinessesByStatusGateWay called");
          if (fetchBusinessParam.function != null) {
            fetchBusinessParam.function!(await _parseBusinessData(event));
          }
        });
        return FetchMyBusinessesByStatusResponseEntity(
            businesses: await _parseBusinessData(snapShot), error: null);
      }
      return FetchMyBusinessesByStatusResponseEntity(
          businesses: null, error: null);
    } catch (e) {
      print(e);
      return FetchMyBusinessesByStatusResponseEntity(
          error: CommonErrors.fromJson({}));
    }
  }

  @override
  void unsubscribe() {
    streamSubscription?.cancel();
  }

  Future<List<BusinessEntity>> _parseBusinessData(
      QuerySnapshot<Map<String, dynamic>> snapshot) async {
    List<BusinessEntity> businessesEntity = [];
    for (var element in snapshot.docs) {
      if (element.exists) {
        print("test business Id ${element.id}");
        var data = element.data();
        businessesEntity.add(BusinessEntity.fromJSON(data, element.id));
      }
    }
    return businessesEntity;
  }
}
