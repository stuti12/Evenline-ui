import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:geoflutterfire2/geoflutterfire2.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/domain/entities/business/update_business_status_param.dart';
import 'package:nextry_dev/domain/entities/business/update_business_status_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/presentation/common/utils/app_constants.dart';

class UpdateBusinessStatusGateWay
    implements
        ReadGateWay<UpdateBusinessStatusResponseEntity,
            UpdateBusinessStatusParam> {
  @override
  Future<UpdateBusinessStatusResponseEntity> read(
      UpdateBusinessStatusParam updateBusinessStatusParam) async {
    try {
      final data = <String, dynamic>{};
      data[GateWayConstants.FIELD_STATUS] = updateBusinessStatusParam.status;

      await FirebaseFirestore.instance
          .collection(GateWayConstants.TABLE_BUSINESSES)
          .doc(updateBusinessStatusParam.businessDocId)
          .set(data, SetOptions(merge: true));

      if (updateBusinessStatusParam.status ==
          AppConstants.BUSINESS_STATUS_PUBLISH) {
        _addHotDealAdData(updateBusinessStatusParam);
        _addStandardAdData(updateBusinessStatusParam);
      }

      return UpdateBusinessStatusResponseEntity(isUpdate: true, error: null);
    } catch (e) {
      print(e);
      return UpdateBusinessStatusResponseEntity(isUpdate: false, error: null);
    }
  }

  _addHotDealAdData(UpdateBusinessStatusParam updateBusinessStatusParam) async {
    var snapshot = await FirebaseFirestore.instance
        .collection(GateWayConstants.TABLE_BUSINESSES)
        .doc(updateBusinessStatusParam.businessDocId)
        .collection(GateWayConstants.TABLE_HOT_DEAL)
        .where(GateWayConstants.FIELD_START_TIME,
            isGreaterThanOrEqualTo: Timestamp.now())
        .get();
    if (snapshot.docs.isNotEmpty) {
      for (var element in snapshot.docs) {
        var data = element.data();
        Map<String, dynamic> param = data;
        param[GateWayConstants.FIELD_BUSINESS_ID] =
            updateBusinessStatusParam.businessDocId;
        param[GateWayConstants.FIELD_HOT_DEAL_ID] = element.id;
        param[GateWayConstants.FIELD_CATEGORY_ID] =
            updateBusinessStatusParam.categoryId;
        param[GateWayConstants.FIELD_LOCATION] = GeoFlutterFire()
            .point(
                latitude: updateBusinessStatusParam.location?.latitude ?? 0.0,
                longitude: updateBusinessStatusParam.location?.longitude ?? 0.0)
            .data;
        await FirebaseFirestore.instance
            .collection(GateWayConstants.TABLE_CLOUD_HOT_DEAL)
            .add(param);
      }
    }
  }

  _addStandardAdData(
      UpdateBusinessStatusParam updateBusinessStatusParam) async {
    var productRef = await FirebaseFirestore.instance
        .collection(GateWayConstants.TABLE_BUSINESSES)
        .doc(updateBusinessStatusParam.businessDocId)
        .collection(GateWayConstants.TABLE_PRODUCT)
        .get();

    if (productRef.docs.isNotEmpty) {
      for (var element in productRef.docs) {
        if (element.exists) {
          var adsRef = await FirebaseFirestore.instance
              .collection(GateWayConstants.TABLE_BUSINESSES)
              .doc(updateBusinessStatusParam.businessDocId)
              .collection(GateWayConstants.TABLE_PRODUCT)
              .doc(element.id)
              .collection(GateWayConstants.TABLE_ADS)
              .where(GateWayConstants.FIELD_PRODUCT_DISCOUNT_START_DATE,
                  isGreaterThanOrEqualTo: Timestamp.now())
              .get();
          if (adsRef.docs.isNotEmpty) {
            for (var item in adsRef.docs) {
              if (item.exists) {
                var data = item.data();
                Map<String, dynamic> param = data;
                param[GateWayConstants.FIELD_BUSINESS_ID] =
                    updateBusinessStatusParam.businessDocId;
                param[GateWayConstants.FIELD_PRODUCT_ID] = element.id;
                param[GateWayConstants.FIELD_STANDARD_AD_ID] = item.id;
                param[GateWayConstants.FIELD_CATEGORY_ID] =
                    updateBusinessStatusParam.categoryId;
                param[GateWayConstants.FIELD_LOCATION] = GeoFlutterFire()
                    .point(
                        latitude:
                            updateBusinessStatusParam.location?.latitude ?? 0.0,
                        longitude:
                            updateBusinessStatusParam.location?.longitude ??
                                0.0)
                    .data;
                if (updateBusinessStatusParam.businessName != null &&
                    updateBusinessStatusParam.businessName!.isNotEmpty) {
                  param[GateWayConstants.FIELD_BUSINESS_NAMES] =
                      updateBusinessStatusParam.businessName ?? '';
                }
                await FirebaseFirestore.instance
                    .collection(GateWayConstants.TABLE_CLOUD_STANDARD_ADS)
                    .add(param);
              }
            }
          }
        }
      }
    }
  }

  @override
  void unsubscribe() {}
}
