import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/domain/entities/business/business_category_entity.dart';
import 'package:nextry_dev/domain/entities/business/fetch_business_category_param.dart';
import 'package:nextry_dev/domain/entities/business/fetch_business_category_response_entity.dart';
import 'package:nextry_dev/domain/entities/error/common_errors.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';

class FetchBusinessCategoryGateWay
    implements
        ReadGateWay<FetchBusinessCategoryResponseEntity,
            FetchBusinessCategoryParam> {
  StreamSubscription<QuerySnapshot<Map<String, dynamic>>>? streamSubscription;

  @override
  Future<FetchBusinessCategoryResponseEntity> read(
      FetchBusinessCategoryParam data) async {
    try {
      final categoryRef = FirebaseFirestore.instance
          .collection(GateWayConstants.TABLE_BUSINESSES)
          .doc(data.businessId)
          .collection(GateWayConstants.TABLE_CATEGORY)
          .orderBy(GateWayConstants.FIELD_CREATED_AT);

      final snapshot = await categoryRef.get();
      final entity = FetchBusinessCategoryResponseEntity();
      entity.businessCategoriesEntity = _parseBusinessCategoryList(snapshot);

      streamSubscription?.cancel();
      streamSubscription = categoryRef.snapshots().listen((event) async {
        if (data.function != null) {
          data.function!(_parseBusinessCategoryList(event));
        }
      });

      return entity;
    } catch (e) {
      print(e);
      return FetchBusinessCategoryResponseEntity(
          commonErrors: CommonErrors.fromJson({}));
    }
  }

  List<BusinessCategoryEntity> _parseBusinessCategoryList(
      QuerySnapshot<Map<String, dynamic>> snapshot) {
    List<BusinessCategoryEntity> businessCategoriesEntity = [];
    for (var element in snapshot.docs) {
      if (element.exists) {
        var data = element.data();
        businessCategoriesEntity
            .add(BusinessCategoryEntity.fromJson(data, element.id));
      }
    }
    return businessCategoriesEntity;
  }

  @override
  void unsubscribe() {
    streamSubscription?.cancel();
  }
}
