import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/data/gateway/common/upload_file_helper.dart';
import 'package:nextry_dev/domain/entities/business/add_update_business_response_entity.dart';
import 'package:nextry_dev/domain/entities/business/business_entity.dart';
import 'package:nextry_dev/domain/entities/config/subscription_terms_condition.dart';
import 'package:nextry_dev/domain/entities/error/common_errors.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/presentation/common/utils/app_constants.dart';

class AddUpdateBusinessGateway
    implements ReadGateWay<AddUpdateBusinessResponseEntity, BusinessEntity> {
  @override
  Future<AddUpdateBusinessResponseEntity> read(BusinessEntity data) async {
    try {
      final profileDocId = FirebaseAuth.instance.currentUser?.uid;

      if (data.profileImage != null &&
          data.profileImage!.isNotEmpty &&
          !data.profileImage!.startsWith(AppConstants.SERVER_FILE)) {
        data.profileImage =
            await UploadFileHelper().uploadFileToFireStore(data.profileImage!);
      }

      await checkAndUploadTermsConditionFile(data.termsConditionEntity);
      await checkAndUploadTermsConditionFile(data.privacyPolicyEntity);
      await checkAndUploadTermsConditionFile(data.returnRefundEntity);

      if (data.id != null && data.id!.isNotEmpty) {
        await FirebaseFirestore.instance
            .collection(GateWayConstants.TABLE_BUSINESSES)
            .doc(data.id)
            .set(data.toJson(isCreateRequest: false, profileDocId),
                SetOptions(merge: true));
      } else {
        var snapShot = await FirebaseFirestore.instance
            .collection(GateWayConstants.TABLE_BUSINESSES)
            .add(data.toJson(profileDocId));
        data.id = snapShot.id;
      }

      return AddUpdateBusinessResponseEntity(
          isSuccess: true, businessId: data.id);
    } catch (e) {
      print(e);
      return AddUpdateBusinessResponseEntity(
          commonErrors: CommonErrors.fromJson({}));
    }
  }

  checkAndUploadTermsConditionFile(
      SubscriptionTermsConditionEntity? termsConditionEntity) async {
    if (termsConditionEntity != null && termsConditionEntity.ar?.isNotEmpty == true) {
      if (termsConditionEntity.ar != null &&
          !termsConditionEntity.ar!.startsWith(AppConstants.SERVER_FILE)) {
        termsConditionEntity.ar = await UploadFileHelper()
            .uploadFileToFireStore(termsConditionEntity.ar!);
      }
      if (termsConditionEntity.en != null &&
          !termsConditionEntity.en!.startsWith(AppConstants.SERVER_FILE)) {
        termsConditionEntity.en = await UploadFileHelper()
            .uploadFileToFireStore(termsConditionEntity.en!);
      }
      if (termsConditionEntity.he != null &&
          !termsConditionEntity.he!.startsWith(AppConstants.SERVER_FILE)) {
        termsConditionEntity.he = await UploadFileHelper()
            .uploadFileToFireStore(termsConditionEntity.he!);
      }
    }
  }

  @override
  void unsubscribe() {}
}
