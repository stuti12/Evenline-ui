import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/domain/entities/business/business_entity.dart';
import 'package:nextry_dev/domain/entities/business/fetch_business_param.dart';
import 'package:nextry_dev/domain/entities/business/fetch_business_response_entity.dart';
import 'package:nextry_dev/domain/entities/error/common_errors.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';

class FetchBusinessDataGateWay
    implements ReadGateWay<FetchBusinessResponseEntity, FetchBusinessParam> {
  StreamSubscription<DocumentSnapshot<Map<String, dynamic>>>?
      streamSubscription;

  @override
  Future<FetchBusinessResponseEntity> read(
      FetchBusinessParam fetchBusinessParam) async {
    try {
      final businessRef = FirebaseFirestore.instance
          .collection(GateWayConstants.TABLE_BUSINESSES)
          .doc(fetchBusinessParam.businessId);

      streamSubscription?.cancel();
      streamSubscription = businessRef.snapshots().listen((event) async {
        if (fetchBusinessParam.function != null) {
          fetchBusinessParam.function!(_parseBusinessData(event));
        }
      });

      var snapshot = await businessRef.get();

      final entity = FetchBusinessResponseEntity();
      entity.businessEntity = _parseBusinessData(snapshot);

      return entity;
    } catch (e) {
      print(e);
      return FetchBusinessResponseEntity(
          commonErrors: CommonErrors.fromJson({}));
    }
  }

  @override
  void unsubscribe() {
    streamSubscription?.cancel();
  }

  BusinessEntity? _parseBusinessData(
      DocumentSnapshot<Map<String, dynamic>> snapshot) {
    if (snapshot.exists) {
      var data = snapshot.data();
      if (data != null) {
        return BusinessEntity.fromJSON(data, snapshot.id);
      }
    }
  }
}
