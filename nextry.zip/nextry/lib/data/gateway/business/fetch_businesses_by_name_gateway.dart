import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/domain/entities/business/business_entity.dart';
import 'package:nextry_dev/domain/entities/business/fetch_business_by_name_param.dart';
import 'package:nextry_dev/domain/entities/business/fetch_business_by_name_response_entity.dart';
import 'package:nextry_dev/domain/entities/error/common_errors.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/presentation/common/utils/app_constants.dart';

class FetchBusinessesByNameGateWay
    implements
        ReadGateWay<FetchBusinessesByNameResponseEntity,
            FetchBusinessByNameParam> {
  @override
  Future<FetchBusinessesByNameResponseEntity> read(
      FetchBusinessByNameParam param) async {
    try {
      List<BusinessEntity> businessesEntity = [];
      final snapShot = await FirebaseFirestore.instance
          .collection(GateWayConstants.TABLE_BUSINESSES)
          .where(GateWayConstants.FIELD_SEARCH_BUSINESS_NAME,
              arrayContains: param.searchName.toLowerCase())
          .where(GateWayConstants.FIELD_BUSINESS_STATUS,
              isEqualTo: AppConstants.BUSINESS_STATUS_PUBLISH)
          .get();

      for (var element in snapShot.docs) {
        if (element.exists) {
          var data = element.data();
          businessesEntity.add(BusinessEntity.fromJSON(data, element.id));
        }
      }
      return FetchBusinessesByNameResponseEntity(
          businesses: businessesEntity, error: null);
    } catch (e) {
      print(e);
      return FetchBusinessesByNameResponseEntity(
          error: CommonErrors.fromJson({}));
    }
  }

  @override
  void unsubscribe() {}
}
