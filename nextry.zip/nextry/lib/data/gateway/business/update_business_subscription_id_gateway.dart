import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/domain/entities/business/update_business_status_response_entity.dart';
import 'package:nextry_dev/domain/entities/business/update_business_subscription_param.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';

class UpdateBusinessSubscriptionIdGateWay
    implements
        ReadGateWay<UpdateBusinessStatusResponseEntity,
            UpdateBusinessSubscriptionParam> {
  @override
  Future<UpdateBusinessStatusResponseEntity> read(
      UpdateBusinessSubscriptionParam param) async {
    try {
      final data = <String, dynamic>{};
      data[GateWayConstants.FIELD_SUBSCRIPTION_ID] = param.subscriptionId;
      data[GateWayConstants.FIELD_PAYPLUS_SUBSCRIPTION] =
          param.payPlusSubscriptionResponseEntity?.toJson();
      data[GateWayConstants.FIELD_STATUS] = param.businessStatus;

      await FirebaseFirestore.instance
          .collection(GateWayConstants.TABLE_BUSINESSES)
          .doc(param.businessDocId)
          .set(data, SetOptions(merge: true));

      return UpdateBusinessStatusResponseEntity(isUpdate: true, error: null);
    } catch (e) {
      print(e);
      return UpdateBusinessStatusResponseEntity(isUpdate: false, error: null);
    }
  }

  @override
  void unsubscribe() {}
}
