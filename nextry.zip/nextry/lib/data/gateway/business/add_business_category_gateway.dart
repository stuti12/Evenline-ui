import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/data/gateway/common/upload_file_helper.dart';
import 'package:nextry_dev/domain/entities/business/add_business_category_param.dart';
import 'package:nextry_dev/domain/entities/business/add_business_category_response_entity.dart';
import 'package:nextry_dev/domain/entities/error/common_errors.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/presentation/common/utils/app_constants.dart';

class AddBusinessCategoryGateway
    implements
        ReadGateWay<AddBusinessCategoryResponseEntity,
            AddBusinessCategoryParam> {
  @override
  Future<AddBusinessCategoryResponseEntity> read(
      AddBusinessCategoryParam data) async {
    try {
      if (data.businessCategoryEntity.logo != null &&
          data.businessCategoryEntity.logo!.isNotEmpty &&
          !data.businessCategoryEntity.logo!
              .startsWith(AppConstants.SERVER_FILE)) {
        _updateCount(data.onUpdate, 20);
        data.businessCategoryEntity.logo = await UploadFileHelper()
            .uploadFileToFireStore(data.businessCategoryEntity.logo!);
      }
      _updateCount(data.onUpdate, 95);

      await FirebaseFirestore.instance
          .collection(GateWayConstants.TABLE_BUSINESSES)
          .doc(data.businessId)
          .collection(GateWayConstants.TABLE_CATEGORY)
          .add(data.businessCategoryEntity.toJson());

      return AddBusinessCategoryResponseEntity(isSuccess: true);
    } catch (e) {
      print(e);
      return AddBusinessCategoryResponseEntity(
          isSuccess: false, commonErrors: CommonErrors.fromJson({}));
    }
  }

  _updateCount(Function? onUpdate, int progress) {
    if (onUpdate != null) {
      onUpdate(progress);
    }
  }

  @override
  void unsubscribe() {}
}
