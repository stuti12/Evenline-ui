import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/domain/entities/error/common_errors.dart';
import 'package:nextry_dev/domain/entities/notification/fetch_notification_entity.dart';
import 'package:nextry_dev/domain/entities/notification/fetch_notification_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';

class FetchNotificationByUserIdGateWay
    implements ReadGateWay<FetchNotificationResponseEntity, Function> {
  StreamSubscription<QuerySnapshot<Map<String, dynamic>>>? streamSubscription;

  @override
  Future<FetchNotificationResponseEntity> read(Function function) async {
    try {
      final userId = FirebaseAuth.instance.currentUser?.uid;
      final notificationRef = FirebaseFirestore.instance
          .collection(GateWayConstants.TABLE_USERS)
          .doc(userId)
          .collection(GateWayConstants.TABLE_NOTIFICATIONS)
          .orderBy(GateWayConstants.FIELD_CREATED_AT, descending: true);

      streamSubscription?.cancel();
      streamSubscription = notificationRef.snapshots().listen((event) async {
        function(_parseNotificationData(event.docs));
      });

      var snapshot = await notificationRef.get();
      List<FetchNotificationEntity> list =
          _parseNotificationData(snapshot.docs) ?? [];

      return FetchNotificationResponseEntity(notificationList: list);
    } catch (e) {
      print(e);
      return FetchNotificationResponseEntity(
          commonErrors: CommonErrors.fromJson({}));
    }
  }

  List<FetchNotificationEntity>? _parseNotificationData(
      List<QueryDocumentSnapshot<Map<String, dynamic>>> docs) {
    List<FetchNotificationEntity> list = [];
    for (var element in docs) {
      if (element.exists) {
        var data = element.data();
        list.add(FetchNotificationEntity.fromJson(data));
      }
    }
    return list;
  }

  @override
  void unsubscribe() {}
}
