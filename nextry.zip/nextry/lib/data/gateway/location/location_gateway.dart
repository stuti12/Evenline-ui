import 'dart:async';

import 'package:location/location.dart';
import 'package:nextry_dev/domain/entities/location/location_info_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway_no_args.dart';

/// Fetch user current location and if user is not approve the permission then
/// first it will ask the permission to fetch user's current location.
class LocationGateWay extends ReadGateWayNoArgs<LocationInfoEntity> {
  Location location = Location();
  late bool _serviceEnabled;
  late PermissionStatus _permissionGranted;
  late LocationData _locationData;

  @override
  Future<LocationInfoEntity> read() async {
    LocationInfoEntity locationInfoEntity = LocationInfoEntity();

    _permissionGranted = await location.hasPermission();
    if (_permissionGranted != PermissionStatus.granted ||
        _permissionGranted != PermissionStatus.grantedLimited) {
      _permissionGranted = await location.requestPermission();
      if (_permissionGranted == PermissionStatus.deniedForever) {
        // show the grant permission UI.
        locationInfoEntity.isUserGrantedLocationPermission = false;
        locationInfoEntity.isUserDeniedForeverLocationPermission = true;
        // return a LocationInfoEntity with isUserGrantedLocationPermission set to false ;
        return locationInfoEntity;
      } else if (_permissionGranted == PermissionStatus.granted ||
          _permissionGranted == PermissionStatus.grantedLimited) {
        locationInfoEntity.isUserGrantedLocationPermission = true;
      } else {
        locationInfoEntity.isUserGrantedLocationPermission = false;
      }
    } else {
      locationInfoEntity.isUserGrantedLocationPermission = true;
    }

    if (locationInfoEntity.isUserGrantedLocationPermission) {
      _serviceEnabled = await location.serviceEnabled();
      if (!_serviceEnabled) {
        _serviceEnabled = await location.requestService();
        if (!_serviceEnabled) {
          locationInfoEntity.isLocationServiceEnabled = false;
        } else {
          locationInfoEntity.isLocationServiceEnabled = true;
        }
      } else {
        locationInfoEntity.isLocationServiceEnabled = true;
      }

      if (locationInfoEntity.isLocationServiceEnabled) {
        _locationData = await location.getLocation();
        locationInfoEntity = _getLocationEntity(_locationData);
        return locationInfoEntity;
      } else {
        return locationInfoEntity;
      }
    } else {
      return locationInfoEntity;
    }
  }

  /// To get location details from Location data class.
  LocationInfoEntity _getLocationEntity(LocationData locationData) {
    LocationInfoEntity newUserLocation = LocationInfoEntity();
    newUserLocation.latitude = locationData.latitude ?? 0.0;
    newUserLocation.longitude = locationData.longitude ?? 0.0;
    newUserLocation.accuracy = locationData.accuracy ?? 0.0;
    newUserLocation.altitude = locationData.altitude ?? 0.0;
    newUserLocation.speed = locationData.speed ?? 0.0;
    newUserLocation.speedAccuracy = locationData.speedAccuracy ?? 0.0;
    newUserLocation.heading = locationData.heading ?? 0.0;
    newUserLocation.time = locationData.time ?? 0.0;
    newUserLocation.isMock = locationData.isMock ?? false;
    newUserLocation.isLocationServiceEnabled = true;
    newUserLocation.isUserGrantedLocationPermission = true;
    return newUserLocation;
  }

  @override
  void dispose() {}
}
