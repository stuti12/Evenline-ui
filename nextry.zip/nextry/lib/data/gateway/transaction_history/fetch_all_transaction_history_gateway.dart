import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/domain/entities/wallet/transaction_entity.dart';
import 'package:nextry_dev/domain/entities/wallet/transaction_history_param.dart';
import 'package:nextry_dev/domain/entities/wallet/transaction_history_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/presentation/common/utils/app_constants.dart';
import 'package:nextry_dev/presentation/screens/transactionHistory/model/transaction_type.dart';

class FetchAllTransactionsHistoryGateway
    implements
        ReadGateWay<TransactionHistoryResponseEntity, TransactionHistoryParam> {
  DocumentSnapshot? lastDocumentSnapShot;

  @override
  Future<TransactionHistoryResponseEntity> read(
      TransactionHistoryParam transactionHistoryParam) async {
    try {
      if (transactionHistoryParam.isCalledFirstTime) {
        lastDocumentSnapShot = null;
      }
      Query<Map<String, dynamic>> query = FirebaseFirestore.instance
          .collection(transactionHistoryParam.isBusiness
              ? GateWayConstants.TABLE_BUSINESSES
              : GateWayConstants.TABLE_USERS)
          .doc(transactionHistoryParam.userUID)
          .collection(GateWayConstants.TABLE_WALLET)
          .doc(transactionHistoryParam.type)
          .collection(GateWayConstants.TABLE_TRANSACTIONS);
      if (transactionHistoryParam.transactionType != TransactionType.DEFAULT) {
        if (transactionHistoryParam.transactionType == TransactionType.ORDER) {
          query =
              query.where(GateWayConstants.FIELD_STATUS, isEqualTo: 'order');
        } else if (transactionHistoryParam.transactionType ==
            TransactionType.NEXTRY) {
          query =
              query.where(GateWayConstants.FIELD_STATUS, isEqualTo: 'nextry');
        } else if (transactionHistoryParam.transactionType ==
            TransactionType.REFUND) {
          query =
              query.where(GateWayConstants.FIELD_STATUS, isEqualTo: 'refund');
        }
      }
      query = query
          .where(GateWayConstants.FIELD_CREATED_AT,
              isGreaterThanOrEqualTo: transactionHistoryParam.fromDate)
          .where(GateWayConstants.FIELD_CREATED_AT,
              isLessThanOrEqualTo: transactionHistoryParam.toDate)
          .orderBy(GateWayConstants.FIELD_CREATED_AT, descending: true);
      if (lastDocumentSnapShot != null) {
        query = query.startAfterDocument(lastDocumentSnapShot!);
      }
      var snapshot =
          await query.limit(AppConstants.TRANSACTION_LIST_LIMIT).get();
      List<TransactionEntity> transactionList = [];

      for (var element in snapshot.docs) {
        if (element.exists) {
          var data = element.data();
          lastDocumentSnapShot = element;
          transactionList.add(TransactionEntity(
              amount: data[GateWayConstants.FIELD_AMOUNT],
              date: data[GateWayConstants.FIELD_CREATED_AT],
              transactionType: data[GateWayConstants.FIELD_TYPE],
              userName: data[GateWayConstants.FIELD_USER_NAME],
              status: data[GateWayConstants.FIELD_STATUS]));
        }
      }
      return TransactionHistoryResponseEntity(transactionList: transactionList);
    } catch (error) {
      print(error);
      return TransactionHistoryResponseEntity();
    }
  }

  @override
  void unsubscribe() {}
}
