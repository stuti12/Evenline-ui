/// All firebase collection constants and shared preference keys.
class GateWayConstants {
  // Shared Preference Keys
  static const KEY_EMAIL = "KEY_EMAIL";
  static const KEY_LOCATION_NOTIFICATION_MESSAGE =
      "KEY_LOCATION_NOTIFICATION_MESSAGE";
  static const KEY_LANGUAGE_CODE = "KEY_LANGUAGE_CODE";
  static const KEY_LOCATION_POPUP = "KEY_LOCATION_POPUP";
  static const KEY_USER_ID = "KEY_USER_ID";
  static const KEY_VERSION = "KEY_VERSION";

  static const String FIELD_ID = 'id';

  // Users Table Collection
  static const String TABLE_USERS = 'users';
  static const String FIELD_NAME = 'name';
  static const String FIELD_EMAIL = 'email';
  static const String FIELD_PHONE = 'phone';
  static const String FIELD_PROFILE_URL = 'profile_url';
  static const FIELD_FCM_TOKEN = "fcm_token";
  static const FIELD_STRIPE_CUSTOMER_ID = "stripe_customer_id";
  static const FIELD_PAY_PLUS_CUSTOMER_ID = "pay_plus_customer_id";
  static const FIELD_LANGUAGE_CODE = "language_code";

  static const String FIELD_USER_ID = 'user_id';

  // Wallet Table Collection
  static const String TABLE_WALLET = 'wallet';
  static const String FIELD_PARTNER_UID = 'Partner UID';
  static const String FIELD_TRANSACTION_DATE = 'Transaction Date';
  static const String FIELD_TRANSACTION_TYPE = 'Transaction Type';
  static const String FIELD_TRANSACTION_AMOUNT = 'Transaction Amount';
  static const String FIELD_TRANSACTION_DATE_FILTERING = 'Date Filtering';
  static const String FIELD_BALLANCE = 'balance';
  static const String FIELD_COINS = 'coins';
  static const String FIELD_SENT_AMOUNT = 'sent_amount';
  static const String FIELD_RECEIVED_AMOUNT = 'received_amount';
  static const String FIELD_AMOUNT = 'amount';
  static const String FIELD_CREATED_AT = 'created_at';
  static const String FIELD_TYPE = 'type';
  static const String FIELD_USER_NAME = 'user_name';
  static const String FIELD_STATUS = 'status';

  // Invoice Table
  static const String TABLE_INVOICE = "invoices";
  static const String FIELD_ATTACHMENTS = "attachments";
  static const String FIELD_FILES_URL = "file_url";
  static const String FIELD_UPLOADED_AT = "uploaded_at";
  static const String FIELD_BUSINESS_ID = "business_id";
  static const String FIELD_INVOICE_BUSINESS_NAME = "business_name";
  static const String FIELD_CURRENCY = "currency";
  static const String FIELD_ORDER_NO = "order_no";
  static const String FIELD_PRICE = "price";

  // Transactions Table Collection
  static const String TABLE_TRANSACTIONS = 'transactions';

  // Configuration Table Collection
  static const String TABLE_CONFIGURATIONS = 'configurations';
  static const String CONFIG_SPLASH_DOC_ID = 'splash_screen';
  static const String FIELD_VIDEO_URL = 'video_url';
  static const String FIELD_IS_LOCKED = 'isLocked';
  static const String FIELD_CU_PHONE = 'cu_phone';
  static const String CONFIG_PAYPLUS_PAYMENT_DOC_ID = 'payplus_payment';
  static const String FIELD_PAYPLUS_SUBSCRIPTION_PAYMENT =
      'payplus_subscription_payment';
  static const String FIELD_API_KEY = 'api_key';
  static const String FIELD_PAGE_UID = 'page_uid';
  static const String FIELD_SECRET_KEY = 'secret_key';
  static const String FIELD_GUIDES_URLS = 'guides_urls';

  //Category Table Collection
  static const String TABLE_CATEGORY = 'categories';
  static const String FIELD_IS_VISIBLE = 'is_visible';
  static const String FIELD_CAT_NAME = 'name';
  static const String FIELD_CAT_LOGO = 'logo';
  static const String FIELD_CAT_LOCALE_NAME = 'cat_name';
  static const String FIELD_CAT_ORDER = 'order';

  // Business Table Collection
  static const String TABLE_BUSINESSES = 'businesses';
  static const String FIELD_CATEGORY_ID = 'category_id';
  static const String FIELD_LOCATION = 'location';
  static const String FIELD_BUSINESS_NAME = 'name';
  static const String FIELD_BUSINESS_PHONE = 'phone';
  static const String FIELD_PROFILE_IMAGE = 'profile_image';
  static const String FIELD_BUSINESS_STATUS = 'status';
  static const String FIELD_WORKTIME = 'worktime';
  static const String FIELD_START_TIME = 'start_time';
  static const String FIELD_END_TIME = 'end_time';
  static const String FIELD_SUNDAY = 'sunday';
  static const String FIELD_MONDAY = 'monday';
  static const String FIELD_TUESDAY = 'tuesday';
  static const String FIELD_WEDNESDAY = 'wednesday';
  static const String FIELD_THURSDAY = 'thursday';
  static const String FIELD_FRIDAY = 'friday';
  static const String FIELD_SATURDAYY = 'saturday';
  static const String FIELD_HOT_DEAL_COUNT = 'hot_deal_count';
  static const String FIELD_ADS_COUNT = 'ads_count';
  static const String FIELD_GEOPOINT = 'geopoint';
  static const String FIELD_DELIVERY_OPTIONS = 'delivery_options';
  static const String FIELD_PAYMENT_METHODS = 'payment_methods';
  static const String FIELD_BUSINESS_NAMES = "business_name";
  static const String FIELD_SEARCH_BUSINESS_NAME = "search_business_name";
  static const String FIELD_PROFILE_LINK = "profile_link";
  static const String FIELD_ISOCODE = "iso_code";
  static const String FIELD_COUPON = "coupon";
  static const String FIELD_COUPON_CODE = "code";
  static const String FIELD_IS_FOREVER = "is_forever";
  static const String FIELD_COUPON_START_DATE = "start_date";
  static const String FIELD_COUPON_END_DATE = "end_date";
  static const String FIELD_SHIPPING_PRICE = "shipping_price";
  static const String FIELD_PAYPLUS_SUBSCRIPTION =
      "payplus_subscription_response";
  static const String FIELD_PAYPLUS_PAYMENT = "payplus_payment";
  static const String FIELD_BUSINESS_DELIVERY_ORDER = "delivery_order";
  static const String FIELD_BUSINESS_PRIVACY_POLICY = "privacy_policy";
  static const String FIELD_BUSINESS_TERMS_CONDITION = "terms_condition";
  static const String FIELD_BUSINESS_RETURN_REFUND = "return_refund";
  static const String FIELD_ORDER_ONLY_IF_OPEN= "order_only_if_open";

  // Product Table Collection
  static const String TABLE_PRODUCT = "products";
  static const String FIELD_PRODUCT_NAME = "name";
  static const String FIELD_PRODUCT_IMAGE = "image";
  static const String FIELD_PRODUCT_DESC = "description";
  static const String FIELD_PRODUCT_PRICE = "price";
  static const String FIELD_PRODUCT_QUANTITY = "quantity";
  static const String FIELD_PRODUCT_COLORS = "colors";
  static const String FIELD_PRODUCT_DISCOUNT = "discount";
  static const String FIELD_PRODUCT_DISCOUNT_PRICE = "price";
  static const String FIELD_PRODUCT_DISCOUNT_START_DATE = "start_date";
  static const String FIELD_PRODUCT_DISCOUNT_END_DATE = "end_date";
  static const String FIELD_PRODUCT_MEDIAS = "medias";
  static const String FIELD_PRODUCT_ATTRIBUTES = "attributes";
  static const String FIELD_PRODUCT_IS_FROM_ADS = "is_from_ads";
  static const String FIELD_PRODUCT_IS_HIDDEN = "is_hidden";

  // Product Cart Table Collection
  static const String TABLE_CART = "carts";
  static const String FIELD_PRODUCTS = "products";
  static const String FIELD_PRODUCT_ID = "product_id";
  static const String FIELD_SHIPPING = "shipping";
  static const String FIELD_CART_COLOR = "color";

  // ADs Table Collection
  static const String TABLE_ADS = "ads";

  //Subscriptions Table Collection
  static const String TABLE_SUBSCRIPTION = "subscriptions";
  static const String FIELD_SUBSCRIPTION_NAME = "name";
  static const String FIELD_SUBSCRIPTION_CURRENCY = "currency";
  static const String FIELD_SUBSCRIPTION_DAYS = "days";
  static const String FIELD_SUBSCRIPTION_DURATION = "duration";
  static const String FIELD_SUBSCRIPTION_HOT_DEALS = "hot_deals";
  static const String FIELD_SUBSCRIPTION_TOTAL_ADS = "total_ads";
  static const String FIELD_SUBSCRIPTION_PRICE = "price";
  static const String FIELD_SUBSCRIPTION_FEATURES = "features";
  static const String FIELD_SUBSCRIPTION_FEATURES_NAME = "name";
  static const String FIELD_SUBSCRIPTION_FEATURES_IS_ENABLE = "is_enable";
  static const String FIELD_SUBSCRIPTION_ID = 'subscription_id';
  static const String FIELD_SORT_ORDER = "sort_order";
  static const String FIELD_STRIP_PRODUCT_ID = "stripe_product_id";
  static const String TABLE_SHIPPER_SUBSCRIPTION = "shipper_subscriptions";

  //Order Table Collection
  static const String TABLE_ORDERS = "orders";
  static const String FIELD_ORDER_ID = "order_id";
  static const String FIELD_ORDER_REF = "order_ref";
  static const String FIELD_ORDER_TRANSACTION_ID = "transaction_id";
  static const String FIELD_ORDER_TOTAL_AMOUNT = "total_amount";
  static const String FIELD_ORDER_PAYMENT_TYPE = "payment_type";
  static const String FIELD_ORDER_STAUS = "status";
  static const String FIELD_ORDER_IS_LEAVE_FEEDBACK = "is_leave_feedback";
  static const String FIELD_ORDER_INVOICE = "invoice";
  static const String FIELD_ORDER_DELIVERY_METHOD = "delivery_method";
  static const String FIELD_ORDER_DESCRIPTION = "description";

  // refund
  static const String FIELD_ORDER_CANCEL_REASON = "cancel_reason";
  static const String FIELD_ORDER_REASON = "reason";

  //Address
  static const String FIELD_ADDRESS = "address";
  static const String FIELD_ADDRESS_STREET = "street";
  static const String FIELD_ADDRESS_POSTAL_CODE = "postal_code";

  //Feedback Table Collection
  static const String TABLE_FEEDBACK = "feedback";
  static const String FIELD_RATING = "rating";
  static const String FIELD_REVIEW = "review";
  static const String FIELD_IS_ANONYMOUSLY = "is_anonymously";

  //Feedback Reported Table Collection
  static const String TABLE_FEEDBACK_REPORTED = "feedback_reported";
  static const String FIELD_FEEDBACK_REPORTED_REPORT_MESSAGE = "report_message";
  static const String FIELD_FEEDBACK_REPORTED_FILES = "files";

  //HotDeal Table Collection
  static const String TABLE_HOT_DEAL = "hot_deal";
  static const String TABLE_CLOUD_HOT_DEAL = "cloud_hot_deal";
  static const String FIELD_HOT_DEAL_ID = "hot_deal_id";

  // Standard Table Collection
  static const String TABLE_CLOUD_STANDARD_ADS = "cloud_standard_ad";
  static const String FIELD_STANDARD_AD_ID = "ad_id";

  // Unavailable Dates
  static const String TABLE_UNAVAILABLE_DATES = "unavailable_dates";
  static const String FIELD_UNAVAILABLE_DATES_START_DATE = "start_date";
  static const String FIELD_UNAVAILABLE_DATES_END_DATE = "end_date";

  //HotDeal Table Collection
  static const String TABLE_ACTIVE_HOT_DEAL = "active_hot_deal";

  //Active Standard Ad Table Collection
  static const String TABLE_ACTIVE_STANDARD_AD = "active_standard_ad";
  static const String FIELD_AD_ID = "ad_id";

  ///Country table collection
  static const String TABLE_COUNTRY = "country";
  static const String FIELD_COUNTRY = "name";

  // Delivery request table collection
  static const String TABLE_DELIVERY_REQUEST = "delivery_request";
  static const String FIELD_DELIVERY_REQUEST_SOURCE_LOCATION =
      "source_location";
  static const String FIELD_DELIVERY_REQUEST_SOURCE_ADDRESS = "source_address";
  static const String FIELD_DELIVERY_REQUEST_DESTINATION_LOCATION =
      "destination_location";
  static const String FIELD_DELIVERY_REQUEST_DESTINATION_ADDRESS =
      "destination_address";
  static const String FIELD_DELIVERY_GOODS_DETAILS = "goods_details";
  static const String FIELD_DELIVERY_REQUEST_WEIGHT = "weight";
  static const String FIELD_DELIVERY_REQUEST_DIMENSIONS = "dimensions";
  static const String FIELD_DELIVERY_REQUEST_DESCRIPTION = "description";
  static const String FIELD_DELIVERY_REQUEST_IMAGE = "image";
  static const String FIELD_DELIVERY_REQUEST_STATUS = "status";
  static const String FIELD_DELIVERY_REQUEST_OFFER_ID = "offer_id";
  static const String FIELD_DELIVERY_REQUEST_DIMENSION_WIDTH = "width";
  static const String FIELD_DELIVERY_REQUEST_DIMENSION_HEIGHT = "height";
  static const String FIELD_DELIVERY_REQUEST_DIMENSION_LENGTH = "length";
  static const String FIELD_DELIVERY_REQUEST_ORDER_NUMBER = "order_number";
  static const String FIELD_NEXTRY_ORDER = "nextry_order";
  static const String FIELD_NEXTRY_BUSINESS_ID = "business_id";
  static const String FIELD_NEXTRY_BUSINESS_ORDER_ID = "business_order_id";
  static const String FIELD_NEXTRY_DELIVERY_ORDER_SHIPPER_IDS = "shipper_ids";
  static const String FIELD_NEXTRY_DELIVERY_ORDER_INVOCIE = "invoice";

  /// Nextry Documents Configuration
  static const String FIELD_SUBSCRITPION_TERMS_CONDITION =
      "subscription_terms_condition";
  static const String FIELD_CONFIG_TERM_AND_CONDITION = "t_and_c_of_nextry";
  static const String FIELD_CONFIG_ACCESSIBILITY_STATEMENT = "accessibility_statement";
  static const String FIELD_CONFIG_PRIVACY_AND_POLICY = "privacy_and_policy";
  static const String FIELD_EN_LANGUAGE_CODE = "en";
  static const String FIELD_HE_LANGUAGE_CODE = "he";
  static const String FIELD_AR_LANGUAGE_CODE = "ar";

  ///Nextry Guides Urls
  static const String FIELD_CONFIG_ADD_LIST_OF_PRODUCTS =
      "add_list_of_products";
  static const String FIELD_CONFIG_NEXTRY_APP_WEBSITE =
      "nextry_app_website";
  // Offer request table collection
  static const String TABLE_OFFER_REQUEST = "offers";
  static const String FIELD_OFFER_REQUEST_SHIPPER_ID = "shipper_id";
  static const String FIELD_OFFER_REQUEST_COST = "cost";
  static const String FIELD_OFFER_REQUEST_CURRENCY = "currency";
  static const String FIELD_OFFER_REQUEST_DELIVERY_TIME = "delivery_time";

  // Stripe Subscriptions
  static String BASE_URL = 'api.stripe.com';
  static String CUSTOMER = '/v1/customers';
  static String SOURCES = '/sources';
  static String SET_UP_INTENTS = '/v1/setup_intents';
  static String SUBSCRIPTIONS = '/v1/subscriptions';
  static String PRODUCTS = '/v1/products';

  static const String FIELD_VALIDATE = "validate";
  static const String FIELD_SOURCE = "source";
  static const String FIELD_PAYMENT_METHOD_TYPES = "payment_method_types[]";
  static const String FIELD_PAYMENT_METHOD = "payment_method";
  static const String FIELD_CONFIRM = "confirm";
  static const String FIELD_CUSTOMER = "customer";
  static const String FIELD_ITEMS_PRICE = "items[0][price]";
  static const String FIELD_OFF_SESSION = "off_session";
  static const String FIELD_DESCRIPTION = "description";
  static const String FIELD_TRIAL_PERIOD_DAYS = "trial_period_days";
  static const String FIELD_ERROR = "error";
  static const String FIELD_MESSAGE = "message";
  static const String FIELD_DATA = "data";
  static const String FIELD_PRODUCT = "product";
  static const String FIELD_ITEMS = "items";
  static const String FIELD_CANCEL_AT_PERIOD_END = "cancel_at_period_end";

  // Unsubscribed Businesses table collection
  static const String TABLE_UNSUBSCRIBED_BUSINESSES = "unsubscribed_businesses";
  static const String FIELD_EXPIRED_DATE = "expired_date";
  static const String TABLE_DELIVERY_OFFER = "offers";
  static const String FIELD_DELIVERY_OFFER_SHIPPER_ID = "shipper_id";
  static const String FIELD_DELIVERY_OFFER_COST = "cost";
  static const String FIELD_DELIVERY_OFFER_CURRENCY = "currency";
  static const String FIELD_DELIVERY_OFFER_DELIVERY_TIME = "delivery_time";
  static const String FIELD_DELIVERY_OFFER_TIME = "time";
  static const String FIELD_DELIVERY_OFFER_UNIT = "unit";

  // ShipperS table collection
  static const String TABLE_SHIPPERS = "shippers";
  static const String FIELD_TABLE_SHIPPERS_NAME = "name";
  static const String FIELD_TABLE_SHIPPERS_PROFILE_URL = "profile_url";
  static const String FIELD_TABLE_SHIPPERS_CREATED_AT = "created_at";
  static const String FIELD_TABLE_SHIPPERS_CURRENT_LOCATION =
      "current_location";
  static const String FIELD_TABLE_SHIPPERS_ADDRESS = "address";
  static const String FIELD_TABLE_SHIPPERS_SEARCH_RADIUS = "search_radius";
  static const String FIELD_IS_WORKING = "is_working";
  static const String FIELD_PAYMENT_URL = "payment_url";

  // Delivery Orders table collection
  static const String TABLE_DELIVERY_ORDERS = "delivery_orders";
  static const String FIELD_CUSTOMER_ID = "customer_id";
  static const String FIELD_ORDER_DETAIL_SOURCE = "source";
  static const String FIELD_ORDER_DETAIL_DESTINATION = "destination";
  static const String FIELD_OFFER_DETAILS = "offer_details";
  static const String FIELD_SERVICE_COST = "service_cost";
  static const String FIELD_ACCEPTED_PAYMENT_METHODS =
      "accepted_payment_methods";
  static const String FIELD_LIVE_LOCATION = "live_location";
  static const String FIELD_DELIVERY_ORDERS_STATUSES = "statuses";
  static const String FIELD_DELIVERY_ORDERS_CURRENT_STATUS = "current_status";

  // My Delivery Orders table collection
  static const String TABLE_MY_DELIVERY_ORDERS = "my_delivery_orders";

  // Report Customers table collection
  static const String TABLE_REPORT_CUSTOMERS = "report_customers";
  static const String FIELD_TITLE = "title";
  static const String FIELD_ATTACHED_FILES = "attached_files";

  // Report Customers table collection
  static const String TABLE_REVIEWS = "reviews";

  // Nextry Hot deals collection
  static const String TABLE_NEXTRY_HOT_DEALS = "nextry_hot_deals";

  // Report Customers table collection
  static const String TABLE_PAYMENT_LINKS_REQUESTS = "payment_links_requests";
  static const String FIELD_IS_HANDLED = 'isHandled';
  static const String FIELD_EMPLOYEE_ID = 'employee_id';
  static const String FIELD_EMPLOYEE_NOTES = 'employee_notes';

  static const String TABLE_SHIPPER_PAYMENT_REQUESTS =
      "shipper_payment_requests";
  static const String FIELD_SHIPPER_PAYMENT_SHIPPER_ID = "shipper_id";

  // Notification Table Collection
  static const String TABLE_NOTIFICATIONS = 'notifications';
  static const String FIELD_DELIVERY_REQUEST_ID = 'delivery_request_id';
  static const String FIELD_DELIVERY_ORDER_ID = 'delivery_order_id';

  //Shipper Feedback reported
  static const String TABLE_SHIPPER_FEEDBACK_REPORTED =
      "shipper_feedback_reported";

  //Ask me table collection
  static const String TABLE_ASK_ME = "ask_me";
  static const String FIELD_ASK_ME_STATUS = "status";
  static const String FIELD_ASK_ME_ATTACHMENTS = "attachments";
  static const String FIELD_ASK_ME_USERID = "userId";
  static const String FIELD_ASK_ME_DESC = "description";
  static const String FIELD_ASK_ME_TITLE = "title";

  /// Force update Configuration
  static const String FIELD_FORCE_UPDATE_MESSAGE = "message";
  static const String FIELD_IS_FORCE = "is_force";
  static const String FIELD_VERSION = "version";
  static const String FIELD_APP_URL = "app_url";

  // PayPlus Subscriptions
  static String PAYPLUS_BASE_URL =
      'restapidev.payplus.co.il'; // For staging or testing url
  static String PAYPLUS_TERMINAL_ID =
      ''; //TODO need to replace with the provided terminal ID
  static String PAYPLUS_CUSTOMER = '/api/v1.0/Customers/Add';
  static String PAYPLUS_CARD_TOKEN = '/api/v1.0/Token/Add';
  static String PAYPLUS_RECURRING_PYAMENTS = '/api/v1.0/RecurringPayments/Add';
  static String PAYPLUS_CUSTOMER_RECURRING_PAYMENTS =
      '/api/v1.0/RecurringPayments/View';
  static String PAYPLUS_DELETE_RECURRING_PYAMENTS =
      '/api/v1.0/RecurringPayments/DeleteRecurring/';
  static String PAYPLUS_VIEW_RECURRING_PYAMENTS =
      '/api/v1.0/RecurringPayments/';
  static String PAYPLUS_VIEW_RECURRING = '/ViewRecurring/';
  static String PAYPLUS_GENERATE_PAYMENT_LINK =
      '/api/v1.0/PaymentPages/generateLink';
  static String PAYPLUS_REFUND_BY_TRANSACTION_ID =
      "/api/v1.0/Transactions/RefundByTransactionUID";

  static String PAYPLUS_PAYMENT_SUCCSS_URL = "https://nextryapp.com/success/";
  static String PAYPLUS_PAYMENT_FAILURE_URL = "https://nextryapp.com/failure/";
  static String PAYPLUS_PAYMENT_CANCEL_URL = "https://nextryapp.com/cancel/";
  static String PAYPLUS_PAYMENT_CALLBACK_URL =
      "https://nextryapp.com/callback/";

  static String PAYPLUS_FIELD_RECURRING_ID = "recurring_payment_uid";
  static String PAYPLUS_FIELD_TERMINAL_ID = "terminal_uid";
  static String PAYPLUS_FIELD_CUSTOMER_ID = "customer_uid";
  static String PAYPLUS_FIELD_TRANSACTION_ID = "transaction_uid";
  static int PAYPLUS_SUBSCRIPTION_CHARGE_METHOD = 3;
  static int PAYPLUS_P2P_CHARGE_METHOD = 1;
  static int PAYPLUS_RECURRING_TYPE_MONTHLY = 2;
  static int PAYPLUS_RECURRING_RANGE_EVERY_MONTH = 1;
}

/// Navigation constants. Based on this application open relevant screen.
enum NavigationStatus { SPLASH, EMAIL_NOT_VERIFY, HOME }
