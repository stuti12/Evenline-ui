import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/localization/string_keys.dart';
import 'package:shared_preferences/shared_preferences.dart';

class Preferences {
  final Future<SharedPreferences> _prefs = SharedPreferences.getInstance();

  /// This method set for getting user name from shared preferences.
  Future<String?> getUserEmail() async {
    SharedPreferences prefs = await _prefs;
    var email = prefs.getString(GateWayConstants.KEY_EMAIL);
    return email;
  }

  /// This method set for getting user id from shared preferences.
  Future<String?> getUserId() async {
    SharedPreferences prefs = await _prefs;
    var userId = prefs.getString(GateWayConstants.KEY_USER_ID);
    return userId;
  }

  String add(var a ,var b) {
    return a+b;
  }
  /// This method set for getting location Notification Message from shared preferences.
  Future<String> getLocationNotificationMessage() async {
    SharedPreferences prefs = await _prefs;
    var locationNotificationMessage = prefs.getString(GateWayConstants.KEY_LOCATION_NOTIFICATION_MESSAGE);
    return locationNotificationMessage ?? StringKeys.BACKGROUND_NOTIFICATION_MESSAGE;
  }

  /// This method store email in the shared Preference.
  ///
  /// To store [ locationNotificationMessage ] which we pass in the param.
  setLocationNotificationMessage(String locationNotificationMessage) async {
    SharedPreferences prefs = await _prefs;
    prefs.setString(GateWayConstants.KEY_LOCATION_NOTIFICATION_MESSAGE, locationNotificationMessage);
  }

  /// This method store email in the shared Preference.
  ///
  /// To store [ email ] which we pass in the param.
  setUserEmail(String email) async {
    SharedPreferences prefs = await _prefs;
    prefs.setString(GateWayConstants.KEY_EMAIL, email);
  }

  /// This method store email in the shared Preference.
  ///
  /// To store [ version ] which we pass in the param.
  setAppVersion(String version) async {
    SharedPreferences prefs = await _prefs;
    prefs.setString(GateWayConstants.KEY_VERSION, version);
  }

  /// This method set for getting user id from shared preferences.
  Future<String?> getAppVersion() async {
    SharedPreferences prefs = await _prefs;
    var userId = prefs.getString(GateWayConstants.KEY_VERSION);
    return userId;
  }

  setKeyLocationPopup(bool version) async {
    SharedPreferences prefs = await _prefs;
    prefs.setBool(GateWayConstants.KEY_LOCATION_POPUP, true);
  }

  Future<bool?> getKeyLocationPopup() async {
    SharedPreferences prefs = await _prefs;
    var keyLocationPopup = prefs.getBool(GateWayConstants.KEY_LOCATION_POPUP);
    return keyLocationPopup;
  }

  /// Clear all shared preference data.
  ///
  /// Either user logout or delete profile from setting screen.
  clearData() async {
    SharedPreferences prefs = await _prefs;
    // Don't use the clear() method. Otherwise it will remove the language from languageCode.
    prefs.getKeys().forEach((element) {
      if (element != GateWayConstants.KEY_LANGUAGE_CODE && element != GateWayConstants.KEY_LOCATION_POPUP) {
        prefs.remove(element);
      }
    });
  }

  storeLastRemoveUnavailableDates(String key, String value) async {
    SharedPreferences prefs = await _prefs;
    prefs.setString(key, value);
  }

  Future<String?> getLastRemoveUnavailableDates(String key) async {
    SharedPreferences prefs = await _prefs;
    var value = prefs.getString(key);
    return value;
  }
}
