class CustomException with Exception {
  String? message;

  CustomException({this.message});
}
