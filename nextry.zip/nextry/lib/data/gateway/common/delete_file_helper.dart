import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';

class DeleteFileHelper {
  final _firebaseStorage = FirebaseStorage.instance;
  User? user = FirebaseAuth.instance.currentUser;

  Future<bool> deleteFileFromFireStore(String firebaseUrl) async {
    try {
      final fileName = _firebaseStorage.refFromURL(firebaseUrl).name;
      final desertRef = _firebaseStorage.ref().child("${user?.uid}/$fileName");
      // Delete the file
      await desertRef.delete();
      return true;
    } catch (e) {
      print(e);
      return false;
    }
  }
}
