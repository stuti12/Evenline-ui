import 'dart:convert';

import 'package:http/http.dart' as http;
import 'package:nextry_dev/data/gateway/common/custom_exception.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';

class HttpService {
  static Future getHttp(String endUrl,
      {Map<String, dynamic>? queryParameters,
      Map<String, String>? headers}) async {
    try {
      var url = Uri.https(GateWayConstants.BASE_URL, endUrl, queryParameters);
      Map<String, String> header = {
        'Authorization':
            'Bearer sk_test_51N1a6mA96WVwXAJrRDPQOZfaWi2pIJklFPKxK0rNHsAOIKY35aPRMAJpzw0i4OO9CWzSbAv4UHdrffjUBS7UxjCo00z13xrxYx',
        'Content-Type': 'application/x-www-form-urlencoded'
      };
      if (headers != null) {
        header.addAll(headers);
      }
      var response = await http.get(url, headers: header);
      var responseData = response.body;
      if (response.statusCode == 200) {
        print(responseData);
        return json.decode(responseData);
      } else {
        var errorResponse = json.decode(responseData);
        var error = errorResponse[GateWayConstants.FIELD_ERROR]
            [GateWayConstants.FIELD_MESSAGE];
        print("Get API, error: $error");
        throw CustomException(message: error);
      }
    } catch (e) {
      print("Get API, catch error: $e");
      rethrow;
    }
  }

  static Future postHttp(String endUrl, Object body,
      [Map<String, String>? headers]) async {
    try {
      var url = Uri.https(GateWayConstants.BASE_URL, endUrl);
      Map<String, String> header = {
        'Authorization':
            'Bearer sk_test_51N1a6mA96WVwXAJrRDPQOZfaWi2pIJklFPKxK0rNHsAOIKY35aPRMAJpzw0i4OO9CWzSbAv4UHdrffjUBS7UxjCo00z13xrxYx',
        'Content-Type': 'application/x-www-form-urlencoded'
      };
      if (headers != null) {
        header.addAll(headers);
      }
      var response = await http.post(
        url,
        headers: header,
        body: body,
      );
      var responseData = response.body;
      if (response.statusCode == 200) {
        print(responseData);
        return json.decode(responseData);
      } else {
        var errorResponse = json.decode(responseData);
        var error = errorResponse[GateWayConstants.FIELD_ERROR]
            [GateWayConstants.FIELD_MESSAGE];
        print("Post API, error: $error");
        throw CustomException(message: error);
      }
    } catch (e) {
      print("Post API, catch error: $e");
      rethrow;
    }
  }
}
