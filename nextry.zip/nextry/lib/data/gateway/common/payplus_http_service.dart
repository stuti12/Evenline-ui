import 'dart:convert';

import 'package:http/http.dart' as http;
import 'package:nextry_dev/data/gateway/common/custom_exception.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';

class PayPlusHttpService {
  static Future getHttp(String endUrl,
      {Map<String, dynamic>? queryParameters,
      Map<String, String>? headers}) async {
    try {
      var url =
          Uri.https(GateWayConstants.PAYPLUS_BASE_URL, endUrl, queryParameters);
      //TODO replace api_key with the provided api key and secret key by the Payplus
      Map<String, String> header = {
        // 'Authorization' : "{\"api_key\":\"ae46161e-4b70-4167-84ab-bde1a7f751b2\",\"secret_key\":\"ae9dc42d-3a56-4306-babb-1ba15beab5b7\"}",
        'Content-Type': 'application/json'
      };
      if (headers != null) {
        header.addAll(headers);
      }
      var response = await http.get(url, headers: header);
      var responseData = response.body;
      if (response.statusCode == 200) {
        print(responseData);
        return json.decode(responseData);
      } else {
        var errorResponse = json.decode(responseData);
        var error = errorResponse[GateWayConstants.FIELD_ERROR]
            [GateWayConstants.FIELD_MESSAGE];
        print("Get API, error: $error");
        throw CustomException(message: error);
      }
    } catch (e) {
      print("Get API, catch error: $e");
      rethrow;
    }
  }

  static Future postHttp(String endUrl, Object body,
      [Map<String, String>? headers]) async {
    try {
      var url = Uri.https(GateWayConstants.PAYPLUS_BASE_URL, endUrl);
      //TODO replace api_key with the provided api key and secret key by the Payplus
      Map<String, String> header = {
        // 'Authorization' : "{\"api_key\":\"ae46161e-4b70-4167-84ab-bde1a7f751b2\",\"secret_key\":\"ae9dc42d-3a56-4306-babb-1ba15beab5b7\"}",
        'Content-Type': 'application/json'
      };
      if (headers != null) {
        header.addAll(headers);
      }
      var response = await http.post(
        url,
        headers: header,
        body: jsonEncode(body),
      );
      var responseData = response.body;
      if (response.statusCode == 200) {
        print(responseData);
        return json.decode(responseData);
      } else {
        var errorResponse = json.decode(responseData);
        var error = errorResponse[GateWayConstants.FIELD_ERROR]
            [GateWayConstants.FIELD_MESSAGE];
        print("Post API, error: $error");
        throw CustomException(message: error);
      }
    } catch (e) {
      print("Post API, catch error: $e");
      rethrow;
    }
  }
}
