import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:nextry_dev/presentation/common/utils/app_extension.dart';

/// This class responsible to upload image on fire storage.
class UploadFileHelper {
  final _firebaseStorage = FirebaseStorage.instance;
  User? user = FirebaseAuth.instance.currentUser;

  /// Upload local file which is located on [ path ] and return server URL.
  Future<String> uploadFileToFireStore(String path) async {
    var imageURL = await _getFileURL(path, user?.uid ?? '');
    return imageURL;
  }

  /// Private method to upload image to firebase store and return the relevant URL.
  Future<String> _getFileURL(String fileUrl, String directoryPath) async {
    File file = File(fileUrl);
    Reference firebaseStorageRef = _firebaseStorage
        .ref()
        .child(directoryPath)
        .child("${Timestamp.now().millisecondsSinceEpoch}_${file.name}");
    await firebaseStorageRef.putFile(file);
    return await firebaseStorageRef.getDownloadURL();
  }

  /// Upload local file which is located on [ path ] and return server URL.
  Future<String> uploadFileToFireStoreForAskMe(String path) async {
    var imageURL = await _getFileURL(path, "askMe/${user?.uid ?? ''}");
    return imageURL;
  }
}
