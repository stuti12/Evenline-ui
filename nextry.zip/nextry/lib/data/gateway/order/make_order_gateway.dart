import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/domain/entities/error/common_errors.dart';
import 'package:nextry_dev/domain/entities/order/make_order_param.dart';
import 'package:nextry_dev/domain/entities/order/make_order_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';

class MakeOrderGateWay
    implements ReadGateWay<MakeOrderResponseEntity, MakeOrderParam> {
  @override
  Future<MakeOrderResponseEntity> read(MakeOrderParam data) async {
    try {
      final userId = FirebaseAuth.instance.currentUser?.uid;

      final ref = await FirebaseFirestore.instance
          .collection(GateWayConstants.TABLE_BUSINESSES)
          .doc(data.orderEntity?.businessId)
          .collection(GateWayConstants.TABLE_ORDERS)
          .add(data.orderEntity!.toJson(userId: userId));

      final Map<String, dynamic> param = <String, dynamic>{};
      param[GateWayConstants.FIELD_ORDER_REF] = ref;
      param[GateWayConstants.FIELD_BUSINESS_ID] = data.orderEntity?.businessId;
      param[GateWayConstants.FIELD_ORDER_ID] = ref.id;
      await FirebaseFirestore.instance
          .collection(GateWayConstants.TABLE_USERS)
          .doc(userId)
          .collection(GateWayConstants.TABLE_ORDERS)
          .add(param);

      await FirebaseFirestore.instance
          .collection(GateWayConstants.TABLE_USERS)
          .doc(userId)
          .collection(GateWayConstants.TABLE_CART)
          .doc(data.cartId)
          .delete();

      return MakeOrderResponseEntity(orderId: ref.id, isSuccess: true);
    } catch (e) {
      print(e);
      return MakeOrderResponseEntity(commonErrors: CommonErrors.fromJson({}));
    }
  }

  @override
  void unsubscribe() {}
}
