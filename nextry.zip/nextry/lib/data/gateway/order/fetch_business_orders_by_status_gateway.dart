import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/domain/entities/error/common_errors.dart';
import 'package:nextry_dev/domain/entities/order/fetch_orders_param.dart';
import 'package:nextry_dev/domain/entities/order/fetch_orders_response_entity.dart';
import 'package:nextry_dev/domain/entities/order/order_entity.dart';
import 'package:nextry_dev/domain/entities/profile/user_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';

class FetchBusinessOrdersByStatusGateWay
    implements ReadGateWay<FetchOrdersResponseEntity, FetchOrdersParam> {
  StreamSubscription<QuerySnapshot<Map<String, dynamic>>>? streamSubscription;

  @override
  Future<FetchOrdersResponseEntity> read(
      FetchOrdersParam fetchOrdersParam) async {
    try {
      final orderRef = FirebaseFirestore.instance
          .collection(GateWayConstants.TABLE_BUSINESSES)
          .doc(fetchOrdersParam.businessId)
          .collection(GateWayConstants.TABLE_ORDERS);
      if (fetchOrdersParam.status != null &&
          fetchOrdersParam.status!.isNotEmpty) {
        orderRef.where(GateWayConstants.FIELD_ORDER_STAUS,
            isEqualTo: fetchOrdersParam.status);
      }

      streamSubscription?.cancel();
      streamSubscription = orderRef.snapshots().listen((event) async {
        List<OrderEntity> orders = [];
        await Future.wait(event.docs.map((element) async {
          if (element.exists) {
            final data = element.data();
            final userEntity =
                await _fetchUserData(data[GateWayConstants.FIELD_USER_ID]);
            orders
                .add(OrderEntity.fromJson(data, element.id, user: userEntity));
          }
        }));

        orders.sort((a, b) => a.createdAt == null
            ? 1
            : b.createdAt == null
                ? -1
                : b.createdAt!.compareTo(a.createdAt!));

        if (fetchOrdersParam.function != null) {
          fetchOrdersParam.function!(orders);
        }
      });

      return FetchOrdersResponseEntity(orders: [], commonErrors: null);
    } catch (e) {
      print(e);
      return FetchOrdersResponseEntity(commonErrors: CommonErrors.fromJson({}));
    }
  }

  @override
  void unsubscribe() {
    streamSubscription?.cancel();
  }

  Future<UserEntity?> _fetchUserData(String? userId) async {
    var snapshot = await FirebaseFirestore.instance
        .collection(GateWayConstants.TABLE_USERS)
        .doc(userId)
        .get();
    if (snapshot.exists) {
      var data = snapshot.data();
      if (data != null) {
        return UserEntity.fromJson(data, snapshot.id);
      }
    }
    return null;
  }
}
