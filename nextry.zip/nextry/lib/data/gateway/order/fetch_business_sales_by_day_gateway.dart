import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/domain/entities/error/common_errors.dart';
import 'package:nextry_dev/domain/entities/order/fetch_business_orders_by_day_response_entity.dart';
import 'package:nextry_dev/domain/entities/order/fetch_orders_param.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/presentation/common/utils/app_constants.dart';

class FetchBusinessSalesByDayGateWay
    implements
        ReadGateWay<FetchBusinessOrdersByDayResponseEntity, FetchOrdersParam> {
  @override
  Future<FetchBusinessOrdersByDayResponseEntity> read(
      FetchOrdersParam fetchOrdersParam) async {
    try {
      var now = DateTime.now();
      var todayDate = DateTime(now.year, now.month, now.day);
      if (fetchOrdersParam.noOfDays != 1) {
        todayDate =
            todayDate.subtract(Duration(days: fetchOrdersParam.noOfDays ?? 1));
      }

      final snapShot = await FirebaseFirestore.instance
          .collection(GateWayConstants.TABLE_BUSINESSES)
          .doc(fetchOrdersParam.businessId)
          .collection(GateWayConstants.TABLE_ORDERS)
          .where(GateWayConstants.FIELD_ORDER_STAUS, whereIn: [
            OrderStatus.withShipper.name,
            OrderStatus.pickedUp.name
          ])
          .where(GateWayConstants.FIELD_CREATED_AT,
              isGreaterThanOrEqualTo: todayDate)
          .orderBy(GateWayConstants.FIELD_CREATED_AT, descending: true)
          .get();

      num totalAmount = 0;
      for (var element in snapShot.docs) {
        if (element.exists) {
          var data = element.data();
          var amount = data[GateWayConstants.FIELD_ORDER_TOTAL_AMOUNT];
          totalAmount = (totalAmount + amount);
        }
      }
      return FetchBusinessOrdersByDayResponseEntity(
          numberOfOrders: totalAmount, commonErrors: null);
    } catch (e) {
      print(e);
      return FetchBusinessOrdersByDayResponseEntity(
          commonErrors: CommonErrors.fromJson({}));
    }
  }

  @override
  void unsubscribe() {}
}
