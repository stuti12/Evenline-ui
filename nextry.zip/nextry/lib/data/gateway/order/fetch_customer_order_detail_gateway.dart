import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/domain/entities/business/business_entity.dart';
import 'package:nextry_dev/domain/entities/error/common_errors.dart';
import 'package:nextry_dev/domain/entities/order/fetch_order_detail_param.dart';
import 'package:nextry_dev/domain/entities/order/fetch_order_detail_response_entity.dart';
import 'package:nextry_dev/domain/entities/order/order_entity.dart';
import 'package:nextry_dev/domain/entities/product/product_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';

class FetchCustomerOrderDetailGateWay
    implements
        ReadGateWay<FetchOrderDetailResponseEntity, FetchOrderDetailParam> {
  StreamSubscription<DocumentSnapshot<Map<String, dynamic>>>?
      streamSubscription;

  @override
  Future<FetchOrderDetailResponseEntity> read(
      FetchOrderDetailParam param) async {
    try {
      final orderRef = await FirebaseFirestore.instance
          .collection(GateWayConstants.TABLE_BUSINESSES)
          .doc(param.businessId)
          .collection(GateWayConstants.TABLE_ORDERS)
          .doc(param.orderId);

      await streamSubscription?.cancel();
      streamSubscription = orderRef.snapshots().listen((event) async {
        if (param.function != null) {
          param.function!(await _parseOrderDetailData(event, param.orderId));
        }
      });

      var snapshot = await orderRef.get();

      OrderEntity? orderEntity =
          await _parseOrderDetailData(snapshot, param.orderId);

      return FetchOrderDetailResponseEntity(orderEntity: orderEntity);
    } catch (e) {
      print(e);
      return FetchOrderDetailResponseEntity(
          commonErrors: CommonErrors.fromJson({}));
    }
  }

  Future<OrderEntity?> _parseOrderDetailData(
      DocumentSnapshot<Map<String, dynamic>> snapshot, String? orderId) async {
    OrderEntity? orderEntity;
    if (snapshot.exists) {
      var data = snapshot.data();
      if (data != null) {
        orderEntity = OrderEntity.fromJson(data, orderId!);
        orderEntity.businessEntity =
            await _fetchBusinessData(orderEntity.businessId);
      }
    }

    if (orderEntity?.products != null && orderEntity!.products!.isNotEmpty) {
      await Future.wait(orderEntity.products!.map((element) async {
        element.productEntity = await _fetchProductData(
            businessId: orderEntity?.businessId, productId: element.productId);
      }));
    }
    return orderEntity;
  }

  Future<ProductEntity?> _fetchProductData(
      {String? businessId, String? productId}) async {
    var snapshot = await FirebaseFirestore.instance
        .collection(GateWayConstants.TABLE_BUSINESSES)
        .doc(businessId)
        .collection(GateWayConstants.TABLE_PRODUCT)
        .doc(productId)
        .get();
    if (snapshot.exists) {
      var data = snapshot.data();
      if (data != null) {
        return ProductEntity.fromJson(data, snapshot.id, businessId ?? '');
      }
    }
    return null;
  }

  Future<BusinessEntity?> _fetchBusinessData(String? businessId) async {
    var snapshot = await FirebaseFirestore.instance
        .collection(GateWayConstants.TABLE_BUSINESSES)
        .doc(businessId)
        .get();
    if (snapshot.exists) {
      var data = snapshot.data();
      if (data != null) {
        return BusinessEntity.fromJSON(data, businessId ?? '');
      }
    }
    return null;
  }

  @override
  void unsubscribe() {}
}
