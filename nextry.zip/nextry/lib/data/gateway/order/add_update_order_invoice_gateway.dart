import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/data/gateway/common/upload_file_helper.dart';
import 'package:nextry_dev/domain/entities/error/common_errors.dart';
import 'package:nextry_dev/domain/entities/order/add_update_order_invoice_param.dart';
import 'package:nextry_dev/domain/entities/order/add_update_order_invoice_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/presentation/common/utils/app_constants.dart';

class AddUpdateOrderInvoiceGateway
    implements
        ReadGateWay<AddUpdateOrderInvoiceResponseEntity,
            AddUpdateOrderInvoiceParam> {
  @override
  Future<AddUpdateOrderInvoiceResponseEntity> read(
      AddUpdateOrderInvoiceParam data) async {
    try {
      if (data.invoice.isNotEmpty &&
          !data.invoice.startsWith(AppConstants.SERVER_FILE)) {
        final imageURL =
            await UploadFileHelper().uploadFileToFireStore(data.invoice);

        final param = <String, dynamic>{};
        param[GateWayConstants.FIELD_ORDER_INVOICE] = imageURL;

        await FirebaseFirestore.instance
            .collection(GateWayConstants.TABLE_BUSINESSES)
            .doc(data.businessId)
            .collection(GateWayConstants.TABLE_ORDERS)
            .doc(data.orderId)
            .set(param, SetOptions(merge: true));
      }

      return AddUpdateOrderInvoiceResponseEntity(isSuccess: true);
    } catch (e) {
      print(e);
      return AddUpdateOrderInvoiceResponseEntity(
          commonErrors: CommonErrors.fromJson({}));
    }
  }

  @override
  void unsubscribe() {}
}
