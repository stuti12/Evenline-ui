import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/domain/entities/error/common_errors.dart';
import 'package:nextry_dev/domain/entities/order/canel_order_param.dart';
import 'package:nextry_dev/domain/entities/order/update_order_status_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';

class CancelOrderGateWay
    implements ReadGateWay<UpdateOrderStatusResponseEntity, CancelOrderParam> {
  @override
  Future<UpdateOrderStatusResponseEntity> read(
      CancelOrderParam cancelOrderParam) async {
    try {
      await FirebaseFirestore.instance
          .collection(GateWayConstants.TABLE_BUSINESSES)
          .doc(cancelOrderParam.businessId)
          .collection(GateWayConstants.TABLE_ORDERS)
          .doc(cancelOrderParam.orderId)
          .set(cancelOrderParam.toJson(), SetOptions(merge: true));

      return UpdateOrderStatusResponseEntity(
          isSuccess: true, commonErrors: null);
    } catch (e) {
      print(e);
      return UpdateOrderStatusResponseEntity(
          isSuccess: false, commonErrors: CommonErrors.fromJson({}));
    }
  }

  @override
  void unsubscribe() {}
}
