import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/domain/entities/business/business_entity.dart';
import 'package:nextry_dev/domain/entities/error/common_errors.dart';
import 'package:nextry_dev/domain/entities/order/fetch_orders_response_entity.dart';
import 'package:nextry_dev/domain/entities/order/order_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';

class FetchCustomerOrdersGateWay
    implements ReadGateWay<FetchOrdersResponseEntity, Function> {
  StreamSubscription<QuerySnapshot<Map<String, dynamic>>>? streamSubscription;

  @override
  Future<FetchOrdersResponseEntity> read(Function function) async {
    try {
      final userId = FirebaseAuth.instance.currentUser?.uid;

      if(userId != null && userId.isNotEmpty) {
        final orderRef = FirebaseFirestore.instance
            .collection(GateWayConstants.TABLE_USERS)
            .doc(userId)
            .collection(GateWayConstants.TABLE_ORDERS);

        await streamSubscription?.cancel();
        streamSubscription = orderRef.snapshots().listen((event) async {
          function(await _parseOrderData(event));
        });

        final snapshot = await orderRef.get();

        return FetchOrdersResponseEntity(
            orders: await _parseOrderData(snapshot), commonErrors: null);
      } else {
        return FetchOrdersResponseEntity(
            orders: null, commonErrors: null);
      }
    } catch (e) {
      print(e);
      return FetchOrdersResponseEntity(commonErrors: CommonErrors.fromJson({}));
    }
  }

  Future<List<OrderEntity>> _parseOrderData(
      QuerySnapshot<Map<String, dynamic>> snapshot) async {
    List<OrderEntity> orders = [];
    await Future.wait(snapshot.docs.map((element) async {
      if (element.exists) {
        var data = element.data();
        final refData = data[GateWayConstants.FIELD_ORDER_REF]
            as DocumentReference<Map<String, dynamic>>;
        final orderRefSnapShot = await refData.get();
        if (orderRefSnapShot.exists) {
          final orderEntity = OrderEntity.fromJson(
              orderRefSnapShot.data()!, data[GateWayConstants.FIELD_ORDER_ID]);
          orderEntity.businessEntity =
              await _fetchBusinessData(orderEntity.businessId);
          orders.add(orderEntity);
        }
      }
    }));

    orders.sort((a, b) => a.createdAt == null
        ? 1
        : b.createdAt == null
            ? -1
            : b.createdAt!.compareTo(a.createdAt!));

    return orders;
  }

  Future<BusinessEntity?> _fetchBusinessData(String? businessId) async {
    var snapshot = await FirebaseFirestore.instance
        .collection(GateWayConstants.TABLE_BUSINESSES)
        .doc(businessId)
        .get();
    if (snapshot.exists) {
      var data = snapshot.data();
      if (data != null) {
        return BusinessEntity.fromJSON(data, businessId ?? '');
      }
    }
    return null;
  }

  @override
  void unsubscribe() {
    streamSubscription?.cancel();
  }
}
