import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/domain/entities/business/business_entity.dart';
import 'package:nextry_dev/domain/entities/error/common_errors.dart';
import 'package:nextry_dev/domain/entities/order/fetch_order_detail_param.dart';
import 'package:nextry_dev/domain/entities/order/fetch_order_detail_response_entity.dart';
import 'package:nextry_dev/domain/entities/order/order_entity.dart';
import 'package:nextry_dev/domain/entities/product/product_entity.dart';
import 'package:nextry_dev/domain/entities/profile/user_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';

class FetchBusinessOrderDetailGateWay
    implements
        ReadGateWay<FetchOrderDetailResponseEntity, FetchOrderDetailParam> {
  @override
  Future<FetchOrderDetailResponseEntity> read(
      FetchOrderDetailParam param) async {
    try {
      final snapshot = await FirebaseFirestore.instance
          .collection(GateWayConstants.TABLE_BUSINESSES)
          .doc(param.businessId)
          .collection(GateWayConstants.TABLE_ORDERS)
          .doc(param.orderId)
          .get();
      OrderEntity? orderEntity;
      if (snapshot.exists) {
        var data = snapshot.data();
        if (data != null) {
          final userEntity =
              await _fetchUserData(data[GateWayConstants.FIELD_USER_ID]);
          orderEntity =
              OrderEntity.fromJson(data, param.orderId!, user: userEntity);
        }
      }

      if (orderEntity?.products != null && orderEntity!.products!.isNotEmpty) {
        await Future.wait(orderEntity.products!.map((element) async {
          element.productEntity = await _fetchProductData(
              businessId: orderEntity?.businessId,
              productId: element.productId);
        }));
      }

      final businessEntity =
      await _fetchBusinessData(param.businessId);

      orderEntity?.businessEntity = businessEntity;


      return FetchOrderDetailResponseEntity(orderEntity: orderEntity);
    } catch (e) {
      print(e);
      return FetchOrderDetailResponseEntity(
          commonErrors: CommonErrors.fromJson({}));
    }
  }

  Future<ProductEntity?> _fetchProductData(
      {String? businessId, String? productId}) async {
    var snapshot = await FirebaseFirestore.instance
        .collection(GateWayConstants.TABLE_BUSINESSES)
        .doc(businessId)
        .collection(GateWayConstants.TABLE_PRODUCT)
        .doc(productId)
        .get();
    if (snapshot.exists) {
      var data = snapshot.data();
      if (data != null) {
        return ProductEntity.fromJson(data, snapshot.id, businessId ?? '');
      }
    }
    return null;
  }

  Future<UserEntity?> _fetchUserData(String? userId) async {
    var snapshot = await FirebaseFirestore.instance
        .collection(GateWayConstants.TABLE_USERS)
        .doc(userId)
        .get();
    if (snapshot.exists) {
      var data = snapshot.data();
      if (data != null) {
        return UserEntity.fromJson(data, snapshot.id);
      }
    }
    return null;
  }

  @override
  void unsubscribe() {}

  Future<BusinessEntity?> _fetchBusinessData(String? businessId) async {
    var snapshot = await FirebaseFirestore.instance
        .collection(GateWayConstants.TABLE_BUSINESSES)
        .doc(businessId)
        .get();
    if (snapshot.exists) {
      var data = snapshot.data();
      if (data != null) {
        return BusinessEntity.fromJSON(data, businessId ?? '');
      }
    }
    return null;
  }
}
