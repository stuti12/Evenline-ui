import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/domain/entities/error/common_errors.dart';
import 'package:nextry_dev/domain/entities/order/update_order_status_param.dart';
import 'package:nextry_dev/domain/entities/order/update_order_status_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/presentation/common/utils/app_constants.dart';

class UpdateOrderStatusGateWay
    implements
        ReadGateWay<UpdateOrderStatusResponseEntity, UpdateOrderStatusParam> {
  @override
  Future<UpdateOrderStatusResponseEntity> read(
      UpdateOrderStatusParam updateOrderStatusParam) async {
    try {
      final data = <String, dynamic>{};
      data[GateWayConstants.FIELD_ORDER_STAUS] = updateOrderStatusParam.status;

      await FirebaseFirestore.instance
          .collection(GateWayConstants.TABLE_BUSINESSES)
          .doc(updateOrderStatusParam.businessId)
          .collection(GateWayConstants.TABLE_ORDERS)
          .doc(updateOrderStatusParam.orderId)
          .set(data, SetOptions(merge: true));

      if (updateOrderStatusParam.status == OrderStatus.withShipper.name) {
        final deliveryOrderStatus = <String, dynamic>{};
        deliveryOrderStatus[
                GateWayConstants.FIELD_DELIVERY_ORDERS_CURRENT_STATUS] =
            DeliveryStatus.inTransit.name;
        deliveryOrderStatus[GateWayConstants.FIELD_DELIVERY_ORDERS_STATUSES] = {
          DeliveryStatus.inTransit.name: Timestamp.now()
        };

        await FirebaseFirestore.instance
            .collection(GateWayConstants.TABLE_DELIVERY_ORDERS)
            .doc(updateOrderStatusParam.deliveryOrderId)
            .set(deliveryOrderStatus, SetOptions(merge: true));
      }
      return UpdateOrderStatusResponseEntity(
          isSuccess: true, commonErrors: null);
    } catch (e) {
      print(e);
      return UpdateOrderStatusResponseEntity(
          isSuccess: false, commonErrors: CommonErrors.fromJson({}));
    }
  }

  @override
  void unsubscribe() {}
}
