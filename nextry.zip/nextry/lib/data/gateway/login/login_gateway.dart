import 'package:firebase_auth/firebase_auth.dart';
import 'package:nextry_dev/data/gateway/common/preferences.dart';
import 'package:nextry_dev/domain/entities/error/common_errors.dart';
import 'package:nextry_dev/domain/entities/login/login_param.dart';
import 'package:nextry_dev/domain/entities/login/login_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';

class LoginGateWay implements ReadGateWay<LoginResponseEntity, LoginParam> {
  @override
  Future<LoginResponseEntity> read(LoginParam loginParams) async {
    final Preferences _prefs = Preferences();

    try {
      UserCredential userCredential =
          await FirebaseAuth.instance.signInWithEmailAndPassword(
        email: loginParams.email,
        password: loginParams.password,
      );
      _prefs.setUserEmail(loginParams.email);
      return LoginResponseEntity(userCredential: userCredential, error: null);
    } on FirebaseAuthException catch (e) {
      return LoginResponseEntity(
          userCredential: null,
          error: CommonErrors(errorCode: e.code, message: e.message!));
    }
  }

  @override
  void unsubscribe() {}
}
