import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/domain/entities/error/common_errors.dart';
import 'package:nextry_dev/domain/entities/payment_link/add_update_request_payment_link_response_entity.dart';
import 'package:nextry_dev/domain/entities/payment_link/request_payment_link_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';

class AddUpdateRequestPaymentLinkGateway
    implements
        ReadGateWay<AddUpdateRequestPaymentLinkResponseEntity,
            RequestPaymentLinkEntity> {
  @override
  Future<AddUpdateRequestPaymentLinkResponseEntity> read(
      RequestPaymentLinkEntity data) async {
    try {
      final userId = FirebaseAuth.instance.currentUser?.uid;
      if (data.id != null && data.id!.isNotEmpty) {
        await FirebaseFirestore.instance
            .collection(GateWayConstants.TABLE_PAYMENT_LINKS_REQUESTS)
            .doc(data.id)
            .set(data.toJson(userId ?? ''), SetOptions(merge: true));
      }

      return AddUpdateRequestPaymentLinkResponseEntity(isSuccess: true);
    } catch (e) {
      print(e);
      return AddUpdateRequestPaymentLinkResponseEntity(
          isSuccess: false, commonErrors: CommonErrors.fromJson({}));
    }
  }

  @override
  void unsubscribe() {}
}
