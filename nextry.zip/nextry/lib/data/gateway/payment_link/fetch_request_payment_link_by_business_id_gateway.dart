import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/domain/entities/error/common_errors.dart';
import 'package:nextry_dev/domain/entities/payment_link/fetch_request_payment_link_by_business_id_response_entity.dart';
import 'package:nextry_dev/domain/entities/payment_link/request_payment_link_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';

class FetchRequestPaymentLinkByBusinessIdGateWay
    implements
        ReadGateWay<FetchRequestPaymentLinkByBusinessIdResponseEntity, String> {
  @override
  Future<FetchRequestPaymentLinkByBusinessIdResponseEntity> read(
      String businessId) async {
    try {
      var snapshot = await FirebaseFirestore.instance
          .collection(GateWayConstants.TABLE_PAYMENT_LINKS_REQUESTS)
          .doc(businessId)
          .get();

      RequestPaymentLinkEntity? requestPaymentLinkEntity;
      if (snapshot.exists) {
        var data = snapshot.data();
        if (data != null) {
          requestPaymentLinkEntity =
              RequestPaymentLinkEntity.fromJSON(data, snapshot.id);
        }
      }
      return FetchRequestPaymentLinkByBusinessIdResponseEntity(
          requestPaymentLinkEntity: requestPaymentLinkEntity);
    } catch (e) {
      print(e);
      return FetchRequestPaymentLinkByBusinessIdResponseEntity(
          commonErrors: CommonErrors.fromJson({}));
    }
  }

  @override
  void unsubscribe() {}
}
