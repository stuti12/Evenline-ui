import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/domain/entities/error/common_errors.dart';
import 'package:nextry_dev/domain/entities/payment_link/fetch_request_payment_link_response_entity.dart';
import 'package:nextry_dev/domain/entities/payment_link/request_payment_link_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';

class FetchRequestPaymentLinkGateWay
    implements ReadGateWay<FetchRequestPaymentLinkResponseEntity, bool> {
  @override
  Future<FetchRequestPaymentLinkResponseEntity> read(bool isHandled) async {
    try {
      var snapshot = await FirebaseFirestore.instance
          .collection(GateWayConstants.TABLE_PAYMENT_LINKS_REQUESTS)
          .where(GateWayConstants.FIELD_IS_HANDLED, isEqualTo: isHandled)
          .get();

      List<RequestPaymentLinkEntity> list = [];
      for (var element in snapshot.docs) {
        if (element.exists) {
          var data = element.data();
          list.add(RequestPaymentLinkEntity.fromJSON(data, element.id));
        }
      }
      return FetchRequestPaymentLinkResponseEntity(
          requestPaymentLinkList: list);
    } catch (e) {
      print(e);
      return FetchRequestPaymentLinkResponseEntity(
          commonErrors: CommonErrors.fromJson({}));
    }
  }

  @override
  void unsubscribe() {}
}
