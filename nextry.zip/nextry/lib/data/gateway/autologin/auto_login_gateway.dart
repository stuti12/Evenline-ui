import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/data/gateway/common/preferences.dart';
import 'package:nextry_dev/domain/gateway/read_gateway_no_args.dart';
import 'package:nextry_dev/presentation/common/utils/app_extension.dart';

/// Class responsible to check user already login or not.
class AutoLoginGateWay implements ReadGateWayNoArgs<NavigationStatus> {
  final Preferences _prefs = Preferences();

  @override
  Future<NavigationStatus> read() async {
    try {
      await FirebaseAuth.instance.currentUser?.reload();
      User? user = FirebaseAuth.instance.currentUser;
      final profileDocId = user?.uid;
      var snapshot = await FirebaseFirestore.instance
          .collection(GateWayConstants.TABLE_USERS)
          .doc(profileDocId)
          .get();

      var userId = await _prefs.getUserId();

      if (snapshot.exists) {
        var data = snapshot.data();
        if (data == null) {
          return NavigationStatus.SPLASH;
        } else if (!user!.emailVerified) {
          return NavigationStatus.EMAIL_NOT_VERIFY;
        } else if (userId.isNullOrEmpty() == true) {
          await logoutUser();
          return NavigationStatus.SPLASH;
        } else {
          return NavigationStatus.HOME;
        }
      } else {
        return NavigationStatus.SPLASH;
      }
    } catch (e) {
      return NavigationStatus.SPLASH;
    }
  }

  logoutUser() async {
    await FirebaseAuth.instance.signOut();
    final user = await GoogleSignIn().isSignedIn();
    if (user) {
      await GoogleSignIn().signOut();
    }
    await _prefs.clearData();
  }

  @override
  void dispose() {}
}
