import 'dart:async';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:nextry_dev/data/gateway/common/preferences.dart';
import 'package:nextry_dev/domain/gateway/read_gateway_no_args.dart';

/// It will send Verification link to relevant user's email id.
class SendEmailVerificationGateWay implements ReadGateWayNoArgs<void> {
  final Preferences _prefs = Preferences();

  @override
  Future<void> read() async {
    try {
      User? user = FirebaseAuth.instance.currentUser;
      if (user != null) {
        await user.sendEmailVerification();
        _prefs.setUserEmail(user.email!);
      }
      return;
    } catch (e) {
      print(e);
      return;
    }
  }

  @override
  void dispose() {}
}
