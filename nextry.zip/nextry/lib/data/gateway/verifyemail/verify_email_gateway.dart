import 'dart:async';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:nextry_dev/domain/entities/verifyemail/verify_email_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway_no_args.dart';

/// It will check user is verified the email or not.
class VerifyEmailGateWay
    implements ReadGateWayNoArgs<VerifyEmailResponseEntity> {
  @override
  Future<VerifyEmailResponseEntity> read() async {
    try {
      bool isVerified = false;
      await FirebaseAuth.instance.currentUser?.reload();
      User? user = FirebaseAuth.instance.currentUser;
      if (user != null && user.emailVerified) {
        // GREAT! show the completion dialog.
        isVerified = true;
      }
      return VerifyEmailResponseEntity(isVerified: isVerified);
    } catch (e) {
      print(e);
      return VerifyEmailResponseEntity();
    }
  }

  @override
  void dispose() {}
}
