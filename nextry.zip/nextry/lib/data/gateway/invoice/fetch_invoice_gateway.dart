import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/domain/entities/business/business_entity.dart';
import 'package:nextry_dev/domain/entities/invoice/invoice_attachment_entity.dart';
import 'package:nextry_dev/domain/entities/invoice/invoice_entity.dart';
import 'package:nextry_dev/domain/entities/invoice/invoice_param.dart';
import 'package:nextry_dev/domain/entities/invoice/invoice_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';

class FetchInvoiceGateway
    implements ReadGateWay<InvoiceResponseEntity, InvoiceParam> {
  @override
  Future<InvoiceResponseEntity> read(InvoiceParam data) async {
    try {
      Query<Map<String, dynamic>> query = FirebaseFirestore.instance
          .collection(data.isBusiness
              ? GateWayConstants.TABLE_BUSINESSES
              : GateWayConstants.TABLE_USERS)
          .doc(data.userUID)
          .collection(GateWayConstants.TABLE_INVOICE);

      if (data.filterDate != null) {
        var now = data.filterDate;
        var todayDate = DateTime(now!.year, now.month, now.day);
        var endDate = DateTime(now.year, now.month, now.day + 1);
        query = query
            .where(GateWayConstants.FIELD_CREATED_AT,
                isGreaterThanOrEqualTo: todayDate)
            .where(GateWayConstants.FIELD_CREATED_AT,
                isLessThanOrEqualTo: endDate);
      }
      query =
          query.orderBy(GateWayConstants.FIELD_CREATED_AT, descending: true);

      var snapshot = await query.get();
      List<InvoiceEntity> invoiceList = [];
      Map<String, String> businesses = {};
      for (var element in snapshot.docs) {
        if (element.exists) {
          var data = element.data();
          var businessId = data[GateWayConstants.FIELD_BUSINESS_ID];
          businesses[businessId] = "";
          invoiceList.add(InvoiceEntity(
              businessEntity: BusinessEntity(id: businessId),
              createdAt: data[GateWayConstants.FIELD_CREATED_AT],
              currency: data[GateWayConstants.FIELD_CURRENCY],
              orderNo: data[GateWayConstants.FIELD_ORDER_NO],
              price: data[GateWayConstants.FIELD_PRICE],
              attachments:
                  getAttachments(data[GateWayConstants.FIELD_ATTACHMENTS])));
        }
      }
      snapshot = await FirebaseFirestore.instance
          .collection(GateWayConstants.TABLE_BUSINESSES)
          .where(FieldPath.documentId, whereIn: businesses.keys.toList())
          .get();
      for (var element in snapshot.docs) {
        if (element.exists) {
          var data = element.data();
          invoiceList
              .where((item) => item.businessEntity?.id == element.id)
              .map((e) {
            return e.businessEntity = BusinessEntity(
                id: e.businessEntity?.id,
                name: data[GateWayConstants.FIELD_NAME],
                profileImage: data[GateWayConstants.FIELD_PROFILE_URL]);
          }).toList();
        }
      }
      return InvoiceResponseEntity(invoiceList: invoiceList);
    } catch (error) {
      print(error);
      return InvoiceResponseEntity();
    }
  }

  List<InvoiceAttachmentEntity> getAttachments(
      List<dynamic> attachments) {
    List<InvoiceAttachmentEntity> attachmentList = [];

    for (var item in attachments) {
      attachmentList.add(InvoiceAttachmentEntity(
          fileURL: item[GateWayConstants.FIELD_FILES_URL],
          uploadedAt: item[GateWayConstants.FIELD_UPLOADED_AT]));
    }
    return attachmentList;
  }

  @override
  void unsubscribe() {}
}
