import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/data/gateway/common/preferences.dart';
import 'package:nextry_dev/domain/entities/user/delete_account_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway_no_args.dart';
import 'package:nextry_dev/localization/string_keys.dart';
import 'package:nextry_dev/presentation/common/utils/app_constants.dart';

class DeleteProfileGateWay
    implements ReadGateWayNoArgs<DeleteAccountResponseEntity> {
  final Preferences _prefs = Preferences();
  DeleteAccountResponseEntity? deleteAccountResponseEntity;

  String errorMessage = '';
  bool isError = false;

  @override
  Future<DeleteAccountResponseEntity> read() async {
    try {
      final userId = FirebaseAuth.instance.currentUser?.uid;
      final currentUserBusiness = await FirebaseFirestore.instance
          .collection(GateWayConstants.TABLE_BUSINESSES)
          .where(GateWayConstants.FIELD_USER_ID, isEqualTo: userId)
          .get();

      for (var element in currentUserBusiness.docs) {
        var count = await businessOrderData(element);
        if (count > 0) {
          errorMessage = StringKeys.ERROR_MESSAGE_FOR_BUSINESS;
          isError = true;
          break;
        }
      }

      if (!isError) {
        var orderRequestRef = FirebaseFirestore.instance
            .collection(GateWayConstants.TABLE_DELIVERY_ORDERS)
            .where(GateWayConstants.FIELD_OFFER_REQUEST_SHIPPER_ID,
                isEqualTo: userId)
            .where(GateWayConstants.FIELD_DELIVERY_ORDERS_CURRENT_STATUS,
                whereIn: [
              DeliveryStatus.inProgress.name,
              DeliveryStatus.inTransit.name,
              DeliveryStatus.inWay.name
            ]);

        final snapShot = await orderRequestRef.count().get();

        if (snapShot.count > 0) {
          isError = true;
          errorMessage = StringKeys.ERROR_MESSAGE_FOR_SHIPPER;
        }
      }

      if (!isError) {
        User? user = FirebaseAuth.instance.currentUser;
        await user?.delete();
        await _prefs.clearData();
      }
    } on FirebaseAuthException catch (e) {
      print("FirebaseAuthException ${e.toString()}");
      return DeleteAccountResponseEntity(
          isError: true, deleteUserError: StringKeys.RE_LOGIN_MESSAGE);
    } catch (e) {
      print("delete account ${e.toString()}");
      return DeleteAccountResponseEntity(
          isError: true, deleteUserError: StringKeys.RE_LOGIN_MESSAGE);
    }
    return DeleteAccountResponseEntity(isError: isError, error: errorMessage);
  }

  Future<int> businessOrderData(dynamic element) async {
    final ordersData = await FirebaseFirestore.instance
        .collection(GateWayConstants.TABLE_BUSINESSES)
        .doc(element.id)
        .collection(GateWayConstants.TABLE_ORDERS)
        .where(GateWayConstants.FIELD_ORDER_STAUS,
            whereIn: [OrderStatus.received.name, OrderStatus.preparing.name])
        .count()
        .get();
    return ordersData.count;
  }

  @override
  void dispose() {}
}
