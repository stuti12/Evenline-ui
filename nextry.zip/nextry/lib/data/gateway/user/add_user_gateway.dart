import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/data/gateway/common/upload_file_helper.dart';
import 'package:nextry_dev/domain/entities/profile/user_entity.dart';
import 'package:nextry_dev/domain/entities/user/add_user_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/presentation/common/utils/app_constants.dart';

class AddUserGateWay implements ReadGateWay<AddUserResponseEntity, UserEntity> {
  @override
  Future<AddUserResponseEntity> read(UserEntity userEntity) async {
    try {
      final profileDocId = FirebaseAuth.instance.currentUser?.uid;

      if (userEntity.profileUrl != null &&
          userEntity.profileUrl!.isNotEmpty &&
          !userEntity.profileUrl!.startsWith(AppConstants.SERVER_FILE)) {
        userEntity.profileUrl = await UploadFileHelper()
            .uploadFileToFireStore(userEntity.profileUrl!);
      }

      final data = <String, dynamic>{};
      if (userEntity.name?.isNotEmpty == true) {
        data[GateWayConstants.FIELD_NAME] = userEntity.name;
      }
      data[GateWayConstants.FIELD_EMAIL] = userEntity.email;
      data[GateWayConstants.FIELD_PHONE] = userEntity.phone;
      data[GateWayConstants.FIELD_ISOCODE] = userEntity.isoCode;
      data[GateWayConstants.FIELD_PROFILE_URL] = userEntity.profileUrl;
      data[GateWayConstants.FIELD_LANGUAGE_CODE] = userEntity.languageCode;

      /// Remove null value otherwise it will be over writing the existing value.
      data.removeWhere((key, value) => value == null);

      await FirebaseFirestore.instance
          .collection(GateWayConstants.TABLE_USERS)
          .doc(profileDocId)
          .set(data, SetOptions(merge: true));

      return AddUserResponseEntity(isAdded: true, error: null);
    } catch (e) {
      print(e);
      return AddUserResponseEntity(isAdded: false, error: null);
    }
  }

  @override
  void unsubscribe() {}
}
