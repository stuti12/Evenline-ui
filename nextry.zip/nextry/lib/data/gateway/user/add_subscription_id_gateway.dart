import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/domain/gateway/write_gateway.dart';

class AddSubscriptionIdGateway extends WriteGateWay<String> {
  @override
  Future<void> write(String data) async {
    try {
      final profileDocId = FirebaseAuth.instance.currentUser?.uid;
      final updateData = <String, dynamic>{};
      updateData[GateWayConstants.FIELD_STRIPE_CUSTOMER_ID] = data;
      await FirebaseFirestore.instance
          .collection(GateWayConstants.TABLE_USERS)
          .doc(profileDocId)
          .set(updateData, SetOptions(merge: true));
    } on FirebaseAuthException catch (e) {
      print(e.toString());
    }
    return;
  }
}
