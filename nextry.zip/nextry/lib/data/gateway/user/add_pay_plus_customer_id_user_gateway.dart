import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/domain/entities/user/add_user_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/presentation/common/utils/app_extension.dart';

class AddPayPlusCustomerIdUserGateWay
    implements ReadGateWay<AddUserResponseEntity, String> {
  @override
  Future<AddUserResponseEntity> read(String payPlusCustomerId) async {
    try {
      final profileDocId = FirebaseAuth.instance.currentUser?.uid;
      final data = <String, dynamic>{};
      data[GateWayConstants.FIELD_PAY_PLUS_CUSTOMER_ID] = payPlusCustomerId.encryptedData();

      await FirebaseFirestore.instance
          .collection(GateWayConstants.TABLE_USERS)
          .doc(profileDocId)
          .set(data, SetOptions(merge: true));

      return AddUserResponseEntity(isAdded: true, error: null);
    } catch (e) {
      print(e);
      return AddUserResponseEntity(isAdded: false, error: null);
    }
  }

  @override
  void unsubscribe() {}
}
