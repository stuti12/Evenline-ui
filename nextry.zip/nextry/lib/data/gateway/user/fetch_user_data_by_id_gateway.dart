import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/domain/entities/profile/user_entity.dart';
import 'package:nextry_dev/domain/entities/user/fetch_user_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';

class FetchUserDataByIdGateWay implements ReadGateWay<FetchUserResponseEntity, String> {
  @override
  Future<FetchUserResponseEntity> read(String userId) async {
    try {
      var snapshot = await FirebaseFirestore.instance
          .collection(GateWayConstants.TABLE_USERS)
          .doc(userId)
          .get();

      UserEntity userEntity = UserEntity();
      if (snapshot.exists) {
        var data = snapshot.data();
        if (data != null) {
          userEntity = UserEntity.fromJson(data, snapshot.id);
        }
      }

      return FetchUserResponseEntity(userEntity: userEntity, error: null);
    } catch (e) {
      print(e);
      return FetchUserResponseEntity(userEntity: null, error: null);
    }
  }

  @override
  void unsubscribe() {

  }
}
