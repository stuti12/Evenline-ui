import 'dart:async';

import 'package:nextry_dev/data/gateway/common/delete_file_helper.dart';
import 'package:nextry_dev/domain/entities/user/delete_file_param.dart';
import 'package:nextry_dev/domain/entities/user/delete_file_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';

class DeleteFileGateWay
    implements ReadGateWay<DeleteFileResponseEntity, DeleteFileParam> {
  @override
  Future<DeleteFileResponseEntity> read(DeleteFileParam param) async {
    try {
      if (param.firebaseUrl != null && param.firebaseUrl!.isNotEmpty) {
        await DeleteFileHelper().deleteFileFromFireStore(param.firebaseUrl!);
        return DeleteFileResponseEntity(isDeleted: true);
      }
      return DeleteFileResponseEntity(isDeleted: false, error: null);
    } catch (e) {
      print(e);
      return DeleteFileResponseEntity(isDeleted: false, error: null);
    }
  }

  @override
  void unsubscribe() {}
}
