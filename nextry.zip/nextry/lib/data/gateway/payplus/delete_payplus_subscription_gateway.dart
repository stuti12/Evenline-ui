import 'package:nextry_dev/data/gateway/common/custom_exception.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/data/gateway/common/payplus_http_service.dart';
import 'package:nextry_dev/domain/entities/config/payplus_payment_config_entity.dart';
import 'package:nextry_dev/domain/entities/payplus/customer_response_entity.dart';
import 'package:nextry_dev/domain/entities/payplus/delete_payplus_subscription_param.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/presentation/common/utils/payplus_helper.dart';

class DeletePayPlusSubscriptionGateway
    implements
        ReadGateWay<CustomerResponseEntity, DeletePayPlusSubscriptionParam> {
  @override
  Future<CustomerResponseEntity> read(
      DeletePayPlusSubscriptionParam data) async {
    try {
      final customer = await _deleteSubscription(data.recurringUid,
          data.deletePayPlusRequest?.toJson(), data.payPlusPaymentConfigEntity);

      return CustomerResponseEntity.fromJson(customer);
    } on CustomException catch (e) {
      print(e);
    } catch (e) {
      print(e);
    }
    return CustomerResponseEntity();
  }

  /// This method the create customer
  Future<Map<String, dynamic>> _deleteSubscription(
      String? recurringId,
      Map<String, dynamic>? body,
      PayPlusPaymentConfigEntity? payPlusPaymentConfigEntity) async {
    try {
      var response = await PayPlusHttpService.postHttp(
          "${GateWayConstants.PAYPLUS_DELETE_RECURRING_PYAMENTS}$recurringId",
          body ?? {},
          PayPlusHelper.getPayPlusHeadersWithKeys(payPlusPaymentConfigEntity));
      return response;
    } catch (e) {
      print(e);
      return {};
    }
  }

  @override
  void unsubscribe() {}
}
