import 'package:nextry_dev/data/gateway/common/custom_exception.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/data/gateway/common/payplus_http_service.dart';
import 'package:nextry_dev/domain/entities/config/payplus_payment_config_entity.dart';
import 'package:nextry_dev/domain/entities/payplus/view_payplus_subscription_param.dart';
import 'package:nextry_dev/domain/entities/payplus/view_recurring_response_entiry.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/presentation/common/utils/payplus_helper.dart';

class ViewPayPlusSubscriptionGateway
    implements
        ReadGateWay<ViewRecurringResponseEntity, ViewPayPlusSubscriptionParam> {
  @override
  Future<ViewRecurringResponseEntity> read(
      ViewPayPlusSubscriptionParam data) async {
    try {
      final viewSubscription = await _viewSubscription(
          data.recurringUid, data.terminalUid, data.payPlusPaymentConfigEntity);
      print(" test ====== ${viewSubscription}");
      return ViewRecurringResponseEntity.fromJson(viewSubscription);
    } on CustomException catch (e) {
      print(e);
    } catch (e) {
      print(e);
    }
    return ViewRecurringResponseEntity();
  }

  /// This method the view subscription
  Future<Map<String, dynamic>> _viewSubscription(
      String? recurringId,
      String? terminalUid,
      PayPlusPaymentConfigEntity? payPlusPaymentConfigEntity) async {
    try {
      var response = await PayPlusHttpService.getHttp(
          "${GateWayConstants.PAYPLUS_VIEW_RECURRING_PYAMENTS}$recurringId${GateWayConstants.PAYPLUS_VIEW_RECURRING}",
          queryParameters: {'terminal_uid': terminalUid},
          headers: PayPlusHelper.getPayPlusHeadersWithKeys(
              payPlusPaymentConfigEntity));
      return response;
    } catch (e) {
      print(e);
      return {};
    }
  }

  @override
  void unsubscribe() {}
}
