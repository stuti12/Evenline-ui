import 'package:nextry_dev/data/gateway/common/custom_exception.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/data/gateway/common/payplus_http_service.dart';
import 'package:nextry_dev/domain/entities/config/payplus_payment_config_entity.dart';
import 'package:nextry_dev/domain/entities/payplus/create_payplus_subscription_param.dart';
import 'package:nextry_dev/domain/entities/payplus/customer_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/presentation/common/utils/app_extension.dart';
import 'package:nextry_dev/presentation/common/utils/payplus_helper.dart';

import '../../../domain/entities/payplus/generate_payment_link_request_param.dart';

class CreatePayPlusSubscriptionGateway
    implements
        ReadGateWay<CustomerResponseEntity, CreatePayPlusSubscriptionParam> {
  @override
  Future<CustomerResponseEntity> read(
      CreatePayPlusSubscriptionParam data) async {
    try {
      var customerId = data.customerId ?? "";
      if (customerId.isNullOrEmpty()) {
        final customer = await _createCustomer(
            data.customerRequestEntity?.toJson(),
            data.payPlusPaymentConfigEntity);
        if (customer.isNotEmpty) {
          customerId = customer['data']['customer_uid'];
        } else {
          return CustomerResponseEntity();
        }
      }
      data.paymentLinkRequestParam?.customer = CustomerReq(uID: customerId);
      final response = await _createPaymentLinkForSubscription(
          data.paymentLinkRequestParam?.toJson(),
          data.payPlusPaymentConfigEntity);
      return CustomerResponseEntity.fromJson(response);
    } on CustomException catch (e) {
      print(e);
    } catch (e) {
      print(e);
    }
    return CustomerResponseEntity();
  }

  /// This method the create customer
  Future<Map<String, dynamic>> _createCustomer(Map<String, dynamic>? body,
      PayPlusPaymentConfigEntity? payPlusPaymentConfigEntity) async {
    try {
      var response = await PayPlusHttpService.postHttp(
          GateWayConstants.PAYPLUS_CUSTOMER,
          body ?? {},
          PayPlusHelper.getPayPlusHeadersWithKeys(payPlusPaymentConfigEntity));
      return response;
    } catch (e) {
      print(e);
      return {};
    }
  }

  /// This method the create subscription for the customer.
  Future<Map<String, dynamic>> _createPaymentLinkForSubscription(
      Map<String, dynamic>? body,
      PayPlusPaymentConfigEntity? payPlusPaymentConfigEntity) async {
    try {
      var response = await PayPlusHttpService.postHttp(
          GateWayConstants.PAYPLUS_GENERATE_PAYMENT_LINK,
          body ?? {},
          PayPlusHelper.getPayPlusHeadersWithKeys(payPlusPaymentConfigEntity));

      return response;
    } catch (e) {
      print(e);
      return {};
    }
  }

  @override
  void unsubscribe() {}
}
