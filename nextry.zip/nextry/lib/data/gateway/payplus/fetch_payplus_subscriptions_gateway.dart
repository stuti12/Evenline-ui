import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:nextry_dev/data/gateway/common/custom_exception.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/domain/entities/business/business_entity.dart';
import 'package:nextry_dev/domain/entities/config/payplus_payment_config_entity.dart';
import 'package:nextry_dev/domain/entities/error/common_errors.dart';
import 'package:nextry_dev/domain/entities/payplus/fetch_paplus_subscriptions_response_entity.dart';
import 'package:nextry_dev/domain/entities/payplus/fetch_payplus_subscription_param.dart';
import 'package:nextry_dev/domain/entities/payplus/payplus_extra_info_entity.dart';
import 'package:nextry_dev/domain/entities/payplus/payplus_subscription_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/presentation/common/utils/app_extension.dart';
import 'package:nextry_dev/presentation/common/utils/payplus_helper.dart';

import '../common/payplus_http_service.dart';

class FetchPayPlusSubscriptionsGateWay
    implements
        ReadGateWay<FetchPayPlusSubscriptionsResponseEntity,
            FetchPayPlusSubscriptionParam> {
  @override
  Future<FetchPayPlusSubscriptionsResponseEntity> read(
      FetchPayPlusSubscriptionParam param) async {
    try {
      List<PayPlusSubscriptionEntity> mySubscriptionList = [];
      var response = await PayPlusHttpService.getHttp(
          GateWayConstants.PAYPLUS_CUSTOMER_RECURRING_PAYMENTS,
          queryParameters: {
            GateWayConstants.PAYPLUS_FIELD_CUSTOMER_ID: param.customerUid,
            GateWayConstants.PAYPLUS_FIELD_TERMINAL_ID: param.terminalUid
          },
          headers: PayPlusHelper.getPayPlusHeadersWithKeys(
              param.payPlusPaymentConfigEntity));
      if (response != null) {
        var subscriptionsList = response[GateWayConstants.FIELD_DATA] as List;
        if (subscriptionsList.isNotEmpty) {
          for (var element in subscriptionsList) {
            print("elelemt ==== ${element["uid"]}");
            BusinessEntity? businessEntity;
            var productDetails = await _getSubscriptionDetailsOfCustomer(
                element["uid"],
                param.terminalUid,
                param.payPlusPaymentConfigEntity);
            var productName = productDetails["items"][0]["name"];
            print("elelemt ==== $productName");
            if (element["extra_info"] != null) {
              PayPlusExtraInfoEntity payPlusExtraInfoEntity =
                  PayPlusExtraInfoEntity.fromJson(element["extra_info"]);
              if (!payPlusExtraInfoEntity.businessId.isNullOrEmpty()) {
                businessEntity = await _fetchBusinessById(
                    payPlusExtraInfoEntity.businessId!);
              }
            }
            if (businessEntity != null) {
              mySubscriptionList.add(
                PayPlusSubscriptionEntity.fromJson(
                    element, productName, businessEntity),
              );
            }
          }
        }
      }
      print("Response Subscriptions ${mySubscriptionList.length}");
      return FetchPayPlusSubscriptionsResponseEntity(
          payPlusSubscriptionList: mySubscriptionList);
    } on CustomException catch (e) {
      return FetchPayPlusSubscriptionsResponseEntity(
          commonErrors: CommonErrors.fromJson(
              {'errorMessage': e.message, 'errorCode': '21332'}));
    } catch (e) {
      print("====tesst ====e $e");
      return FetchPayPlusSubscriptionsResponseEntity(
          commonErrors: CommonErrors.fromJson({}));
    }
  }

  /// This method retrieve list of subscription of the user
  Future<Map<String, dynamic>> _getSubscriptionDetailsOfCustomer(
      String? recurringId,
      String? terminalUid,
      PayPlusPaymentConfigEntity? payPlusPaymentConfigEntity) async {
    var response = await PayPlusHttpService.getHttp(
        "${GateWayConstants.PAYPLUS_VIEW_RECURRING_PYAMENTS}$recurringId${GateWayConstants.PAYPLUS_VIEW_RECURRING}",
        queryParameters: {'terminal_uid': terminalUid},
        headers: PayPlusHelper.getPayPlusHeadersWithKeys(
            payPlusPaymentConfigEntity));
    return response;
  }

  Future<BusinessEntity> _fetchBusinessById(String businessId) async {
    var snapshot = await FirebaseFirestore.instance
        .collection(GateWayConstants.TABLE_BUSINESSES)
        .doc(businessId)
        .get();

    var entity = BusinessEntity();
    if (snapshot.exists) {
      var data = snapshot.data();
      if (data != null) {
        entity = BusinessEntity.fromJSON(data, businessId);
      }
    }
    return entity;
  }

  @override
  void unsubscribe() {}
}
