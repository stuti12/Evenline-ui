import 'package:nextry_dev/data/gateway/common/custom_exception.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/data/gateway/common/payplus_http_service.dart';
import 'package:nextry_dev/domain/entities/config/payplus_payment_config_entity.dart';
import 'package:nextry_dev/domain/entities/payplus/customer_response_entity.dart';
import 'package:nextry_dev/domain/entities/payplus/payplus_refund_by_transaction_request_param.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';
import 'package:nextry_dev/presentation/common/utils/payplus_helper.dart';

class RefundByTransactionIdPayPlusGateway
    implements
        ReadGateWay<CustomerResponseEntity, PayPlusRefundByTransactionRequest> {
  @override
  Future<CustomerResponseEntity> read(
      PayPlusRefundByTransactionRequest data) async {
    try {
      final response = await _refundByTransactionId(
          data.toJson(), data.payPlusPaymentConfigEntity);
      return CustomerResponseEntity.fromJson(response);
    } on CustomException catch (e) {
      print(e);
    } catch (e) {
      print(e);
    }
    return CustomerResponseEntity();
  }

  /// This method the create customer
  Future<Map<String, dynamic>> _refundByTransactionId(
      Map<String, dynamic>? body,
      PayPlusPaymentConfigEntity? payPlusPaymentConfigEntity) async {
    try {
      var response = await PayPlusHttpService.postHttp(
          GateWayConstants.PAYPLUS_REFUND_BY_TRANSACTION_ID,
          body ?? {},
          PayPlusHelper.getPayPlusHeadersWithKeys(payPlusPaymentConfigEntity));
      return response;
    } catch (e) {
      print(e);
      return {};
    }
  }

  @override
  void unsubscribe() {}
}
