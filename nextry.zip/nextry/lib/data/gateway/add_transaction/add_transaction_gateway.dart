import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/domain/entities/wallet/add_transaction_param.dart';
import 'package:nextry_dev/domain/gateway/read_gateway.dart';

class AddTransactionGateway implements ReadGateWay<void, AddTransactionParam> {
  DocumentSnapshot? lastDocumentSnapShot;

  @override
  void unsubscribe() {}

  @override
  Future<void> read(AddTransactionParam data) async {
    Map<String, dynamic> param = {};
    param[GateWayConstants.FIELD_AMOUNT] = data.transactionEntity?.amount;
    param[GateWayConstants.FIELD_CREATED_AT] = data.transactionEntity?.date;
    param[GateWayConstants.FIELD_STATUS] = data.transactionEntity?.status;
    param[GateWayConstants.FIELD_TYPE] =
        data.transactionEntity?.transactionType;
    param[GateWayConstants.FIELD_USER_ID] = data.transactionEntity?.userID;
    param[GateWayConstants.FIELD_USER_NAME] = data.transactionEntity?.userName;
    print("==== ${data.transactionHistoryParam?.type}");

    await FirebaseFirestore.instance
        .collection(GateWayConstants.TABLE_BUSINESSES)
        .doc(data.transactionHistoryParam?.userUID)
        .collection(GateWayConstants.TABLE_WALLET)
        .doc(data.transactionHistoryParam?.type)
        .collection(GateWayConstants.TABLE_TRANSACTIONS)
        .add(param);
  }
}
