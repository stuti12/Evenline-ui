import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:nextry_dev/data/gateway/common/gateway_constants.dart';
import 'package:nextry_dev/domain/entities/category/category_entity.dart';
import 'package:nextry_dev/domain/entities/category/category_response_entity.dart';
import 'package:nextry_dev/domain/gateway/read_gateway_no_args.dart';

class CategoryGateway implements ReadGateWayNoArgs<CategoryResponseEntity> {
  @override
  Future<CategoryResponseEntity> read() async {
    try {
      var snapshot = await FirebaseFirestore.instance
          .collection(GateWayConstants.TABLE_CATEGORY)
          .orderBy(GateWayConstants.FIELD_CAT_ORDER)
          .get();

      final categoryResponseEntity = CategoryResponseEntity();
      List<CategoryEntity>? categories = [];
      CategoryEntity categoryEntity = CategoryEntity();
      for (var element in snapshot.docs) {
        if (element.exists) {
          categoryEntity = CategoryEntity();
          var data = element.data();
          categoryEntity.docId = element.id;
          categoryEntity.name = data[GateWayConstants.FIELD_CAT_NAME];
          categoryEntity.logo = data[GateWayConstants.FIELD_CAT_LOGO];
          categoryEntity.isVisible = data[GateWayConstants.FIELD_IS_VISIBLE];
          if (data[GateWayConstants.FIELD_CAT_LOCALE_NAME] != null) {
            final localeName = data[GateWayConstants.FIELD_CAT_LOCALE_NAME]
                as Map<String, dynamic>;
            localeName.forEach((key, value) {
              categoryEntity.catName[key] = value;
            });
          }
          categories.add(categoryEntity);
        }
      }
      categoryResponseEntity.categories = categories;
      return categoryResponseEntity;
    } catch (e) {
      print(e);
      return CategoryResponseEntity();
    }
  }

  @override
  void dispose() {}
}
