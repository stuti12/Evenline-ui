import 'package:flutter_simple_dependency_injection/injector.dart';
import 'package:nextry_dev/data/gateway/add_transaction/add_transaction_gateway.dart';
import 'package:nextry_dev/data/gateway/ads/add_update_ads_gateway.dart';
import 'package:nextry_dev/data/gateway/ads/convert_discount_to_ads_gateway.dart';
import 'package:nextry_dev/data/gateway/ads/fetch_active_ads_gateway.dart';
import 'package:nextry_dev/data/gateway/ads/fetch_all_scheduled_ads_gateway.dart';
import 'package:nextry_dev/data/gateway/ads/fetch_home_ads_gateway.dart';
import 'package:nextry_dev/data/gateway/ads/fetch_unavailable_dates_gateway.dart';
import 'package:nextry_dev/data/gateway/ads/remove_active_ads_gateway.dart';
import 'package:nextry_dev/data/gateway/ads/remove_ads_gateway.dart';
import 'package:nextry_dev/data/gateway/ads/remove_product_ads_gateway.dart';
import 'package:nextry_dev/data/gateway/ads/update_unavailable_dates_gateway.dart';
import 'package:nextry_dev/data/gateway/all_card/fetch_all_card_gateway.dart';
import 'package:nextry_dev/data/gateway/askme/add_ask_me_gateway.dart';
import 'package:nextry_dev/data/gateway/autologin/auto_login_gateway.dart';
import 'package:nextry_dev/data/gateway/business/add_business_category_gateway.dart';
import 'package:nextry_dev/data/gateway/business/add_unsubscribed_businesses_gateway.dart';
import 'package:nextry_dev/data/gateway/business/add_update_business_gateway.dart';
import 'package:nextry_dev/data/gateway/business/fetch_business_category_gateway.dart';
import 'package:nextry_dev/data/gateway/business/fetch_business_data_gateway.dart';
import 'package:nextry_dev/data/gateway/business/fetch_businesses_by_name_gateway.dart';
import 'package:nextry_dev/data/gateway/business/fetch_my_businesses_by_status_gateway.dart';
import 'package:nextry_dev/data/gateway/business/update_business_status_gateway.dart';
import 'package:nextry_dev/data/gateway/business/update_business_subscription_id_gateway.dart';
import 'package:nextry_dev/data/gateway/cart/add_update_product_cart_gateway.dart';
import 'package:nextry_dev/data/gateway/cart/delete_cart_by_id_gateway.dart';
import 'package:nextry_dev/data/gateway/cart/fetch_cart_data_by_businessId_gateway.dart';
import 'package:nextry_dev/data/gateway/cart/fetch_cart_data_gateway.dart';
import 'package:nextry_dev/data/gateway/category/category_gateway.dart';
import 'package:nextry_dev/data/gateway/config/contact_us_config_gateway.dart';
import 'package:nextry_dev/data/gateway/config/fetch_app_update_data_gateway.dart';
import 'package:nextry_dev/data/gateway/config/fetch_configurations_data_gateway.dart';
import 'package:nextry_dev/data/gateway/config/fetch_guides_urls_data_gateway.dart';
import 'package:nextry_dev/data/gateway/config/fetch_nextry_documents_data_gateway.dart';
import 'package:nextry_dev/data/gateway/config/fetch_payplus_payment_config_gateway.dart';
import 'package:nextry_dev/data/gateway/config/splash/splash_config_gateway.dart';
import 'package:nextry_dev/data/gateway/delivery/add_delivery_offer_gateway.dart';
import 'package:nextry_dev/data/gateway/delivery/add_delivery_orders_gateway.dart';
import 'package:nextry_dev/data/gateway/delivery/add_delivery_request_gateway.dart';
import 'package:nextry_dev/data/gateway/delivery/add_report_customers_gateway.dart';
import 'package:nextry_dev/data/gateway/delivery/add_shipper_review_gateway.dart';
import 'package:nextry_dev/data/gateway/delivery/add_update_shipper_gateway.dart';
import 'package:nextry_dev/data/gateway/delivery/cancel_delivery_order_gateway.dart';
import 'package:nextry_dev/data/gateway/delivery/cancel_delivery_request_gateway.dart';
import 'package:nextry_dev/data/gateway/delivery/fetch_delivery_offer_gateway.dart';
import 'package:nextry_dev/data/gateway/delivery/fetch_delivery_order_detail_gateway.dart';
import 'package:nextry_dev/data/gateway/delivery/fetch_delivery_orders_by_filter_gateway.dart';
import 'package:nextry_dev/data/gateway/delivery/fetch_delivery_orders_by_shipper_id_gateway.dart';
import 'package:nextry_dev/data/gateway/delivery/fetch_delivery_request_by_user_id_gateway.dart';
import 'package:nextry_dev/data/gateway/delivery/fetch_delivery_request_data_by_id_gateway.dart';
import 'package:nextry_dev/data/gateway/delivery/fetch_delivery_request_gateway.dart';
import 'package:nextry_dev/data/gateway/delivery/fetch_shipper_data_by_id_gateway.dart';
import 'package:nextry_dev/data/gateway/delivery/fetch_shipper_delivery_offer_gateway.dart';
import 'package:nextry_dev/data/gateway/delivery/fetch_shipper_information_gateway.dart';
import 'package:nextry_dev/data/gateway/delivery/fetch_shipper_review_gateway.dart';
import 'package:nextry_dev/data/gateway/delivery/request_delete_shipper_feedback_gateway.dart';
import 'package:nextry_dev/data/gateway/delivery/update_delivery_order_gateway.dart';
import 'package:nextry_dev/data/gateway/delivery/update_delivery_order_status_gateway.dart';
import 'package:nextry_dev/data/gateway/delivery/update_shipper_current_location_gateway.dart';
import 'package:nextry_dev/data/gateway/feedback/create_customer_feedback_gateway.dart';
import 'package:nextry_dev/data/gateway/feedback/create_feedback_report_gateway.dart';
import 'package:nextry_dev/data/gateway/feedback/fetch_all_business_feedbacks_gateway.dart';
import 'package:nextry_dev/data/gateway/forgotpassword/forgot_password_gateway.dart';
import 'package:nextry_dev/data/gateway/hotdeal/fetch_active_hot_deals_gateway.dart';
import 'package:nextry_dev/data/gateway/hotdeal/fetch_all_scheduled_hot_deals_gateway.dart';
import 'package:nextry_dev/data/gateway/hotdeal/fetch_home_hot_deals_gateway.dart';
import 'package:nextry_dev/data/gateway/hotdeal/fetch_nextry_hot_deals_gateway.dart';
import 'package:nextry_dev/data/gateway/hotdeal/make_hot_deal_ad_gateway.dart';
import 'package:nextry_dev/data/gateway/hotdeal/remove_active_hot_deal_gateway.dart';
import 'package:nextry_dev/data/gateway/hotdeal/remove_hot_deal_gateway.dart';
import 'package:nextry_dev/data/gateway/invoice/fetch_invoice_gateway.dart';
import 'package:nextry_dev/data/gateway/location/location_gateway.dart';
import 'package:nextry_dev/data/gateway/login/login_gateway.dart';
import 'package:nextry_dev/data/gateway/logout/logout_gateway.dart';
import 'package:nextry_dev/data/gateway/notification/fetch_notification_by_user_id_gateway.dart';
import 'package:nextry_dev/data/gateway/order/add_update_order_invoice_gateway.dart';
import 'package:nextry_dev/data/gateway/order/cancel_order_gateway.dart';
import 'package:nextry_dev/data/gateway/order/fetch_business_order_detail_gateway.dart';
import 'package:nextry_dev/data/gateway/order/fetch_business_orders_by_day_gateway.dart';
import 'package:nextry_dev/data/gateway/order/fetch_business_orders_by_status_gateway.dart';
import 'package:nextry_dev/data/gateway/order/fetch_business_sales_by_day_gateway.dart';
import 'package:nextry_dev/data/gateway/order/fetch_customer_order_detail_gateway.dart';
import 'package:nextry_dev/data/gateway/order/fetch_customer_orders_gateway.dart';
import 'package:nextry_dev/data/gateway/order/make_order_gateway.dart';
import 'package:nextry_dev/data/gateway/order/update_order_status_gateway.dart';
import 'package:nextry_dev/data/gateway/payment_link/add_update_request_payment_link_gateway.dart';
import 'package:nextry_dev/data/gateway/payment_link/fetch_request_payment_link_by_business_id_gateway.dart';
import 'package:nextry_dev/data/gateway/payment_link/fetch_request_payment_link_gateway.dart';
import 'package:nextry_dev/data/gateway/payplus/create_payplus_subscription_gateway.dart';
import 'package:nextry_dev/data/gateway/payplus/delete_payplus_subscription_gateway.dart';
import 'package:nextry_dev/data/gateway/payplus/fetch_payplus_subscriptions_gateway.dart';
import 'package:nextry_dev/data/gateway/payplus/refund_by_transactionid_payplus_gateway.dart';
import 'package:nextry_dev/data/gateway/payplus/view_payplus_subscription_gateway.dart';
import 'package:nextry_dev/data/gateway/product/add_product_discount_gateway.dart';
import 'package:nextry_dev/data/gateway/product/add_update_product_gateway.dart';
import 'package:nextry_dev/data/gateway/product/delete_product_category_gateway.dart';
import 'package:nextry_dev/data/gateway/product/delete_product_discount_gateway.dart';
import 'package:nextry_dev/data/gateway/product/delete_product_gateway.dart';
import 'package:nextry_dev/data/gateway/product/fetch_product_by_category_gateway.dart';
import 'package:nextry_dev/data/gateway/product/fetch_product_gateway.dart';
import 'package:nextry_dev/data/gateway/product/fetch_relative_product_gateway.dart';
import 'package:nextry_dev/data/gateway/push/push_token_gateway.dart';
import 'package:nextry_dev/data/gateway/shipper_payment_link/add_update_request_payment_link_gateway.dart';
import 'package:nextry_dev/data/gateway/shipper_subscription/fetch_shipper_subscription_data_gateway.dart';
import 'package:nextry_dev/data/gateway/signup/apple_sign_in_gateway.dart';
import 'package:nextry_dev/data/gateway/signup/google_sign_in_gateway.dart';
import 'package:nextry_dev/data/gateway/signup/signup_gateway.dart';
import 'package:nextry_dev/data/gateway/subscriptions/cancel_my_subscription_gateway.dart';
import 'package:nextry_dev/data/gateway/subscriptions/create_subscription_gateway.dart';
import 'package:nextry_dev/data/gateway/subscriptions/fetch_my_subscriptions_gateway.dart';
import 'package:nextry_dev/data/gateway/subscriptions/fetch_subscription_data_gateway.dart';
import 'package:nextry_dev/data/gateway/transaction_history/fetch_all_transaction_history_gateway.dart';
import 'package:nextry_dev/data/gateway/user/add_pay_plus_customer_id_user_gateway.dart';
import 'package:nextry_dev/data/gateway/user/add_subscription_id_gateway.dart';
import 'package:nextry_dev/data/gateway/user/add_user_gateway.dart';
import 'package:nextry_dev/data/gateway/user/delete_file_gateway.dart';
import 'package:nextry_dev/data/gateway/user/delete_profile_gateway.dart';
import 'package:nextry_dev/data/gateway/user/fetch_user_data_by_id_gateway.dart';
import 'package:nextry_dev/data/gateway/user/fetch_user_gateway.dart';
import 'package:nextry_dev/data/gateway/verifyemail/send_email_verification_gateway.dart';
import 'package:nextry_dev/data/gateway/verifyemail/verify_email_gateway.dart';
import 'package:nextry_dev/data/gateway/wallet/fetch_all_transactions_gateway.dart';
import 'package:nextry_dev/data/gateway/wallet/fetch_balance_gateway.dart';
import 'package:nextry_dev/domain/interactors/ads/add_update_ads_interactor.dart';
import 'package:nextry_dev/domain/interactors/ads/add_update_ads_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/ads/convert_discount_to_ads_interactor.dart';
import 'package:nextry_dev/domain/interactors/ads/convert_discount_to_ads_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/ads/fetch_active_ads_interactor.dart';
import 'package:nextry_dev/domain/interactors/ads/fetch_active_ads_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/ads/fetch_all_scheduled_ads_interactor.dart';
import 'package:nextry_dev/domain/interactors/ads/fetch_all_scheduled_ads_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/ads/fetch_home_ads_interactor.dart';
import 'package:nextry_dev/domain/interactors/ads/fetch_home_ads_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/ads/fetch_unavailable_dates_interactor.dart';
import 'package:nextry_dev/domain/interactors/ads/fetch_unavailable_dates_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/ads/remove_active_ad_interactor.dart';
import 'package:nextry_dev/domain/interactors/ads/remove_active_ad_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/ads/remove_ad_interactor.dart';
import 'package:nextry_dev/domain/interactors/ads/remove_ad_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/ads/remove_product_ad_interactor.dart';
import 'package:nextry_dev/domain/interactors/ads/remove_product_ad_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/ads/update_unavailable_dates_interactor.dart';
import 'package:nextry_dev/domain/interactors/ads/update_unavailable_dates_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/all_card/all_card_interactor.dart';
import 'package:nextry_dev/domain/interactors/all_card/all_card_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/askme/add_ask_me_interactor.dart';
import 'package:nextry_dev/domain/interactors/askme/add_ask_me_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/autologin/auto_login_interactor.dart';
import 'package:nextry_dev/domain/interactors/autologin/auto_login_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/business/add_business_category_interactor.dart';
import 'package:nextry_dev/domain/interactors/business/add_business_category_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/business/add_unsubscribed_businesses_interactor.dart';
import 'package:nextry_dev/domain/interactors/business/add_unsubscribed_businesses_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/business/add_update_business_interactor.dart';
import 'package:nextry_dev/domain/interactors/business/add_update_business_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/business/fetch_business_category_interactor.dart';
import 'package:nextry_dev/domain/interactors/business/fetch_business_category_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/business/fetch_business_data_interactor.dart';
import 'package:nextry_dev/domain/interactors/business/fetch_business_data_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/business/fetch_businesses_by_name_interactor.dart';
import 'package:nextry_dev/domain/interactors/business/fetch_businesses_by_name_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/business/fetch_my_businesses_by_status_interactor.dart';
import 'package:nextry_dev/domain/interactors/business/fetch_my_businesses_by_status_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/business/update_business_status_interactor.dart';
import 'package:nextry_dev/domain/interactors/business/update_business_status_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/business/update_business_subscription_id_interactor.dart';
import 'package:nextry_dev/domain/interactors/business/update_business_subscription_id_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/cart/add_update_product_cart_interactor.dart';
import 'package:nextry_dev/domain/interactors/cart/add_update_product_cart_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/cart/delete_cart_by_id_interactor.dart';
import 'package:nextry_dev/domain/interactors/cart/delete_cart_by_id_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/cart/fetch_cart_data_by_businessid_interactor.dart';
import 'package:nextry_dev/domain/interactors/cart/fetch_cart_data_by_businessid_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/cart/fetch_cart_data_interactor.dart';
import 'package:nextry_dev/domain/interactors/cart/fetch_cart_data_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/category/category_interactor.dart';
import 'package:nextry_dev/domain/interactors/category/category_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/config/contact_us_config_interactor.dart';
import 'package:nextry_dev/domain/interactors/config/contact_us_config_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/config/fetch_config_interactor.dart';
import 'package:nextry_dev/domain/interactors/config/fetch_config_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/config/fetch_guides_urls_interactor.dart';
import 'package:nextry_dev/domain/interactors/config/fetch_guides_urls_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/config/fetch_force_update_interactor.dart';
import 'package:nextry_dev/domain/interactors/config/fetch_force_update_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/config/fetch_nextry_documents_interactor.dart';
import 'package:nextry_dev/domain/interactors/config/fetch_nextry_documents_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/config/fetch_payplus_payment_config_interactor.dart';
import 'package:nextry_dev/domain/interactors/config/fetch_payplus_payment_config_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/config/splash/splash_config_interactor.dart';
import 'package:nextry_dev/domain/interactors/config/splash/splash_config_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/delivery/add_delivery_offer_interactor.dart';
import 'package:nextry_dev/domain/interactors/delivery/add_delivery_offer_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/delivery/add_delivery_orders_interactor.dart';
import 'package:nextry_dev/domain/interactors/delivery/add_delivery_orders_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/delivery/add_delivery_request_interactor.dart';
import 'package:nextry_dev/domain/interactors/delivery/add_delivery_request_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/delivery/add_report_customers_interactor.dart';
import 'package:nextry_dev/domain/interactors/delivery/add_report_customers_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/delivery/add_shipper_review_interactor.dart';
import 'package:nextry_dev/domain/interactors/delivery/add_shipper_review_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/delivery/add_update_shippers_interactor.dart';
import 'package:nextry_dev/domain/interactors/delivery/add_update_shippers_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/delivery/cancel_delivery_order_interactor.dart';
import 'package:nextry_dev/domain/interactors/delivery/cancel_delivery_order_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/delivery/cancel_delivery_request_interactor.dart';
import 'package:nextry_dev/domain/interactors/delivery/cancel_delivery_request_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/delivery/fetch_delivery_offer_interactor.dart';
import 'package:nextry_dev/domain/interactors/delivery/fetch_delivery_offer_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/delivery/fetch_delivery_order_detail_interactor.dart';
import 'package:nextry_dev/domain/interactors/delivery/fetch_delivery_order_detail_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/delivery/fetch_delivery_orders_by_filter_interactor.dart';
import 'package:nextry_dev/domain/interactors/delivery/fetch_delivery_orders_by_filter_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/delivery/fetch_delivery_orders_by_shipper_id_interactor.dart';
import 'package:nextry_dev/domain/interactors/delivery/fetch_delivery_orders_by_shipper_id_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/delivery/fetch_delivery_request_by_user_id_interactor.dart';
import 'package:nextry_dev/domain/interactors/delivery/fetch_delivery_request_by_user_id_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/delivery/fetch_delivery_request_data_by_id_interactor.dart';
import 'package:nextry_dev/domain/interactors/delivery/fetch_delivery_request_data_by_id_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/delivery/fetch_delivery_request_interactor.dart';
import 'package:nextry_dev/domain/interactors/delivery/fetch_delivery_request_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/delivery/fetch_shipper_data_by_id_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/delivery/fetch_shipper_date_by_id_interactor.dart';
import 'package:nextry_dev/domain/interactors/delivery/fetch_shipper_delivery_offer_interactor.dart';
import 'package:nextry_dev/domain/interactors/delivery/fetch_shipper_delivery_offer_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/delivery/fetch_shipper_information_interactor.dart';
import 'package:nextry_dev/domain/interactors/delivery/fetch_shipper_information_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/delivery/fetch_shipper_review_interactor.dart';
import 'package:nextry_dev/domain/interactors/delivery/fetch_shipper_review_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/delivery/request_delete_shipper_feedback_interactor.dart';
import 'package:nextry_dev/domain/interactors/delivery/request_delete_shipper_feedback_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/delivery/update_delivery_order_interactor.dart';
import 'package:nextry_dev/domain/interactors/delivery/update_delivery_order_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/delivery/update_delivery_order_status_interactor.dart';
import 'package:nextry_dev/domain/interactors/delivery/update_delivery_order_status_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/delivery/update_shipper_current_location_interactor.dart';
import 'package:nextry_dev/domain/interactors/delivery/update_shipper_current_location_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/feedback/create_customer_feedback_interactor.dart';
import 'package:nextry_dev/domain/interactors/feedback/create_customer_feedback_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/feedback/create_feedbac_report_interactor.dart';
import 'package:nextry_dev/domain/interactors/feedback/create_feedbac_report_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/feedback/fetch_all_business_feedbacks_interactor.dart';
import 'package:nextry_dev/domain/interactors/feedback/fetch_all_business_feedbacks_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/forgotpassword/forgot_password_interactor.dart';
import 'package:nextry_dev/domain/interactors/forgotpassword/forgot_password_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/hotdeal/fetch_active_hot_deals_interactor.dart';
import 'package:nextry_dev/domain/interactors/hotdeal/fetch_active_hot_deals_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/hotdeal/fetch_all_scheduled_hot_deals_interactor.dart';
import 'package:nextry_dev/domain/interactors/hotdeal/fetch_all_scheduled_hot_deals_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/hotdeal/fetch_home_hot_deals_interactor.dart';
import 'package:nextry_dev/domain/interactors/hotdeal/fetch_home_hot_deals_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/hotdeal/fetch_nextry_hot_deals_interactor.dart';
import 'package:nextry_dev/domain/interactors/hotdeal/fetch_nextry_hot_deals_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/hotdeal/make_hot_deal_ad_interactor.dart';
import 'package:nextry_dev/domain/interactors/hotdeal/make_hot_deal_ad_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/hotdeal/remove_active_hot_deal_interactor.dart';
import 'package:nextry_dev/domain/interactors/hotdeal/remove_active_hot_deal_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/hotdeal/remove_hot_deal_interactor.dart';
import 'package:nextry_dev/domain/interactors/hotdeal/remove_hot_deal_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/location/location_interactor.dart';
import 'package:nextry_dev/domain/interactors/location/location_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/login/login_interactor.dart';
import 'package:nextry_dev/domain/interactors/login/login_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/logout/logout_interactor.dart';
import 'package:nextry_dev/domain/interactors/logout/logout_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/notification/fetch_notification_by_user_id_interactor.dart';
import 'package:nextry_dev/domain/interactors/notification/fetch_notification_by_user_id_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/order/add_update_order_invoice_interactor.dart';
import 'package:nextry_dev/domain/interactors/order/add_update_order_invoice_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/order/cancel_order_status_interactor.dart';
import 'package:nextry_dev/domain/interactors/order/cancel_order_status_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/order/fetch_business_order_detail_interactor.dart';
import 'package:nextry_dev/domain/interactors/order/fetch_business_order_detail_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/order/fetch_business_orders_by_day_interactor.dart';
import 'package:nextry_dev/domain/interactors/order/fetch_business_orders_by_day_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/order/fetch_business_orders_by_status_interactor.dart';
import 'package:nextry_dev/domain/interactors/order/fetch_business_orders_by_status_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/order/fetch_business_sales_by_day_interactor.dart';
import 'package:nextry_dev/domain/interactors/order/fetch_business_sales_by_day_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/order/fetch_customer_order_detail_interactor.dart';
import 'package:nextry_dev/domain/interactors/order/fetch_customer_order_detail_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/order/fetch_customer_orders_interactor.dart';
import 'package:nextry_dev/domain/interactors/order/fetch_customer_orders_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/order/make_order_interactor.dart';
import 'package:nextry_dev/domain/interactors/order/make_order_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/order/update_order_status_interactor.dart';
import 'package:nextry_dev/domain/interactors/order/update_order_status_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/payment_link/add_update_request_payment_link_interactor.dart';
import 'package:nextry_dev/domain/interactors/payment_link/add_update_request_payment_link_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/payment_link/fetch_request_payment_link_by_business_id_interactor.dart';
import 'package:nextry_dev/domain/interactors/payment_link/fetch_request_payment_link_by_business_id_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/payment_link/fetch_request_payment_link_interactor.dart';
import 'package:nextry_dev/domain/interactors/payment_link/fetch_request_payment_link_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/payplus/create_payplus_subscription_interactor.dart';
import 'package:nextry_dev/domain/interactors/payplus/create_payplus_subscription_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/payplus/delete_payplus_subscription_interactor.dart';
import 'package:nextry_dev/domain/interactors/payplus/delete_payplus_subscription_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/payplus/fetch_payplus_customer_subscription_interactor.dart';
import 'package:nextry_dev/domain/interactors/payplus/fetch_payplus_customer_subscription_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/payplus/refund_by_transaction_payplus_interactor.dart';
import 'package:nextry_dev/domain/interactors/payplus/refund_by_transaction_payplus_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/payplus/view_payplus_subscription_interactor.dart';
import 'package:nextry_dev/domain/interactors/payplus/view_payplus_subscription_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/product/add_product_discount_interactor.dart';
import 'package:nextry_dev/domain/interactors/product/add_product_discount_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/product/add_update_product_interactor.dart';
import 'package:nextry_dev/domain/interactors/product/add_update_product_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/product/delete_product_category_interactor.dart';
import 'package:nextry_dev/domain/interactors/product/delete_product_category_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/product/delete_product_discount_interactor.dart';
import 'package:nextry_dev/domain/interactors/product/delete_product_discount_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/product/delete_product_interactor.dart';
import 'package:nextry_dev/domain/interactors/product/delete_product_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/product/fetch_product_by_category_interactor.dart';
import 'package:nextry_dev/domain/interactors/product/fetch_product_by_category_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/product/fetch_product_interactor.dart';
import 'package:nextry_dev/domain/interactors/product/fetch_product_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/product/fetch_relative_product_interactor.dart';
import 'package:nextry_dev/domain/interactors/product/fetch_relative_product_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/push/push_notification_interactor.dart';
import 'package:nextry_dev/domain/interactors/push/push_notification_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/shipper_payment_link/add_update_request_payment_link_interactor.dart';
import 'package:nextry_dev/domain/interactors/shipper_payment_link/add_update_request_payment_link_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/shipper_subscription/fetch_shipper_subscription_data_interactor.dart';
import 'package:nextry_dev/domain/interactors/shipper_subscription/fetch_shipper_subscription_data_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/signup/apple_sign_in_interactor.dart';
import 'package:nextry_dev/domain/interactors/signup/apple_sign_in_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/signup/google_sign_in_interactor.dart';
import 'package:nextry_dev/domain/interactors/signup/google_sign_in_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/signup/sign_up_interactor.dart';
import 'package:nextry_dev/domain/interactors/signup/sign_up_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/subscriptions/cancel_my_subscription_interactor.dart';
import 'package:nextry_dev/domain/interactors/subscriptions/cancel_my_subscription_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/subscriptions/create_subscription_interactor.dart';
import 'package:nextry_dev/domain/interactors/subscriptions/create_subscription_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/subscriptions/fetch_my_subscriptions_interactor.dart';
import 'package:nextry_dev/domain/interactors/subscriptions/fetch_my_subscriptions_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/subscriptions/fetch_subscription_data_interactor.dart';
import 'package:nextry_dev/domain/interactors/subscriptions/fetch_subscription_data_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/user/add_pay_plus_customer_id_user_interactor.dart';
import 'package:nextry_dev/domain/interactors/user/add_pay_plus_customer_id_user_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/user/add_subscription_id_interactor.dart';
import 'package:nextry_dev/domain/interactors/user/add_subscription_id_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/user/add_user_interactor.dart';
import 'package:nextry_dev/domain/interactors/user/add_user_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/user/delete_file_interactor.dart';
import 'package:nextry_dev/domain/interactors/user/delete_file_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/user/delete_profile_interactor.dart';
import 'package:nextry_dev/domain/interactors/user/delete_profile_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/user/fetch_user_data_by_id_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/user/fetch_user_data_id_interactor.dart';
import 'package:nextry_dev/domain/interactors/user/fetch_user_interactor.dart';
import 'package:nextry_dev/domain/interactors/user/fetch_user_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/verifyemail/send_email_verification_interactor.dart';
import 'package:nextry_dev/domain/interactors/verifyemail/send_email_verification_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/verifyemail/verify_email_interactor.dart';
import 'package:nextry_dev/domain/interactors/verifyemail/verify_email_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/wallet/add_transaction_interactor.dart';
import 'package:nextry_dev/domain/interactors/wallet/add_transaction_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/wallet/fetch_all_transactions_interactor.dart';
import 'package:nextry_dev/domain/interactors/wallet/fetch_all_transactions_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/wallet/invoice_interactor.dart';
import 'package:nextry_dev/domain/interactors/wallet/invoice_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/wallet/read_balance_interactor.dart';
import 'package:nextry_dev/domain/interactors/wallet/read_balance_interactor_impl.dart';
import 'package:nextry_dev/domain/interactors/wallet/transactions_history_interactor.dart';
import 'package:nextry_dev/domain/interactors/wallet/transactions_history_interactor_impl.dart';

class ModuleContainer {
  Injector initialise(Injector injector) {
    injector.map<ReadBalanceInteractor>(
        (i) => ReadBalanceInteractorImpl(gateWay: FetchBalanceGateway()),
        isSingleton: false);

    injector.map<FetchAllTransactionsInteractor>(
        (i) => FetchAllTransactionsInteractorImpl(
            gateWay: FetchAllTransactionsGateway()),
        isSingleton: false);

    injector.map<TransactionsHistoryInteractor>(
        (i) => TransactionsHistoryInteractorImpl(
            gateWay: FetchAllTransactionsHistoryGateway()),
        isSingleton: false);

    injector.map<AddTransactionInteractor>(
        (i) => AddTransactionInteractorImpl(gateWay: AddTransactionGateway()),
        isSingleton: false);

    injector.map<InvoiceInteractor>(
        (i) => InvoiceInteractorImpl(gateWay: FetchInvoiceGateway()),
        isSingleton: false);

    injector.map<SignUpInteractor>(
        (injector) => SignUpInteractorImpl(gateway: SignUpGateWay()),
        isSingleton: false);

    injector.map<LogoutInteractor>(
        (injector) => LogoutInteractorImpl(gateway: LogoutGateWay()),
        isSingleton: false);

    injector.map<ForgotPasswordInteractor>(
        (injector) =>
            ForgotPasswordInteractorImpl(gateway: ForgotPasswordGateWay()),
        isSingleton: false);

    injector.map<LoginInteractor>(
        (injector) => LoginInteractorImpl(gateway: LoginGateWay()),
        isSingleton: false);

    injector.map<GoogleSignInInteractor>(
        (injector) =>
            GoogleSignInInteractorImpl(gateway: GoogleSignInGateWay()),
        isSingleton: false);

    injector.map<AutoLoginInteractor>(
        (injector) => AutoLoginInteractorImpl(gateway: AutoLoginGateWay()),
        isSingleton: false);

    injector.map<DeleteProfileInteractor>(
        (injector) =>
            DeleteProfileInteractorImpl(gateway: DeleteProfileGateWay()),
        isSingleton: false);

    injector.map<FetchUserInteractor>(
        (injector) => FetchUserInteractorImpl(gateway: FetchUserGateWay()),
        isSingleton: false);

    injector.map<AddUserInteractor>(
        (injector) => AddUserInteractorImpl(gateway: AddUserGateWay()),
        isSingleton: false);

    injector.map<SplashConfigInteractor>(
        (injector) =>
            SplashConfigInteractorImpl(gateway: SplashConfigGateway()),
        isSingleton: false);

    injector.map<DeleteFileInteractor>(
        (injector) => DeleteFileInteractorImpl(gateway: DeleteFileGateWay()),
        isSingleton: false);

    injector.map<CategoryInteractor>(
        (injector) => CategoryInteractorImpl(gateway: CategoryGateway()),
        isSingleton: false);

    injector.map<LocationInteractor>(
        (injector) => LocationInteractorImpl(gateway: LocationGateWay()),
        isSingleton: false);

    injector.map<AddUpdateBusinessInteractor>(
        (injector) => AddUpdateBusinessInteractorImpl(
            gateway: AddUpdateBusinessGateway()),
        isSingleton: false);

    injector.map<UpdateBusinessStatusInteractor>(
        (injector) => UpdateBusinessStatusInteractorImpl(
            gateway: UpdateBusinessStatusGateWay()),
        isSingleton: false);

    injector.map<FetchBusinessDataInteractor>(
        (injector) => FetchBusinessDataInteractorImpl(
            gateway: FetchBusinessDataGateWay()),
        isSingleton: false);

    injector.map<FetchBusinessCategoryInteractor>(
        (injector) => FetchBusinessCategoryInteractorImpl(
            gateway: FetchBusinessCategoryGateWay()),
        isSingleton: false);

    injector.map<FetchMyBusinessesByStatusInteractor>(
        (injector) => FetchMyBusinessesByStatusInteractorImpl(
            gateway: FetchMyBusinessesByStatusGateWay()),
        isSingleton: false);

    injector.map<AddUpdateProductInteractor>(
        (injector) =>
            AddUpdateProductInteractorImpl(gateway: AddUpdateProductGateway()),
        isSingleton: false);

    injector.map<DeleteProductCategoryInteractor>(
        (injector) => DeleteProductCategoryInteractorImpl(
            gateway: DeleteProductCategoryGateway()),
        isSingleton: false);

    injector.map<DeleteProductInteractor>(
        (injector) =>
            DeleteProductInteractorImpl(gateway: DeleteProductGateway()),
        isSingleton: false);

    injector.map<FetchProductByCategoryGateWayInteractor>(
        (injector) => FetchProductByCategoryGateWayInteractorImpl(
            gateway: FetchProductByCategoryGateWay()),
        isSingleton: false);

    injector.map<AddProductDiscountInteractor>(
        (injector) => AddProductDiscountInteractorImpl(
            gateway: AddProductDiscountGateway()),
        isSingleton: false);

    injector.map<DeleteProductDiscountInteractor>(
        (injector) => DeleteProductDiscountInteractorImpl(
            gateway: DeleteProductDiscountGateway()),
        isSingleton: false);

    injector.map<FetchProductInteractor>(
        (injector) =>
            FetchProductInteractorImpl(gateway: FetchProductGateWay()),
        isSingleton: false);
    injector.map<SendEmailVerificationInteractor>(
        (injector) => SendEmailVerificationInteractorImpl(
            gateway: SendEmailVerificationGateWay()),
        isSingleton: false);

    injector.map<VerifyEmailInteractor>(
        (injector) => VerifyEmailInteractorImpl(gateway: VerifyEmailGateWay()),
        isSingleton: false);

    injector.map<FetchRelativeProductGateWayInteractor>(
        (injector) => FetchRelativeProductGateWayInteractorImpl(
            gateway: FetchRelativeProductGateWay()),
        isSingleton: false);

    injector.map<AppleSignInInteractor>(
        (injector) => AppleSignInInteractorImpl(gateway: AppleSignInGateWay()),
        isSingleton: false);

    injector.map<AddUpdateProductCartInteractor>(
        (injector) => AddUpdateProductCartInteractorImpl(
            gateway: AddUpdateProductCartGateway()),
        isSingleton: false);

    injector.map<AddBusinessCategoryInteractor>(
        (injector) => AddBusinessCategoryInteractorImpl(
            gateway: AddBusinessCategoryGateway()),
        isSingleton: false);

    injector.map<FetchCartDataInteractor>(
        (injector) =>
            FetchCartDataInteractorImpl(gateway: FetchCartDataGateWay()),
        isSingleton: false);

    injector.map<AddUpdateAdsInteractor>(
        (injector) =>
            AddUpdateAdsInteractorImpl(gateway: AddUpdateAdsGateway()),
        isSingleton: false);

    injector.map<FetchSubscriptionDataInteractor>(
        (injector) => FetchSubscriptionDataInteractorImpl(
            gateway: FetchSubscriptionDataGateWay()),
        isSingleton: false);

    injector.map<FetchCartDataByBusinessIdInteractor>(
        (injector) => FetchCartDataByBusinessIdInteractorImpl(
            gateway: FetchCartDataByBusinessIdDataGateWay()),
        isSingleton: false);

    injector.map<UpdateBusinessSubscriptionIdInteractor>(
        (injector) => UpdateBusinessSubscriptionIdInteractorImpl(
            gateway: UpdateBusinessSubscriptionIdGateWay()),
        isSingleton: false);

    injector.map<MakeOrderInteractor>(
        (injector) => MakeOrderInteractorImpl(gateway: MakeOrderGateWay()),
        isSingleton: false);

    injector.map<FetchCustomerOrdersInteractor>(
        (injector) => FetchCustomerOrdersInteractorImpl(
            gateway: FetchCustomerOrdersGateWay()),
        isSingleton: false);

    injector.map<FetchBusinessOrdersByStatusInteractor>(
        (injector) => FetchBusinessOrdersByStatusInteractorImpl(
            gateway: FetchBusinessOrdersByStatusGateWay()),
        isSingleton: false);

    injector.map<UpdateOrderStatusInteractor>(
        (injector) => UpdateOrderStatusInteractorImpl(
            gateway: UpdateOrderStatusGateWay()),
        isSingleton: false);

    injector.map<FetchCustomerOrderDetailInteractor>(
        (injector) => FetchCustomerOrderDetailInteractorImpl(
            gateway: FetchCustomerOrderDetailGateWay()),
        isSingleton: false);

    injector.map<DeleteCartByIdInteractor>(
        (injector) =>
            DeleteCartByIdInteractorImpl(gateway: DeleteCartByIdGateway()),
        isSingleton: false);

    injector.map<FetchBusinessOrderDetailInteractor>(
        (injector) => FetchBusinessOrderDetailInteractorImpl(
            gateway: FetchBusinessOrderDetailGateWay()),
        isSingleton: false);

    injector.map<CreateCustomerFeedbackInteractor>(
        (injector) => CreateCustomerFeedbackInteractorImpl(
            gateway: CreateCustomerFeedbackGateway()),
        isSingleton: false);

    injector.map<FetchAllBusinessFeedbacksInteractor>(
        (injector) => FetchAllBusinessFeedbacksInteractorImpl(
            gateway: FetchAllBusinessFeedbacksGateway()),
        isSingleton: false);

    injector.map<CreateFeedbackReportInteractor>(
        (injector) => CreateFeedbackReportInteractorImpl(
            gateway: CreateFeedbackReportGateway()),
        isSingleton: false);

    injector.map<MakeHotDealAdInteractor>(
        (injector) =>
            MakeHotDealAdInteractorImpl(gateway: MakeHotDealAdGateway()),
        isSingleton: false);

    injector.map<RemoveHotDealInteractor>(
        (injector) =>
            RemoveHotDealInteractorImpl(gateway: RemoveHotDealGateway()),
        isSingleton: false);

    injector.map<FetchAllScheduledHotDealsInteractor>(
        (injector) => FetchAllScheduledHotDealsInteractorImpl(
            gateway: FetchAllScheduledHotDealsGateWay()),
        isSingleton: false);

    injector.map<FetchUnavailableDatesInteractor>(
        (injector) => FetchUnavailableDatesInteractorImpl(
            gateway: FetchUnavailableDatesGateWay()),
        isSingleton: false);

    injector.map<FetchAllScheduledAdsInteractor>(
        (injector) => FetchAllScheduledAdsInteractorImpl(
            gateway: FetchAllScheduledAdsGateWay()),
        isSingleton: false);

    injector.map<RemoveAdInteractor>(
        (injector) => RemoveAdInteractorImpl(gateway: RemoveAdsGateway()),
        isSingleton: false);

    injector.map<ConvertDiscountToAdsInteractor>(
        (injector) => ConvertDiscountToAdsInteractorImpl(
            gateway: ConvertDiscountToAdsGateWay()),
        isSingleton: false);

    injector.map<PushNotificationInteractor>(
        (injector) =>
            PushNotificationInteractorImpl(gateway: PushTokenGateway()),
        isSingleton: false);

    injector.map<FetchBusinessOrdersByDayInteractor>(
        (injector) => FetchBusinessOrdersByDayInteractorImpl(
            gateway: FetchBusinessOrdersByDayGateWay()),
        isSingleton: false);

    injector.map<FetchBusinessSalesByDayInteractor>(
        (injector) => FetchBusinessSalesByDayInteractorImpl(
            gateway: FetchBusinessSalesByDayGateWay()),
        isSingleton: false);

    injector.map<UpdateUnavailableDatesInteractor>(
        (injector) => UpdateUnavailableDatesInteractorImpl(
            gateway: UpdateUnavailableDatesGateWay()),
        isSingleton: false);

    injector.map<FetchActiveHotDealsInteractor>(
        (injector) => FetchActiveHotDealsInteractorImpl(
            gateway: FetchActiveHotDealsGateWay()),
        isSingleton: false);

    injector.map<FetchActiveAdsInteractor>(
        (injector) =>
            FetchActiveAdsInteractorImpl(gateway: FetchActiveAdsGateWay()),
        isSingleton: false);

    injector.map<FetchHomeAdsInteractor>(
        (injector) =>
            FetchHomeAdsInteractorImpl(gateway: FetchHomeAdsGateWay()),
        isSingleton: false);

    injector.map<FetchHomeHotDealsInteractor>(
        (injector) => FetchHomeHotDealsInteractorImpl(
            gateway: FetchHomeHotDealsGateWay()),
        isSingleton: false);

    injector.map<RemoveActiveAdInteractor>(
        (injector) =>
            RemoveActiveAdInteractorImpl(gateway: RemoveActiveAdsGateWay()),
        isSingleton: false);

    injector.map<RemoveActiveHotDealInteractor>(
        (injector) => RemoveActiveHotDealInteractorImpl(
            gateway: RemoveActiveHotDealGateway()),
        isSingleton: false);

    injector.map<FetchConfigInteractor>(
        (injector) => FetchConfigInteractorImpl(
            gateway: FetchConfigurationsDataGateWay()),
        isSingleton: false);

    injector.map<CreateSubscriptionInteractor>(
        (injector) => CreateSubscriptionInteractorImpl(
            gateway: CreateSubscriptionGateway()),
        isSingleton: false);

    injector.map<FetchMySubscriptionsInteractor>(
        (injector) => FetchMySubscriptionsInteractorImpl(
            gateway: FetchMySubscriptionsGateWay()),
        isSingleton: false);

    injector.map<AddUnSubscribedBusinessesInteractor>(
        (injector) => AddUnSubscribedBusinessesInteractorImpl(
            gateway: AddUnSubscribedBusinessesGateway()),
        isSingleton: false);

    injector.map<AddSubscriptionIdInteractor>(
        (injector) => AddSubscriptionIdInteractorImpl(
            gateway: AddSubscriptionIdGateway()),
        isSingleton: false);
    injector.map<AddDeliveryRequestInteractor>(
        (injector) => AddDeliveryRequestInteractorImpl(
            gateway: AddDeliveryRequestGateway()),
        isSingleton: false);

    injector.map<AddDeliveryOfferInteractor>(
        (injector) =>
            AddDeliveryOfferInteractorImpl(gateway: AddOfferRequestGateway()),
        isSingleton: false);

    injector.map<FetchDeliveryRequestInteractor>(
        (injector) => FetchDeliveryRequestInteractorImpl(
            gateway: FetchDeliveryRequestGateWay()),
        isSingleton: false);

    injector.map<FetchDeliveryOfferInteractor>(
        (injector) => FetchDeliveryOfferInteractorImpl(
            gateway: FetchDeliveryOfferGateWay()),
        isSingleton: false);

    injector.map<CancelMySubscriptionInteractor>(
        (injector) => CancelMySubscriptionInteractorImpl(
            gateway: CancelMySubscriptionGateway()),
        isSingleton: false);

    injector.map<AllCardInteractor>(
        (injector) => AllCardInteractorImpl(gateway: FetchAllCardGateway()),
        isSingleton: false);

    injector.map<AddDeliveryOrdersInteractor>(
        (injector) => AddDeliveryOrdersInteractorImpl(
            gateway: AddDeliveryOrdersGateway()),
        isSingleton: false);

    injector.map<AddReportCustomersInteractor>(
        (injector) => AddReportCustomersInteractorImpl(
            gateway: AddReportCustomersGateway()),
        isSingleton: false);

    injector.map<AddShipperReviewInteractor>(
        (injector) =>
            AddShipperReviewInteractorImpl(gateway: AddShipperReviewGateway()),
        isSingleton: false);

    injector.map<FetchBusinessesByNameInteractor>(
        (injector) => FetchBusinessesByNameInteractorImpl(
            gateway: FetchBusinessesByNameGateWay()),
        isSingleton: false);

    injector.map<FetchNextryHotDealsInteractor>(
        (injector) => FetchNextryHotDealsInteractorImpl(
            gateway: FetchNextryHotDealsGateWay()),
        isSingleton: false);

    injector.map<AddUpdateOrderInvoiceInteractor>(
        (injector) => AddUpdateOrderInvoiceInteractorImpl(
            gateway: AddUpdateOrderInvoiceGateway()),
        isSingleton: false);

    injector.map<FetchDeliveryRequestByUserIdInteractor>(
        (injector) => FetchDeliveryRequestByUserIdInteractorImpl(
            gateway: FetchDeliveryRequestByUserIdGateWay()),
        isSingleton: false);

    injector.map<UpdateDeliveryOrderInteractor>(
        (injector) => UpdateDeliveryOrderInteractorImpl(
            gateway: UpdateDeliveryOrderGateway()),
        isSingleton: false);

    injector.map<AddUpdateRequestPaymentLinkInteractor>(
        (injector) => AddUpdateRequestPaymentLinkInteractorImpl(
            gateway: AddUpdateRequestPaymentLinkGateway()),
        isSingleton: false);

    injector.map<FetchRequestPaymentLinkInteractor>(
        (injector) => FetchRequestPaymentLinkInteractorImpl(
            gateway: FetchRequestPaymentLinkGateWay()),
        isSingleton: false);

    injector.map<FetchDeliveryOrdersByFilterInteractor>(
        (injector) => FetchDeliveryOrdersByFilterInteractorImpl(
            gateway: FetchDeliveryOrdersByFilterGateWay()),
        isSingleton: false);

    injector.map<FetchShipperReviewInteractor>(
        (injector) => FetchShipperReviewInteractorImpl(
            gateway: FetchShipperReviewGateway()),
        isSingleton: false);

    injector.map<FetchDeliveryOrderDetailInteractor>(
        (injector) => FetchDeliveryOrderDetailInteractorImpl(
            gateway: FetchDeliveryOrderDetailGateWay()),
        isSingleton: false);

    injector.map<FetchRequestPaymentLinkByBusinessIdInteractor>(
        (injector) => FetchRequestPaymentLinkByBusinessIdInteractorImpl(
            gateway: FetchRequestPaymentLinkByBusinessIdGateWay()),
        isSingleton: false);

    injector.map<CancelDeliveryRequestInteractor>(
        (injector) => CancelDeliveryRequestInteractorImpl(
            gateway: CancelDeliveryRequestGateway()),
        isSingleton: false);

    injector.map<FetchDeliveryOrdersByShipperIdInteractor>(
        (injector) => FetchDeliveryOrdersByShipperIdInteractorImpl(
            gateway: FetchDeliveryOrdersByShipperIdGateWay()),
        isSingleton: false);

    injector.map<FetchNotificationByUserIdInteractor>(
        (injector) => FetchNotificationByUserIdInteractorImpl(
            gateway: FetchNotificationByUserIdGateWay()),
        isSingleton: false);

    injector.map<AddUpdateShippersInteractor>(
        (injector) =>
            AddUpdateShippersInteractorImpl(gateway: AddUpdateShipperGateway()),
        isSingleton: false);

    injector.map<FetchShipperInformationInteractor>(
        (injector) => FetchShipperInformationInteractorImpl(
            gateway: FetchShipperInformationGateway()),
        isSingleton: false);

    injector.map<CancelDeliveryOrderInteractor>(
        (injector) => CancelDeliveryOrderInteractorImpl(
            gateway: CancelDeliveryOrderGateway()),
        isSingleton: false);

    injector.map<UpdateDeliveryOrderStatusInteractor>(
        (injector) => UpdateDeliveryOrderStatusInteractorImpl(
            gateway: UpdateDeliveryOrderStatusGateway()),
        isSingleton: false);

    injector.map<RequestDeleteShipperFeedbackInteractor>(
        (injector) => RequestDeleteShipperFeedbackInteractorImpl(
            gateway: RequestDeleteShipperFeedbackFeedbackGateway()),
        isSingleton: false);

    injector.map<FetchUserDataByIdInteractor>(
        (injector) => FetchUserDataByIdInteractorImpl(
            gateway: FetchUserDataByIdGateWay()),
        isSingleton: false);

    injector.map<UpdateShipperCurrentLocationInteractor>(
        (injector) => UpdateShipperCurrentLocationInteractorImpl(
            gateway: UpdateShipperCurrentLocationGateway()),
        isSingleton: false);

    injector.map<FetchShipperDataByIdInteractor>(
        (injector) => FetchShipperDataByIdInteractorImpl(
            gateway: FetchShipperDataByIdGateway()),
        isSingleton: false);

    injector.map<AddAskMeInteractor>(
        (injector) => AddAskMeInteractorImpl(gateway: AddAskMeGateway()),
        isSingleton: false);

    injector.map<ContactUsConfigInteractor>(
        (injector) =>
            ContactUsConfigInteractorImpl(gateway: ContactUsConfigGateway()),
        isSingleton: false);

    injector.map<CreatePayPlusSubscriptionInteractor>(
        (injector) => CreatePayPlusSubscriptionInteractorImpl(
            gateway: CreatePayPlusSubscriptionGateway()),
        isSingleton: false);

    injector.map<DeletePayPlusSubscriptionInteractor>(
        (injector) => DeletePayPlusSubscriptionInteractorImpl(
            gateway: DeletePayPlusSubscriptionGateway()),
        isSingleton: false);

    injector.map<ViewPayPlusSubscriptionInteractor>(
        (injector) => ViewPayPlusSubscriptionInteractorImpl(
            gateway: ViewPayPlusSubscriptionGateway()),
        isSingleton: false);

    injector.map<RefundByTransactionIdPayPlusInteractor>(
        (injector) => RefundByTransactionIdPayPlusInteractorImpl(
            gateway: RefundByTransactionIdPayPlusGateway()),
        isSingleton: false);

    injector.map<FetchPayPlusPaymentConfigInteractor>(
        (injector) => FetchPayPlusPaymentConfigInteractorImpl(
            gateway: FetchPayPlusPaymentConfigGateWay()),
        isSingleton: false);

    injector.map<AddPayPlusCustomerIdUserInteractor>(
        (injector) => AddPayPlusCustomerIdUserInteractorImpl(
            gateway: AddPayPlusCustomerIdUserGateWay()),
        isSingleton: false);

    injector.map<FetchPayPlusCustomerSubscriptionInteractor>(
        (injector) => FetchPayPlusCustomerSubscriptionInteractorImpl(
            gateway: FetchPayPlusSubscriptionsGateWay()),
        isSingleton: false);

    injector.map<FetchShipperSubscriptionDataInteractor>(
        (injector) => FetchShipperSubscriptionDataInteractorImpl(
            gateway: FetchShipperSubscriptionDataGateWay()),
        isSingleton: false);

    injector.map<CancelOrderStatusInteractor>(
        (injector) =>
            CancelOrderStatusInteractorImpl(gateway: CancelOrderGateWay()),
        isSingleton: false);

    injector.map<FetchShipperDeliveryOfferInteractor>(
        (injector) => FetchShipperDeliveryOfferInteractorImpl(
            gateway: FetchShipperDeliveryOfferGateWay()),
        isSingleton: false);

    injector.map<FetchNextryDocumentsInteractor>(
        (injector) => FetchNextryDocumentsInteractorImpl(
            gateway: FetchNextryDocumentsDataGateWay()),
        isSingleton: false);

    injector.map<AddUpdateShipperRequestPaymentLinkInteractor>(
        (injector) => AddUpdateShipperRequestPaymentLinkInteractorImpl(
            gateway: AddUpdateShipperRequestPaymentLinkGateway()),
        isSingleton: false);

    injector.map<FetchGuidesUrlsInteractor>(
        (injector) => FetchGuidesUrlsInteractorImpl(
            gateway: FetchGuidesUrlsDataGateWay()),
        isSingleton: false);

    injector.map<FetchForceUpdateInteractor>(
        (injector) =>
            FetchForceUpdateInteractorImpl(gateway: FetchAppUpdateGateWay()),
        isSingleton: false);

    injector.map<FetchDeliveryRequestDataByIdInteractor>(
        (injector) => FetchDeliveryRequestDataByIdInteractorImpl(
            gateway: FetchDeliveryRequestDataByIdGateway()),
        isSingleton: false);

    injector.map<RemoveProductAdInteractor>(
            (injector) => RemoveProductAdInteractorImpl(gateway: RemoveProductAdsGateway()),
        isSingleton: false);

    return injector;
  }
}
