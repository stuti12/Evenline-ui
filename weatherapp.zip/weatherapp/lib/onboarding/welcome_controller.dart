import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:weatherapp/onboarding/welcome.dart';

import '../home/home_screen.dart';
import '../utils/strings.dart';

class WelcomeController extends GetxController{
  var value = 0.25.obs;

  @override
  void onInit() {
    super.onInit();
  }

}