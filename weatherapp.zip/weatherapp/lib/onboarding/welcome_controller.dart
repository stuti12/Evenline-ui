import 'package:get/get.dart';

class WelcomeController extends GetxController {
  var value = 0.25.obs;

  @override
  void onInit() {
    super.onInit();
  }
}
