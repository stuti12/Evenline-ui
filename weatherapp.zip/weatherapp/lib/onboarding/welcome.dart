import 'package:clippy_flutter/arc.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:smooth_page_indicator/smooth_page_indicator.dart';
import 'package:weatherapp/home/home_screen.dart';
import 'package:weatherapp/onboarding/welcome_controller.dart';
import 'package:weatherapp/utils/colors.dart';
import 'package:weatherapp/utils/custom/gradient.dart';
import 'package:weatherapp/utils/images.dart';

import '../utils/strings.dart';

class WelcomeScreen extends StatefulWidget {
  const WelcomeScreen({Key? key}) : super(key: key);

  @override
  State<WelcomeScreen> createState() => _WelcomeScreenState();
}

class _WelcomeScreenState extends State<WelcomeScreen> {
  PageController _controller = PageController();
  PageController _pageController = PageController();
  WelcomeController welcomeController = Get.put(WelcomeController());
  double value = 0.25;

  @override
  void initState() {
    _controller = PageController(initialPage: 0);
    _pageController = PageController(initialPage: 0);
    super.initState();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  _storeOnboardInfo() async {
    print("Shared pref called");
    int isViewed = 0;
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setInt('onBoard', isViewed);
    print(prefs.getInt('onBoard'));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(gradient: GradientWidget.linearGradient()),
        child: Column(
          children: [
            SizedBox(
              height: 40.h,
            ),
            Align(
              alignment: Alignment.topRight,
              child: TextButton(
                onPressed: () {
                  _storeOnboardInfo();
                  Get.offAll(const HomeScreen());
                },
                child: Text(
                  'Skip',
                  style: TextStyle(
                      fontWeight: FontWeight.w500,
                      color: AppColor.colorWhite,
                      fontSize: 14.sp,
                      fontFamily: 'Poppins-Regular'),
                ),
              ),
            ),
            SizedBox(
                height: 230.h,
                child: PageView.builder(
                    physics: const NeverScrollableScrollPhysics(),
                    controller: _controller,
                    itemBuilder: (context, index) {
                      return Image.asset(images[index]);
                    })),
            SmoothPageIndicator(
              controller: _controller,
              count: onboardData.length,
              effect: ExpandingDotsEffect(
                  dotHeight: 10.h,
                  dotWidth: 10.w,
                  dotColor: AppColor.colorWhite,
                  activeDotColor: AppColor.blackColor),
            ),
            Expanded(
                child: Align(
                    alignment: Alignment.bottomCenter,
                    child: Arc(
                      arcType: ArcType.CONVEX,
                      edge: Edge.TOP,
                      height: 80.h,
                      clipShadows: [ClipShadow(color: Colors.black)],
                      child: Container(
                        height: 0.5.sh,
                        width: double.infinity,
                        color: Colors.white,
                        child: Container(
                          margin: EdgeInsets.symmetric(horizontal: 40.w),
                          child: Column(
                            children: [
                              Expanded(
                                child: PageView.builder(
                                    physics: NeverScrollableScrollPhysics(),
                                    itemCount: onboardData.length,
                                    controller: _pageController,
                                    itemBuilder: (context, index) {
                                      return onBoardText(
                                          onboardData[index].text1, onboardData[index].text2);
                                    }),
                              ),
                              Stack(
                                children: [
                                  Obx(
                                    () => Padding(
                                      padding: EdgeInsets.all(10.r),
                                      child: Transform.scale(
                                        scale: 2.0,
                                        child: CircularProgressIndicator(
                                          color: AppColor.welcomeProgressGradient1,
                                          strokeWidth: 2.r,
                                          value: welcomeController.value.value,
                                        ),
                                      ),
                                    ),
                                  ),
                                  Container(
                                    padding: EdgeInsets.all(4.r),
                                    margin: EdgeInsets.only(bottom: 30.h),
                                    decoration: BoxDecoration(
                                        shape: BoxShape.circle,
                                        // Box decoration takes a gradient
                                        gradient: GradientWidget.linearGradient()),
                                    child: IconButton(
                                      onPressed: () {
                                        _storeOnboardInfo();

                                        if (_controller.page != onboardData.length - 1 &&
                                            _pageController.page != onboardData.length - 1) {
                                          _controller.nextPage(
                                              duration: const Duration(microseconds: 10),
                                              curve: Curves.bounceIn);
                                          _pageController.nextPage(
                                              duration: Duration(microseconds: 10),
                                              curve: Curves.bounceIn);
                                          welcomeController.value.value =
                                              welcomeController.value.value + 0.25;
                                        } else {
                                          Get.offAll(const HomeScreen());
                                        }
                                      },
                                      icon: const Icon(
                                        Icons.arrow_forward_outlined,
                                        color: Colors.white,
                                      ),
                                    ),
                                  ),
                                ],
                              )
                            ],
                          ),
                        ),
                      ),
                    )))
          ],
        ),
      ),
    );
  }

  List images = [AppImage.imgCloud, AppImage.imgSun, AppImage.imgHourlyForecast, AppImage.imgMoon];

  List<OnBoard> onboardData = [
    OnBoard(Strings.onboardingTitle, Strings.onboardingSubTitle),
    OnBoard(Strings.onboardingTitle2, Strings.onboardingSubTitle2),
    OnBoard(Strings.onboardingTitle3, Strings.onboardingSubTitle3),
    OnBoard(Strings.onboardingTitle3, Strings.onboardingSubTitle),
  ];

  Widget onBoardText(String text, String text2) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.center,
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Text(
          text,
          textAlign: TextAlign.center,
          style: TextStyle(
              color: AppColor.welcomeTextColor,
              fontFamily: 'Poppins-Regular',
              fontSize: 28.sp,
              fontWeight: FontWeight.w600),
        ),
        SizedBox(
          height: 12.h,
        ),
        Text(
          text2,
          textAlign: TextAlign.center,
          style: TextStyle(
              color: AppColor.welcomeSubtitleTextColor,
              fontFamily: 'Poppins-Regular',
              fontSize: 16.sp,
              fontWeight: FontWeight.w400),
        ),
      ],
    );
  }
}

class OnBoard {
  final String text1;
  final String text2;

  OnBoard(this.text1, @required this.text2);
}
