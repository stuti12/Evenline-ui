import 'package:flutter/material.dart';

class AppColor {

  static Color primaryColorGradient = const Color(0xFF484B5B);
  static Color primaryColorGradient2 = const Color(0xFF2C2D35);
  static Color primaryColorBottom = Colors.white;
  static Color colorWhite = Colors.white;
  static Color colorRed = const Color(0xFFFF0000);
  static Color welcomeTextColor = const Color(0xFF0A0A22);
  static Color welcomeSubtitleTextColor = const Color(0xFF8B95A2);
  static Color welcomeProgressGradient1 = const Color(0xFFFF4F80);
  static Color welcomeProgressGradient2 = const Color(0xFFC23ACC);
  static Color textColor = const Color(0xFF9B9EAD);
  static Color transparentColor = Colors.transparent;
  static Color blackColor = const Color(0xFF000000);
  static Color colorGreyGradient1 = const Color(0xFFA2A4B5);
  static Color colorGreyGradient2 = const Color(0xFF545760);
  static Color darkGreyGradient1 = const Color(0xFF2F313A);
  static Color darkGreyGradient2 = const Color(0xFF232329);
  static Color colorGrey = const Color(0xFF868794);
  static Color colorGreyChartText = const Color(0xFF73767F);
  static Color colorGreyCorona = const Color(0xFF9A9EAE);
  static Color colorTodayScreenBg = const Color(0xFF32333E);
  static Color colorTodayScreenText = const Color(0xFF9B9EAD);
  static Color colorProgressGradient = const Color(0xFF22FFE0);
  static Color colorProgressGradient2 = const Color(0xFFFEDE35);
  static Color colorProgressGradient3 = const Color(0xFFFE381D);
  static Color colorProgressGradient4 = const Color(0xFFFE1D1D);
  static Color colorForecastGradient = const Color(0xFFA6A8AC);
  static Color colorForecastText = const Color(0xFFFFBD00);
  static  Shader gradient = const LinearGradient(colors: [  Color(0xFFA2A4B5),
    Color(0xFF545760),]).createShader(Rect.fromLTWH(0.0, 0.0, 100.0, 70.0));
}