import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class Helper {
  static DateTime? stringToDate(String string, {String? format, bool isUTCTime = false}) {
    DateFormat formatter = DateFormat(format);
    if (string.isNotEmpty) {
      try {

        var convertedDate = formatter.parse(string);
        if (isUTCTime) {
          convertedDate = convertedDate.add(DateTime.now().timeZoneOffset);
        }
        return convertedDate;
      } catch (e) {
        debugPrint('---- Error :: ${e.toString()} ----');
      }
    }
    return null;
  }
}