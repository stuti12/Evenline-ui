class ApiConst{
  static const String baseUrl = 'https://api.openweathermap.org/';
}