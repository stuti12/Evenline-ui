import 'package:flutter/material.dart';

import '../colors.dart';

class GradientWidget {
  static LinearGradient linearGradient() =>
      LinearGradient(begin: Alignment.topCenter, end: Alignment.topCenter, colors: [
        AppColor.primaryColorGradient,
        AppColor.primaryColorGradient2,
      ]);
}

class GradientTextWidget {
  static LinearGradient linearGradient() =>
      LinearGradient( colors: [
        AppColor.colorGreyGradient1,
        AppColor.colorGreyGradient1,
      ],);
}


class GradientWidgetForecast {
  static LinearGradient linearGradient() =>
      LinearGradient(begin: Alignment.topCenter, end: Alignment.topCenter, colors: [
        AppColor.colorForecastGradient,
        AppColor.primaryColorGradient,
      ],stops: [0.1,0.5]);
}

class GradientWidgetToday {
  static LinearGradient linearGradient() =>
      LinearGradient( colors: [
        AppColor.darkGreyGradient1,
        AppColor.darkGreyGradient2,
      ]);
}