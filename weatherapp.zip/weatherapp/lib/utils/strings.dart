class Strings {
  static const String textSkip = 'Skip';
  static const String onboardingTitle = 'Detailed Hourly Forecast';
  static const String onboardingSubTitle = 'Get in - depth weather information.';
  static const String onboardingTitle2 = 'Real-Time Weather Map';
  static const String onboardingSubTitle2 =
      'Watch the progress of the precipitation to stay informed';
  static const String onboardingTitle3 = 'Weather Around the World';
  static const String onboardingSubTitle3 = 'Add any location you want and swipe easily to change.';
  static const String location = 'Tamil Nadu, Chennai';
  static const String textToday = 'Today';
  static const String textTotal = 'Total';
  static const String textForecast = 'Forecast';
  static const String textPre = 'Precipitation';
  static const String textRadar = 'Radar Sun & Moon';
  static const String textPrecipitations = 'Precipitation: ';
  static const String textPrecipitation = 'Precipitation ';
  static const String text21 = '21%';
  static const String textWind = 'Wind: ';
  static const String text10 = '10 km/h';
  static const String textHumidity = 'Humidity:';
  static const String text59 = '59%';
  static const String textsunset = 'Sunset';
  static const String textSunrise = 'Sunset';
  static const String text29 = '29%';
  static const String textMonday = 'Monday';
  static const String textTuesDay = 'Tuesday';
  static const String textWednesDay = 'Wednesday';
  static const String textThursDay = 'Thursday';
  static const String textFriDay = 'Friday';
  static const String textSaturDay = 'Saturday';
  static const String textSunday = 'Sunday';
  static const String textShow = 'Show More';
  static const String textFeels = 'Feels Like';
  static const String textVisibility = 'Visibility';
  static const String textUV = 'UV Index';
  static const String textDewPoint = 'Dew Point';
  static const String textAir = 'Air Quality';
  static const String textCorona = 'Coronavirus Latest';
  static const String textTamilnadu = 'Tamilnadu Chennai';
  static const String textSunAndMoon = 'Sun & Moon';
  static const String textSunRise = 'Sun Rise';
  static const String textMore = 'More Detail';
  static const String textNotification = 'Notification';
  static const String textSetting = 'Settings';
  static const String texttools = 'Tools';
  static const String textFeedback = 'Send Feedback';
  static const String textRate = 'Rate this app';
  static const String textShare = 'Share your weather';
  static const String textConfirmCase = 'Confirmed Cases';
  static const String textAirNote = 'You have good air quality - enjoy your outdoor activities.';
  static const String textSee = 'See minute-by-minute forecasts';
  static const String textPlan = 'Plan fot the next 5 hours';
  static const String textNote =
      'Tonight - Clear. Winds from SW to SSW at 10 to 11 mph (16.1 to 17.7 kph). The overnight low will be 69° F (20.0 ° C)';

  static const String baseUrl = 'https://api.openweathermap.org/';
  static const String apiKey = "9c4a957eb18fb11a0d5ffc951e6d3281";
}

class ApiConst {
  static const String baseUrl = 'https://api.openweathermap.org/';
}
