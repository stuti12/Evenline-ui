import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:syncfusion_flutter_gauges/gauges.dart';
import 'package:weatherapp/home/controller/today_controller.dart';
import 'package:weatherapp/location_permission_controller/global_controller.dart';
import 'package:weatherapp/utils/custom/seperator.dart';
import 'package:weatherapp/utils/images.dart';
import '../utils/colors.dart';
import '../utils/custom/gradient.dart';
import '../utils/custom/gradient_text.dart';
import '../utils/strings.dart';

class TodayScreen extends StatefulWidget {
  const TodayScreen({Key? key}) : super(key: key);

  @override
  State<TodayScreen> createState() => _TodayScreenState();
}

class _TodayScreenState extends State<TodayScreen>
    with WidgetsBindingObserver, AutomaticKeepAliveClientMixin {
  // final RefreshController _refreshController = RefreshController(initialRefresh: false);
  final TodayScreenController todayScreenController = Get.put(TodayScreenController());
  GetUserLocation globalController = GetUserLocation();

  @override
  void initState() {
    WidgetsBinding.instance.addObserver(this);
    _apiCalls();
    debugPrint('Temp-->${todayScreenController.temp.value}');
    super.initState();
  }

  @override
  bool get wantKeepAlive => true;

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      _apiCalls();
    }
  }

  _apiCalls() {
    globalController.getLocationPermission();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: AppColor.primaryColorGradient2,
        body: RefreshIndicator(
          onRefresh: () async {
            _apiCalls();
          },
          child: Obx(() => todayScreenController.isLoading.value == false
              ? SingleChildScrollView(
                  child: Container(
                    padding: EdgeInsets.symmetric(horizontal: 10.w),
                    decoration: BoxDecoration(gradient: GradientWidget.linearGradient()),
                    child: Column(
                      children: [
                        Column(
                          children: [
                            SizedBox(
                              height: 10.h,
                            ),
                            Container(
                              decoration: BoxDecoration(
                                  color: AppColor.colorTodayScreenBg,
                                  borderRadius: BorderRadius.all(Radius.circular(30.r))),
                              child: Padding(
                                padding: EdgeInsets.symmetric(horizontal: 17.w, vertical: 7.h),
                                child: Text(
                                  DateFormat('EEEE, dd MMM').format(DateTime.now()),
                                  style: TextStyle(
                                      color: AppColor.colorTodayScreenText, fontFamily: 'Poppins'),
                                ),
                              ),
                            ),

                            //temprature
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceAround,
                              children: [
                                Obx(
                                  () => todayScreenController.weatherList.isNotEmpty
                                      ? Image.network(
                                          'https://openweathermap.org/img/wn/${todayScreenController.weatherList[0].icon}@2x.png',
                                        )
                                      : Image.asset(
                                          AppImage.imgTodayWeather,
                                          fit: BoxFit.fill,
                                        ),
                                ),
                                Obx(() => Column(
                                      children: [
                                        GradientText(
                                            '${(todayScreenController.temp.value).toStringAsFixed(0)}${'\u00B0'}',
                                            style: TextStyle(
                                                fontWeight: FontWeight.bold,
                                                fontFamily: 'Poppins',
                                                fontSize: 54.sp,
                                                shadows: [
                                                  Shadow(
                                                      blurRadius: 2.r,
                                                      color: AppColor.transparentColor)
                                                ]),
                                            gradient: LinearGradient(colors: [
                                              AppColor.colorGreyGradient1,
                                              AppColor.colorGreyGradient2
                                            ])),
                                        todayScreenController.weatherList.isNotEmpty
                                            ? Text(
                                                todayScreenController.weatherList[0].description
                                                    .toString(),
                                                style: TextStyle(
                                                    fontWeight: FontWeight.w400,
                                                    color: AppColor.colorWhite,
                                                    fontFamily: 'Poppins'),
                                              )
                                            : Text(
                                                "NA",
                                                style: TextStyle(
                                                    fontWeight: FontWeight.w400,
                                                    color: AppColor.colorWhite,
                                                    fontFamily: 'Poppins'),
                                              )
                                      ],
                                    ))
                              ],
                            ),
                            SizedBox(
                              height: 10.h,
                            ),
                            Row(
                              children: [
                                Obx(
                                  () => RichText(
                                    text:
                                        todayScreenController.weeklyWeatherListFilter?.isNotEmpty ==
                                                true
                                            ? TextSpan(
                                                text:
                                                    '${((todayScreenController.weeklyWeatherListFilter?[0].main?.tempMax) - 273.15).toStringAsFixed(0)}${'\u00B0'}/${((todayScreenController.weeklyWeatherListFilter?[0].main?.tempMin ?? 0) - 273.15).toStringAsFixed(0)}${'\u00B0'} ',
                                                style: TextStyle(
                                                    fontFamily: 'Poppins',
                                                    fontWeight: FontWeight.w400,
                                                    fontSize: 12.sp,
                                                    color: AppColor.colorTodayScreenText),
                                              )
                                            : TextSpan(
                                                text: 'NA/NA',
                                                style: TextStyle(
                                                    fontFamily: 'Poppins',
                                                    fontWeight: FontWeight.w400,
                                                    fontSize: 12.sp,
                                                    color: AppColor.colorTodayScreenText),
                                              ),
                                  ),
                                ),
                                Obx(
                                  () => RichText(
                                      text: TextSpan(
                                          text: ' | Feels like ',
                                          style: TextStyle(
                                              fontFamily: 'Poppins',
                                              fontWeight: FontWeight.w400,
                                              fontSize: 12.sp,
                                              color: AppColor.colorTodayScreenText),
                                          children: [
                                        TextSpan(
                                            text:
                                                '${((todayScreenController.feels.value) - 273.15).toStringAsFixed(0)}${'\u00B0'}C',
                                            style: TextStyle(
                                                fontFamily: 'Poppins',
                                                fontWeight: FontWeight.w400,
                                                fontSize: 12.sp,
                                                color: AppColor.colorWhite))
                                      ])),
                                ),
                                const Spacer(),
                                Text(
                                  '|',
                                  style: TextStyle(color: AppColor.colorTodayScreenText),
                                ),
                                const Spacer(),
                                Obx(() => RichText(
                                      text: TextSpan(
                                          text: 'Wind ',
                                          style: TextStyle(
                                              fontFamily: 'Poppins',
                                              fontWeight: FontWeight.w500,
                                              fontSize: 12.sp,
                                              color: AppColor.colorTodayScreenText),
                                          children: <TextSpan>[
                                            TextSpan(
                                              text:
                                                  '${todayScreenController.wind.value.toString()} km',
                                              style: TextStyle(
                                                  fontFamily: 'Poppins',
                                                  fontWeight: FontWeight.w400,
                                                  fontSize: 12.sp,
                                                  color: AppColor.colorWhite),
                                            ),
                                            TextSpan(
                                              text: '/ H WSW',
                                              style: TextStyle(
                                                  fontFamily: 'Poppins',
                                                  fontWeight: FontWeight.w400,
                                                  fontSize: 12.sp,
                                                  color: AppColor.colorTodayScreenText),
                                            ),
                                          ]),
                                    )),
                              ],
                            ),
                            SizedBox(
                              height: 16.h,
                            ),
                            Padding(
                              padding: EdgeInsets.symmetric(horizontal: 16.w),
                              child: MySeparator(
                                height: 1.h,
                                color: AppColor.colorTodayScreenText,
                              ),
                            ),
                            SizedBox(
                              height: 16.h,
                            ),
                            //precipitation
                            Padding(
                              padding: EdgeInsets.symmetric(horizontal: 8.w),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Expanded(
                                    child: Row(
                                      children: [
                                        Image.asset(
                                          AppImage.imgPrecipitation,
                                          width: 30.w,
                                          height: 30.w,
                                        ),
                                        SizedBox(
                                          width: 5.w,
                                        ),
                                        RichText(
                                          text: TextSpan(
                                              text: Strings.textPrecipitations,
                                              style: TextStyle(
                                                  fontFamily: 'Poppins',
                                                  fontWeight: FontWeight.w500,
                                                  fontSize: 12.sp,
                                                  color: AppColor.colorTodayScreenText),
                                              children: <TextSpan>[
                                                TextSpan(
                                                  text: 'NA',
                                                  style: TextStyle(
                                                      fontFamily: 'Poppins',
                                                      fontWeight: FontWeight.w400,
                                                      fontSize: 12.sp,
                                                      color: AppColor.colorWhite),
                                                ),
                                              ]),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Row(
                                    children: [
                                      Image.asset(
                                        AppImage.imgRainy,
                                        width: 20.w,
                                        height: 20.w,
                                      ),
                                      SizedBox(
                                        width: 5.w,
                                      ),
                                      Obx(
                                        () => RichText(
                                          text: TextSpan(
                                              text: Strings.textHumidity,
                                              style: TextStyle(
                                                  fontFamily: 'Poppins',
                                                  fontWeight: FontWeight.w500,
                                                  fontSize: 12.sp,
                                                  color: AppColor.colorTodayScreenText),
                                              children: <TextSpan>[
                                                TextSpan(
                                                  text: ' ${todayScreenController.humidity.value}'
                                                      '%',
                                                  style: TextStyle(
                                                      fontFamily: 'Poppins',
                                                      fontWeight: FontWeight.w400,
                                                      fontSize: 12.sp,
                                                      color: AppColor.colorWhite),
                                                ),
                                              ]),
                                        ),
                                      )
                                    ],
                                  ),
                                ],
                              ),
                            ),
                            SizedBox(
                              height: 10.h,
                            ),
                            //wind
                            Padding(
                              padding: EdgeInsets.symmetric(horizontal: 8.w),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Row(
                                    children: [
                                      Image.asset(
                                        AppImage.imgSun,
                                        width: 30.w,
                                        height: 30.w,
                                      ),
                                      SizedBox(
                                        width: 5.w,
                                      ),
                                      Obx(() => RichText(
                                            overflow: TextOverflow.ellipsis,
                                            text: TextSpan(
                                                text: Strings.textWind,
                                                style: TextStyle(
                                                    fontFamily: 'Poppins',
                                                    fontWeight: FontWeight.w500,
                                                    fontSize: 12.sp,
                                                    color: AppColor.colorTodayScreenText),
                                                children: <TextSpan>[
                                                  TextSpan(
                                                    text:
                                                        '${todayScreenController.wind.value.toString()}'
                                                        'km/h',
                                                    style: TextStyle(
                                                        fontFamily: 'Poppins',
                                                        fontWeight: FontWeight.w400,
                                                        fontSize: 12.sp,
                                                        color: AppColor.colorWhite),
                                                  ),
                                                ]),
                                          ))
                                    ],
                                  ),
                                  Row(
                                    children: [
                                      Image.asset(
                                        AppImage.imgMoon,
                                        width: 30.w,
                                        height: 30.w,
                                      ),
                                      SizedBox(
                                        width: 5.w,
                                      ),
                                      Obx(
                                        () => RichText(
                                          text: TextSpan(
                                              text: '${Strings.textsunset}: ',
                                              style: TextStyle(
                                                  fontFamily: 'Poppins',
                                                  fontWeight: FontWeight.w500,
                                                  fontSize: 12.sp,
                                                  color: AppColor.colorTodayScreenText),
                                              children: <TextSpan>[
                                                TextSpan(
                                                  text:
                                                      '${(DateTime.now().hour * 100 / DateTime.fromMillisecondsSinceEpoch(todayScreenController.sunset.value * 1000).hour).toStringAsFixed(0)}'
                                                      '${'%'}',
                                                  style: TextStyle(
                                                      fontFamily: 'Poppins',
                                                      fontWeight: FontWeight.w400,
                                                      fontSize: 12.sp,
                                                      color: AppColor.colorWhite),
                                                ),
                                              ]),
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                            SizedBox(
                              height: 20.h,
                            ),
                            SizedBox(
                              height: 120.h,
                              child: Obx(() => todayScreenController
                                          .dailyWeathersList?.isNotEmpty ==
                                      true
                                  ? ListView.builder(
                                      shrinkWrap: true,
                                      scrollDirection: Axis.horizontal,
                                      itemCount: todayScreenController.dailyWeathersList?.length,
                                      itemBuilder: (context, int index) {
                                        return temperaturesData(index: index);
                                      })
                                  : Text(
                                      "NA",
                                      style: TextStyle(
                                          fontWeight: FontWeight.w400,
                                          color: AppColor.colorWhite,
                                          fontFamily: 'Poppins'),
                                    )),
                            ),
                            SizedBox(
                              height: 14.h,
                            ),
                          ],
                        ),
                        //expand container
                        Container(
                          margin: EdgeInsets.symmetric(vertical: 4.h),
                          decoration: BoxDecoration(
                              gradient: GradientWidgetToday.linearGradient(),
                              borderRadius: BorderRadius.all(Radius.circular(10.r))),
                          child: Column(
                            children: [
                              SizedBox(
                                height: 20.h,
                              ),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.end,
                                children: [
                                  SizedBox(
                                    width: 20.w,
                                  ),
                                  Text(
                                    'High',
                                    style: TextStyle(
                                        fontFamily: 'Poppins',
                                        color: AppColor.colorTodayScreenText,
                                        fontWeight: FontWeight.w400),
                                  ),
                                  SizedBox(
                                    width: 10.w,
                                  ),
                                  Text(
                                    '|',
                                    style: TextStyle(
                                        fontFamily: 'Poppins',
                                        color: AppColor.colorTodayScreenText,
                                        fontWeight: FontWeight.w400),
                                  ),
                                  SizedBox(
                                    width: 10.w,
                                  ),
                                  Text(
                                    'Low',
                                    style: TextStyle(
                                        fontFamily: 'Poppins',
                                        color: AppColor.colorTodayScreenText,
                                        fontWeight: FontWeight.w400),
                                  ),
                                  SizedBox(
                                    width: 20.w,
                                  ),
                                ],
                              ),
                              Obx(() => todayScreenController.weeklyWeatherListFilter?.isNotEmpty ==
                                      true
                                  ? ListView.builder(
                                      physics: const ClampingScrollPhysics(),
                                      padding: EdgeInsets.zero,
                                      itemCount:
                                          todayScreenController.weeklyWeatherListFilter?.length,
                                      shrinkWrap: true,
                                      itemBuilder: (context, int weatherIndex) {
                                        return ListTileTheme(
                                          horizontalTitleGap: 0.0,
                                          dense: true,
                                          child: ExpansionTile(
                                              controlAffinity: ListTileControlAffinity.leading,
                                              iconColor: AppColor.colorWhite,
                                              collapsedIconColor: AppColor.colorWhite,
                                              textColor: AppColor.colorWhite,
                                              title: Row(
                                                mainAxisAlignment: MainAxisAlignment.spaceAround,
                                                children: [
                                                  SizedBox(
                                                    width: 0.3.sw,
                                                    child: Obx(
                                                      () => Text(
                                                        DateFormat('EEEE').format(
                                                            DateFormat("yyyy-MM-DD").parse(
                                                                '${(todayScreenController.weeklyWeatherListFilter?[weatherIndex].dtTxt)?.substring(0, 10)}')),
                                                        style: TextStyle(
                                                            fontSize: 13.sp,
                                                            fontFamily: 'Poppins',
                                                            fontWeight: FontWeight.w500,
                                                            color: AppColor.colorWhite),
                                                      ),
                                                    ),
                                                  ),
                                                  Obx(() => todayScreenController
                                                              .weeklyWeatherListFilter?[
                                                                  weatherIndex]
                                                              .weather?[0]
                                                              .icon !=
                                                          null
                                                      ? Image.network(
                                                          'https://openweathermap.org/img/wn/${todayScreenController.weeklyWeatherListFilter?[weatherIndex].weather?[0].icon}@2x.png',
                                                          height: 40.h,
                                                        )
                                                      : Image.asset(AppImage.iconCloud)),
                                                  Obx(() => Text(
                                                        '${((todayScreenController.weeklyWeatherListFilter?[weatherIndex].main?.tempMax ?? 0) - 273.15).toStringAsFixed(0)}${"\u00B0"}',
                                                        style: TextStyle(
                                                            color: AppColor.colorWhite,
                                                            fontSize: 12.sp,
                                                            fontFamily: 'Poppins',
                                                            fontWeight: FontWeight.w600),
                                                        overflow: TextOverflow.ellipsis,
                                                      )),
                                                  Obx(() => Text(
                                                        '${((todayScreenController.weeklyWeatherListFilter?[weatherIndex].main?.tempMin ?? 0) - 273.15).toStringAsFixed(0)}${"\u00B0"}',
                                                        style: TextStyle(
                                                            color: AppColor.colorWhite,
                                                            fontSize: 12.sp,
                                                            fontFamily: 'Poppins',
                                                            fontWeight: FontWeight.w600),
                                                        overflow: TextOverflow.ellipsis,
                                                      )),
                                                ],
                                              ),
                                              children: [
                                                Container(
                                                    margin: EdgeInsets.only(bottom: 8.h),
                                                    height: 120.h,
                                                    child: ListView.builder(
                                                        shrinkWrap: false,
                                                        physics: const BouncingScrollPhysics(),
                                                        scrollDirection: Axis.horizontal,
                                                        itemCount: todayScreenController
                                                            .hourList[weatherIndex].length,
                                                        itemBuilder: (context, int hourIndex) {
                                                          return weatherDetail(
                                                              dayIndex: weatherIndex,
                                                              hourIndex: hourIndex);
                                                        })),
                                              ]),
                                        );
                                      })
                                  : Text(
                                      "NA",
                                      style: TextStyle(
                                          fontWeight: FontWeight.w400,
                                          color: AppColor.colorWhite,
                                          fontFamily: 'Poppins'),
                                    ))
                            ],
                          ),
                        ),
                        SizedBox(
                          height: 10.h,
                        ),
//DETails
                        Container(
                          padding: EdgeInsets.symmetric(horizontal: 14.w),
                          decoration: BoxDecoration(
                              gradient: GradientWidgetToday.linearGradient(),
                              borderRadius: BorderRadius.all(Radius.circular(10.r))),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              SizedBox(
                                height: 10.h,
                              ),
                              Text(
                                'Details',
                                style: TextStyle(
                                    fontWeight: FontWeight.w600,
                                    fontFamily: 'Poppins',
                                    fontSize: 14.sp,
                                    color: AppColor.colorWhite),
                              ),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                children: [
                                  Obx(() => todayScreenController.weatherList.isNotEmpty
                                      ? Image.network(
                                          'https://openweathermap.org/img/wn/${todayScreenController.weatherList[0].icon}@2x.png',
                                          width: 0.4.sw,
                                        )
                                      : Image.asset(
                                          AppImage.iconCloud,
                                          height: 30.h,
                                        )),
                                  Expanded(
                                    child: Padding(
                                      padding: EdgeInsets.only(right: 20.w),
                                      child: Column(
                                        children: [
                                          Row(
                                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                            children: [
                                              Text(
                                                Strings.textFeels,
                                                style: TextStyle(
                                                    fontWeight: FontWeight.w400,
                                                    fontFamily: 'Poppins',
                                                    fontSize: 13.sp,
                                                    color: AppColor.colorTodayScreenText),
                                              ),
                                              Obx(() => Text(
                                                    '${(todayScreenController.feels.value - 273.15).toStringAsFixed(0)}${'\u00B0'}',
                                                    style: TextStyle(
                                                        fontWeight: FontWeight.w400,
                                                        fontFamily: 'Poppins',
                                                        fontSize: 13.sp,
                                                        color: AppColor.colorWhite),
                                                  ))
                                            ],
                                          ),
                                          SizedBox(
                                            height: 10.h,
                                          ),
                                          Row(
                                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                            children: [
                                              Text(
                                                Strings.textHumidity,
                                                style: TextStyle(
                                                    fontWeight: FontWeight.w400,
                                                    fontFamily: 'Poppins',
                                                    fontSize: 13.sp,
                                                    color: AppColor.colorTodayScreenText),
                                              ),
                                              Obx(() => Text(
                                                    ' ${todayScreenController.humidity.value}'
                                                    '%',
                                                    style: TextStyle(
                                                        fontWeight: FontWeight.w400,
                                                        fontFamily: 'Poppins',
                                                        fontSize: 13.sp,
                                                        color: AppColor.colorWhite),
                                                  )),
                                            ],
                                          ),
                                          SizedBox(
                                            height: 10.h,
                                          ),
                                          Row(
                                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                            children: [
                                              Text(
                                                Strings.textVisibility,
                                                style: TextStyle(
                                                    fontWeight: FontWeight.w400,
                                                    fontFamily: 'Poppins',
                                                    fontSize: 13.sp,
                                                    color: AppColor.colorTodayScreenText),
                                              ),
                                              Obx(
                                                () => Text(
                                                  '${todayScreenController.visibility.value} ${'km'}',
                                                  style: TextStyle(
                                                      fontWeight: FontWeight.w400,
                                                      fontFamily: 'Poppins',
                                                      fontSize: 13.sp,
                                                      color: AppColor.colorWhite),
                                                ),
                                              ),
                                            ],
                                          ),
                                          SizedBox(
                                            height: 10.h,
                                          ),
                                          Row(
                                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                            children: [
                                              Text(
                                                Strings.textUV,
                                                style: TextStyle(
                                                    fontWeight: FontWeight.w400,
                                                    fontFamily: 'Poppins',
                                                    fontSize: 13.sp,
                                                    color: AppColor.colorTodayScreenText),
                                              ),
                                              Text(
                                                'NA',
                                                style: TextStyle(
                                                    fontWeight: FontWeight.w400,
                                                    fontFamily: 'Poppins',
                                                    fontSize: 13.sp,
                                                    color: AppColor.colorWhite),
                                              ),
                                            ],
                                          ),
                                          SizedBox(
                                            height: 10.h,
                                          ),
                                          Row(
                                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                            children: [
                                              Text(
                                                Strings.textDewPoint,
                                                style: TextStyle(
                                                    fontWeight: FontWeight.w400,
                                                    fontFamily: 'Poppins',
                                                    fontSize: 13.sp,
                                                    color: AppColor.colorTodayScreenText),
                                              ),
                                              Text(
                                                'NA',
                                                style: TextStyle(
                                                    fontWeight: FontWeight.w400,
                                                    fontFamily: 'Poppins',
                                                    fontSize: 13.sp,
                                                    color: AppColor.colorWhite),
                                              ),
                                            ],
                                          ),
                                        ],
                                      ),
                                    ),
                                  )
                                ],
                              ),
                              SizedBox(
                                height: 20.h,
                              ),
                              Text(
                                Strings.textNote,
                                style: TextStyle(
                                    fontFamily: 'Poppins',
                                    color: AppColor.colorTodayScreenText,
                                    fontSize: 12.sp),
                              ),
                              SizedBox(
                                height: 20.h,
                              )
                            ],
                          ),
                        ),
                        SizedBox(
                          height: 10.h,
                        ),

                        //air
                        Container(
                          padding: EdgeInsets.symmetric(horizontal: 14.w),
                          decoration: BoxDecoration(
                              gradient: GradientWidgetToday.linearGradient(),
                              borderRadius: BorderRadius.all(Radius.circular(10.r))),
                          child: Column(
                            children: [
                              Row(
                                children: [
                                  SizedBox(
                                    height: 10.h,
                                  ),
                                  Text(
                                    Strings.textAir,
                                    style: TextStyle(
                                        fontWeight: FontWeight.w600,
                                        fontFamily: 'Poppins',
                                        fontSize: 14.sp,
                                        color: AppColor.colorWhite),
                                  ),
                                  Expanded(
                                    child: Align(
                                        alignment: Alignment.topRight,
                                        child: IconButton(
                                            onPressed: () {},
                                            icon: Icon(
                                              Icons.info_outline,
                                              color: AppColor.colorWhite,
                                            ))),
                                  )
                                ],
                              ),
                              SizedBox(
                                height: 10.h,
                              ),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                children: [
                                  SizedBox(
                                    height: 80.h,
                                    width: 0.3.sw,
                                    child: SfRadialGauge(axes: <RadialAxis>[
                                      RadialAxis(
                                        annotations: [
                                          GaugeAnnotation(
                                            positionFactor: 0.1,
                                            angle: 90,
                                            widget: RichText(
                                              textAlign: TextAlign.center,
                                              text: TextSpan(
                                                  text: '31\n',
                                                  style: TextStyle(
                                                      fontFamily: 'Poppins',
                                                      fontWeight: FontWeight.w500,
                                                      fontSize: 18.sp,
                                                      color: AppColor.colorWhite),
                                                  children: <TextSpan>[
                                                    TextSpan(
                                                      text: 'Moderate',
                                                      style: TextStyle(
                                                          fontFamily: 'Poppins',
                                                          fontWeight: FontWeight.w400,
                                                          fontSize: 10.sp,
                                                          color: AppColor.colorWhite),
                                                    ),
                                                  ]),
                                            ),
                                          )
                                        ],
                                        minimum: 0,
                                        maximum: 100,
                                        showLabels: false,
                                        showTicks: false,
                                        axisLineStyle: AxisLineStyle(
                                          thickness: 0.1,
                                          cornerStyle: CornerStyle.bothCurve,
                                          color: const Color(0xFFFE1D1D),
                                          gradient: SweepGradient(colors: <Color>[
                                            AppColor.colorProgressGradient,
                                            AppColor.colorProgressGradient2,
                                            AppColor.colorProgressGradient4,
                                            AppColor.colorGrey,
                                          ], stops: const <double>[
                                            0.15,
                                            0.20,
                                            0.60,
                                            0.80
                                          ]),
                                          thicknessUnit: GaugeSizeUnit.factor,
                                        ),
                                      )
                                    ]),
                                  ),
                                  Expanded(
                                    child: Text(
                                      Strings.textAirNote,
                                      style: TextStyle(
                                          fontFamily: 'Poppins',
                                          color: AppColor.colorTodayScreenText,
                                          fontSize: 12.sp),
                                    ),
                                  )
                                ],
                              ),
                              SizedBox(
                                height: 20.h,
                              ),
                              MySeparator(
                                height: 0.5.h,
                                color: AppColor.colorTodayScreenText,
                              ),
                              SizedBox(
                                height: 10.h,
                              ),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  RichText(
                                    text: TextSpan(
                                        text: 'US EPA AQI ',
                                        style: TextStyle(
                                            fontFamily: 'Poppins',
                                            fontWeight: FontWeight.w500,
                                            fontSize: 12.sp,
                                            color: AppColor.colorTodayScreenText),
                                        children: <TextSpan>[
                                          TextSpan(
                                            text: 'NA',
                                            style: TextStyle(
                                                fontFamily: 'Poppins',
                                                fontWeight: FontWeight.w400,
                                                fontSize: 12.sp,
                                                color: AppColor.colorWhite),
                                          ),
                                        ]),
                                  ),
                                  RichText(
                                    text: TextSpan(
                                        text: 'Dominant poppulant',
                                        style: TextStyle(
                                            fontFamily: 'Poppins',
                                            fontWeight: FontWeight.w500,
                                            fontSize: 12.sp,
                                            color: AppColor.colorTodayScreenText),
                                        children: <TextSpan>[
                                          TextSpan(
                                            text: ' PM 10',
                                            style: TextStyle(
                                                fontFamily: 'Poppins',
                                                fontWeight: FontWeight.w400,
                                                fontSize: 12.sp,
                                                color: AppColor.colorWhite),
                                          ),
                                        ]),
                                  ),
                                ],
                              ),
                              SizedBox(
                                height: 20.h,
                              )
                            ],
                          ),
                        ),
                        SizedBox(
                          height: 20.h,
                        ),

//corona
                        Container(
                          padding: EdgeInsets.symmetric(horizontal: 14.w),
                          decoration: BoxDecoration(
                              gradient: GradientWidgetToday.linearGradient(),
                              borderRadius: BorderRadius.all(Radius.circular(10.r))),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  SizedBox(
                                    height: 10.h,
                                  ),
                                  Text(
                                    Strings.textCorona,
                                    style: TextStyle(
                                        fontWeight: FontWeight.w600,
                                        fontFamily: 'Poppins',
                                        fontSize: 14.sp,
                                        color: AppColor.colorWhite),
                                  ),
                                  Expanded(
                                    child: Align(
                                        alignment: Alignment.topRight,
                                        child: IconButton(
                                            onPressed: () {},
                                            icon: Icon(
                                              Icons.more_horiz,
                                              color: AppColor.colorWhite,
                                            ))),
                                  )
                                ],
                              ),
                              SizedBox(
                                height: 4.h,
                              ),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Obx(() => Text(
                                              todayScreenController.city.value,
                                              style: TextStyle(
                                                  fontFamily: 'Poppins',
                                                  fontWeight: FontWeight.w500,
                                                  color: AppColor.colorTodayScreenText,
                                                  fontSize: 13.sp),
                                            )),
                                        SizedBox(
                                          height: 4.h,
                                        ),
                                        Text(
                                          Strings.textConfirmCase,
                                          style: TextStyle(
                                              fontWeight: FontWeight.w500,
                                              fontFamily: 'Poppins',
                                              fontSize: 13.sp,
                                              color: AppColor.colorWhite),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Column(
                                    children: [
                                      Text(
                                        Strings.textToday,
                                        style: TextStyle(
                                            fontWeight: FontWeight.w400,
                                            fontFamily: 'Poppins',
                                            fontSize: 13.sp,
                                            color: AppColor.colorTodayScreenText),
                                      ),
                                      SizedBox(
                                        height: 10.h,
                                      ),
                                      Container(
                                        decoration: BoxDecoration(
                                            color: AppColor.colorTodayScreenBg,
                                            borderRadius: BorderRadius.all(Radius.circular(4.r))),
                                        child: Padding(
                                          padding: EdgeInsets.only(
                                              left: 8.w, right: 8.w, top: 2.h, bottom: 6.h),
                                          child: Text(
                                            textAlign: TextAlign.center,
                                            '56676767',
                                            style: TextStyle(
                                                color: AppColor.colorTodayScreenText,
                                                fontFamily: 'Poppins'),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                  SizedBox(
                                    width: 10.w,
                                  ),
                                  Column(
                                    children: [
                                      Text(
                                        Strings.textTotal,
                                        style: TextStyle(
                                            fontWeight: FontWeight.w400,
                                            fontFamily: 'Poppins',
                                            fontSize: 13.sp,
                                            color: AppColor.colorTodayScreenText),
                                      ),
                                      SizedBox(
                                        height: 10.h,
                                      ),
                                      Container(
                                        decoration: BoxDecoration(
                                            color: AppColor.colorRed,
                                            borderRadius: BorderRadius.all(Radius.circular(4.r))),
                                        child: Padding(
                                          padding: EdgeInsets.only(
                                              left: 8.w, right: 8.w, top: 2.h, bottom: 6.h),
                                          child: Text(
                                            textAlign: TextAlign.center,
                                            '56676767',
                                            style: TextStyle(
                                                color: AppColor.colorTodayScreenText,
                                                fontFamily: 'Poppins'),
                                          ),
                                        ),
                                      ),
                                    ],
                                  )
                                ],
                              ),
                              SizedBox(
                                height: 20.h,
                              ),
                              MySeparator(
                                height: 0.5.h,
                                color: AppColor.colorTodayScreenText,
                              ),
                              SizedBox(
                                height: 10.h,
                              ),
                              Wrap(
                                crossAxisAlignment: WrapCrossAlignment.start,
                                children: [
                                  Text(
                                    'More Detail',
                                    style: TextStyle(
                                        fontSize: 13.sp,
                                        fontFamily: 'Poppins',
                                        color: AppColor.colorWhite),
                                  ),
                                  InkWell(
                                      onTap: () {},
                                      child: const Icon(
                                        Icons.keyboard_arrow_down,
                                        color: Colors.white,
                                      )),
                                ],
                              )
                            ],
                          ),
                        ),

                        SizedBox(
                          height: 10.h,
                        ),
                        //Sun

                        Container(
                          padding: EdgeInsets.symmetric(horizontal: 14.w),
                          decoration: BoxDecoration(
                              gradient: GradientWidgetToday.linearGradient(),
                              borderRadius: BorderRadius.all(Radius.circular(10.r))),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              SizedBox(
                                height: 10.h,
                              ),
                              Text(
                                Strings.textSunAndMoon,
                                style: TextStyle(
                                    fontWeight: FontWeight.w600,
                                    fontFamily: 'Poppins',
                                    fontSize: 14.sp,
                                    color: AppColor.colorWhite),
                              ),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Column(
                                    children: [
                                      Obx(() => Text(
                                            ('${DateFormat.Hm().format(
                                              DateTime.fromMillisecondsSinceEpoch(
                                                  todayScreenController.sunrise.value * 1000),
                                            )} ${'AM'}'),
                                            style: TextStyle(
                                                fontFamily: 'Poppins',
                                                fontWeight: FontWeight.w500,
                                                color: AppColor.colorWhite,
                                                fontSize: 14.sp),
                                          )),
                                      SizedBox(
                                        height: 6.h,
                                      ),
                                      Text(
                                        Strings.textSunRise,
                                        style: TextStyle(
                                            fontWeight: FontWeight.w500,
                                            fontFamily: 'Poppins',
                                            fontSize: 12.sp,
                                            color: AppColor.colorTodayScreenText),
                                      ),
                                    ],
                                  ),

                                  Padding(
                                    padding: EdgeInsets.only(top: 16.h),
                                    child: Stack(children: [
                                      SizedBox(
                                        height: 70.h,
                                        width: 0.2.sw,
                                        child: SfRadialGauge(axes: <RadialAxis>[
                                          RadialAxis(
                                            showLabels: false,
                                            showTicks: false,
                                            axisLineStyle: AxisLineStyle(
                                              thickness: 0.03,
                                              color: AppColor.colorTodayScreenText,
                                              thicknessUnit: GaugeSizeUnit.factor,
                                            ),
                                            startAngle: 180,
                                            endAngle: 360,
                                          ),
                                        ]),
                                      ),
                                      Positioned(
                                          top: 0.h,
                                          right: 0.w,
                                          child: Image.asset(
                                            AppImage.imgIconSun,
                                            height: 24.h,
                                          ))
                                    ]),
                                  ),
                                  // CircularBorder(width: 1.r,size: 45.h,),
                                  Column(
                                    children: [
                                      Obx(() => Text(
                                            ('${DateFormat.Hm().format(
                                              DateTime.fromMillisecondsSinceEpoch(
                                                  todayScreenController.sunset.value * 1000),
                                            )} ${'PM'}'),
                                            style: TextStyle(
                                                fontFamily: 'Poppins',
                                                fontWeight: FontWeight.w500,
                                                color: AppColor.colorWhite,
                                                fontSize: 14.sp),
                                          )),
                                      SizedBox(
                                        height: 6.h,
                                      ),
                                      Text(
                                        Strings.textsunset,
                                        style: TextStyle(
                                            fontWeight: FontWeight.w500,
                                            fontFamily: 'Poppins',
                                            fontSize: 12.sp,
                                            color: AppColor.colorTodayScreenText),
                                      ),
                                    ],
                                  ),
                                ],
                              )
                            ],
                          ),
                        ),
                        SizedBox(
                          height: 20.h,
                        )
                      ],
                    ),
                  ),
                )
              : Center(
                  child: CircularProgressIndicator(
                  color: AppColor.primaryColorGradient,
                ))),
        ));
  }

  Widget temperaturesData({required int index}) {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 8.w),
      padding: EdgeInsets.symmetric(horizontal: 8.w),
      decoration: BoxDecoration(
          color: AppColor.darkGreyGradient2, borderRadius: BorderRadius.all(Radius.circular(30.r))),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          Obx(() => todayScreenController.dailyWeathersList?[index].dtTxt?.isNotEmpty == true
              ? Text(
                  todayScreenController.dailyWeathersList?[index].dtTxt?.substring(11, 16) ?? "",
                  style: TextStyle(
                      fontSize: 12.sp, color: AppColor.colorTodayScreenText, fontFamily: 'Poppins'),
                )
              : const Text('')),
          Obx(() => todayScreenController.dailyWeathersList?[index].weather?.isNotEmpty == true
              ? Image.network(
                  'https://openweathermap.org/img/wn/${todayScreenController.dailyWeathersList?[index].weather?[0].icon}@2x.png',
                  height: 30.h,
                  width: 30.w,
                )
              : Image.asset('')),
          Obx(
            () => todayScreenController.dailyWeathersList?[index].main?.temp != null
                ? Text(
                    '${((todayScreenController.dailyWeathersList?[index].main?.temp ?? 0.0) - 273.15).toStringAsFixed(0)} ${"\u00B0C"}',
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: 14.sp,
                        fontWeight: FontWeight.w600,
                        fontFamily: 'Poppins-Bold.ttf'),
                  )
                : const Text(''),
          ),
        ],
      ),
    );
  }

  Widget weatherDetail({required int dayIndex, required int hourIndex}) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 6.w),
      margin: EdgeInsets.symmetric(horizontal: 10.w),
      decoration: BoxDecoration(
          color: AppColor.colorTodayScreenBg, borderRadius: BorderRadius.all(Radius.circular(8.r))),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          Image.network(
            'https://openweathermap.org/img/wn/${todayScreenController.hourList[dayIndex][hourIndex].weather?[0].icon}@2x.png',
            height: 40.h,
          ),
          Text(
            '${((todayScreenController.hourList[dayIndex][hourIndex].main?.temp) - 273.15).toStringAsFixed(0)}${'\u00B0'}',
            style: TextStyle(
                color: AppColor.colorWhite,
                fontSize: 12.sp,
                fontFamily: 'Poppins',
                fontWeight: FontWeight.w600),
          ),
          Text(
            DateFormat('hh a').format(DateTime.parse(DateFormat("HH")
                .parse((todayScreenController.hourList[dayIndex][hourIndex].dtTxt
                        ?.substring(11, 13)) ??
                    '')
                .toString())),
            style: TextStyle(
                color: AppColor.colorWhite,
                fontSize: 12.sp,
                fontFamily: 'Poppins',
                fontWeight: FontWeight.w600),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    super.dispose();
    WidgetsBinding.instance.removeObserver(this);
  }
}
