import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:geocoding/geocoding.dart';
import 'package:geolocator/geolocator.dart' hide Location;
import 'package:get/get.dart';
import 'package:weatherapp/model/weekly_weather.dart';

import '../../network/dio/base_service.dart';
import '../../utils/strings.dart';

class ForecastController extends GetxController {
  var isLoading = true.obs;
  var longitude = 0.0.obs;
  var latitude = 0.0.obs;

  List<WeeklyWeatherList>? weeklyWeatherList = <WeeklyWeatherList>[].obs;
  List<WeeklyWeatherList>? weeklyWeatherListFilter = <WeeklyWeatherList>[].obs;
  List<WeeklyWeatherList>? weeklyWeatherForecastListFilter = <WeeklyWeatherList>[].obs;

  BaseService service = BaseService();

  @override
  void onInit() {
    super.onInit();
  }

  Future _getLocation() async {
    Position position = await getCurrentLoc();
    List placemarks = await placemarkFromCoordinates(latitude.value, longitude.value);
    Placemark place = placemarks[0];
    String lCity = '${place.locality},${place.administrativeArea}';
    return lCity;
  }

  Future getCurrentLoc() async {
    Position position = await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.best);
    latitude.value = position.latitude;
    longitude.value = position.longitude;
    debugPrint("--long${longitude.toString()}");
    debugPrint("--lat${latitude.toString()}");
    return position;
  }

  Future<WeeklyWeather> buildWeeklyWeatherForecast() async {
    String lCity = await _getLocation();

    var result = await service.request(
        "${ApiConst.baseUrl}data/2.5/forecast?lat=${latitude.value}&lon=${longitude.value}&cnt=40&appid=${BaseService.apiKey}");
    var weeklyWeatherData = WeeklyWeather.fromJson(result.data);
    debugPrint('->20/12 list${jsonEncode(weeklyWeatherData.list)}');
    weeklyWeatherList?.clear();
    for (var i in weeklyWeatherData.list!) {
      weeklyWeatherList?.add(i);
    }
    debugPrint('-->20/12 length${weeklyWeatherList?.length}');

    var dateFilter = weeklyWeatherData.list!;

    weeklyWeatherListFilter?.clear();
    for (var i = 0; i < dateFilter.length; i++) {
      if (weeklyWeatherListFilter != null && weeklyWeatherListFilter!.isNotEmpty) {
        if (weeklyWeatherListFilter?.last.dtTxt?.substring(0, 10) !=
            dateFilter[i].dtTxt?.substring(0, 10)) {
          weeklyWeatherListFilter?.add(weeklyWeatherList![i]);
        }
      } else {
        weeklyWeatherListFilter?.add(dateFilter[i]);
      }
    }

    //daily forecast
    weeklyWeatherForecastListFilter?.clear();
    for (int k = 0; k < dateFilter.length; k++) {
      if (weeklyWeatherList?.first.dtTxt?.substring(0, 10) ==
          dateFilter[k].dtTxt?.substring(0, 10)) {
        weeklyWeatherForecastListFilter?.add(weeklyWeatherList![k]);
      }
    }

    update();
    return weeklyWeatherData;
  }

  apiCall() async {
    await buildWeeklyWeatherForecast();
  }
}
