import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart' hide Location ;
import 'package:get/get.dart';
import 'package:location/location.dart' hide LocationAccuracy;
import 'package:weatherapp/location_permission_controller/global_controller.dart';
import 'package:weatherapp/model/weekly_weather.dart';
import 'package:weatherapp/utils/api_constants.dart';

import '../../network/dio/base_service.dart';

class ForecastController extends GetxController {
  var isLoading = true.obs;
  double longitude = 0;
  double latitude = 0;
  GlobalController globalController = GlobalController();

  List<WeeklyWeatherList>? weeklyWeatherList = <WeeklyWeatherList>[].obs;
  List<WeeklyWeatherList>? weeklyWeatherListFilter = <WeeklyWeatherList>[].obs;
  List<WeeklyWeatherList>? weeklyWeatherListFilterInner = <WeeklyWeatherList>[].obs;


  BaseService service = BaseService();
  @override
  void onInit() {
    super.onInit();

  }
  _getLocation() async {
    Position position = await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.high);
    longitude = position.longitude;
    latitude = position.latitude;
  }


  Future<WeeklyWeather> buildWeeklyWeather(BuildContext context) async {
    _getLocation();
    var result = await service.request(
        "${ApiConst.baseUrl}data/2.5/forecast?lat=$latitude&lon=${longitude}&cnt=40&appid=${BaseService.apiKey}");
    var weeklyWeatherData = WeeklyWeather.fromJson(result.data);
    debugPrint('->20/12 list${jsonEncode(weeklyWeatherData.list)}');
    for (var i in weeklyWeatherData.list!) {
      weeklyWeatherList?.add(i);
    }
    debugPrint('-->20/9length${weeklyWeatherList?.length}');

    var dateFilter = weeklyWeatherData.list!;

    weeklyWeatherListFilter?.clear();
    for(var i = 0;i < dateFilter.length; i++ ) {

      if(weeklyWeatherListFilter != null && weeklyWeatherListFilter!.isNotEmpty) {
        if(weeklyWeatherListFilter?.last.dtTxt?.substring(0,10)!= dateFilter[i].dtTxt?.substring(0,10)) {
          weeklyWeatherListFilter?.add(weeklyWeatherList![i]);
        }
      }
      else {
        weeklyWeatherListFilter?.add(dateFilter[i]);
      }
    }

    update();
    return weeklyWeatherData;
  }

  getLocation(BuildContext context) async {
    bool isServiceEnabled;
    LocationPermission locationPermission;
    isServiceEnabled = await Geolocator.isLocationServiceEnabled();

    if (!isServiceEnabled) {
      if (Platform.isAndroid) {
        Location location = Location();

        isServiceEnabled = await location.requestService();
        if (isServiceEnabled) {
          getLocation(context);
        }
      } else {
        await Geolocator.openLocationSettings();
      }

      return Future.error('Location services are disabled.');
    }

    locationPermission = await Geolocator.checkPermission();
    if (locationPermission == LocationPermission.deniedForever) {
      return Future.error("Location denied");
    } else if (locationPermission == LocationPermission.denied) {
      locationPermission = await Geolocator.requestPermission();
      // Geolocator.openAppSettings();
    }

    if (locationPermission == LocationPermission.denied) {
      Geolocator.openAppSettings();
      return Future.error("Location denied");
    }

    await buildWeeklyWeather(context);

  }

}
