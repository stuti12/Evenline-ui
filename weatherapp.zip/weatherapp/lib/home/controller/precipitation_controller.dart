import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:geocoding/geocoding.dart';
import 'package:geolocator/geolocator.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';

import '../../model/weekly_weather.dart';
import '../../network/dio/base_service.dart';
import '../../utils/helper.dart';
import '../../utils/strings.dart';

class PrecipitationController extends GetxController {
  var longitude = 0.0.obs;
  var latitude = 0.0.obs;

  List<WeeklyWeatherList>? weeklyWeatherList = <WeeklyWeatherList>[].obs;
  List<WeeklyWeatherList>? weeklyWeatherListFilter = <WeeklyWeatherList>[].obs;
  List<int>? tempPrecipitationWeeklyWeatherListFilter = <int>[].obs;
  List<String>? daysPrecipitationWeeklyWeatherListFilter = <String>[].obs;
  List<WeeklyWeatherList>? weeklyWeatherForecastListFilter = <WeeklyWeatherList>[].obs;

  BaseService service = BaseService();
  var isLoading = false.obs;
  var data = <ChartData>[].obs;

  Future _getCurrentLocation() async {
    Position position = await getCurrentLoc();
    List placemarks = await placemarkFromCoordinates(latitude.value, longitude.value);
    Placemark place = placemarks[0];
    String lCity = '${place.locality},${place.administrativeArea}';
    return lCity;
  }

  Future getCurrentLoc() async {
    Position position = await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.best);
    latitude.value = position.latitude;
    longitude.value = position.longitude;
    debugPrint("--long${longitude.toString()}");
    debugPrint("--lat${latitude.toString()}");
    return position;
  }

  Future<WeeklyWeather> buildWeeklyWeatherForecast() async {
    isLoading.value = true;
   String city= await _getCurrentLocation();
    var result = await service.request(
        "${ApiConst.baseUrl}data/2.5/forecast?lat=${latitude.value}&lon=${longitude.value}&appid=${BaseService.apiKey}");
    var weeklyWeatherData = WeeklyWeather.fromJson(result.data);
    debugPrint('->21/12 Precipitation list${jsonEncode(weeklyWeatherData.list)}');
    weeklyWeatherList?.clear();
    for (var i in weeklyWeatherData.list!) {
      weeklyWeatherList?.add(i);
    }
    debugPrint('-->21/12 length${weeklyWeatherList?.length}');

    var dateFilter = weeklyWeatherData.list!;

    //filter 6 days
    weeklyWeatherListFilter?.clear();
    for (var i = 0; i < dateFilter.length; i++) {
      if (weeklyWeatherListFilter != null && weeklyWeatherListFilter!.isNotEmpty) {
        if (weeklyWeatherListFilter?.last.dtTxt?.substring(0, 10) !=
            dateFilter[i].dtTxt?.substring(0, 10)) {
          weeklyWeatherListFilter?.add(weeklyWeatherList![i]);
        }
      } else {
        weeklyWeatherListFilter?.add(dateFilter[i]);
      }
    }

    //getting y axis
    tempPrecipitationWeeklyWeatherListFilter?.clear();
    debugPrint('forCastWeeklyWeatherListFilter:--> ${weeklyWeatherListFilter?.length}');
    for (int i = 0; i < weeklyWeatherListFilter!.length; i++) {
      tempPrecipitationWeeklyWeatherListFilter
          ?.add(weeklyWeatherListFilter?[i].main?.humidity ?? 0);
    }

    //getting x axis
    daysPrecipitationWeeklyWeatherListFilter?.clear();
    for (var l = 0; l < weeklyWeatherListFilter!.length; l++) {
      daysPrecipitationWeeklyWeatherListFilter?.add(DateFormat('EEE').format(
          DateFormat("yyyy-MM-DD")
              .parse('${(weeklyWeatherListFilter?[l].dtTxt)?.substring(0, 10)}')));
    }

    DateTime? dt = Helper.stringToDate(weeklyWeatherList?[0].dtTxt ?? '');
    debugPrint('DateTime Conversion-->${dt}');

    //displaying data
    for (var s = 0; s < daysPrecipitationWeeklyWeatherListFilter!.length; s++) {
      data.add(
        ChartData(daysPrecipitationWeeklyWeatherListFilter?[s] ?? '',
            (tempPrecipitationWeeklyWeatherListFilter?[s] ?? 0)),
      );
    }
    data.refresh();

    //precipitation daily forecast
    weeklyWeatherForecastListFilter?.clear();
    for (int k = 0; k < dateFilter.length; k++) {
      if (weeklyWeatherList?.first.dtTxt?.substring(0, 10) ==
          dateFilter[k].dtTxt?.substring(0, 10)) {
        weeklyWeatherForecastListFilter?.add(weeklyWeatherList![k]);
      }
    }

    update();
    isLoading.value = false;
    return weeklyWeatherData;
  }

  apiCall() async {
    await buildWeeklyWeatherForecast();
  }
}

class ChartData {
  ChartData(this.x, this.y);

  final String x;
  final int y;
}
