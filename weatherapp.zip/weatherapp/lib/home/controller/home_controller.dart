import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:weatherapp/home/controller/forecast_controller.dart';
import 'package:weatherapp/home/controller/precipitation_controller.dart';
import 'package:weatherapp/home/controller/today_controller.dart';

import '../../network/dio/base_service.dart';

class HomeController extends GetxController {
  var isSearch = false.obs;
  var longitude = 0.0.obs;
  var city = ''.obs;
  var latitude = 0.0.obs;
  TextEditingController controller = TextEditingController();
  BaseService service = BaseService();
  TodayScreenController todayScreenController = Get.put(TodayScreenController());
  ForecastController forecastController = Get.put(ForecastController());
  PrecipitationController precipitationController = Get.put(PrecipitationController());

  apiCalls(BuildContext context) {
   // todayScreenController.apiCall(context);
   // forecastController.apiCall(context);
   // precipitationController.apiCall(context);
  }
}
