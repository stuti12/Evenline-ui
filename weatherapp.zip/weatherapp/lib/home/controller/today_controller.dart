import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:geocoding/geocoding.dart' hide Location;
import 'package:geolocator/geolocator.dart';
import 'package:get/get.dart';
import 'package:location/location.dart' hide LocationAccuracy;
import 'package:weatherapp/location_permission_controller/global_controller.dart';
import 'package:weatherapp/model/current_weather_model.dart';
import 'package:weatherapp/model/daily_weather.dart';
import 'package:weatherapp/model/weekly_weather.dart';
import 'package:weatherapp/utils/api_constants.dart';

import '../../network/dio/base_service.dart';

class TodayScreenController extends GetxController {
  var isLoading = true.obs;
  double longitude = 0;
  double latitude = 0;
  GlobalController globalController = GlobalController();
  List<Weather>? weatherList = <Weather>[].obs;
  List<WeatherList>? weathersList = <WeatherList>[].obs;
  List<DailyWeather>? dailyWeatherList = <DailyWeather>[].obs;
  final weatherMain = Rxn<Main>();
  final weatherSys = Rxn<Sys>();
  var list = <Main>[].obs;
  var city = ''.obs;
  RxString time = ''.obs;
  RxDouble temp = 0.0.obs;
  RxDouble feels = 0.0.obs;
  RxInt humidity = 0.obs;
  var sunset = 0.obs;
  var sunrise = 0.obs;
  var wind = 0.0.obs;
  var dailyWind = 0.0.obs;
  var visibility = 0.0.obs;
  List<WeeklyWeatherList>? weeklyWeatherList = <WeeklyWeatherList>[].obs;
  List<WeeklyWeatherList>? weeklyWeatherListFilter = <WeeklyWeatherList>[].obs;
  List<WeeklyWeatherList>? weeklyWeatherListFilterInner = <WeeklyWeatherList>[].obs;
  List<List<WeeklyWeatherList> > hourList=[];

  BaseService service = BaseService();
  @override
  void onInit() {
    super.onInit();
    debugPrint("time--> ${time.value}");
  }
  _getLocation() async {
    Position position = await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.high);
    longitude = position.longitude;
    latitude = position.latitude;
  }
  Future<CurrentWeather> buildCurrentWeather(BuildContext context) async {
    //_getLoc();
    Position position = await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.best);
    double longitude = position.longitude;
    double latitude = position.latitude;
    debugPrint("--long$longitude");
    debugPrint("--lat${latitude}");
    List placemarks = await placemarkFromCoordinates(position.latitude, position.longitude);
    Placemark place = placemarks[0];

    city.value =  '${place.locality},${place.administrativeArea}';
    debugPrint("--city$city");

    var result = await service.request(
        "${ApiConst.baseUrl}data/2.5/weather?lat=$latitude&lon=$longitude&appid=${BaseService.apiKey}");
    var weatherData = CurrentWeather.fromJson(result.data);
    debugPrint("16/12 iiii =-=-=-=->${jsonEncode(weatherData)}");

    for (var i in weatherData.weather!) {
     // debugPrint("16/12 iiii =-=-=-=->${jsonEncode(i)}");
      weatherList?.add(i);
    }

    temp.value = weatherData.main?.temp ?? 10.0;
    double d = temp.value - 273.15;

    temp.value = d;
    weatherMain()?.temp = weatherData.main?.temp ?? 10.0;

    wind.value = double.parse(weatherData.wind?.speed.toString() ?? '0');
    debugPrint('-->21/9 ${wind.value}');

    feels.value = weatherData.main?.feelsLike ?? 10.0;
    double d2 = feels.value - 273.15;

    feels.value = d2;

    visibility.value = double.parse(weatherData.visibility.toString());
    visibility.value = visibility.value / 1000;

    humidity.value = weatherData.main!.humidity!;

    sunset.value = weatherData.sys?.sunset ?? 0;
    sunrise.value = weatherData.sys?.sunrise ?? 0;
    debugPrint('sunset-->${sunset.value}');
    update();
    return weatherData;
  }

  Future<DailyWeatherData> buildDailyWeather(BuildContext context) async {
    _getLocation();
    var result = await service.request(
        "${ApiConst.baseUrl}data/2.5/forecast?lat=$latitude&lon=$longitude&appid=${BaseService.apiKey}");
    var dailyWeatherData = DailyWeatherData.fromJson(result.data);
    for (var i in dailyWeatherData.list!) {
      weathersList!.add(i);
    }


    debugPrint("19/12  =-=-=-=->${jsonEncode(dailyWeatherData)}");
    debugPrint("19/12 lenght  =-=-=-=->${weathersList?.length}");

    update();
    return dailyWeatherData;
  }

  Future<WeeklyWeather> buildWeeklyWeather(BuildContext context) async {
    _getLocation();
    var result = await service.request(
        "${ApiConst.baseUrl}data/2.5/forecast?lat=$latitude&lon=${longitude}&cnt=40&appid=${BaseService.apiKey}");
    var weeklyWeatherData = WeeklyWeather.fromJson(result.data);
    debugPrint('->20/12 list${jsonEncode(weeklyWeatherData.list)}');
    for (var i in weeklyWeatherData.list!) {
      weeklyWeatherList?.add(i);
    }
    debugPrint('-->20/9length${weeklyWeatherList?.length}');

    var dateFilter = weeklyWeatherData.list!;
    weeklyWeatherListFilter?.clear();
    for(var i = 0;i < dateFilter.length; i++ ) {

      if(weeklyWeatherListFilter != null && weeklyWeatherListFilter!.isNotEmpty) {
        if(weeklyWeatherListFilter?.last.dtTxt?.substring(0,10)!= dateFilter[i].dtTxt?.substring(0,10)) {
          weeklyWeatherListFilter?.add(weeklyWeatherList![i]);
        }
      }
      else {
        weeklyWeatherListFilter?.add(dateFilter[i]);
      }
    }

    for(int k=0;k<weeklyWeatherListFilter!.length;k++){
      List<WeeklyWeatherList>?  local=[];

        weeklyWeatherList
            ?.where((i) =>
        i.dtTxt?.substring(0, 10) == weeklyWeatherListFilter?[k].dtTxt?.substring(0, 10))
            .map((e) {
          local.add(e);
        })
            .toList();
        hourList.add(local);
      }

print("Hour List"+hourList[2][2].dtTxt.toString());


    update();
    return weeklyWeatherData;
  }

  getLocation(BuildContext context) async {
    bool isServiceEnabled;
    LocationPermission locationPermission;
    isServiceEnabled = await Geolocator.isLocationServiceEnabled();

    if (!isServiceEnabled) {
      if (Platform.isAndroid) {
        Location location = Location();

        isServiceEnabled = await location.requestService();
        if (isServiceEnabled) {
          getLocation(context);
        }
      } else {
        await Geolocator.openLocationSettings();
      }

      return Future.error('Location services are disabled.');
    }

    locationPermission = await Geolocator.checkPermission();
    if (locationPermission == LocationPermission.deniedForever) {
      return Future.error("Location denied");
    } else if (locationPermission == LocationPermission.denied) {
      locationPermission = await Geolocator.requestPermission();
     // Geolocator.openAppSettings();
    }

    if (locationPermission == LocationPermission.denied) {
      Geolocator.openAppSettings();
      return Future.error("Location denied");
    }

    await buildCurrentWeather(context);
    await buildDailyWeather(context);
    await buildWeeklyWeather(context);

  }


}
