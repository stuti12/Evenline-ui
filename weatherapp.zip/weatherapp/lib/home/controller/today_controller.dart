import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:geocoding/geocoding.dart' hide Location;
import 'package:geolocator/geolocator.dart';
import 'package:get/get.dart';
import 'package:place_picker/place_picker.dart';
import 'package:weatherapp/model/current_weather_model.dart';
import 'package:weatherapp/model/daily_weather.dart';
import 'package:weatherapp/model/weekly_weather.dart';

import '../../database/db.dart';
import '../../network/dio/base_service.dart';
import '../../utils/strings.dart';

class TodayScreenController extends GetxController {
  var isLoading = false.obs;
  var longitude = 0.0.obs;
  var latitude = 0.0.obs;
  var weatherList = <Weather>[].obs;
  List<WeeklyWeatherList>? weeklyWeatherList = <WeeklyWeatherList>[].obs;
  List<WeeklyWeatherList>? weeklyWeatherListFilter = <WeeklyWeatherList>[].obs;
  List<WeatherList>? dailyWeathersList = <WeatherList>[].obs;
  List<List<WeeklyWeatherList>> hourList = [];
  var city = ''.obs;

  RxDouble temp = 0.0.obs;
  RxDouble feels = 0.0.obs;
  RxInt humidity = 0.obs;
  var sunset = 0.obs;
  var sunrise = 0.obs;
  var wind = 0.0.obs;
  var visibility = 0.0.obs;
  BaseService service = BaseService();
  var locations = <Map<String, dynamic>>[].obs;


  Future _getLocation() async {
    Position position = await getCurrentLoc();
    List placemarks = await placemarkFromCoordinates(latitude.value, longitude.value);
    Placemark place = placemarks[0];
    String lCity = '${place.locality},${place.administrativeArea}';
    return lCity;
  }

  Future getCurrentLoc() async {
    Position position = await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.best);
    latitude.value = position.latitude;
    longitude.value = position.longitude;
    debugPrint("--long${longitude.toString()}");
    debugPrint("--lat${latitude.toString()}");
    return position;
  }

  //Current Weather api call
  Future<CurrentWeather> buildCurrentWeather() async {
    isLoading.value = true;
    String lCity = await _getLocation();
    city.value = lCity;
    debugPrint("--Long${longitude.value.toString()}");

    var result = await service.request(
        "${ApiConst.baseUrl}data/2.5/weather?lat=${latitude.value}&lon=${longitude.value}&appid=${BaseService.apiKey}");
    var weatherData = CurrentWeather.fromJson(result.data);
    debugPrint("16/12 response-->${jsonEncode(weatherData)}");

    weatherList.clear();
    for (var i in weatherData.weather ?? []) {
      weatherList.add(i);
    }

    weatherList.refresh();

    debugPrint('Length${weatherList.length}');
    temp.value = weatherData.main?.temp ?? 0.0;
    double d = temp.value - 273.15;
    temp.value = d;

    wind.value = double.parse(weatherData.wind?.speed.toString() ?? '0');
    feels.value = weatherData.main?.feelsLike ?? 10.0;

    visibility.value = double.parse(weatherData.visibility.toString());
    visibility.value = visibility.value / 1000;

    humidity.value = weatherData.main?.humidity ?? 11;

    sunset.value = weatherData.sys?.sunset ?? 0;
    sunrise.value = weatherData.sys?.sunrise ?? 0;
    debugPrint('sunset-->${sunset.value}');

    update();
    addItem();
    isLoading.value = false;
    return weatherData;
  }

  // Daily weather
  Future<DailyWeatherData> buildDailyWeather() async {
    isLoading.value = true;
    String lCity = await _getLocation();
    city.value = lCity;
    var result = await service.request(
        "${ApiConst.baseUrl}data/2.5/forecast?lat=${latitude.value}&lon=${longitude.value}&appid=${BaseService.apiKey}");
    var dailyWeatherData = DailyWeatherData.fromJson(result.data);
    //weekly weather data of horizontal list
    dailyWeathersList?.clear();
    for (var i in dailyWeatherData.list!) {
      dailyWeathersList?.add(i);
    }

    update();
    isLoading.value = false;
    return dailyWeatherData;
  }

  //Weekly weather
  Future<WeeklyWeather> buildWeeklyWeather() async {
    isLoading.value = true;
    String lCity = await _getLocation();
    city.value = lCity;
    var result = await service.request(
        "${ApiConst.baseUrl}data/2.5/forecast?lat=${latitude.value}&lon=${longitude.value}&cnt=40&appid=${BaseService.apiKey}");
    var weeklyWeatherData = WeeklyWeather.fromJson(result.data);
    weeklyWeatherList?.clear();
    for (var i in weeklyWeatherData.list ?? []) {
      weeklyWeatherList?.add(i);
    }

    var dateFilter = weeklyWeatherData.list ?? [];
    weeklyWeatherListFilter?.clear();
    //filter days weather(Expand Header)
    for (var i = 0; i < dateFilter.length; i++) {
      if (weeklyWeatherListFilter != null && weeklyWeatherListFilter?.isNotEmpty == true) {
        if (weeklyWeatherListFilter?.last.dtTxt?.substring(0, 10) !=
            dateFilter[i].dtTxt?.substring(0, 10)) {
          weeklyWeatherListFilter?.add(dateFilter[i]);
        }
      } else {
        weeklyWeatherListFilter?.add(dateFilter[i]);
      }
    }

    //day wise hour's weather filter
    for (int k = 0; k < weeklyWeatherListFilter!.length; k++) {
      List<WeeklyWeatherList>? local = [];

      weeklyWeatherList
          ?.where((i) =>
              i.dtTxt?.substring(0, 10) == weeklyWeatherListFilter?[k].dtTxt?.substring(0, 10))
          .map((e) {
        local.add(e);
      }).toList();
      hourList.add(local);
    }

    update();
    isLoading.value = false;
    return weeklyWeatherData;
  }

  //today screen apicall
  apiCall() async {
    isLoading.value = true;
    await buildCurrentWeather();
    await buildDailyWeather();
    await buildWeeklyWeather();

    isLoading.value = false;
  }

  //location Permission method


  //search
  void showPlacePicker(BuildContext context) async {
    LocationResult? result =
        await Navigator.of(context).push(MaterialPageRoute(builder: (context) => PlacePicker('')));
    longitude.value = result?.latLng?.longitude ?? 0.0;
    latitude.value = result?.latLng?.latitude ?? 0.0;
    city.value = '${result?.city?.name.toString() ?? ''}'
        '${','}'
        '${result?.administrativeAreaLevel1?.name.toString() ?? ''}';
    debugPrint('Lat-->$latitude');
    debugPrint('city-->$city');
    debugPrint('Long-->$longitude');
    apiCall();

    update();
  }

  //display db data
  Future<void> refreshLocation() async {
    final data = await SQLHelper.getItems();

    locations.value = data;
    locations.refresh();
    debugPrint('locations-->${locations.length}');
    update();
  }

  //add db data
  Future<void> addItem() async {
    await SQLHelper.createItem(
        city.value, temp.value.toStringAsFixed(0), weatherList[0].main.toString());
    debugPrint('Database value->${city.value}${weatherList[0].main.toString()}');
    update();
  }
}
