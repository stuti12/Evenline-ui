import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:syncfusion_flutter_charts/charts.dart';
import 'package:weatherapp/home/controller/precipitation_controller.dart';
import 'package:weatherapp/utils/custom/gradient.dart';

import '../utils/colors.dart';
import '../utils/helper.dart';
import '../utils/images.dart';
import '../utils/strings.dart';

class PrecipitationScreen extends StatefulWidget {
  const PrecipitationScreen({Key? key}) : super(key: key);

  @override
  State<PrecipitationScreen> createState() => _PrecipitationScreenState();
}

class _PrecipitationScreenState extends State<PrecipitationScreen> with AutomaticKeepAliveClientMixin{
  List forecastData = [
    {
      "id": 1,
      "day": "SUN",
      "date": "SEPT 12",
      "imgForecast": AppImage.iconCloud,
      "ssw": "ssw 11 km/h",
      "temperature": "33 / 28",
      "percent": "30%"
    },
    {
      "id": 1,
      "day": "SUN",
      "date": "SEPT 12",
      "imgForecast": AppImage.iconCloud,
      "ssw": "ssw 11 km/h",
      "temperature": "33 / 28",
      "percent": "30%"
    },
  ];
 // RefreshController _refreshController = RefreshController(initialRefresh: false);

  @override
  void initState() {
    precipitationController.apiCall();
    super.initState();
  }


  @override
  bool get wantKeepAlive => true;
  PrecipitationController precipitationController = Get.put(PrecipitationController());
  final GlobalKey<RefreshIndicatorState> _refreshIndicatorKey = GlobalKey<RefreshIndicatorState>();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColor.primaryColorGradient2,
      body: RefreshIndicator(
      onRefresh: () async{
        precipitationController.apiCall();
      },
        child: Obx(() => precipitationController.isLoading.value == false
            ? SingleChildScrollView(
                child: Container(
                  padding: EdgeInsets.symmetric(horizontal: 12.w),
                  decoration: BoxDecoration(gradient: GradientWidget.linearGradient()),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(
                        height: 10.h,
                      ),
                      Text(Strings.textPrecipitation,
                          style: TextStyle(
                              fontFamily: 'Poppins',
                              fontWeight: FontWeight.w600,
                              fontSize: 14.sp,
                              color: AppColor.colorWhite)),
                      SizedBox(
                        height: 20.h,
                      ),

                      //chart
                      SfCartesianChart(
                          enableAxisAnimation: true,
                          primaryXAxis: CategoryAxis(
                              isVisible: true,
                              axisLine: AxisLine(width: 1.w),
                              labelStyle: const TextStyle(color: Colors.white)),
                          primaryYAxis: NumericAxis(
                              minimum: 0,
                              maximum: 100,
                              interval: 25,
                              labelStyle: const TextStyle(color: Colors.white)),
                          series: <ChartSeries<ChartData, String>>[
                            ColumnSeries<ChartData, String>(
                                dataSource: precipitationController.data,
                                xValueMapper: (ChartData data, _) => data.x,
                                yValueMapper: (ChartData data, _) => data.y,
                                color: AppColor.colorGrey)
                          ]),

                      SizedBox(
                        height: 10.h,
                      ),

                      Text(Strings.textPrecipitation,
                          style: TextStyle(
                              fontFamily: 'Poppins',
                              fontWeight: FontWeight.w600,
                              fontSize: 14.sp,
                              color: AppColor.colorWhite)),
                      SizedBox(
                        height: 10.h,
                      ),
                      ListView.builder(
                          itemCount:
                              precipitationController.weeklyWeatherForecastListFilter?.length,
                          shrinkWrap: true,
                          itemBuilder: (context, int index) {
                            return forecastList(index: index);
                          }),
                      SizedBox(
                        height: 20.h,
                      ),
                    ],
                  ),
                ),
              )
            : Center(
                child: CircularProgressIndicator(
                  color: AppColor.colorProgressGradient,
                ),
              )),
      ),
    );
  }

  Widget forecastList({required int index}) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 12.w, vertical: 12.h),
      margin: EdgeInsets.symmetric(horizontal: 8.w, vertical: 2.h),
      decoration: BoxDecoration(
          gradient: GradientWidgetToday.linearGradient(),
          borderRadius: BorderRadius.circular(10.r)),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          RichText(
            text: TextSpan(
                text: '${DateFormat('EEE').format(DateTime.now())}\n',
                style: TextStyle(
                    fontFamily: 'Poppins',
                    fontWeight: FontWeight.w500,
                    fontSize: 13.sp,
                    color: AppColor.colorTodayScreenText),
                children: <TextSpan>[
                  TextSpan(
                    text: DateFormat('dd MMM').format(DateTime.now()),
                    style: TextStyle(
                        fontFamily: 'Poppins',
                        fontWeight: FontWeight.w500,
                        fontSize: 13.sp,
                        color: AppColor.colorWhite),
                  ),
                ]),
          ),
          SizedBox(
            width: 4.w,
          ),
          Obx(() => precipitationController.weeklyWeatherListFilter?.isNotEmpty == true
              ? Image.network(
                  'https://openweathermap.org/img/wn/${precipitationController.weeklyWeatherForecastListFilter?[index].weather?[0].icon}@2x.png',
                  width: 40.w,
                )
              : Image.asset(AppImage.iconCloud)),
          SizedBox(
            width: 4.w,
          ),
          Obx(
            () => RichText(
              text: TextSpan(
                  text:
                      '${precipitationController.weeklyWeatherForecastListFilter?[index].weather?[0].description?.toTitleCase() ?? "NA"}\n',
                  style: TextStyle(
                      fontFamily: 'Poppins',
                      fontWeight: FontWeight.w500,
                      fontSize: 13.sp,
                      color: AppColor.colorForecastText),
                  children: <TextSpan>[
                    precipitationController.weeklyWeatherForecastListFilter?[index].weather?[0]
                                .description?.isNotEmpty ==
                            true
                        ? TextSpan(
                            text:
                                '${precipitationController.weeklyWeatherForecastListFilter?[index].wind?.speed.toString()} km/h',
                            style: TextStyle(
                                fontFamily: 'Poppins',
                                fontWeight: FontWeight.w400,
                                fontSize: 13.sp,
                                color: AppColor.colorTodayScreenText),
                          )
                        : TextSpan(
                            text: 'No Data',
                            style: TextStyle(
                                fontFamily: 'Poppins',
                                fontWeight: FontWeight.w400,
                                fontSize: 13.sp,
                                color: AppColor.colorTodayScreenText),
                          ),
                  ]),
            ),
          ),
          Expanded(
            child: Column(
              children: [
                Obx(() => precipitationController.weeklyWeatherForecastListFilter?.isNotEmpty ==
                        true
                    ? Text(
                        '${((precipitationController.weeklyWeatherForecastListFilter?[index].main?.tempMax ?? 0) - 273.15).toStringAsFixed(0)}${'\u00B0'} / ${((precipitationController.weeklyWeatherForecastListFilter?[index].main?.tempMin ?? 0) - 273.15).toStringAsFixed(0)}${'\u00B0'}',
                        style: TextStyle(
                            fontFamily: 'Poppins',
                            fontWeight: FontWeight.w500,
                            fontSize: 12.sp,
                            color: AppColor.colorWhite))
                    : Text(
                        'NA',
                        style: TextStyle(
                          fontFamily: 'Poppins',
                          fontWeight: FontWeight.w500,
                          fontSize: 12.sp,
                        ),
                      )),
                Obx(
                  () => Text.rich(
                    style: TextStyle(
                        fontFamily: 'Poppins',
                        fontWeight: FontWeight.w500,
                        fontSize: 12.sp,
                        color: AppColor.colorWhite),
                    TextSpan(
                      children: [
                        WidgetSpan(
                            child: Padding(
                          padding: EdgeInsets.only(left: 8.r),
                          child: Icon(
                            Icons.water_drop,
                            color: AppColor.colorWhite,
                          ),
                        )),
                        TextSpan(
                          text:
                              '${precipitationController.weeklyWeatherForecastListFilter?[index].main?.humidity}%',
                        ),
                      ],
                    ),
                  ),
                )
              ],
            ),
          ),
          Icon(
            Icons.keyboard_arrow_right,
            color: AppColor.colorWhite,
          ),
          SizedBox(
            height: 10.h,
          ),
        ],
      ),
    );
  }
}
