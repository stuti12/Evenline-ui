import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:syncfusion_flutter_charts/charts.dart';
import 'package:weatherapp/utils/custom/gradient.dart';

import '../utils/colors.dart';
import '../utils/images.dart';
import '../utils/strings.dart';

class PrecipitationScreen extends StatefulWidget {
  const PrecipitationScreen({Key? key}) : super(key: key);

  @override
  State<PrecipitationScreen> createState() => _PrecipitationScreenState();
}

class _PrecipitationScreenState extends State<PrecipitationScreen> {
  List forecastData = [
    {"id":1,"day":"SUN","date":"SEPT 12","imgForecast":AppImage.iconCloud,"ssw": "ssw 11 km/h","temperature":"33 / 28","percent":"30%"},
    {"id":1,"day":"SUN","date":"SEPT 12","imgForecast":AppImage.iconCloud,"ssw": "ssw 11 km/h","temperature":"33 / 28","percent":"30%"},
  ];
  late List<_ChartData> data;
  @override
  void initState() {
    data = [
      _ChartData('30%', 12),
      _ChartData('40%', 30),
      _ChartData('50%', 6.4),
      _ChartData('70%', 14),
      _ChartData('80%', 14),
      _ChartData('90%', 10),
      _ChartData('96%', 10),

    ];
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(backgroundColor: AppColor.primaryColorGradient2,
      body: SingleChildScrollView(
        child: Container(padding: EdgeInsets.symmetric(horizontal: 12.w),
          decoration: BoxDecoration(gradient: GradientWidget.linearGradient()),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(
                height: 10.h,
              ),
              Text(Strings.textPrecipitation,
                  style: TextStyle(
                      fontFamily: 'Poppins',
                      fontWeight: FontWeight.w600,
                      fontSize: 14.sp,
                      color: AppColor.colorWhite)),
              SizedBox(
                height: 10.h,
              ),

              //chart
            SfCartesianChart(
                primaryXAxis: CategoryAxis(axisLine: AxisLine(width: 1,),isVisible: true,labelStyle: TextStyle(color: Colors.white)),
                primaryYAxis: NumericAxis(minimum: 0, maximum: 40, interval: 10,isVisible: false),
                series: <ChartSeries<_ChartData, String>>[
                  ColumnSeries<_ChartData, String>(
                      dataSource: data,
                      xValueMapper: (_ChartData data, _) => data.x,
                      yValueMapper: (_ChartData data, _) => data.y,
                      color: AppColor.colorGrey)
                ]),

              SizedBox(
                height: 10.h,
              ),

              Text(Strings.textPrecipitation,
                  style: TextStyle(
                      fontFamily: 'Poppins',
                      fontWeight: FontWeight.w600,
                      fontSize: 14.sp,
                      color: AppColor.colorWhite)),
              SizedBox(
                height: 10.h,
              ),
              ListView.builder(itemCount: forecastData.length,
                  shrinkWrap: true,
                  itemBuilder: (context,int index){
                    return forecastList(index: index);
                  }),

            ],
          ),
        ),
      ),
    );
  }
  Widget forecastList({required int index}) {
    return Container(
      padding: EdgeInsets.all(12.r),
      margin: EdgeInsets.symmetric(vertical: 2.h),
      decoration: BoxDecoration(
          gradient: GradientWidgetForecast.linearGradient(),
          borderRadius: BorderRadius.circular(10.r)),
      child: Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          RichText(
            text: TextSpan(
                text: '${forecastData[index]['day']}\n',
                style: TextStyle(
                    fontFamily: 'Poppins',
                    fontWeight: FontWeight.w500,
                    fontSize: 13.sp,
                    color: AppColor.colorTodayScreenText),
                children: <TextSpan>[
                  TextSpan(
                    text: forecastData[index]['date'],
                    style: TextStyle(
                        fontFamily: 'Poppins',
                        fontWeight: FontWeight.w500,
                        fontSize: 13.sp,
                        color: AppColor.colorWhite),
                  ),
                ]),
          ),
          Image.asset(
            forecastData[index]['imgForecast'],
            width: 40.w,
          ),
          RichText(
            text: TextSpan(
                text: 'Thunderstorms\n',
                style: TextStyle(
                    fontFamily: 'Poppins',
                    fontWeight: FontWeight.w500,
                    fontSize: 13.sp,
                    color: AppColor.colorForecastText),
                children: <TextSpan>[
                  TextSpan(
                    text: forecastData[index]['ssw'],
                    style: TextStyle(
                        fontFamily: 'Poppins',
                        fontWeight: FontWeight.w400,
                        fontSize: 13.sp,
                        color: AppColor.colorTodayScreenText),
                  ),
                ]),
          ),
          Column(
            children: [
              Text('86${'\u00B0'}/80${'\u00B0'}',
                  style: TextStyle(
                      fontFamily: 'Poppins',
                      fontWeight: FontWeight.w500,
                      fontSize: 13.sp,
                      color: AppColor.colorWhite)),
              Text.rich(style: TextStyle(  fontFamily: 'Poppins',
                  fontWeight: FontWeight.w500,
                  fontSize: 13.sp,
                  color: AppColor.colorWhite),
                TextSpan(
                  children: [
                    WidgetSpan(child: Icon(Icons.water_drop,color: AppColor.colorWhite,)),
                    TextSpan(text: forecastData[index]['percent'],),

                  ],
                ),
              ),

            ],
          ),
          Icon(
            Icons.keyboard_arrow_right,
            color: AppColor.colorWhite,
          ),
          SizedBox(height: 10.h,),
        ],
      ),
    );
  }
}

class _ChartData {
  _ChartData(this.x, this.y);

  final String x;
  final double y;
}