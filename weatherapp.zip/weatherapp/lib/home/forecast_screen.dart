import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';
import 'package:weatherapp/home/controller/forecast_controller.dart';

import '../utils/colors.dart';
import '../utils/custom/gradient.dart';
import '../utils/images.dart';
import '../utils/strings.dart';

class ForecastScreen extends StatefulWidget {
  const ForecastScreen({Key? key}) : super(key: key);

  @override
  State<ForecastScreen> createState() => _ForecastScreenState();
}

class _ForecastScreenState extends State<ForecastScreen> with WidgetsBindingObserver {
  @override
  void initState() {
    _apiCalls();
    WidgetsBinding.instance.addObserver(this);
    super.initState();
  }

  _apiCalls() {
    forecastController.getLocation(context);
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      _apiCalls();
    }
  }

  @override
  void dispose() {
    super.dispose();
    WidgetsBinding.instance.removeObserver(this);
  }

  List tempratureDetailData = [
    {"id": 1, "tempImg": AppImage.iconCloud, "title": "Sun", "temp": "80"},
    {"id": 1, "tempImg": AppImage.iconCloud, "title": "Mon", "temp": "80"},
    {"id": 1, "tempImg": AppImage.iconCloud, "title": "Tue", "temp": "80"},
    {"id": 1, "tempImg": AppImage.iconCloud, "title": "Wed", "temp": "80"},
    {"id": 1, "tempImg": AppImage.iconCloud, "title": "Thu", "temp": "80"},
    {"id": 1, "tempImg": AppImage.iconCloud, "title": "Fri", "temp": "80"},
    {"id": 1, "tempImg": AppImage.iconCloud, "title": "Sat", "temp": "80"},
  ];
  ForecastController forecastController = Get.put(ForecastController());
  List forecastData = [
    {
      "id": 1,
      "day": "SUN",
      "date": "SEPT 12",
      "imgForecast": AppImage.iconCloud,
      "ssw": "ssw 11 km/h",
      "temperature": "33 / 28",
      "percent": "30%"
    },
    {
      "id": 1,
      "day": "SUN",
      "date": "SEPT 12",
      "imgForecast": AppImage.iconCloud,
      "ssw": "ssw 11 km/h",
      "temperature": "33 / 28",
      "percent": "30%"
    },
  ];
  RefreshController _refreshController = RefreshController(initialRefresh: false);

  _onLoading() async {
    // your api here
    _refreshController.loadComplete();
  }

  _refresh() {
    _apiCalls();
    _refreshController.refreshCompleted();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SmartRefresher(
        controller: _refreshController,
        enablePullDown: true,
        onLoading: _onLoading,
        onRefresh: _refresh,
        child: SingleChildScrollView(
          child: Container(
            padding: EdgeInsets.symmetric(horizontal: 8.w),
            decoration: BoxDecoration(gradient: GradientWidget.linearGradient()),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(
                  height: 14.h,
                ),
                SizedBox(
                    height: 140.h,
                    child: Obx(
                      () => ListView.builder(
                          physics: BouncingScrollPhysics(),
                          shrinkWrap: true,
                          scrollDirection: Axis.horizontal,
                          itemCount: forecastController.weeklyWeatherListFilter?.length,
                          itemBuilder: (context, int index) {
                            return weatherDetail(index: index);
                          }),
                    )),
                SizedBox(
                  height: 10.h,
                ),
                RichText(
                  text: TextSpan(
                      text: 'Average: ',
                      style: TextStyle(
                          fontFamily: 'Poppins',
                          fontWeight: FontWeight.w600,
                          fontSize: 13.sp,
                          color: AppColor.colorTodayScreenText),
                      children: <TextSpan>[
                        TextSpan(
                          text: '28%',
                          style: TextStyle(
                              fontFamily: 'Poppins',
                              fontWeight: FontWeight.w600,
                              fontSize: 13.sp,
                              color: AppColor.colorWhite),
                        ),
                      ]),
                ),
                SizedBox(
                  height: 10.h,
                ),
                Container(
                  height: 260.h,
                  decoration: BoxDecoration(
                      gradient: GradientWidgetToday.linearGradient(),
                      borderRadius: BorderRadius.all(Radius.circular(10.r))),
                  child: Image.asset(
                    AppImage.imgChart,
                    fit: BoxFit.fill,
                  ),
                ),
                SizedBox(
                  height: 15.h,
                ),
                Container(
                  decoration: BoxDecoration(
                      gradient: GradientWidgetToday.linearGradient(),
                      borderRadius: BorderRadius.all(Radius.circular(30.r))),
                  child: ListView(
                    shrinkWrap: true,
                    children: [
                      ListTile(
                        contentPadding: EdgeInsets.zero,
                        title: Padding(
                          padding: EdgeInsets.only(left: 20.w),
                          child: Text(
                            Strings.textSee,
                            style: TextStyle(
                                fontFamily: 'Poppins',
                                color: AppColor.colorGreyChartText,
                                fontWeight: FontWeight.w600,
                                fontSize: 13.sp),
                          ),
                        ),
                        subtitle: Padding(
                          padding: EdgeInsets.only(left: 20.w),
                          child: Text(
                            Strings.textPlan,
                            style: TextStyle(
                                fontFamily: 'Poppins',
                                color: AppColor.colorWhite,
                                fontWeight: FontWeight.w500,
                                fontSize: 13.sp),
                          ),
                        ),
                        trailing: Container(
                          margin: EdgeInsets.only(right: 6.w),
                          decoration: BoxDecoration(
                              gradient: GradientWidget.linearGradient(),
                              borderRadius: BorderRadius.circular(30.r)),
                          child: IconButton(
                            onPressed: () {},
                            icon: Icon(
                              Icons.keyboard_arrow_right,
                              color: AppColor.colorWhite,
                            ),
                          ),
                        ),
                      )
                    ],
                  ),
                ),
                SizedBox(
                  height: 10.h,
                ),
                ListView.builder(
                    itemCount: forecastData.length,
                    shrinkWrap: true,
                    itemBuilder: (context, int index) {
                      return InkWell(onTap: () {}, child: forecastList(index: index));
                    }),
                SizedBox(
                  height: 20.h,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget weatherDetail({required int index}) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 4.w),
      margin: EdgeInsets.symmetric(horizontal: 8.w),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          Obx(() => Image.network(
                'https://openweathermap.org/img/wn/${forecastController.weeklyWeatherList?[index].weather?[0].icon}@2x.png',
              )),
          Obx(
            () => forecastController.weeklyWeatherListFilter?[index].dtTxt != null
                ? Text(
                    DateFormat('EEEE').format(DateFormat("yyyy-MM-DD").parse(
                        '${(forecastController.weeklyWeatherListFilter?[index].dtTxt)?.substring(0, 10)}')),
                    style: TextStyle(
                        fontSize: 14.sp,
                        fontFamily: 'Poppins',
                        fontWeight: FontWeight.w500,
                        color: AppColor.colorTodayScreenText),
                  )
                : Text(
                    'No Data',
                    style: TextStyle(
                        fontSize: 13.sp,
                        fontFamily: 'Poppins',
                        fontWeight: FontWeight.w500,
                        color: AppColor.colorTodayScreenText),
                  ),
          ),
          Obx(() => Text(
                '${((forecastController.weeklyWeatherListFilter?[index].main?.temp ?? 0 )-273.15).toStringAsFixed(0)}${'\u00B0'}',
                style:
                    TextStyle(fontSize: 14.sp, color: AppColor.colorWhite, fontFamily: 'Poppins',fontWeight: FontWeight.w600),
              ))

        ],
      ),
    );
  }

  Widget forecastList({required int index}) {
    return Container(
      padding: EdgeInsets.all(12.r),
      margin: EdgeInsets.symmetric(horizontal: 6.w, vertical: 2.h),
      decoration: BoxDecoration(
          gradient: GradientWidgetToday.linearGradient(),
          borderRadius: BorderRadius.circular(10.r)),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          RichText(
            text: TextSpan(
                text: '${forecastData[index]['day']}\n',
                style: TextStyle(
                    fontFamily: 'Poppins',
                    fontWeight: FontWeight.w500,
                    fontSize: 13.sp,
                    color: AppColor.colorTodayScreenText),
                children: <TextSpan>[
                  TextSpan(
                    text: forecastData[index]['date'],
                    style: TextStyle(
                        fontFamily: 'Poppins',
                        fontWeight: FontWeight.w500,
                        fontSize: 13.sp,
                        color: AppColor.colorWhite),
                  ),
                ]),
          ),
          Expanded(
            child: Image.asset(
              forecastData[index]['imgForecast'],
            ),
          ),
          RichText(
            text: TextSpan(
                text: 'Thunderstorms\n',
                style: TextStyle(
                    fontFamily: 'Poppins',
                    fontWeight: FontWeight.w500,
                    fontSize: 13.sp,
                    color: AppColor.colorForecastText),
                children: <TextSpan>[
                  TextSpan(
                    text: forecastData[index]['ssw'],
                    style: TextStyle(
                        fontFamily: 'Poppins',
                        fontWeight: FontWeight.w400,
                        fontSize: 13.sp,
                        color: AppColor.colorTodayScreenText),
                  ),
                ]),
          ),
          Expanded(
            child: Column(
              children: [
                Text('86${'\u00B0'}/80${'\u00B0'}',
                    style: TextStyle(
                        fontFamily: 'Poppins',
                        fontWeight: FontWeight.w500,
                        fontSize: 13.sp,
                        color: AppColor.colorWhite)),
                Text.rich(
                  style: TextStyle(
                      fontFamily: 'Poppins',
                      fontWeight: FontWeight.w500,
                      fontSize: 13.sp,
                      color: AppColor.colorWhite),
                  TextSpan(
                    children: [
                      WidgetSpan(
                          child: Icon(
                        Icons.water_drop,
                        color: AppColor.colorWhite,
                      )),
                      TextSpan(
                        text: forecastData[index]['percent'],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          Icon(
            Icons.keyboard_arrow_right,
            color: AppColor.colorWhite,
          ),
          SizedBox(
            height: 10.h,
          ),
        ],
      ),
    );
  }
}

/*SfCartesianChart _buildHilo() {
    return SfCartesianChart(
      plotAreaBorderWidth: 0,
      title: ChartTitle(text: 'AAPL - 2016'),

      primaryYAxis: NumericAxis(
          interval: 20,
          minimum: 140,
          maximum: 60,
          labelFormat: r'${value}',
          ),
      series: _getHiloSeries(),
    );
  }*/

/*  List<HiloSeries<ChartSampleData, String?>> _getHiloSeries() {
    return <HiloSeries<ChartSampleData, String?>>[
      HiloSeries<ChartSampleData, String?>(
          dataSource: <ChartSampleData>[
            ChartSampleData(
                x:'',
                secondSeriesYValue: 98.97,
                high: 101.19,
                low: 95.36,
                thirdSeriesYValue: 97.13),
            ChartSampleData(
                x:'',
                secondSeriesYValue: 98.41,
                high: 101.46,
                low: 93.42,
                thirdSeriesYValue: 101.42),
            ChartSampleData(
                x: '',
                secondSeriesYValue: 101.52,
                high: 101.53,
                low: 92.39,
                thirdSeriesYValue: 97.34),
            ChartSampleData(
                x: '',
                secondSeriesYValue: 96.47,
                high: 97.33,
                low: 93.69,
                thirdSeriesYValue: 94.02),
            ChartSampleData(
                x: '',
                secondSeriesYValue: 93.13,
                high: 96.35,
                low: 92.59,
                thirdSeriesYValue: 93.99),
            ChartSampleData(
                x: '',
                secondSeriesYValue: 95.02,
                high: 98.89,
                low: 94.61,
                thirdSeriesYValue: 96.04),
            ChartSampleData(
                x:'',
                secondSeriesYValue: 92.31,
                high: 94.0237,
                low: 94.0237,
                thirdSeriesYValue: 92.91),
            ChartSampleData(
                x: '',
                secondSeriesYValue: 96.86,
                high: 103.75,
                low: 96.65,
                thirdSeriesYValue: 103.01),
            ChartSampleData(
                x: '',
                secondSeriesYValue: 102.39,
                high: 102.83,
                low: 100.15,
                thirdSeriesYValue: 102.26),
            ChartSampleData(
                x:'',
                secondSeriesYValue: 101.91,
                high: 106.5,
                low: 101.78,
                thirdSeriesYValue: 105.92),
            ChartSampleData(
                x: 'DateTime(2016, 03, 21)',
                secondSeriesYValue: 105.93,
                high: 107.65,
                low: 104.89,
                thirdSeriesYValue: 105.67),
            ChartSampleData(
                x:'',
                secondSeriesYValue: 106,
                high: 110.42,
                low: 104.88,
                thirdSeriesYValue: 109.99),
            ChartSampleData(
                x: '',
                secondSeriesYValue: 110.42,
                high: 112.19,
                low: 108.121,
                thirdSeriesYValue: 108.66),
            ChartSampleData(
                x: '',
                secondSeriesYValue: 108.97,
                high: 112.39,
                low: 108.66,
                thirdSeriesYValue: 109.85),


          ],
          color: AppColor.colorGrey,
          name: 'AAPL',
          xValueMapper: (ChartSampleData sales, _) => sales.x ,

          /// High and low value mapper used to render the hilo series.
          lowValueMapper: (ChartSampleData sales, _) => sales.low,
          highValueMapper: (ChartSampleData sales, _) => sales.high)
    ];
  }*/
/*class ChartSampleData {
  /// Holds the datapoint values like x, y, etc.,
  ChartSampleData(
      {this.x,
        this.y,
        this.xValue,
        this.yValue,
        this.secondSeriesYValue,
        this.thirdSeriesYValue,
        this.pointColor,
        this.size,
        this.text,
        this.open,
        this.close,
        this.low,
        this.high,
        this.volume});

  /// Holds x value of the datapoint
  final dynamic x;

  /// Holds y value of the datapoint
  final num? y;

  /// Holds x value of the datapoint
  final dynamic xValue;

  /// Holds y value of the datapoint
  final num? yValue;

  final num? secondSeriesYValue;

  final num? thirdSeriesYValue;

  final Color? pointColor;

  final num? size;

  final String? text;

  final num? open;

  final num? close;

  final num? low;

  final num? high;

  /// Holds open value of the datapoint
  final num? volume;
}*/
