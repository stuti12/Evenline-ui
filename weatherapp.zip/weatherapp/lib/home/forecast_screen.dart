import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:weatherapp/home/controller/forecast_controller.dart';

import '../utils/colors.dart';
import '../utils/custom/gradient.dart';
import '../utils/helper.dart';
import '../utils/images.dart';
import '../utils/strings.dart';

class ForecastScreen extends StatefulWidget {
  const ForecastScreen({Key? key}) : super(key: key);

  @override
  State<ForecastScreen> createState() => _ForecastScreenState();
}

class _ForecastScreenState extends State<ForecastScreen> with AutomaticKeepAliveClientMixin{
  @override
  void initState() {
    forecastController.apiCall();

    super.initState();
  }


  ForecastController forecastController = Get.put(ForecastController());
  List forecastData = [
    {
      "id": 1,
      "day": "SUN",
      "date": "SEPT 12",
      "imgForecast": AppImage.iconCloud,
      "ssw": "ssw 11 km/h",
      "temperatureMax": "33",
      "temperatureMin": "24",
      "percent": "30%"
    },
    {
      "id": 1,
      "day": "SUN",
      "date": "SEPT 12",
      "imgForecast": AppImage.iconCloud,
      "ssw": "ssw 11 km/h",
      "temperatureMax": "33",
      "temperatureMin": "28",
      "percent": "30%"
    },
  ];

  // final RefreshController _refreshController = RefreshController(initialRefresh: false);

  @override
  bool get wantKeepAlive => true;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: RefreshIndicator(
        onRefresh: () async {
          forecastController.apiCall();
        },
        child: SingleChildScrollView(
          child: Container(
            padding: EdgeInsets.symmetric(horizontal: 8.w),
            decoration: BoxDecoration(gradient: GradientWidget.linearGradient()),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(
                  height: 14.h,
                ),
                SizedBox(
                    height: 140.h,
                    child: Obx(
                      () => ListView.builder(
                          shrinkWrap: true,
                          scrollDirection: Axis.horizontal,
                          itemCount: forecastController.weeklyWeatherListFilter?.isNotEmpty == true
                              ? forecastController.weeklyWeatherListFilter?.length
                              : 1,
                          itemBuilder: (context, int index) {
                            return weatherDetail(findex: index);
                          }),
                    )),
                SizedBox(
                  height: 10.h,
                ),
                RichText(
                  text: TextSpan(
                      text: 'Average: ',
                      style: TextStyle(
                          fontFamily: 'Poppins',
                          fontWeight: FontWeight.w600,
                          fontSize: 13.sp,
                          color: AppColor.colorTodayScreenText),
                      children: <TextSpan>[
                        TextSpan(
                          text: '28%',
                          style: TextStyle(
                              fontFamily: 'Poppins',
                              fontWeight: FontWeight.w600,
                              fontSize: 13.sp,
                              color: AppColor.colorWhite),
                        ),
                      ]),
                ),
                SizedBox(
                  height: 10.h,
                ),
                Container(
                  height: 260.h,
                  decoration: BoxDecoration(
                      gradient: GradientWidgetToday.linearGradient(),
                      borderRadius: BorderRadius.all(Radius.circular(10.r))),
                  child: Image.asset(
                    AppImage.imgChart,
                    fit: BoxFit.fill,
                  ),
                ),
                SizedBox(
                  height: 15.h,
                ),
                Container(
                  decoration: BoxDecoration(
                      gradient: GradientWidgetToday.linearGradient(),
                      borderRadius: BorderRadius.all(Radius.circular(30.r))),
                  child: ListView(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    children: [
                      ListTile(
                        contentPadding: EdgeInsets.zero,
                        title: Padding(
                          padding: EdgeInsets.only(left: 20.w),
                          child: Text(
                            Strings.textSee,
                            style: TextStyle(
                                fontFamily: 'Poppins',
                                color: AppColor.colorGreyChartText,
                                fontWeight: FontWeight.w600,
                                fontSize: 13.sp),
                          ),
                        ),
                        subtitle: Padding(
                          padding: EdgeInsets.only(left: 20.w),
                          child: Text(
                            Strings.textPlan,
                            style: TextStyle(
                                fontFamily: 'Poppins',
                                color: AppColor.colorWhite,
                                fontWeight: FontWeight.w500,
                                fontSize: 13.sp),
                          ),
                        ),
                        trailing: Container(
                          margin: EdgeInsets.only(right: 6.w),
                          decoration: BoxDecoration(
                              gradient: GradientWidget.linearGradient(),
                              borderRadius: BorderRadius.circular(30.r)),
                          child: IconButton(
                            onPressed: () {},
                            icon: Icon(
                              Icons.keyboard_arrow_right,
                              color: AppColor.colorWhite,
                            ),
                          ),
                        ),
                      )
                    ],
                  ),
                ),
                SizedBox(
                  height: 10.h,
                ),
                Obx(() => forecastController.weeklyWeatherForecastListFilter?.isNotEmpty == true
                    ? ListView.builder(
                        itemCount: forecastController.weeklyWeatherForecastListFilter?.length,
                        shrinkWrap: true,
                        physics: const BouncingScrollPhysics(),
                        itemBuilder: (context, int index) {
                          return InkWell(onTap: () {}, child: forecastList(index: index));
                        })
                    : Container(
                        decoration: BoxDecoration(
                            gradient: GradientWidgetToday.linearGradient(),
                            borderRadius: BorderRadius.all(Radius.circular(10.r))),
                        height: 100.h,
                      )),
                SizedBox(
                  height: 20.h,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget weatherDetail({required int findex}) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 8.w),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          Obx(() => forecastController.weeklyWeatherListFilter?.isNotEmpty == true
              ? Image.network(
                  'https://openweathermap.org/img/wn/${forecastController.weeklyWeatherListFilter?[findex].weather?[0].icon}@2x.png',
                  width: 40.w,
                )
              : Image.asset(AppImage.iconCloud)),
          Obx(
            () => forecastController.weeklyWeatherListFilter?.isNotEmpty == true
                ? Text(
                    DateFormat('EEE').format(DateFormat("yyyy-MM-DD").parse(
                        '${(forecastController.weeklyWeatherListFilter?[findex].dtTxt)?.substring(0, 10)}')),
                    style: TextStyle(
                        fontSize: 11.sp,
                        fontFamily: 'Poppins',
                        fontWeight: FontWeight.w600,
                        color: AppColor.colorTodayScreenText),
                  )
                : Text(
                    'No Data',
                    style: TextStyle(
                        fontSize: 12.sp,
                        fontFamily: 'Poppins',
                        fontWeight: FontWeight.w500,
                        color: AppColor.colorTodayScreenText),
                  ),
          ),
          Obx(() => forecastController.weeklyWeatherListFilter?.isNotEmpty == true
              ? Text(
                  '${((forecastController.weeklyWeatherListFilter?[findex].main?.temp ?? 0) - 273.15).toStringAsFixed(0)}${'\u00B0'}',
                  style: TextStyle(
                      fontSize: 14.sp,
                      color: AppColor.colorWhite,
                      fontFamily: 'Poppins',
                      fontWeight: FontWeight.w600),
                )
              : Text(
                  'NA',
                  style: TextStyle(
                      fontSize: 14.sp,
                      color: AppColor.colorWhite,
                      fontFamily: 'Poppins',
                      fontWeight: FontWeight.w600),
                ))
        ],
      ),
    );
  }

  Widget forecastList({required int index}) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 12.w, vertical: 10.h),
      margin: EdgeInsets.symmetric(horizontal: 8.w, vertical: 2.h),
      decoration: BoxDecoration(
          gradient: GradientWidgetToday.linearGradient(),
          borderRadius: BorderRadius.circular(10.r)),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          RichText(
            text: TextSpan(
                text: '${DateFormat('EEE').format(DateTime.now())}\n',
                style: TextStyle(
                    fontFamily: 'Poppins',
                    fontWeight: FontWeight.w500,
                    fontSize: 13.sp,
                    color: AppColor.colorTodayScreenText),
                children: <TextSpan>[
                  TextSpan(
                    text: DateFormat('dd MMM').format(DateTime.now()),
                    style: TextStyle(
                        fontFamily: 'Poppins',
                        fontWeight: FontWeight.w500,
                        fontSize: 13.sp,
                        color: AppColor.colorWhite),
                  ),
                ]),
          ),
          SizedBox(
            width: 4.w,
          ),
          Obx(() => forecastController.weeklyWeatherListFilter?.isNotEmpty == true
              ? Image.network(
                  'https://openweathermap.org/img/wn/${forecastController.weeklyWeatherForecastListFilter?[index].weather?[0].icon}@2x.png',
                  width: 40.w,
                )
              : Image.asset(AppImage.iconCloud)),
          SizedBox(
            width: 4.w,
          ),
          SizedBox(
            width: 0.2.sw,
            child: Obx(
              () => RichText(
                text: TextSpan(
                    text:
                        '${forecastController.weeklyWeatherForecastListFilter?[index].weather?[0].description?.toTitleCase() ?? "NA"}\n',
                    style: TextStyle(
                        fontFamily: 'Poppins',
                        fontWeight: FontWeight.w500,
                        fontSize: 13.sp,
                        color: AppColor.colorForecastText),
                    children: <TextSpan>[
                      forecastController.weeklyWeatherForecastListFilter?[index].weather?[0]
                                  .description?.isNotEmpty ==
                              true
                          ? TextSpan(
                              text:
                                  '${forecastController.weeklyWeatherForecastListFilter?[index].wind?.speed.toString()} km/h',
                              style: TextStyle(
                                  fontFamily: 'Poppins',
                                  fontWeight: FontWeight.w400,
                                  fontSize: 13.sp,
                                  color: AppColor.colorTodayScreenText),
                            )
                          : TextSpan(
                              text: 'No Data',
                              style: TextStyle(
                                  fontFamily: 'Poppins',
                                  fontWeight: FontWeight.w400,
                                  fontSize: 13.sp,
                                  color: AppColor.colorTodayScreenText),
                            ),
                    ]),
              ),
            ),
          ),
          SizedBox(
            width: 0.17.sw,
            child: Column(
              children: [
                Obx(() => Text(
                    '${((forecastController.weeklyWeatherForecastListFilter?[index].main?.tempMax ?? 0) - 273.15).toStringAsFixed(0)}${'\u00B0'} / ${((forecastController.weeklyWeatherListFilter?[index].main?.tempMin ?? 0) - 273.15).toStringAsFixed(0)}${'\u00B0'}',
                    style: TextStyle(
                        fontFamily: 'Poppins',
                        fontWeight: FontWeight.w500,
                        fontSize: 12.sp,
                        color: AppColor.colorWhite))),
                Obx(
                  () => Text.rich(
                    style: TextStyle(
                        fontFamily: 'Poppins',
                        fontWeight: FontWeight.w500,
                        fontSize: 12.sp,
                        color: AppColor.colorWhite),
                    TextSpan(
                      children: [
                        WidgetSpan(
                            child: Padding(
                          padding: EdgeInsets.only(left: 8.r),
                          child: Icon(
                            Icons.water_drop,
                            color: AppColor.colorWhite,
                          ),
                        )),
                        TextSpan(
                          text:
                              '${forecastController.weeklyWeatherForecastListFilter?[index].main?.humidity}%',
                        ),
                      ],
                    ),
                  ),
                )
              ],
            ),
          ),
          Icon(
            Icons.keyboard_arrow_right,
            color: AppColor.colorWhite,
          ),
          SizedBox(
            height: 10.h,
          ),
        ],
      ),
    );
  }
}
