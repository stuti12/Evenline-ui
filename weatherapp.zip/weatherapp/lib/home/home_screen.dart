import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:weatherapp/home/controller/home_controller.dart';
import 'package:weatherapp/home/controller/today_controller.dart';
import 'package:weatherapp/home/forecast_screen.dart';
import 'package:weatherapp/home/precipitation_screen.dart';
import 'package:weatherapp/home/today_screen.dart';
import 'package:weatherapp/utils/colors.dart';
import 'package:weatherapp/utils/images.dart';

import '../utils/strings.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  List<Menu> menu = [
    Menu(Strings.textNotification, Icons.notifications),
    Menu(Strings.textSetting, Icons.settings),
    Menu(Strings.textFeedback, Icons.notifications),
    Menu(Strings.textRate, Icons.star),
    Menu(Strings.textShare, Icons.share),
  ];

  List<History> history = [
    History('Chennai, TN', '29', 'Clear'),
    History('New Delhi, TN', '29', 'Party Cloudy'),
  ];

  List<String> tabs = [Strings.textToday, Strings.textForecast, Strings.textPre, Strings.textRadar];
  TodayScreenController todayScreenController = Get.put(TodayScreenController());
  HomeController homeController = Get.put(HomeController());
  bool isSearch = true;

  @override
  void initState() {
    super.initState();
    //  homeController.apiCalls(context);
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: tabs.length,
      child: Scaffold(
        drawer: getDrawer(context),
        appBar: AppBar(
          backgroundColor: AppColor.primaryColorGradient2,
          title: Obx(() => !homeController.isSearch.value
              ? Text(
                  todayScreenController.city.value,
                  style: TextStyle(
                      fontFamily: 'Poppins',
                      fontWeight: FontWeight.w500,
                      color: AppColor.colorWhite,
                      fontSize: 14.sp),
                )
              : Container(
                  width: double.infinity,
                  height: 40,
                  decoration:
                      BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(5)),
                  child: Center(
                    child: TextField(
                      onTap: () {
                        todayScreenController.showPlacePicker(context);

                        homeController.isSearch.value = false;

                        // showPlacePicker();
                      },
                      controller: homeController.controller,
                      decoration: InputDecoration(
                          prefixIcon: const Icon(Icons.search),
                          suffixIcon: IconButton(
                            icon: const Icon(Icons.clear),
                            onPressed: () {
                              homeController.isSearch.value = false;
                              homeController.controller.clear();
                            },
                          ),
                          hintText: 'Search...',
                          border: InputBorder.none),
                    ),
                  ),
                )),
          elevation: 0,
          centerTitle: true,
          actions: [
            Obx(() => !homeController.isSearch.value
                ? IconButton(
                    onPressed: () {
                      homeController.isSearch.value = true;
                    },
                    icon: const Icon(Icons.search))
                : Container())
          ],
          bottom: TabBar(
            isScrollable: true,
            tabs: [for (var tabText in tabs) Tab(text: tabText)],
            indicatorColor: AppColor.colorWhite,
            indicatorSize: TabBarIndicatorSize.label,
            labelStyle: TextStyle(fontFamily: 'Poppins', fontSize: 14.sp),
            unselectedLabelStyle:
                TextStyle(fontFamily: 'Poppins', fontSize: 14.sp, fontWeight: FontWeight.w500),
          ),
        ),
        body:  TabBarView(
          children: [
            const TodayScreen(),
            const ForecastScreen(),
            PrecipitationScreen(),
            Container(),
          ],
        ),
      ),
    );
  }

  Widget getDrawer(BuildContext context) {
    todayScreenController.refreshLocation();
    return Drawer(
      backgroundColor: AppColor.primaryColorGradient2,
      child: ListView(
        children: [
          Column(
            children: [
              Padding(
                padding: EdgeInsets.only(left: 8.w, top: 16.h),
                child: Row(
                  children: [
                    SizedBox(
                      width: 10.w,
                    ),
                    Image.asset(
                      AppImage.imgProfile,
                    ),
                    SizedBox(
                      width: 10.w,
                    ),
                    Text(
                      "Sign In",
                      style: TextStyle(
                          fontFamily: 'Poppins', fontSize: 16.sp, color: AppColor.colorWhite),
                    ),
                    Expanded(
                      child: Align(
                          alignment: Alignment.topRight,
                          child: IconButton(
                              onPressed: () {
                                Navigator.pop(context);
                              },
                              icon: Icon(
                                Icons.close,
                                color: AppColor.colorWhite,
                              ))),
                    ),
                    SizedBox(
                      height: 20.w,
                    ),
                  ],
                ),
              ),
              SizedBox(
                height: 10.h,
              ),
              Divider(
                height: 6.h,
                color: Colors.grey,
                thickness: 0.5,
              ),
              SizedBox(
                height: 20.h,
              ),
              Padding(
                padding: EdgeInsets.only(left: 18.w),
                child: Row(
                  children: [
                    Text(
                      "Location",
                      style: TextStyle(
                          fontFamily: 'Poppins',
                          fontSize: 16.sp,
                          color: AppColor.colorWhite,
                          fontWeight: FontWeight.w500),
                    ),
                    SizedBox(
                      width: 14.w,
                    ),
                    Text(
                      '|',
                      style: TextStyle(color: AppColor.colorTodayScreenText),
                    ),
                    SizedBox(
                      width: 14.w,
                    ),
                    Text(
                      "Edit",
                      style: TextStyle(
                          fontFamily: 'Poppins',
                          fontSize: 16.sp,
                          color: AppColor.colorProgressGradient),
                    ),
                  ],
                ),
              ),
              SizedBox(
                height: 10.h,
              ),

              //location history
              Obx(() => ListView.builder(
                physics: BouncingScrollPhysics(),
                  itemCount: todayScreenController.locations.length,
                  shrinkWrap: true,
                  itemBuilder: (context, int index) {
                    return ListTile(
                      dense: true,
                      leading: Icon(
                        Icons.location_on_rounded,
                        color: AppColor.colorWhite,
                      ),
                      title: Text(
                        todayScreenController.locations[index]['title'],
                        style: TextStyle(
                            fontFamily: 'Poppins',
                            color: AppColor.colorWhite,
                            fontWeight: FontWeight.w500,
                            fontSize: 14.sp),
                      ),
                      subtitle: Text(
                        '${(todayScreenController.locations[index]['temp'])}${'\u00B0'}, ${todayScreenController.locations[index]['description']}',
                        style: TextStyle(
                            fontFamily: 'Poppins',
                            color: AppColor.colorTodayScreenText,
                            fontWeight: FontWeight.w500,
                            fontSize: 12.sp),
                      ),
                    );
                  })),
            ],
          ),
          Divider(
            height: 6.h,
            color: Colors.grey,
            thickness: 0.5,
          ),
          ListTile(
            title: Text(
              Strings.texttools,
              style: TextStyle(
                  fontFamily: 'Poppins', fontWeight: FontWeight.w400, color: AppColor.colorGrey),
            ),
          ),
          ListView.builder(
              shrinkWrap: true,
              itemCount: menu.length,
              itemBuilder: (context, index) {
                return _getMenu(index);
              })
        ],
      ),
    );
  }

  Widget _getMenu(int index) {
    return ListTile(
      onTap: () {
        print('Item${index} Tapped');
      },
      leading: Icon(menu[index].icons),
      title: Text(
        menu[index].name,
        style: TextStyle(
            color: AppColor.colorWhite,
            fontFamily: 'Poppins',
            fontWeight: FontWeight.w600,
            fontSize: 16.sp),
      ),
    );
  }
}

class Menu {
  final String name;
  final IconData icons;

  Menu(this.name, this.icons);
}

class History {
  final String name;
  final String temp;
  final String desc;

  History(
    this.name,
    this.temp,
    this.desc,
  );
}
