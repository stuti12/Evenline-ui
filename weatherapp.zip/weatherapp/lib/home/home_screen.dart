import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:weatherapp/home/controller/today_controller.dart';
import 'package:weatherapp/home/forecast_screen.dart';
import 'package:weatherapp/home/precipitation_screen.dart';
import 'package:weatherapp/home/today_screen.dart';
import 'package:weatherapp/utils/colors.dart';
import 'package:weatherapp/utils/images.dart';

import '../utils/strings.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  TodayScreenController todayScreenController  =Get.put(TodayScreenController());

  List<Menu> menu = [
    Menu(Strings.textNotification, Icons.notifications),
    Menu(Strings.textSetting, Icons.settings),
    Menu(Strings.textFeedback, Icons.notifications),
    Menu(Strings.textRate, Icons.star),
    Menu(Strings.textShare, Icons.share),
  ];

  List<String> tabs = [Strings.textToday, Strings.textForecast,Strings.textPre,Strings.textRadar];

@override
  void initState() {

    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: tabs.length,
      child: Scaffold(
        drawer: getDrawer(),
        appBar: AppBar(
          backgroundColor: AppColor.primaryColorGradient2,
          title:Obx(()=>Text(
            todayScreenController.city.value,
            style: TextStyle(
                fontFamily: 'Poppins',
                fontWeight: FontWeight.w500,
                color: AppColor.colorWhite,
                fontSize: 14.sp),
          )),
          elevation: 0,
          centerTitle: true,
          actions: [
            IconButton(
                onPressed: () {},
                icon: Icon(
                  Icons.more_vert,
                  color: AppColor.colorWhite,
                ))
          ],
          bottom: TabBar(isScrollable: true,
            tabs: [
              for (var tabText in tabs)
                Tab(text: tabText)
            ],
            indicatorColor: AppColor.colorWhite,
            indicatorSize: TabBarIndicatorSize.label,
            labelStyle: TextStyle(fontFamily: 'Poppins', fontSize: 14.sp),
            unselectedLabelStyle:
                TextStyle(fontFamily: 'Poppins', fontSize: 14.sp,fontWeight: FontWeight.w500),

          ),
        ),
        body: const TabBarView(
          children: [
            TodayScreen(),
            ForecastScreen(),
            PrecipitationScreen(),
            TodayScreen(),
          ],
        ),
      ),
    );
  }

  Widget getDrawer() {
    return Drawer(
      backgroundColor: AppColor.primaryColorGradient2,
      child: ListView(
        children: [
          Column(
            children: [
              Padding(
                padding:  EdgeInsets.only(left: 8.w,top: 16.h),
                child: Row(
                  children: [
                    SizedBox(
                      width: 10.w,
                    ),
                    Image.asset(
                      AppImage.imgProfile,
                    ),
                    SizedBox(
                      width: 10.w,
                    ),
                    Text(
                      "Sign In",
                      style: TextStyle(
                          fontFamily: 'Poppins',
                          fontSize: 16.sp,
                          color: AppColor.colorWhite),
                    ),
                    Expanded(
                      child: Align(
                          alignment: Alignment.topRight,
                          child: IconButton(
                              onPressed: () {
                                Navigator.pop(context);
                              },
                              icon: Icon(
                                Icons.close,
                                color: AppColor.colorWhite,
                              ))),
                    ),
                    SizedBox(
                      height: 20.w,
                    ),
                  ],
                ),
              ),
              SizedBox(
                height: 10.h,
              ),
              Divider(
                height: 6.h,
                color: Colors.grey,
                thickness: 0.5,
              ),
              SizedBox(
                height: 20.h,
              ),
              Padding(
                padding: EdgeInsets.only(left: 18.w),
                child: Row(
                  children: [
                    Text(
                      "Location",
                      style: TextStyle(
                          fontFamily: 'Poppins',
                          fontSize: 16.sp,
                          color: AppColor.colorWhite,
                          fontWeight: FontWeight.w500),
                    ),
                    SizedBox(
                      width: 14.w,
                    ),
                    Text(
                      '|',
                      style:
                      TextStyle(color: AppColor.colorTodayScreenText),
                    ),
                    SizedBox(
                      width: 14.w,
                    ),
                    Text(
                      "Edit",
                      style: TextStyle(
                          fontFamily: 'Poppins',
                          fontSize: 16.sp,
                          color: AppColor.colorProgressGradient),
                    ),
                  ],
                ),
              ),
              SizedBox(
                height: 10.h,
              ),
              ListTile(dense: true,
                leading: Icon(
                  Icons.location_on_rounded,
                  color: AppColor.colorWhite,
                ),
                title: Text(
                  'Chennai',
                  style: TextStyle(
                      fontFamily: 'Poppins', color: AppColor.colorWhite,fontWeight: FontWeight.w500,fontSize: 14.sp),
                ),
                subtitle:  Text(
                  '29\u00B0 Clear',
                  style: TextStyle(
                      fontFamily: 'Poppins', color: AppColor.colorTodayScreenText,fontWeight: FontWeight.w500,fontSize: 12.sp),
                ),
              ),
              ListTile(dense: true,
                leading: Icon(
                  Icons.location_on_rounded,
                  color: AppColor.colorWhite,
                ),
                title: Text(
                  'New Deli,IND',
                  style: TextStyle(
                      fontFamily: 'Poppins', color: AppColor.colorWhite,fontWeight: FontWeight.w500,fontSize: 14.sp),
                ),
                subtitle:  Text(
                  '39\u00B0 Partly Cloudy',
                  style: TextStyle(
                      fontFamily: 'Poppins', color: AppColor.colorTodayScreenText,fontWeight: FontWeight.w500,fontSize: 12.sp),
                ),
              )
            ],
          ),
          Divider(
            height: 6.h,
            color: Colors.grey,
            thickness: 0.5,
          ),
          ListTile(
            title: Text(
              Strings.texttools,
              style: TextStyle(
                  fontFamily: 'Poppins',
                  fontWeight: FontWeight.w400,
                  color: AppColor.colorGrey),
            ),
          ),
          ListView.builder(shrinkWrap: true,itemCount: menu.length,
              itemBuilder: (context,index){
            return _getMenu(index);
          })
        ],
      ),
    );
  }
  Widget _getMenu(int index) {
    return  ListTile(onTap: (){
      print('Item${index} Tapped');
    },
      leading: Icon(
          menu[index].icons
      ),
      title: Text(
        menu[index].name,
        style: TextStyle(
            color: AppColor.colorWhite,
            fontFamily: 'Poppins',
            fontWeight: FontWeight.w600,
            fontSize: 16.sp),
      ),
    );
  }
}

class Menu{
 final String name;
 final IconData icons;
  Menu(this.name,this.icons);
}