import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:weatherapp/home/home_screen.dart';

import '../onboarding/welcome.dart';

int? isviewed;

class SplashScreen extends StatefulWidget {
  const SplashScreen({Key? key}) : super(key: key);

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  _checkOnBoard() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    isviewed = prefs.getInt('onBoard');
    Timer(
        const Duration(seconds: 2),
        () => isviewed != 0
            ? Navigator.pushReplacement(
                context, MaterialPageRoute(builder: (context) => const WelcomeScreen()))
            : Navigator.pushReplacement(
                context, MaterialPageRoute(builder: (context) => const HomeScreen())));
  }

  @override
  void initState() {
    _checkOnBoard();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
          height: 1.sh,
          width: 1.sw,
          child: Image.asset(
            'assets/images/logo.png',
            fit: BoxFit.fill,
          )),
    );
  }
}
