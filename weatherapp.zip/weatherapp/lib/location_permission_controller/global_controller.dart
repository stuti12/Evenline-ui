import 'dart:io';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:get/get.dart';
import 'package:location/location.dart' hide LocationAccuracy;
class GlobalController extends GetxController {
  final RxBool loading = true.obs;
  RxDouble long = 0.0.obs;
  RxDouble lat = 0.0.obs;


  @override
  void onInit() {
    super.onInit();
  }

  getLocation(BuildContext context) async {
    bool isServiceEnabled;
    LocationPermission locationPermission;
    isServiceEnabled = await Geolocator.isLocationServiceEnabled();

    if (!isServiceEnabled) {
      if (Platform.isAndroid) {
        Location location =  Location();

        isServiceEnabled = await location.requestService();
        if (isServiceEnabled) {
          getLocation(context);
        }
      } else {
        await Geolocator.openLocationSettings();
      }
      return Future.error("Location not enabled");
    }

    locationPermission = await Geolocator.checkPermission();
    if (locationPermission == LocationPermission.deniedForever) {
      return Future.error("Location denied");
    } else if (locationPermission == LocationPermission.denied) {
      locationPermission = await Geolocator.requestPermission();
    }

    if (locationPermission == LocationPermission.denied) {
      Geolocator.openAppSettings();
      return Future.error("Location denied");
    }

    update();
  }


}