package com.example.strengthstudio.myprograms

import android.os.Bundle
import android.view.MotionEvent
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.example.strengthstudio.R
import com.example.strengthstudio.databinding.ActivityReplyBinding
import com.example.strengthstudio.myprograms.adapter.CommentReplyAdapter
import com.example.strengthstudio.myprograms.data.CommentReplyData
import com.example.strengthstudio.utils.hideKeyboard
import java.time.LocalDate

class ReplyActivity : AppCompatActivity() {
    private val binding: ActivityReplyBinding by lazy {
        ActivityReplyBinding.inflate(layoutInflater)
    }
    private var commentReplyList = mutableListOf<CommentReplyData>()
    private lateinit var communityReplyAdapter: CommentReplyAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        binding.toolbarReply.tvTitle.visibility = View.VISIBLE
        binding.toolbarReply.tvTitle.text = "Reply (25)"

        setAdapter()
        setData()
        setClickListeners()
    }

    private fun setClickListeners() {
        binding.apply {
            toolbarReply.arrowImageViewBack.setOnClickListener {
                finish()
            }
            val imageProfile = intent.getIntExtra("ProfileImage", 0)
            val name = intent.getStringExtra("Name")
            val desc = intent.getStringExtra("Description")
            val time = intent.getStringExtra("time")
            val likeCount = intent.getStringExtra("likeCount")
            val dislikeCount = intent.getStringExtra("dislikeCount")

            textCaden.text = name
            imgUser.setImageResource(imageProfile)
            textJustNow.text = time
            textComment.text = desc
            textLike.text = likeCount
            textDislike.text = dislikeCount
            var like = Integer.parseInt(likeCount.toString())
            var dislike = Integer.parseInt(dislikeCount.toString())
            imgLike.setOnClickListener {
                like++
                textLike.text = like.toString()
            }

            imgDislike.setOnClickListener {
                dislike++
                textDislike.text = dislike.toString()
            }
            etTypeYourComments.setOnTouchListener(object : View.OnTouchListener {
                override fun onTouch(v: View?, event: MotionEvent?): Boolean {
                    val DRAWABLE_RIGHT = 2
                    if (event?.action == MotionEvent.ACTION_UP) {
                        if (event.rawX >= (etTypeYourComments.right - etTypeYourComments.compoundDrawables[DRAWABLE_RIGHT].bounds.width())) {
                            when {
                                etTypeYourComments.text.isNullOrEmpty() -> {
                                    etTypeYourComments.error = "Required"
                                    return false
                                }
                                else -> {
                                    val current = LocalDate.now()
                                    commentReplyList.add(CommentReplyData(commentReplyList.size, R.drawable.ic_person_profile, "Vishal", etTypeYourComments.text.toString(), current.toString()))
                                    communityReplyAdapter.notifyItemInserted(commentReplyList.size - 1)
                                    rvReply.smoothScrollToPosition(commentReplyList.size - 1)

                                    etTypeYourComments.text?.clear()
                                    return true
                                }
                            }
                        }
                    }
                    return false
                }

            })
        }
    }

    override fun dispatchTouchEvent(ev: MotionEvent?): Boolean {
        if (currentFocus != null) {
            binding.mainViewCommentReply.hideKeyboard()
        }
        return super.dispatchTouchEvent(ev)
    }

    private fun setData() {
        commentReplyList = mutableListOf(
            CommentReplyData(1, R.drawable.ic_person_profile, getString(R.string.caden), getString(R.string.you_can_t_go_wrong_with_this_bundle_sick_programs_thank_you_jamal_and_sst_team), getString(R.string.just_now)), CommentReplyData(2, R.drawable.ic_person_profile, getString(R.string.caden), getString(R.string.you_can_t_go_wrong_with_this_bundle_sick_programs_thank_you_jamal_and_sst_team), getString(R.string.just_now)),
            CommentReplyData(1, R.drawable.ic_person_profile, getString(R.string.caden), getString(R.string.you_can_t_go_wrong_with_this_bundle_sick_programs_thank_you_jamal_and_sst_team), getString(R.string.just_now))
        )
        communityReplyAdapter.submitList(commentReplyList)

    }

    private fun setAdapter() {
        binding.apply {
            communityReplyAdapter = CommentReplyAdapter(this@ReplyActivity)
            rvReply.adapter = communityReplyAdapter

        }
    }
}