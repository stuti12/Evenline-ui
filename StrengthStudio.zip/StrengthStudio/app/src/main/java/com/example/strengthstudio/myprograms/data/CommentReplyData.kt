package com.example.strengthstudio.myprograms.data

data class CommentReplyData(var id: Int, var profileImage: Int?, var name: String, var description: String, var time: String)