package com.example.strengthstudio.programdetails

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import androidx.fragment.app.Fragment
import com.example.strengthstudio.R
import com.example.strengthstudio.databinding.FragmentReviewsBinding
import com.example.strengthstudio.utils.toast
import com.google.android.material.bottomsheet.BottomSheetDialog
import java.time.LocalDate

class ReviewsFragment : Fragment() {
    private val binding: FragmentReviewsBinding by lazy {
        FragmentReviewsBinding.inflate(layoutInflater)
    }
    private lateinit var adapter: ReviewAdapter
    private var dataList = listOf<ReviewData>()

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        // Inflate the layout for this fragment
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        setAdapter()
    }

    private fun setAdapter() {
        adapter = ReviewAdapter(requireActivity())

        dataList = listOf(ReviewData(1, R.drawable.ic_person_profile, "Cardon", "October 9, 2021", "You can’t go wrong with this bundle, sick programs. Thank you Jamal and SST Team"), ReviewData(1, R.drawable.ic_person_profile, "Cardon", "October 9, 2021", "You can’t go wrong with this bundle, sick programs. Thank you Jamal and SST Team"))

        binding.rvReview.adapter = adapter
        adapter.submitList(dataList)

        Log.d("size", "${dataList.size}")
        if (dataList.isEmpty()) {
            binding.rvReview.visibility = View.GONE
            binding.viewNoData.visibility = View.VISIBLE
        } else {
            binding.rvReview.visibility = View.VISIBLE
            binding.viewNoData.visibility = View.GONE
        }
        binding.btnAddYourReview.setOnClickListener {
            showBottomSheetDialog()
        }

    }

    private fun showBottomSheetDialog() {
        val bottomSheetDialog = BottomSheetDialog(requireActivity())
        val view = layoutInflater.inflate(R.layout.bottomsheet_program_review, null)
        bottomSheetDialog.setContentView(view)
        val buttonClose: Button = view.findViewById(R.id.btnClose)
        val etReview: EditText = view.findViewById(R.id.etReview)
        bottomSheetDialog.show()
        val buttonSubmit: Button = view.findViewById(R.id.btnSubmit)
        buttonSubmit.setOnClickListener {
            val current = LocalDate.now()
            dataList = listOf(ReviewData(3, R.drawable.ic_person_profile, "Cardon", current.toString(), etReview.text.toString()))
            adapter.submitList(dataList)
            requireActivity().toast(getString(R.string.text_review_submitte))
        }
        buttonClose.setOnClickListener {
            bottomSheetDialog.dismiss()
        }

    }

    override fun onDestroy() {
        super.onDestroy()
        return
    }
}