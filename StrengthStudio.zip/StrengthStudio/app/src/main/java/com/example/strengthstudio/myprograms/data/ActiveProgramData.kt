package com.example.strengthstudio.myprograms.data

data class ActiveProgramData(val image: Int, val title: String, val duration: String)
