package com.example.strengthstudio.completexercise

import android.os.Bundle
import android.text.SpannableString
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.method.LinkMovementMethod
import android.view.MotionEvent
import android.view.View
import android.view.ViewTreeObserver
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DividerItemDecoration
import com.example.strengthstudio.R
import com.example.strengthstudio.completexercise.adapter.ParentItemAdapter
import com.example.strengthstudio.completexercise.data.ChildData
import com.example.strengthstudio.completexercise.data.ParentData
import com.example.strengthstudio.databinding.ActivityCompleteExerciseBinding
import com.example.strengthstudio.utils.MySpannable
import com.example.strengthstudio.utils.hideKeyboard


class CompleteExerciseActivity : AppCompatActivity() {
    private val binding: ActivityCompleteExerciseBinding by lazy {
        ActivityCompleteExerciseBinding.inflate(layoutInflater)
    }
    private lateinit var adapter: ParentItemAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        setClickListener()
        setData()
    }

    override fun dispatchTouchEvent(ev: MotionEvent?): Boolean {
        if (currentFocus != null) {
            binding.mainViewCompleteEx.hideKeyboard()
        }
        return super.dispatchTouchEvent(ev)
    }

    private fun setData() {
        adapter = ParentItemAdapter(ParentItemList())
        binding.rvExerciseDetail.adapter = adapter
        val verticalDecoration = DividerItemDecoration(binding.rvExerciseDetail.context, DividerItemDecoration.VERTICAL)
        val verticalDivider = ContextCompat.getDrawable(this, R.drawable.horizontal_devider)
        verticalDecoration.setDrawable(verticalDivider!!)
        binding.rvExerciseDetail.addItemDecoration(verticalDecoration)

    }

    private fun ParentItemList(): List<ParentData> {
        val itemList: MutableList<ParentData> = ArrayList()
        val item = ParentData(ChildItemList())
        itemList.add(item)
        val item2 = ParentData(ChildItemList())
        itemList.add(item2)
        val item3 = ParentData(ChildItemList())
        itemList.add(item3)
        val item4 = ParentData(ChildItemList())
        itemList.add(item4)
        return itemList
    }

    private fun ChildItemList(): List<ChildData> {
        val ChildItemList: MutableList<ChildData> = ArrayList()
        ChildItemList.add(ChildData(68))
        return ChildItemList
    }

    private fun setClickListener() {
        binding.apply {
            toolbarCompleteExercise.arrowImageViewBack.setOnClickListener {
                finish()
            }
            makeTextViewResizable(textCompleteExerciseSubTitle, 1, "more", true)
        }
    }

    fun makeTextViewResizable(tv: TextView, maxLine: Int, expandText: String, viewMore: Boolean) {
        if (tv.tag == null) {
            tv.tag = tv.text
        }
        val vto = tv.viewTreeObserver
        vto.addOnGlobalLayoutListener(object : ViewTreeObserver.OnGlobalLayoutListener {
            override fun onGlobalLayout() {
                val text: String
                val lineEndIndex: Int
                val obs = tv.viewTreeObserver
                obs.removeOnGlobalLayoutListener(this)
                if (maxLine == 0) {
                    lineEndIndex = tv.layout.getLineEnd(0)
                    text = tv.text.subSequence(0, lineEndIndex - expandText.length + 1).toString() + " " + expandText
                } else if (maxLine > 0 && tv.lineCount >= maxLine) {
                    lineEndIndex = tv.layout.getLineEnd(maxLine - 1)
                    text = tv.text.subSequence(0, lineEndIndex - expandText.length + 1).toString() + " " + expandText
                } else {
                    lineEndIndex = tv.layout.getLineEnd(tv.layout.lineCount - 1)
                    text = tv.text.subSequence(0, lineEndIndex).toString() + " " + expandText
                }
                tv.text = text
                tv.movementMethod = LinkMovementMethod.getInstance()
                tv.setText(
                    addClickablePartTextViewResizable(
                        SpannableString(tv.text.toString()), tv, expandText, viewMore
                    ), TextView.BufferType.SPANNABLE
                )
            }
        })
    }

    private fun addClickablePartTextViewResizable(strSpanned: Spanned, tv: TextView, spanableText: String, viewMore: Boolean): SpannableStringBuilder? {
        val str = strSpanned.toString()
        val ssb = SpannableStringBuilder(strSpanned)

        if (str.contains(spanableText)) {
            ssb.setSpan(object : MySpannable(false) {
                override fun onClick(widget: View) {
                    tv.layoutParams = tv.layoutParams
                    tv.setText(tv.tag.toString(), TextView.BufferType.SPANNABLE)
                    tv.invalidate()
                    if (viewMore) {
                        makeTextViewResizable(tv, 1, "more", false)
                    } else {
                        makeTextViewResizable(tv, 3, "less", true)
                    }
                }
            }, str.indexOf(spanableText), str.indexOf(spanableText) + spanableText.length, 0)
        }
        return ssb
    }

}