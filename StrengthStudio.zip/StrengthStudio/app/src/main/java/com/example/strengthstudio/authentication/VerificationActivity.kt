package com.example.strengthstudio.authentication

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.MotionEvent
import android.view.inputmethod.InputMethodManager
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.addTextChangedListener
import com.example.strengthstudio.R
import com.example.strengthstudio.databinding.ActivityVerificationBinding
import com.example.strengthstudio.profile.CreateProfileActivity
import com.example.strengthstudio.utils.hideKeyboard
import com.example.strengthstudio.utils.toast

class VerificationActivity : AppCompatActivity() {
    private val binding: ActivityVerificationBinding by lazy {
        ActivityVerificationBinding.inflate(layoutInflater)
    }
    var flag: Boolean? = false
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        setClickListener()
        flag = intent.getBooleanExtra("Flag", true)
        /* flagForget = intent.getBooleanExtra("FlagForget",false)*/
    }

    private fun setClickListener() {
        binding.apply {
            toolbar.arrowImageViewBack.setOnClickListener {
                finish()
            }
            btnVerify.setOnClickListener {
                if (validation()) {
                    if (flag == true) {
                        startActivity(Intent(this@VerificationActivity, CreateProfileActivity::class.java))
                    } else {
                        startActivity(Intent(this@VerificationActivity, ResetActivity::class.java))
                    }
                } else {
                    this@VerificationActivity.toast(getString(R.string.txt_required_otp))
                }
            }
            etOtp.addTextChangedListener {
                if (it.toString().trim().isNotEmpty()) {
                    etOtp2.requestFocus()
                }
            }
            etOtp2.addTextChangedListener {
                if (it.toString().trim().isNotEmpty()) {
                    etOtp3.requestFocus()
                } else {
                    etOtp.requestFocus()
                }
            }

            etOtp3.addTextChangedListener {
                if (it.toString().trim().isNotEmpty()) {
                    etOtp4.requestFocus()
                } else {
                    etOtp2.requestFocus()
                }
            }
            etOtp4.addTextChangedListener {
                if (it.toString().trim().isNotEmpty()) {
                    val hideKeyboard =
                        getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager
                    hideKeyboard?.hideSoftInputFromWindow(etOtp4.windowToken, 0)
                } else {
                    binding.etOtp3.requestFocus()
                }
            }

        }
    }

    private fun validation(): Boolean {
        binding.apply {
            return !(etOtp.text.isNullOrEmpty() || etOtp2.text.isNullOrEmpty() || etOtp3.text.isNullOrEmpty() || etOtp4.text.isNullOrEmpty())
        }
    }

    override fun dispatchTouchEvent(ev: MotionEvent?): Boolean {
        if (currentFocus != null) {
            binding.mainVerification.hideKeyboard()
        }
        return super.dispatchTouchEvent(ev)
    }
}