package com.example.strengthstudio.authentication

import android.content.Intent
import android.os.Bundle
import android.view.MotionEvent
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.addTextChangedListener
import com.example.strengthstudio.R
import com.example.strengthstudio.databinding.ActivityForgetPasswordBinding
import com.example.strengthstudio.utils.hideKeyboard
import com.example.strengthstudio.utils.makeLinks
import com.example.strengthstudio.utils.toast

class ForgetPasswordActivity : AppCompatActivity() {
    private val binding: ActivityForgetPasswordBinding by lazy {
        ActivityForgetPasswordBinding.inflate(layoutInflater)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        binding.toolbar.tvTitle.visibility = View.INVISIBLE
        setSpannableText()
        setClickListener()
    }

    private fun setSpannableText() {
        binding.textRememberPassword.makeLinks(Pair(getString(R.string.text_signin), View.OnClickListener {
            val intent = Intent(applicationContext, SigninActivity::class.java)
            startActivity(intent)
        }))
    }

    override fun dispatchTouchEvent(ev: MotionEvent?): Boolean {
        if (currentFocus != null) {
            binding.mainForgetView.hideKeyboard()
        }
        return super.dispatchTouchEvent(ev)
    }

    private fun validation(): Boolean {
        binding.apply {
            return if (etEmail.text.isNullOrEmpty()) {
                textLayoutEmail.error = "Required Email ID"
                false
            } else {
                textLayoutEmail.error = null
                true
            }
        }
    }

    override fun onBackPressed() {
//        startActivity(Intent(this, SigninActivity::class.java))
    }

    private fun setClickListener() {
        binding.apply {
            btnForgetPassword.setOnClickListener {
                if (validation()) {
                    this@ForgetPasswordActivity.toast(getString(R.string.text_pasword_sent))
                    val intent = Intent(this@ForgetPasswordActivity, VerificationActivity::class.java)
                    intent.putExtra("Flag", false)
                    startActivity(intent)
                    // intent.putExtra("FlagForget",false)
                }
            }

            etEmail.addTextChangedListener {
                textLayoutEmail.error = null
            }


            toolbar.arrowImageViewBack.setOnClickListener {
                finish()
            }
        }
    }
}