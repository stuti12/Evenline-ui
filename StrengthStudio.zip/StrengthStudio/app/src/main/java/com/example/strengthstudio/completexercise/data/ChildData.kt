package com.example.strengthstudio.completexercise.data

class ChildData(var textKg: Int)

class ParentData(var ChildItemList: List<ChildData>)

