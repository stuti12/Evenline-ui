package com.example.strengthstudio.completexercise.adapter

import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.RecyclerView.RecycledViewPool
import com.example.strengthstudio.R
import com.example.strengthstudio.completexercise.data.ParentData


class ParentItemAdapter internal constructor(itemList: List<ParentData>) : RecyclerView.Adapter<ParentItemAdapter.ParentViewHolder>() {

    private val viewPool = RecycledViewPool()
    private val itemList: List<ParentData>
    override fun onCreateViewHolder(viewGroup: ViewGroup, i: Int): ParentViewHolder {


        val view: View = LayoutInflater.from(viewGroup.context).inflate(R.layout.item_exercise_parent, viewGroup, false)
        return ParentViewHolder(view)
    }

    override fun onBindViewHolder(parentViewHolder: ParentViewHolder, position: Int) {

        val parentItem: ParentData = itemList[position]

        val layoutManager = LinearLayoutManager(
            parentViewHolder.ChildRecyclerView.context, LinearLayoutManager.HORIZONTAL,
            false
        )

        layoutManager.initialPrefetchItemCount = parentItem.ChildItemList.size

        val childItemAdapter = ChildItemAdapter(parentItem.ChildItemList)
        parentViewHolder.ChildRecyclerView.layoutManager = layoutManager
        parentViewHolder.ChildRecyclerView.adapter = childItemAdapter
        parentViewHolder.ChildRecyclerView.setRecycledViewPool(viewPool)
    }


    override fun getItemCount(): Int {
        Log.d("Size", itemList.size.toString())
        return itemList.size
    }


    inner class ParentViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val ChildRecyclerView: RecyclerView

        init {

            ChildRecyclerView = itemView
                .findViewById(R.id.parentRecyclerview)
        }
    }

    init {
        this.itemList = itemList
    }
}
