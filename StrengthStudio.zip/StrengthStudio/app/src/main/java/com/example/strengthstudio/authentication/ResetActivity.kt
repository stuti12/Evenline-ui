package com.example.strengthstudio.authentication

import android.content.Intent
import android.os.Bundle
import android.view.MotionEvent
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.addTextChangedListener
import com.example.strengthstudio.R
import com.example.strengthstudio.databinding.ActivityResetBinding
import com.example.strengthstudio.utils.hideKeyboard
import com.example.strengthstudio.utils.toast
import com.google.android.material.bottomsheet.BottomSheetDialog


class ResetActivity : AppCompatActivity() {
    private val binding: ActivityResetBinding by lazy {
        ActivityResetBinding.inflate(layoutInflater)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        setClickListener()
    }

    override fun dispatchTouchEvent(ev: MotionEvent?): Boolean {
        if (currentFocus != null) {
            binding.mainResetView.hideKeyboard()
        }
        return super.dispatchTouchEvent(ev)
    }

    private fun setClickListener() {
        binding.apply {
            toolbar.arrowImageViewBack.setOnClickListener {
                //startActivity(Intent(this@ResetActivity,VerificationActivity::class.java))
                finish()
            }

            etCPassword.addTextChangedListener {
                validation()
            }

            etPassword.addTextChangedListener {
                textLayoutPassword.error = null
            }

            btnSubmit.setOnClickListener {
                if (validation()) {
                    this@ResetActivity.toast("New Password Set")
                    showBottomSheetDialog()
                    startActivity(Intent(this@ResetActivity, SigninActivity::class.java))
                    finish()
                } else {
                    this@ResetActivity.toast("Please check again")
                }
            }
        }
    }

    private fun showBottomSheetDialog() {
        val bottomSheetDialog = BottomSheetDialog(this)
        bottomSheetDialog.setContentView(R.layout.bottom_sheet_password_change)
        bottomSheetDialog.show()
    }

    private fun validation(): Boolean {
        binding.apply {
            val pswd: String = etPassword.text.toString()
            val cpswd: String = etCPassword.text.toString()
            when {
                etPassword.text.isNullOrEmpty() -> {
                    textLayoutPassword.error = getString(R.string.error_require_password)
                    return false
                }
                etCPassword.text.isNullOrEmpty() -> {
                    textLayoutCPassword.error = getString(R.string.error_require_password)
                    return false
                }

                pswd != cpswd -> {
                    textLayoutCPassword.error = getString(R.string.text_password_not_match)
                    return false
                }
                else -> {
                    textLayoutPassword.error = null
                    textLayoutCPassword.error = null
                    return true
                }
            }
        }
    }


}