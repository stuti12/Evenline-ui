package com.example.strengthstudio.myprograms.adapter

import android.content.Context
import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.Filter
import android.widget.Filterable
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.strengthstudio.databinding.ItemActiveProgramLayoutBinding
import com.example.strengthstudio.myprograms.data.ActiveProgramData
import java.util.*

class ActiveProgramAdapter(private val context: Context) : ListAdapter<ActiveProgramData, ActiveProgramAdapter.MyViewHolder>(DiffUtilCallBack()), Filterable {
    var onItemClick: ((ActiveProgramData) -> Unit)? = null
    var filterList: MutableList<ActiveProgramData> = mutableListOf<ActiveProgramData>()
    override fun submitList(list: MutableList<ActiveProgramData>?) {
        super.submitList(list)
        list?.let {
            filterList.clear()
            filterList.addAll(list)
        }
    }

    inner class MyViewHolder(private val binding: ItemActiveProgramLayoutBinding) : RecyclerView.ViewHolder(binding.root) {
        val cardRow = binding.cardActive
        fun bind(dataModel: ActiveProgramData, position: Int) {
            binding.apply {
                imgActive.setImageResource(dataModel.image)
                textTitle.text = dataModel.title
                textDuration.text = dataModel.duration

            }

        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val binding = ItemActiveProgramLayoutBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return MyViewHolder(binding)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val currentItem = getItem(position)
        holder.bind(currentItem, position)
        holder.cardRow.setOnClickListener {
            onItemClick?.invoke(currentItem)
        }
    }

    override fun getFilter(): Filter {
        return object : Filter() {

            override fun performFiltering(constraint: CharSequence?): FilterResults {
                val charSearch = constraint.toString()
                val resultList: ArrayList<ActiveProgramData> = arrayListOf()
                if (charSearch.isEmpty()) {
                    resultList.clear()
                    resultList.addAll(filterList)
                } else {
                    resultList.clear()
                    for (row in filterList) {
                        if (row.title.lowercase(Locale.getDefault()).contains(constraint.toString().lowercase((Locale.getDefault())))) {
                            resultList.add(row)
                            Log.d("result", "$resultList")

                        }
                    }
                }
                val filterResults = FilterResults()
                filterResults.values = resultList
                return filterResults
            }

            override fun publishResults(constraint: CharSequence?, results: FilterResults?) {

                /*  filterList.clear()
                  filterList.addAll(results?.values as List<VideoLibraryData>)*/
                Log.d("Publish", "${results?.values}")
                submitList(results?.values as MutableList<ActiveProgramData>)
            }

        }
    }


}

class DiffUtilCallBack : DiffUtil.ItemCallback<ActiveProgramData>() {
    override fun areItemsTheSame(oldItem: ActiveProgramData, newItem: ActiveProgramData): Boolean {
        return oldItem.title == newItem.title
    }

    override fun areContentsTheSame(oldItem: ActiveProgramData, newItem: ActiveProgramData): Boolean {
        return areItemsTheSame(oldItem, newItem)
    }

}