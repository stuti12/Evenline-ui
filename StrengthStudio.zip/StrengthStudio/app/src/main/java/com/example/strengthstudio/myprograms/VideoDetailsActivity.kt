package com.example.strengthstudio.myprograms

import android.net.Uri
import android.os.Bundle
import android.widget.MediaController
import androidx.appcompat.app.AppCompatActivity
import com.example.strengthstudio.databinding.ActivityVideoDetailsBinding

class VideoDetailsActivity : AppCompatActivity() {
    private val binding: ActivityVideoDetailsBinding by lazy {
        ActivityVideoDetailsBinding.inflate(layoutInflater)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        setClickListeners()
        setIntentData()
    }

    private fun setIntentData() {
        val videoName = intent.getStringExtra("VideoName")
        val desc = intent.getStringExtra("Description")
        val videoTime = intent.getStringExtra("Time")
        binding.apply {
            textVideoTitle.text = videoName
            textVideoDescription.text = desc
            textVideoTime.text = videoTime

            val stringUrl: String = "https://flutter.github.io/assets-for-api-docs/assets/videos/bee.mp4"
            val uri: Uri = Uri.parse(stringUrl)

            var mediaController: MediaController? = null
            if (mediaController == null) {
                mediaController = MediaController(this@VideoDetailsActivity)
                mediaController.setAnchorView(binding.videoViewDetails)
            }

            videoViewDetails.setVideoURI(uri)
            videoViewDetails.setMediaController(mediaController)
            videoViewDetails.requestFocus()
            videoViewDetails.start()

        }
    }

    private fun setClickListeners() {

        binding.apply {
            imgBack.setOnClickListener {
                finish()
            }
        }

    }
}