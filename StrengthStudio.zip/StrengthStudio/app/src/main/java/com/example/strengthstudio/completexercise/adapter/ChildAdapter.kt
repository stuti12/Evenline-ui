package com.example.strengthstudio.completexercise.adapter


import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import androidx.recyclerview.widget.RecyclerView
import com.example.strengthstudio.R
import com.example.strengthstudio.completexercise.data.ChildData


class ChildItemAdapter internal constructor(childItemList: List<ChildData>) : RecyclerView.Adapter<ChildItemAdapter.ChildViewHolder>() {
    private val ChildItemList: List<ChildData>
    override fun onCreateViewHolder(viewGroup: ViewGroup, i: Int): ChildViewHolder {
        val view: View = LayoutInflater.from(viewGroup.context).inflate(R.layout.item_exercise_child, viewGroup, false)
        return ChildViewHolder(view)
    }

    override fun onBindViewHolder(childViewHolder: ChildViewHolder, position: Int) {
        val childItem: ChildData = ChildItemList[position]
//        childViewHolder.ChildItemTitle.setText(childItem.textKg)
    }

    override fun getItemCount(): Int {
        Log.d("Childsize", "${ChildItemList.size}")
        return ChildItemList.size
    }

    inner class ChildViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var ChildItemTitle: EditText

        init {
            ChildItemTitle = itemView.findViewById(R.id.et80kg) as EditText
        }
    }

    // Constructor
    init {
        ChildItemList = childItemList
    }
}