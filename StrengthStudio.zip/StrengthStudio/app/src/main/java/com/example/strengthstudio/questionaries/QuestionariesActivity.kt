package com.example.strengthstudio.questionaries

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import androidx.appcompat.app.AppCompatActivity
import com.example.strengthstudio.R
import com.example.strengthstudio.databinding.ActivityQuestionariesBinding
import com.example.strengthstudio.myprograms.MyProgramsActivity
import com.example.strengthstudio.utils.setColouredSpan

class QuestionariesActivity : AppCompatActivity() {
    private val binding: ActivityQuestionariesBinding by lazy {
        ActivityQuestionariesBinding.inflate(layoutInflater)
    }
    private var position = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        setClickListeners()
        binding.toolbarQuestionaries.tvTitle.visibility = View.VISIBLE
        binding.toolbarQuestionaries.tvTitle.text = "Questionnaires"
    }

    override fun onBackPressed() {
        binding.apply {
            when (position) {
                0 -> {
                    super.onBackPressed()
                }
                1 -> {
                    cardViewQuestionaries4.visibility = View.GONE
                    cardViewQuestionaries3.visibility = View.VISIBLE
                    position = stepView.currentStep - 1
                    binding.stepView.done(false)
                    binding.stepView.go(position, true)
                    btnQuestThreeNext.text = getString(R.string.text_next)
                }
                2 -> {
                    cardViewQuestionaries3.visibility = View.GONE
                    cardViewQuestionaries2.visibility = View.VISIBLE
                    position = stepView.currentStep - 1
                    binding.stepView.done(false)
                    binding.stepView.go(position, true)
                    btnQuestTwoNext.text = getString(R.string.text_next)
                }
                else -> {
                    cardViewQuestionaries2.visibility = View.GONE
                    cardViewQuestionaries1.visibility = View.VISIBLE
                    position = stepView.currentStep - 1
                    binding.stepView.done(false)
                    binding.stepView.go(position, true)
                    btnNext.text = getString(R.string.text_next)
                }
            }
        }
    }

    private fun setClickListeners() {
        binding.apply {
            toolbarQuestionaries.arrowImageViewBack.setOnClickListener {
                finish()

            }
            val stepQues = mutableListOf("General", "Squat", "BenchPress", "Deadlift")
            stepView.setSteps(stepQues)
            textDescriptionQuestionTitle.setColouredSpan("THIS QUESTIONNAIRE HAS 4 PARTS", Color.WHITE)

            val adapter = ArrayAdapter.createFromResource(this@QuestionariesActivity, R.array.feeds, android.R.layout.simple_spinner_item)
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            filledExposedDropdown.setAdapter(adapter)
            filledExposedDropdownBenchPress.setAdapter(adapter)
            filledExposedDropdownBenchPressVarient.setAdapter(adapter)

            btnNext.setOnClickListener {
                when (position) {
                    0 -> {
                        cardViewQuestionaries1.visibility = View.GONE
                        cardViewQuestionaries2.visibility = View.VISIBLE
                        position = stepView.currentStep + 1
                        stepView.done(false)
                        stepView.go(position, true)
                        btnNext.text = "NEXT"
                    }
                    1 -> {
                        cardViewQuestionaries2.visibility = View.GONE
                        cardViewQuestionaries3.visibility = View.VISIBLE
                        position = stepView.currentStep + 1
                        stepView.done(false)
                        stepView.go(position, true)
                        btnNext.text = "NEXT"
                    }
                    2 -> {
                        cardViewQuestionaries3.visibility = View.GONE
                        cardViewQuestionaries4.visibility = View.VISIBLE
                        position = stepView.currentStep + 1
                        stepView.done(false)
                        stepView.go(position, true)
                        btnNext.text = "SUBMIT"
                    }
                    else -> {
                        position = 0
                        stepView.done(true)
                        stepView.go(4, true)
                    }
                }
            }

            btnQuestTwoNext.setOnClickListener {
                when (position) {
                    1 -> {
                        cardViewQuestionaries2.visibility = View.GONE
                        cardViewQuestionaries3.visibility = View.VISIBLE
                        position = stepView.currentStep + 1
                        stepView.done(false)
                        stepView.go(position, true)
                        btnQuestTwoNext.text = "NEXT"
                    }
                    2 -> {
                        cardViewQuestionaries3.visibility = View.GONE
                        cardViewQuestionaries4.visibility = View.VISIBLE
                        position = stepView.currentStep + 1
                        stepView.done(false)
                        stepView.go(position, true)
                        btnQuestTwoNext.text = "SUBMIT"
                    }
                    else -> {
                        position = 0
                        stepView.done(true)
                        stepView.go(4, true)
                    }
                }
            }

            btnQuestThreeNext.setOnClickListener {
                when (position) {

                    2 -> {
                        cardViewQuestionaries3.visibility = View.GONE
                        cardViewQuestionaries4.visibility = View.VISIBLE
                        position = stepView.currentStep + 1
                        stepView.done(false)
                        stepView.go(position, true)
                        btnQuestionFourNext.text = "SUBMIT"
                    }
                    else -> {
                        position = 0
                        stepView.done(true)
                        stepView.go(4, true)
                    }
                }
            }

            btnQuestionFourNext.setOnClickListener {
                startActivity(Intent(this@QuestionariesActivity, MyProgramsActivity::class.java))
                finish()
            }
        }
    }
}