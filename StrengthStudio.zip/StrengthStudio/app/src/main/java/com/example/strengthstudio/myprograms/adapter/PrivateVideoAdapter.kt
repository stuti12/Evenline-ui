package com.example.strengthstudio.myprograms.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.strengthstudio.databinding.ChoiceChipBinding
import com.example.strengthstudio.databinding.ItemPrivateVideoBinding
import com.example.strengthstudio.myprograms.data.PrivateVideoData
import com.google.android.material.chip.Chip

class PrivateVideoAdapter(private val context: Context) : ListAdapter<PrivateVideoData, PrivateVideoAdapter.MyViewHolder>(DiffUtilPrivateVideoCallBack()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val binding = ItemPrivateVideoBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return MyViewHolder(binding)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val currentItem = getItem(position)
        holder.bind(currentItem, position)

    }

    inner class MyViewHolder(private val binding: ItemPrivateVideoBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(dataModel: PrivateVideoData, position: Int) {
            binding.apply {
                dataModel.banner?.let { imgPrivateVideoBanner.setImageResource(it) }
                textPrivateVideoTitle.text = dataModel.name
                textPrivateVideoSubTitle.text = dataModel.description
                text10mAgo.text = dataModel.time
                var like = 1
                imgLike.setOnClickListener {
                    like++
                    textLike.text = (like.toString())

                    if (like == 1000) {
                        textLike.text = "1k"
                    }
                }

                if (dataModel.banner == null) {
                    imgPrivateVideoBanner.visibility = View.GONE
                    imgPlay.visibility = View.GONE
                }
                setupChip()
            }
        }

        private fun setupChip() {
            val nameList = arrayListOf("Power building", "HyperTrophy", "Medium", "Hard", "Extra Hard")
            for (name in nameList) {
                val chip = createChip(name)
                binding.chipPrivateVideo.addView(chip)
            }

        }

        private fun createChip(label: String): Chip {
            val chip = ChoiceChipBinding.inflate(LayoutInflater.from(context)).root
            chip.text = label
            return chip
        }
    }

}

class DiffUtilPrivateVideoCallBack : DiffUtil.ItemCallback<PrivateVideoData>() {
    override fun areItemsTheSame(oldItem: PrivateVideoData, newItem: PrivateVideoData): Boolean {
        return oldItem.name == newItem.name
    }

    override fun areContentsTheSame(oldItem: PrivateVideoData, newItem: PrivateVideoData): Boolean {
        return areItemsTheSame(oldItem, newItem)
    }

}