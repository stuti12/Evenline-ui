package com.example.strengthstudio.listeners

interface ItemClickListener {
    fun onItemClick(position: Int)
}