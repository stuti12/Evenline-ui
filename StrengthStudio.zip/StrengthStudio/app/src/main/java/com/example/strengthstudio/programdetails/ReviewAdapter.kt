package com.example.strengthstudio.programdetails

import android.content.Context
import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.strengthstudio.databinding.ItemReviewsBinding

class ReviewAdapter(context: Context) : ListAdapter<ReviewData, ReviewAdapter.MyViewHolder>(DiffUtilCallBack()) {
    inner class MyViewHolder(private val binding: ItemReviewsBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(dataModel: ReviewData) {
            binding.apply {
                textCaden.text = dataModel.name
                imgUser.setImageResource(dataModel.profileImage)
                textDate.text = dataModel.date
                textYouCantGo.text = dataModel.textReview
                ratingbarProgramDetail.setOnRatingBarChangeListener { ratingBar, rating, fromUser ->
                    val rateValue: String = java.lang.String.valueOf(ratingbarProgramDetail.rating)
                    Log.d("rating", rateValue)
                    textRating.text = rateValue
                    //   textRating.text = dataModel.rating
                }
            }

        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val binding = ItemReviewsBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return MyViewHolder(binding)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val currentItem = getItem(position)
        holder.bind(currentItem)
        /*  if(currentItem == null) {
             holder.itemView.findViewById<ConstraintLayout>(R.id.viewNoData).visibility = View.VISIBLE
          }
          else {
              holder.itemView.findViewById<ConstraintLayout>(R.id.viewWithData).visibility = View.VISIBLE
          }*/
    }

}

class DiffUtilCallBack : DiffUtil.ItemCallback<ReviewData>() {
    override fun areItemsTheSame(oldItem: ReviewData, newItem: ReviewData): Boolean {
        return oldItem.id == newItem.id
    }

    override fun areContentsTheSame(oldItem: ReviewData, newItem: ReviewData): Boolean {
        return areItemsTheSame(oldItem, newItem)
    }

}