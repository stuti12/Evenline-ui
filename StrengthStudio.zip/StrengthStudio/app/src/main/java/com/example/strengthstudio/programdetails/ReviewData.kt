package com.example.strengthstudio.programdetails

data class ReviewData(val id: Int, val profileImage: Int, val name: String, val date: String, val textReview: String)