package com.example.strengthstudio.authentication

import android.content.Intent
import android.os.Bundle
import android.view.MotionEvent
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.addTextChangedListener
import com.example.strengthstudio.R
import com.example.strengthstudio.databinding.ActivitySignUpBinding
import com.example.strengthstudio.utils.hideKeyboard
import com.example.strengthstudio.utils.makeLinks
import com.example.strengthstudio.utils.toast

class SignUpActivity : AppCompatActivity() {
    private val binding: ActivitySignUpBinding by lazy {
        ActivitySignUpBinding.inflate(layoutInflater)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        setSpannableText()
        setClickListener()
    }

    private fun setSpannableText() {
        binding.textDontHaveAccount.makeLinks(Pair("Sign In", View.OnClickListener {
            val intent = Intent(applicationContext, SigninActivity::class.java)
            startActivity(intent)
            finish()
        }))
    }

    private fun validation(): Boolean {
        binding.apply {
            when {
                etEmail.text.isNullOrEmpty() -> {
                    textLayoutEmail.error = "Required Email ID"
                    return false
                }
                else -> {
                    textLayoutEmail.error = null
                }
            }
            when {
                etPassword.text.isNullOrEmpty() -> {
                    textLayoutPassword.error = getString(R.string.error_require_password)
                    return false
                }
                else -> {
                    textLayoutPassword.error = null
                    when {
                        etCPassword.text.isNullOrEmpty() -> {
                            textLayoutCPassword.error = getString(R.string.error_require_password)
                            return false
                        }
                        etCPassword.text.toString() != etPassword.text.toString() -> {
                            textLayoutCPassword.error = getString(R.string.text_password_not_match)
                            return false
                        }
                        else -> {
                            textLayoutCPassword.error = null
                        }
                    }
                }
            }

            /* if(!Patterns.EMAIL_ADDRESS.matcher(etEmail.text).matches()) {
                 textLayoutEmail.error = "Invalid Email ID"
                 return false
             }*/
            return true
        }
    }

    override fun dispatchTouchEvent(ev: MotionEvent?): Boolean {
        if (currentFocus != null) {
            binding.signInParent.hideKeyboard()
        }
        return super.dispatchTouchEvent(ev)
    }

    private fun setClickListener() {
        binding.apply {
            btnSignUp.setOnClickListener {
                if (validation()) {
                    this@SignUpActivity.toast(getString(R.string.text_signin_success))
                    val intent = Intent(this@SignUpActivity, VerificationActivity::class.java)
                    intent.putExtra("Flag", true)
                    startActivity(intent)
                    // intent.putExtra("Flag",true)
                } else {
                    this@SignUpActivity.toast("Login Fail")
                }
            }

            etEmail.addTextChangedListener {
                textLayoutEmail.error = null
            }

            etPassword.addTextChangedListener {
                textLayoutPassword.error = null
            }

            etCPassword.addTextChangedListener {
                validation()
            }
            toolbar.arrowImageViewBack.setOnClickListener {
                finish()
            }
        }
    }
}