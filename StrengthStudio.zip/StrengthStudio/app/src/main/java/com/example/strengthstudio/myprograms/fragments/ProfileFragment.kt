package com.example.strengthstudio.myprograms.fragments

import android.graphics.Color
import android.os.Bundle
import android.text.SpannableString
import android.text.style.ForegroundColorSpan
import android.text.style.RelativeSizeSpan
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.example.strengthstudio.R
import com.example.strengthstudio.databinding.BottomsheetFreeUserProfileBinding
import com.example.strengthstudio.databinding.FragmentProfileBinding
import com.google.android.material.bottomsheet.BottomSheetDialog


class ProfileFragment : Fragment() {
    private val binding: FragmentProfileBinding by lazy {
        FragmentProfileBinding.inflate(layoutInflater)
    }
    lateinit var bottomSheetView: BottomsheetFreeUserProfileBinding
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        return binding.root

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        setClickListeners()

    }

    private fun setClickListeners() {
        binding.apply {
            binding.toolbarProfile.arrowImageViewBack.visibility = View.GONE
            binding.toolbarProfile.tvTitle.text = "Profile"
            binding.toolbarProfile.tvTitle.visibility = View.VISIBLE
            btnBecomePremiumMember.setOnClickListener {
                showBottomSheetDialog()
            }
            btnEditProfile.setOnClickListener {
                viewPremiumProfile.visibility = View.VISIBLE
                viewFreeProfile.visibility = View.GONE
            }

            btnPremiumMember.setOnClickListener {
                showBottomSheetPremiumDialog()
            }
            btnEditProfilePremium.setOnClickListener {
                viewPremiumProfile.visibility = View.GONE
                viewFreeProfile.visibility = View.VISIBLE
            }
        }
    }

    private fun showBottomSheetDialog() {
        bottomSheetView = BottomsheetFreeUserProfileBinding.inflate(layoutInflater)
        val bottomSheetDialog = BottomSheetDialog(requireActivity())
        bottomSheetDialog.setContentView(bottomSheetView.root)
        val price = bottomSheetView.text2999.text.toString()
        val ss1 = SpannableString(price)
        ss1.setSpan(RelativeSizeSpan(2f), 0, 6, 0) // set size
        ss1.setSpan(ForegroundColorSpan(Color.WHITE), 0, 6, 0) // set color
        bottomSheetView.text2999.text = ss1
        bottomSheetDialog.show()
    }

    private fun showBottomSheetPremiumDialog() {
        val bottomSheetDialog = BottomSheetDialog(requireActivity())
        bottomSheetDialog.setContentView(R.layout.bottomsheet_premium_user_profile)
        bottomSheetDialog.show()
    }

}