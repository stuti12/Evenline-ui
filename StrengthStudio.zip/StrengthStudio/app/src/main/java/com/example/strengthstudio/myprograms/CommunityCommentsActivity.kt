package com.example.strengthstudio.myprograms

import android.os.Bundle
import android.view.MotionEvent
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.example.strengthstudio.R
import com.example.strengthstudio.databinding.ActivityCommunityCommentsBinding
import com.example.strengthstudio.myprograms.adapter.CommunityCommentAdapter
import com.example.strengthstudio.myprograms.data.CommunityCommentData
import com.example.strengthstudio.utils.hideKeyboard

class CommunityCommentsActivity : AppCompatActivity() {
    private val binding: ActivityCommunityCommentsBinding by lazy {
        ActivityCommunityCommentsBinding.inflate(layoutInflater)
    }
    private var commentList = mutableListOf<CommunityCommentData>()
    private lateinit var communityCommentAdapter: CommunityCommentAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        setUpClickListener()
    }

    override fun dispatchTouchEvent(ev: MotionEvent?): Boolean {
        if (currentFocus != null) {
            binding.mainViewComment.hideKeyboard()
        }
        return super.dispatchTouchEvent(ev)
    }

    private fun setUpClickListener() {
        binding.apply {
            communityCommentAdapter = CommunityCommentAdapter(this@CommunityCommentsActivity)
            rvComment.adapter = communityCommentAdapter
            commentList = mutableListOf(
                CommunityCommentData(1, R.drawable.ic_person_profile, getString(R.string.caden), getString(R.string.you_can_t_go_wrong_with_this_bundle_sick_programs_thank_you_jamal_and_sst_team), getString(R.string.just_now)), CommunityCommentData(2, R.drawable.ic_person_profile, getString(R.string.caden), getString(R.string.you_can_t_go_wrong_with_this_bundle_sick_programs_thank_you_jamal_and_sst_team), getString(R.string.just_now)),
                CommunityCommentData(3, R.drawable.ic_person_profile, "Stuti", getString(R.string.you_can_t_go_wrong_with_this_bundle_sick_programs_thank_you_jamal_and_sst_team), getString(R.string.just_now)),

                )
            communityCommentAdapter.submitList(commentList)

            imgBack.setOnClickListener {
                finish()
            }

            //drawable button click
            etTypeYourComments.setOnTouchListener(object : View.OnTouchListener {
                override fun onTouch(v: View?, event: MotionEvent?): Boolean {
                    val DRAWABLE_RIGHT = 2
                    if (event?.action == MotionEvent.ACTION_UP) {
                        if (event.rawX >= (etTypeYourComments.right - etTypeYourComments.compoundDrawables[DRAWABLE_RIGHT].bounds.width())) {
                            // your action here
                            when {
                                etTypeYourComments.text.isNullOrEmpty() -> {
                                    etTypeYourComments.error = "Required"
                                    return false
                                }
                                else -> {
                                    commentList.add(CommunityCommentData(commentList.size, R.drawable.ic_person_profile, "Vishal", etTypeYourComments.text.toString(), "Just Now"))
                                    communityCommentAdapter.notifyItemInserted(commentList.size - 1)
                                    rvComment.smoothScrollToPosition(commentList.size - 1)
                                    etTypeYourComments.text?.clear()
                                    return true
                                }
                            }
                        }
                    }
                    return false
                }

            })
        }
    }
}