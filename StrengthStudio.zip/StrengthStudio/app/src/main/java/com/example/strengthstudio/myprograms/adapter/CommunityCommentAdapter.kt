package com.example.strengthstudio.myprograms.adapter

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.strengthstudio.databinding.ItemCommunityCommentBinding
import com.example.strengthstudio.myprograms.ReplyActivity
import com.example.strengthstudio.myprograms.data.CommunityCommentData

class CommunityCommentAdapter(private val context: Context) : ListAdapter<CommunityCommentData, CommunityCommentAdapter.MyViewHolder>(DiffUtilCommunityCommentCallBack()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val binding = ItemCommunityCommentBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return MyViewHolder(binding)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val currentItem = getItem(position)
        holder.bind(currentItem, position)

    }

    inner class MyViewHolder(val binding: ItemCommunityCommentBinding) : RecyclerView.ViewHolder(binding.root) {

        fun bind(dataModel: CommunityCommentData, position: Int) {
            binding.apply {
                dataModel.profileImage?.let { imgUser.setImageResource(it) }
                textCaden.text = dataModel.name
                textComment.text = dataModel.description
                textJustNow.text = dataModel.time
                var like = 1
                var dislike = 1
                imgLike.setOnClickListener {
                    like++
                    textLike.text = (like.toString())

                    if (like == 1000) {
                        textLike.text = "1k"
                    }
                }
                imgDislike.setOnClickListener {
                    dislike++
                    textDislike.text = (dislike.toString())

                    if (dislike == 1000) {
                        textDislike.text = "1k"
                    }
                }
                textReply.setOnClickListener {
                    Intent(context, ReplyActivity::class.java).apply {
                        putExtra("ProfileImage", dataModel.profileImage)
                        putExtra("Name", dataModel.name)
                        putExtra("Description", dataModel.description)
                        putExtra("time", dataModel.time)
                        putExtra("likeCount", textLike.text.toString())
                        putExtra("dislikeCount", textDislike.text.toString())
                        context.startActivity(this)
                    }
                }
            }
        }

    }

}

class DiffUtilCommunityCommentCallBack : DiffUtil.ItemCallback<CommunityCommentData>() {
    override fun areItemsTheSame(oldItem: CommunityCommentData, newItem: CommunityCommentData): Boolean {
        return oldItem.id == newItem.id
    }

    override fun areContentsTheSame(oldItem: CommunityCommentData, newItem: CommunityCommentData): Boolean {
        return areItemsTheSame(oldItem, newItem)
    }

}