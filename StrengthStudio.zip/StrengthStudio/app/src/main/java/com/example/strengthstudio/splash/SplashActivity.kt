package com.example.strengthstudio.splash

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.appcompat.app.AppCompatActivity
import com.example.strengthstudio.authentication.SigninActivity
import com.example.strengthstudio.databinding.ActivitySplashBinding
import com.example.strengthstudio.myprograms.MyProgramsActivity
import com.example.strengthstudio.utils.SessionManager
import java.util.concurrent.TimeUnit

class SplashActivity : AppCompatActivity() {
    private val binding: ActivitySplashBinding by lazy {
        ActivitySplashBinding.inflate(layoutInflater)
    }
    private lateinit var delay: Handler

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        displaySplash()
    }

    private fun displaySplash() {
        delay = Handler(Looper.getMainLooper())
        delay.postDelayed({
            val token = SessionManager.getToken(this)
            if (!token.isNullOrBlank()) {
                val intent = Intent(this, MyProgramsActivity::class.java)
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(intent)
            } else {
                val intent = Intent(this@SplashActivity, SigninActivity::class.java)
                startActivity(intent)
            }

            finish()
        }, TimeUnit.SECONDS.toMillis(2))
    }
}