package com.example.strengthstudio.day1

import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.example.strengthstudio.R
import com.example.strengthstudio.databinding.ActivityDayOneBinding
import com.example.strengthstudio.day1.adapter.WorkOutAdapter
import com.example.strengthstudio.day1.data.WorkoutData


class DayOneActivity : AppCompatActivity() {
    private val binding: ActivityDayOneBinding by lazy {
        ActivityDayOneBinding.inflate(layoutInflater)
    }
    private var dataList = listOf<WorkoutData>()
    private lateinit var adapter: WorkOutAdapter
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        binding.toolbarDayOne.tvTitle.visibility = View.VISIBLE
        binding.toolbarDayOne.tvTitle.text = "Day 1"
        setClickListener()
        setAdapter()

    }

    private fun setAdapter() {
        binding.apply {
            adapter = WorkOutAdapter(this@DayOneActivity)
            rvDayOne.adapter = adapter
            dataList = listOf(
                WorkoutData(
                    1,
                    "Low Bar BackSquat",
                    "5 repos \n" + "5 repos \n" + "5 reps",
                    "80 lbs \n" + "80 lbs \n" + "80 lbs",
                    "5 repo \n" + "5 repo \n" + "5 repo",
                    getString(R.string.note_lorem_ipsum_dolor_sit_amet_consectetur_adipiscing_elit_sed_do_eiusmod_tempor_incididunt_ut_labore_et_dolore_magna_aliqua_ut_enim_ad_minim_veniam_quis_nostrud_exercitation_ullamco_laboris_nisi_ut_aliquip_ex_ea_commodo_consequat_duis_aute_irure_dolor_in_reprehenderit_in_voluptate_velit_esse_cillum_dolore_eu_fugiat_nulla_pariatur_less)
                ),
                WorkoutData(
                    2,
                    "Bench Press",
                    "5 repos \n" + "5 repos \n" + "5 reps",
                    "80 lbs \n" + "80 lbs \n" + "80 lbs",
                    "5 repo \n" + "5 repo \n" + "5 repo",
                    getString(R.string.note_lorem_ipsum_dolor_sit_amet_consectetur_adipiscing_elit_sed_do_eiusmod_tempor_incididunt_ut_labore_et_dolore_magna_aliqua_ut_enim_ad_minim_veniam_quis_nostrud_exercitation_ullamco_laboris_nisi_ut_aliquip_ex_ea_commodo_consequat_duis_aute_irure_dolor_in_reprehenderit_in_voluptate_velit_esse_cillum_dolore_eu_fugiat_nulla_pariatur_less)
                ),
                WorkoutData(
                    3,
                    "Deadlift",
                    "3 repos \n" + "3 repos \n" + "3 reps",
                    "83 lbs \n" + "83 lbs \n" + "83 lbs",
                    "5 repo \n" + "5 repo \n" + "5 repo",
                    getString(R.string.note_lorem_ipsum_dolor_sit_amet_consectetur_adipiscing_elit_sed_do_eiusmod_tempor_incididunt_ut_labore_et_dolore_magna_aliqua_ut_enim_ad_minim_veniam_quis_nostrud_exercitation_ullamco_laboris_nisi_ut_aliquip_ex_ea_commodo_consequat_duis_aute_irure_dolor_in_reprehenderit_in_voluptate_velit_esse_cillum_dolore_eu_fugiat_nulla_pariatur_less)
                )

            )
            adapter.submitList(dataList)
        }
    }

    private fun setClickListener() {
        binding.apply {
            toolbarDayOne.arrowImageViewBack.setOnClickListener {
                finish()
            }
            // textExpand.setText(R.string.note_lorem_ipsum_dolor_sit_amet_consectetur_adipiscing_elit_sed_do_eiusmod_tempor_incididunt_ut_labore_et_dolore_magna_aliqua_ut_enim_ad_minim_veniam_quis_nostrud_exercitation_ullamco_laboris_nisi_ut_aliquip_ex_ea_commodo_consequat_duis_aute_irure_dolor_in_reprehenderit_in_voluptate_velit_esse_cillum_dolore_eu_fugiat_nulla_pariatur_less.toString())
        }
    }
}