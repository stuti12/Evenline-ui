package com.example.strengthstudio.myprograms.fragments

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.ArrayAdapter
import android.widget.AutoCompleteTextView
import android.widget.Button
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.strengthstudio.R
import com.example.strengthstudio.databinding.FragmentCommunityBinding
import com.example.strengthstudio.listeners.ItemClickListener
import com.example.strengthstudio.myprograms.PrivateVideoActivity
import com.example.strengthstudio.myprograms.adapter.CommunityAdapter
import com.example.strengthstudio.myprograms.adapter.FilterAdapter
import com.example.strengthstudio.myprograms.data.CommunityData
import com.example.strengthstudio.myprograms.data.FilterData
import com.google.android.material.bottomsheet.BottomSheetDialog


class CommunityFragment : Fragment(), ItemClickListener {
    private val binding: FragmentCommunityBinding by lazy {
        FragmentCommunityBinding.inflate(layoutInflater)
    }
    private var activeList = listOf<CommunityData>()
    private lateinit var adapter: CommunityAdapter
    private var filterList = listOf<FilterData>()
    var oldPosition: Int = 0
    private lateinit var filterAdapter: FilterAdapter

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {

        // Inflate the layout for this fragment
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        setAdapter()
        setClickListener()
    }

    private fun setClickListener() {
        binding.apply {
            toolbarCommunity.arrowImageViewBack.visibility = View.GONE
            toolbarCommunity.tvTitle.text = "Community"
            toolbarCommunity.tvTitle.visibility = View.VISIBLE
            toolbarCommunity.searchView.visibility = View.VISIBLE
            toolbarCommunity.searchView.setOnSearchClickListener {
                toolbarCommunity.searchView.layoutParams.width = ConstraintLayout.LayoutParams.MATCH_PARENT
                toolbarCommunity.tvTitle.visibility = View.GONE
                imgFilter.visibility = View.GONE
                imgNotification.visibility = View.GONE
            }
            toolbarCommunity.searchView.setOnCloseListener {
                toolbarCommunity.searchView.visibility = View.VISIBLE
                toolbarCommunity.searchView.layoutParams.width = ConstraintLayout.LayoutParams.WRAP_CONTENT
                toolbarCommunity.searchView.gravity = Gravity.END
                imgFilter.visibility = View.VISIBLE
                imgNotification.visibility = View.VISIBLE
                toolbarCommunity.tvTitle.visibility = View.VISIBLE
                false
            }

            imgFilter.setOnClickListener {
                showBottomSheetDialog()
            }

            floatingAdd.setOnClickListener {
                showFeedBottomSheetDialog()
            }

        }
    }

    private fun showBottomSheetDialog() {
        val bottomSheetDialog = BottomSheetDialog(requireActivity())
        filterAdapter = FilterAdapter(requireActivity(), this)
        val view = layoutInflater.inflate(R.layout.bottomsheet_community_filter, null)
        val recycleView = view.findViewById<RecyclerView>(R.id.rvFilter)
        recycleView.adapter = filterAdapter
        filterList = listOf(FilterData("Squat"), FilterData("Bench Press"), FilterData("Deadlift"), FilterData("Training"), FilterData("Nutrition"), FilterData("Extra"))
        filterAdapter.submitList(filterList)
        bottomSheetDialog.setContentView(view)
        bottomSheetDialog.show()

    }

    private fun showFeedBottomSheetDialog() {
        val bottomSheetDialog = BottomSheetDialog(requireActivity())
        val view = layoutInflater.inflate(R.layout.bottomsheet_create_feed, null)
        val spinner: AutoCompleteTextView = view.findViewById(R.id.filled_exposed_dropdown)
        val viewmain: ConstraintLayout = view.findViewById(R.id.mainViewBottomCreateFeed)
        viewmain.setOnTouchListener { _, _ ->
            val imm: InputMethodManager = context?.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.hideSoftInputFromWindow(view.windowToken, 0)

        }
        val adapter = ArrayAdapter.createFromResource(requireActivity(), R.array.feeds, android.R.layout.simple_spinner_item)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinner.setAdapter(adapter)
        bottomSheetDialog.setContentView(view)
        bottomSheetDialog.show()

        val buttonClose: Button = view.findViewById(R.id.btnClose)
        buttonClose.setOnClickListener {
            bottomSheetDialog.dismiss()
        }

    }

    private fun setAdapter() {
        binding.apply {
            adapter = CommunityAdapter(requireActivity())

            rvCommunity.layoutManager = LinearLayoutManager(requireActivity())
            rvCommunity.adapter = adapter

            activeList = listOf(
                CommunityData(
                    R.drawable.ic_program_detail_banner, getString(
                        R.string.jamal_browner_s_12_week_intermediate_vol_4
                    ), getString(R.string.lorem_ipsum_is_simply_dummy_text_of_the_printing_and_typesetting_industry_lorem_ipsum_has_been_the_industry_s_standard_dummy_text_ever_more), getString(R.string._10m_ago)
                ), CommunityData(
                    banner = null, getString(
                        R.string.jamal_browner_s_12_week_intermediate_vol_4
                    ), getString(R.string.lorem_ipsum_is_simply_dummy_text_of_the_printing_and_typesetting_industry_lorem_ipsum_has_been_the_industry_s_standard_dummy_text_ever_more), getString(R.string._10m_ago)
                ), CommunityData(
                    R.drawable.ic_program_detail_banner, getString(
                        R.string.jamal_browner_s_12_week_intermediate_vol_4
                    ), getString(R.string.lorem_ipsum_is_simply_dummy_text_of_the_printing_and_typesetting_industry_lorem_ipsum_has_been_the_industry_s_standard_dummy_text_ever_more), getString(R.string._10m_ago)
                )
            )
            adapter.submitList(activeList)
            imgNotification.setOnClickListener {
                startActivity(Intent(requireActivity(), PrivateVideoActivity::class.java))
            }
        }
    }

    override fun onItemClick(position: Int) {
        //other way for changing position and textcolor
        /*
        filterList.mapIndexed { index, _ ->
             filterList[index].isCheck = false
         }*/
        filterList[oldPosition].isCheck = false
        filterList[position].isCheck = true
        oldPosition = position
        filterAdapter.notifyDataSetChanged()
    }
}