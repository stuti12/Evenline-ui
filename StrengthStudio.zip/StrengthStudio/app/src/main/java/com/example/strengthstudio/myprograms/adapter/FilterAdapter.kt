package com.example.strengthstudio.myprograms.adapter

import android.content.Context
import android.graphics.Color
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.strengthstudio.R
import com.example.strengthstudio.databinding.ItemFilterBinding
import com.example.strengthstudio.listeners.ItemClickListener
import com.example.strengthstudio.myprograms.data.FilterData

class FilterAdapter(private val context: Context, val itemClickListener: ItemClickListener) : ListAdapter<FilterData, FilterAdapter.MyViewHolder>(DiffUtilFilterCallBack()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val binding = ItemFilterBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return MyViewHolder(binding)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val currentItem = getItem(position)
        holder.bind(currentItem)
        if (currentItem.isCheck) {
            holder.itemView.findViewById<TextView>(R.id.textFilter).setTextColor(Color.WHITE)
        } else {
            holder.itemView.findViewById<TextView>(R.id.textFilter).setTextColor(Color.GRAY)
        }
        holder.itemView.setOnClickListener {
            itemClickListener.onItemClick(holder.adapterPosition)
        }

    }

    inner class MyViewHolder(val binding: ItemFilterBinding) : RecyclerView.ViewHolder(binding.root) {

        fun bind(dataModel: FilterData) {
            binding.apply {
                textFilter.text = dataModel.filter
            }

        }
    }
}

class DiffUtilFilterCallBack : DiffUtil.ItemCallback<FilterData>() {
    override fun areItemsTheSame(oldItem: FilterData, newItem: FilterData): Boolean {
        return oldItem.filter == newItem.filter
    }

    override fun areContentsTheSame(oldItem: FilterData, newItem: FilterData): Boolean {
        return areItemsTheSame(oldItem, newItem)
    }

}