package com.example.strengthstudio.myprograms

import android.os.Bundle
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.findNavController
import androidx.navigation.ui.setupWithNavController
import com.example.strengthstudio.R
import com.example.strengthstudio.databinding.ActivityMyProgramsBinding

class MyProgramsActivity : AppCompatActivity() {
    private val binding: ActivityMyProgramsBinding by lazy {
        ActivityMyProgramsBinding.inflate(layoutInflater)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        setClickListener()
        this.onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                finishAffinity()
            }

        })
    }

    private fun setClickListener() {
        val navController = findNavController(R.id.navFragment)
        binding.bottomJetpackNavigation.setupWithNavController(navController)
    }


}