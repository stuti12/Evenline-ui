package com.example.strengthstudio.programlibrary.data

object Constants {
    const val PARENT = 0
    const val CHILD = 1
}

data class RecycleParentData(
    val parentTitle: String? = null,
    var type: Int = Constants.PARENT,

    var subList: MutableList<RecycleChildData> = ArrayList(),
    var isExpanded: Boolean = false
)

data class RecycleChildData(val img: Int, val title: String, val status: String)