package com.example.strengthstudio.day1.adapter

import android.content.Context
import android.graphics.Color
import android.text.Spannable
import android.text.SpannableString
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.method.LinkMovementMethod
import android.text.style.ForegroundColorSpan
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.ViewTreeObserver
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.strengthstudio.databinding.ItemWorkoutDayoneBinding
import com.example.strengthstudio.day1.data.WorkoutData
import com.example.strengthstudio.myprograms.data.ActiveProgramData
import com.example.strengthstudio.utils.Constants.Companion.FIVE
import com.example.strengthstudio.utils.Constants.Companion.ZERO
import com.example.strengthstudio.utils.MySpannable

class WorkOutAdapter(private val context: Context) : ListAdapter<WorkoutData, WorkOutAdapter.MyViewHolder>(DiffUtilWorkOutCallBack()) {
    var onItemClick: ((ActiveProgramData) -> Unit)? = null

    inner class MyViewHolder(private val binding: ItemWorkoutDayoneBinding) : RecyclerView.ViewHolder(binding.root) {
        //  val cardRow = binding.itemViewWorkout
        fun bind(dataModel: WorkoutData) {
            binding.apply {
                textLowBarBackSquat.text = dataModel.workoutname
                text5reps5reps5reps.text = dataModel.repos
                text80lbs80lbs80lbs.text = dataModel.lbs
                text5rpe.text = dataModel.repo
                textNote.text = dataModel.desc
                //   textNot.text = dataModel.note
                val spannable = SpannableString(dataModel.desc)
                spannable.setSpan(ForegroundColorSpan(Color.WHITE), ZERO, FIVE, Spannable.SPAN_EXCLUSIVE_INCLUSIVE)
                textNote.text = spannable
                makeTextViewResizable(textNote, 3, "more", true)
            }

        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val binding = ItemWorkoutDayoneBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return MyViewHolder(binding)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val currentItem = getItem(position)
        holder.bind(currentItem)
        /*  holder.cardRow.setOnClickListener {
              onItemClick?.invoke(currentItem)
          }*/
    }

    fun makeTextViewResizable(tv: TextView, maxLine: Int, expandText: String, viewMore: Boolean) {
        if (tv.tag == null) {
            tv.tag = tv.text
        }
        val vto = tv.viewTreeObserver
        vto.addOnGlobalLayoutListener(object : ViewTreeObserver.OnGlobalLayoutListener {
            override fun onGlobalLayout() {
                val text: String
                val lineEndIndex: Int
                val obs = tv.viewTreeObserver
                obs.removeOnGlobalLayoutListener(this)
                if (maxLine == 0) {
                    lineEndIndex = tv.layout.getLineEnd(0)
                    text = tv.text.subSequence(0, lineEndIndex - expandText.length + 1).toString() + " " + expandText
                } else if (maxLine > 0 && tv.lineCount >= maxLine) {
                    lineEndIndex = tv.layout.getLineEnd(maxLine - 1)
                    text = tv.text.subSequence(0, lineEndIndex - expandText.length + 1).toString() + " " + expandText
                } else {
                    lineEndIndex = tv.layout.getLineEnd(tv.layout.lineCount - 1)
                    text = tv.text.subSequence(0, lineEndIndex).toString() + " " + expandText
                }
                tv.text = text
                tv.movementMethod = LinkMovementMethod.getInstance()
                tv.setText(
                    addClickablePartTextViewResizable(
                        SpannableString(tv.text.toString()), tv, lineEndIndex, expandText,
                        viewMore
                    ), TextView.BufferType.SPANNABLE
                )
            }
        })
    }

    private fun addClickablePartTextViewResizable(strSpanned: Spanned, tv: TextView, maxLine: Int, spanableText: String, viewMore: Boolean): SpannableStringBuilder? {
        val str = strSpanned.toString()
        val ssb = SpannableStringBuilder(strSpanned)

        if (str.contains(spanableText)) {
            ssb.setSpan(object : MySpannable(false) {
                override fun onClick(widget: View) {
                    tv.layoutParams = tv.layoutParams
                    tv.setText(tv.tag.toString(), TextView.BufferType.SPANNABLE)
                    tv.invalidate()
                    if (viewMore) {
                        makeTextViewResizable(tv, -1, "less", false)
                    } else {
                        makeTextViewResizable(tv, 3, "more", true)
                    }
                }
            }, str.indexOf(spanableText), str.indexOf(spanableText) + spanableText.length, 0)
        }
        return ssb
    }

}


class DiffUtilWorkOutCallBack : DiffUtil.ItemCallback<WorkoutData>() {
    override fun areItemsTheSame(oldItem: WorkoutData, newItem: WorkoutData): Boolean {
        return oldItem.workoutname == newItem.workoutname
    }

    override fun areContentsTheSame(oldItem: WorkoutData, newItem: WorkoutData): Boolean {
        return areItemsTheSame(oldItem, newItem)
    }

}