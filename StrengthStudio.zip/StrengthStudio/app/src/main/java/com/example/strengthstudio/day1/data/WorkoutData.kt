package com.example.strengthstudio.day1.data

data class WorkoutData(val id: Int, val workoutname: String?, val repos: String?, val lbs: String?, val repo: String?, val desc: String?)
