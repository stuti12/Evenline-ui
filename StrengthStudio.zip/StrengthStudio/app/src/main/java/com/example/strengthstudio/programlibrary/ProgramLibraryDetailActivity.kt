package com.example.strengthstudio.programlibrary

import android.os.Bundle
import android.view.View
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import com.example.strengthstudio.R
import com.example.strengthstudio.databinding.ActivityProgramLibraryDetailBinding
import com.example.strengthstudio.programlibrary.adapter.ProgramLibraryDetailAdapter
import com.example.strengthstudio.programlibrary.data.RecycleChildData
import com.example.strengthstudio.programlibrary.data.RecycleParentData
import com.google.android.material.bottomsheet.BottomSheetDialog

class ProgramLibraryDetailActivity : AppCompatActivity() {
    private val binding: ActivityProgramLibraryDetailBinding by lazy {
        ActivityProgramLibraryDetailBinding.inflate(layoutInflater)
    }
    val listData: MutableList<RecycleParentData> = ArrayList()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        binding.toolbar.tvTitle.visibility = View.VISIBLE
        binding.toolbar.tvTitle.text = "Jamal Browner’s 12 Week"
        setClickListener()
        setData()
    }

    private fun setClickListener() {
        binding.apply {
            toolbar.arrowImageViewBack.setOnClickListener {
                finish()
            }
            imgHeaderSettings.setOnClickListener {
                showBottomSheetDialog()
            }
        }
    }

    private fun showBottomSheetDialog() {
        val bottomSheetDialog = BottomSheetDialog(this)
        val view = layoutInflater.inflate(R.layout.bottomsheet_updateplan, null)
        val buttonClose: Button = view.findViewById(R.id.btnClose)
        buttonClose.setOnClickListener {
            bottomSheetDialog.dismiss()
        }
        bottomSheetDialog.setContentView(view)
        bottomSheetDialog.show()
    }

    //Expandable Data
    private fun setData() {
        val parentData: Array<String> = arrayOf("DAY 1", "DAY 2", "DAY 3", "DAY 4", "DAY 5", "DAY 6", "DAY 7")
        val childData1: MutableList<RecycleChildData> = mutableListOf(RecycleChildData(R.drawable.ic_program_child, "Squat", "Completed"), (RecycleChildData(R.drawable.ic_program_child, "Squat", "Pending")), (RecycleChildData(R.drawable.ic_program_child, "Squat", "Pending")))
        val childData2: MutableList<RecycleChildData> = mutableListOf((RecycleChildData(R.drawable.ic_program_child, "Squat", "Completed")), RecycleChildData(R.drawable.ic_program_child, "Squat", "Pending"), (RecycleChildData(R.drawable.ic_program_child, "Squat", "Pending")))
        val childData3: MutableList<RecycleChildData> = mutableListOf(RecycleChildData(R.drawable.ic_program_child, "Squat", "Completed"), (RecycleChildData(R.drawable.ic_program_child, "Squat", "Completed")))
        val childData4: MutableList<RecycleChildData> = mutableListOf(RecycleChildData(R.drawable.ic_program_child, "Squat", "Pending"))

        val parentObj1 = RecycleParentData(parentTitle = parentData[0], subList = childData1)
        val parentObj2 = RecycleParentData(parentTitle = parentData[1], subList = childData2)
        val parentObj3 = RecycleParentData(parentTitle = parentData[2], subList = childData3)
        val parentObj4 = RecycleParentData(parentTitle = parentData[3], subList = childData4)
        val parentObj5 = RecycleParentData(parentTitle = parentData[4], subList = childData4)

        listData.add(parentObj1)
        listData.add(parentObj2)
        listData.add(parentObj3)
        listData.add(parentObj4)
        listData.add(parentObj5)
        binding.rvProgram.adapter = ProgramLibraryDetailAdapter(this@ProgramLibraryDetailActivity, listData)
    }
}