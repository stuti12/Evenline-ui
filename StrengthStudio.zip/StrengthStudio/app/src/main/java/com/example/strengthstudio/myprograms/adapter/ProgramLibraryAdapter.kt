package com.example.strengthstudio.myprograms.adapter

import android.content.Context
import android.graphics.Paint
import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.strengthstudio.databinding.ChoiceChipBinding
import com.example.strengthstudio.databinding.ItemProgramLibraryBinding
import com.example.strengthstudio.myprograms.data.ProgramLibraryData
import com.google.android.material.chip.Chip

class ProgramLibraryAdapter(var context: Context) : ListAdapter<ProgramLibraryData, ProgramLibraryAdapter.MyViewHolder>(DiffUtilProgramCallBack()) {
    var onItemClick: ((ProgramLibraryData) -> Unit)? = null

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val binding = ItemProgramLibraryBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return MyViewHolder(binding)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val currentItem = getItem(position)
        holder.bind(currentItem, position)
        holder.cardRow.setOnClickListener {
            onItemClick?.invoke(currentItem)
        }

    }

    inner class MyViewHolder(private val binding: ItemProgramLibraryBinding) : RecyclerView.ViewHolder(binding.root) {
        val cardRow = binding.cardProgram
        fun bind(dataModel: ProgramLibraryData, position: Int) {
            binding.apply {
                imgProgramLibrary.setImageResource(dataModel.imageLibrary)
                textProgramLibraryTitle.text = dataModel.title

                ratingProgramLibrary.setOnRatingBarChangeListener { ratingBar, rating, fromUser ->
                    val rateValue: String = java.lang.String.valueOf(ratingProgramLibrary.rating)
                    Log.d("rating", rateValue)
                    textRating.text = rateValue
                    //   textRating.text = dataModel.rating
                }

                text154.paintFlags = text154.paintFlags or Paint.STRIKE_THRU_TEXT_FLAG

                setupChip()
            }

        }

        private fun setupChip() {
            val nameList = arrayListOf("Power building", "HyperTrophy", "Medium", "Hard", "Extra Hard")
            for (name in nameList) {
                val chip = createChip(name)
                binding.chip.addView(chip)
            }

        }

        private fun createChip(label: String): Chip {
            val chip = ChoiceChipBinding.inflate(LayoutInflater.from(context)).root
            chip.text = label
            return chip
        }
    }

}

class DiffUtilProgramCallBack : DiffUtil.ItemCallback<ProgramLibraryData>() {
    override fun areItemsTheSame(oldItem: ProgramLibraryData, newItem: ProgramLibraryData): Boolean {
        return oldItem.id == newItem.id
    }

    override fun areContentsTheSame(oldItem: ProgramLibraryData, newItem: ProgramLibraryData): Boolean {
        return areItemsTheSame(oldItem, newItem)
    }

}