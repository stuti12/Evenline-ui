package com.example.strengthstudio.myprograms.data

data class FilterData(val filter: String, var isCheck: Boolean = false)
