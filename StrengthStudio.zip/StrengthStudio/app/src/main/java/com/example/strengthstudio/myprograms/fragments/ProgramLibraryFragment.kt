package com.example.strengthstudio.myprograms.fragments

import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.RecyclerView
import com.example.strengthstudio.R
import com.example.strengthstudio.databinding.FragmentProgramLibraryBinding
import com.example.strengthstudio.listeners.ItemClickListener
import com.example.strengthstudio.myprograms.adapter.FilterAdapter
import com.example.strengthstudio.myprograms.adapter.ProgramLibraryAdapter
import com.example.strengthstudio.myprograms.data.FilterData
import com.example.strengthstudio.myprograms.data.ProgramLibraryData
import com.example.strengthstudio.programdetails.ProgramDetailsActivity
import com.google.android.material.bottomsheet.BottomSheetDialog


class ProgramLibraryFragment : Fragment(), ItemClickListener {
    private val binding: FragmentProgramLibraryBinding by lazy {
        FragmentProgramLibraryBinding.inflate(layoutInflater)
    }
    private var programList = listOf<ProgramLibraryData>()
    private lateinit var adapter: ProgramLibraryAdapter
    var oldPosition: Int = 0
    private lateinit var filterAdapter: FilterAdapter
    private var filterList = listOf<FilterData>()
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        // Inflate the layout for this fragment
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        setAdapter()
        setData()
        setClickListener()
        binding.apply {
            toolbarProgramLibrary.arrowImageViewBack.visibility = View.GONE
            toolbarProgramLibrary.tvTitle.text = "Program Library"
            toolbarProgramLibrary.tvTitle.visibility = View.VISIBLE
            toolbarProgramLibrary.searchView.visibility = View.VISIBLE
            toolbarProgramLibrary.searchView.setOnSearchClickListener {
                imgFilter.visibility = View.GONE
                toolbarProgramLibrary.searchView.layoutParams.width = ConstraintLayout.LayoutParams.MATCH_PARENT
                toolbarProgramLibrary.tvTitle.visibility = View.GONE
            }
            toolbarProgramLibrary.searchView.setOnCloseListener {
                toolbarProgramLibrary.searchView.visibility = View.VISIBLE
                toolbarProgramLibrary.searchView.layoutParams.width = ConstraintLayout.LayoutParams.WRAP_CONTENT
                toolbarProgramLibrary.searchView.gravity = Gravity.END
                toolbarProgramLibrary.tvTitle.visibility = View.VISIBLE
                false
            }
        }
    }

    private fun setClickListener() {
        binding.apply {
            imgFilter.setOnClickListener {
                showBottomSheetDialog()
            }
        }
    }

    private fun setAdapter() {
        adapter = ProgramLibraryAdapter(requireActivity())
        adapter.onItemClick = {
            startActivity(Intent(requireActivity(), ProgramDetailsActivity::class.java))
        }
        binding.rvProgramLibrary.adapter = adapter

    }

    private fun setData() {
        programList = listOf(
            /*  ProgramLibraryData(1, R.drawable.ic_active1, getString(R.string.jamal_browner_s_12_week_intermediate_vol_4), ""),
              ProgramLibraryData(2, R.drawable.ic_active1, getString(R.string.jamal_browner_s_12_week_intermediate_vol_4), ""),
              ProgramLibraryData(3, R.drawable.ic_active1, getString(R.string.jamal_browner_s_12_week_intermediate_vol_4), "")
          */
        )
        binding.btnRefreshPage.setOnClickListener {
            programList = listOf(
                ProgramLibraryData(1, R.drawable.ic_active1, getString(R.string.jamal_browner_s_12_week_intermediate_vol_4), ""),
                ProgramLibraryData(2, R.drawable.ic_active1, getString(R.string.jamal_browner_s_12_week_intermediate_vol_4), ""),
                ProgramLibraryData(3, R.drawable.ic_active1, getString(R.string.jamal_browner_s_12_week_intermediate_vol_4), "")
            )
            adapter.submitList(programList)
            binding.viewNoData.visibility = View.GONE
            binding.rvProgramLibrary.visibility = View.VISIBLE
        }
        adapter.submitList(programList)

        if (programList.isNullOrEmpty()) {
            binding.rvProgramLibrary.visibility = View.GONE
            binding.viewNoData.visibility = View.VISIBLE
        } else {
            binding.rvProgramLibrary.visibility = View.VISIBLE
            binding.viewNoData.visibility = View.GONE
        }
    }

    private fun showBottomSheetDialog() {
        filterAdapter = FilterAdapter(requireActivity(), this)

        val bottomSheetDialog = BottomSheetDialog(requireActivity())
        val view = layoutInflater.inflate(R.layout.bottomsheet_program_library_filter, null)
        val recycleView = view.findViewById<RecyclerView>(R.id.rvFilter)
        recycleView.adapter = filterAdapter
        filterList = listOf(FilterData("All"), FilterData(getString(R.string.txt_strength)), FilterData(getString(R.string.power_building)), FilterData(getString(R.string.hypertrophy)))
        filterAdapter.submitList(filterList)

        bottomSheetDialog.setContentView(view)
        bottomSheetDialog.show()

    }

    override fun onItemClick(position: Int) {
        filterList[oldPosition].isCheck = false
        filterList[position].isCheck = true
        oldPosition = position
        filterAdapter.notifyDataSetChanged()
    }
}