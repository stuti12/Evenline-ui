package com.example.strengthstudio.programdetails

import android.os.Bundle
import android.view.MotionEvent
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.example.strengthstudio.R
import com.example.strengthstudio.databinding.ActivityProgramDetailsBinding
import com.example.strengthstudio.utils.hideKeyboard
import com.google.android.material.tabs.TabLayout

class ProgramDetailsActivity : AppCompatActivity() {
    private val binding: ActivityProgramDetailsBinding by lazy {
        ActivityProgramDetailsBinding.inflate(layoutInflater)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        setClickListener()
        binding.toolbarProgram.tvTitle.visibility = View.VISIBLE
        binding.toolbarProgram.tvTitle.text = "Program Library"
//        replaceFragment(DetailsFragment())

    }

    private fun replaceFragment(fragment: Fragment) {
        supportFragmentManager.beginTransaction().replace(R.id.fragmentProgramLibrary, fragment).commit()
    }

    override fun dispatchTouchEvent(ev: MotionEvent?): Boolean {
        if (currentFocus != null) {
            binding.mainViewProgramDetail.hideKeyboard()
        }
        return super.dispatchTouchEvent(ev)
    }

    private fun setClickListener() {
        binding.apply {
            toolbarProgram.arrowImageViewBack.setOnClickListener {
                finish()
            }
            ratingbarProgramDetail.setOnRatingBarChangeListener { _, rating, fromUser ->
                val rateValue: String = java.lang.String.valueOf(ratingbarProgramDetail.rating)
                textRating.text = rateValue
            }
            tabProgram.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {

                override fun onTabSelected(tab: TabLayout.Tab?) {
                    when (tabProgram.selectedTabPosition) {
                        0 -> {
                            replaceFragment(DetailsFragment())
                        }
                        1 -> {
                            replaceFragment(ReviewsFragment())
                        }
                    }
                }

                override fun onTabUnselected(tab: TabLayout.Tab?) {
                }

                override fun onTabReselected(tab: TabLayout.Tab?) {

                }

            })
        }
    }
}