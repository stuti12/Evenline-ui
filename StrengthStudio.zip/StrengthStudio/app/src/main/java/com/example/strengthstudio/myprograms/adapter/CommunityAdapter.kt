package com.example.strengthstudio.myprograms.adapter

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.strengthstudio.databinding.ChoiceChipBinding
import com.example.strengthstudio.databinding.ItemCommunityBinding
import com.example.strengthstudio.myprograms.CommunityCommentsActivity
import com.example.strengthstudio.myprograms.data.CommunityData
import com.google.android.material.chip.Chip

class CommunityAdapter(private val context: Context) : ListAdapter<CommunityData, CommunityAdapter.MyViewHolder>(DiffUtilCommunityCallBack()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val binding = ItemCommunityBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return MyViewHolder(binding)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val currentItem = getItem(position)
        holder.bind(currentItem, position)

    }

    inner class MyViewHolder(private val binding: ItemCommunityBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(dataModel: CommunityData, position: Int) {
            binding.apply {
                dataModel.banner?.let { imgCommunityBanner.setImageResource(it) }
                textCommunityTitle.text = dataModel.name
                textCommunitySubTitle.text = dataModel.description
                text10mAgo.text = dataModel.time
                var like = 1
                imgLike.setOnClickListener {
                    like++
                    textLike.text = (like.toString())

                    if (like == 1000) {
                        textLike.text = "1k"
                    }
                }

                if (dataModel.banner == null) {
                    imgCommunityBanner.visibility = View.GONE
                    imgPlay.visibility = View.GONE
                    chipCommunity.visibility = View.VISIBLE
                }
                setupChip()
                imgComment.setOnClickListener {
                    context.startActivity(Intent(context, CommunityCommentsActivity::class.java))
                }
            }


        }

        private fun setupChip() {
            val nameList = arrayListOf("Power building", "HyperTrophy", "Medium", "Hard", "Extra Hard")
            for (name in nameList) {
                val chip = createChip(name)
                binding.chipCommunity.addView(chip)
            }

        }

        private fun createChip(label: String): Chip {
            val chip = ChoiceChipBinding.inflate(LayoutInflater.from(context)).root
            chip.text = label
            return chip
        }
    }

}

class DiffUtilCommunityCallBack : DiffUtil.ItemCallback<CommunityData>() {
    override fun areItemsTheSame(oldItem: CommunityData, newItem: CommunityData): Boolean {
        return oldItem.name == newItem.name
    }

    override fun areContentsTheSame(oldItem: CommunityData, newItem: CommunityData): Boolean {
        return areItemsTheSame(oldItem, newItem)
    }

}