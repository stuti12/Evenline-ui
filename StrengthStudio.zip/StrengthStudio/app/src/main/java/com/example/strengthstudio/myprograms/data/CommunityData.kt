package com.example.strengthstudio.myprograms.data

data class CommunityData(var banner: Int?, var name: String, var description: String, var time: String)