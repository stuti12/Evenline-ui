package com.example.strengthstudio.myprograms.adapter

import android.content.Context
import android.net.Uri
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.MediaController
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.strengthstudio.databinding.ItemPhotoVideoBinding

class AddPrivateVideoAdapter(private val context: Context) : ListAdapter<Uri?, AddPrivateVideoAdapter.MyViewHolder>(DiffUtilAddVideoCallBack()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val binding = ItemPhotoVideoBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return MyViewHolder(binding)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val currentItem = getItem(position)
        holder.bind(currentItem)
    }

    inner class MyViewHolder(val binding: ItemPhotoVideoBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(dataModel: Uri?) {
            binding.apply {
                Log.d("Image", "$dataModel")
                val mediaTypeRaw = context.contentResolver.getType(dataModel!!)
                if (mediaTypeRaw?.startsWith("image") == true) {
                    videoView.visibility = View.GONE
                    imgAddPhoto.setImageURI(dataModel)
                } else if (mediaTypeRaw?.startsWith("video") == true) {
                    imgAddPhoto.visibility = View.GONE
                    videoView.setVideoURI(dataModel)
                    videoView.setMediaController(MediaController(context))
                    videoView.start()
                }

            }

        }

    }
}

class DiffUtilAddVideoCallBack : DiffUtil.ItemCallback<Uri?>() {
    override fun areItemsTheSame(oldItem: Uri, newItem: Uri): Boolean {
        return oldItem.compareTo(newItem) == 1
    }

    override fun areContentsTheSame(oldItem: Uri, newItem: Uri): Boolean {
        return true
    }

}