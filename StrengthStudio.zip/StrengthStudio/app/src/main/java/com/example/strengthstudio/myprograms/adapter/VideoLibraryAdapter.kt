package com.example.strengthstudio.myprograms.adapter

import android.content.Context
import android.content.Intent
import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.Filter
import android.widget.Filterable
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.strengthstudio.databinding.ItemVideoLibraryBinding
import com.example.strengthstudio.myprograms.VideoDetailsActivity
import com.example.strengthstudio.myprograms.data.VideoLibraryData
import java.util.*

class VideoLibraryAdapter(private val context: Context) : ListAdapter<VideoLibraryData, VideoLibraryAdapter.MyViewHolder>(DiffUtilVideoCallBack()), Filterable {
    var onItemClick: ((VideoLibraryData) -> Unit)? = null
    var filterList: MutableList<VideoLibraryData> = mutableListOf<VideoLibraryData>()
    override fun submitList(list: MutableList<VideoLibraryData>?) {
        super.submitList(list)
        list?.let {
            filterList.clear()
            filterList.addAll(list)
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val binding = ItemVideoLibraryBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return MyViewHolder(binding)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val currentItem = currentList[position]
        holder.bind(currentItem, position)
        holder.cardRow.setOnClickListener {
            onItemClick?.invoke(currentItem)
        }
    }

    inner class MyViewHolder(val binding: ItemVideoLibraryBinding) : RecyclerView.ViewHolder(binding.root) {
        val cardRow = binding.cardVideo
        fun bind(dataModel: VideoLibraryData, position: Int) {
            binding.apply {
                imgVideoBanner.setImageResource(dataModel.videoImage)
                textVideoTitle.text = dataModel.videoName
                textVideoDescription.text = dataModel.description
                textVideoTime.text = dataModel.videoTime
                textVideoDuration.text = dataModel.duration
                imgPlay.setOnClickListener {
                    Intent(context, VideoDetailsActivity::class.java).apply {
                        putExtra("Time", dataModel.videoTime)
                        putExtra("VideoName", dataModel.videoName)
                        putExtra("Description", dataModel.description)
                        context.startActivity(this)
                    }
                }
            }

        }
    }

    override fun getFilter(): Filter {
        return object : Filter() {

            override fun performFiltering(constraint: CharSequence?): FilterResults {
                val charSearch = constraint.toString()
                val resultList: ArrayList<VideoLibraryData> = arrayListOf()
                if (charSearch.isEmpty()) {
                    resultList.clear()
                    resultList.addAll(filterList)
                } else {
                    resultList.clear()
                    for (row in filterList) {
                        if (row.videoName.lowercase(Locale.getDefault()).contains(constraint.toString().lowercase((Locale.getDefault())))) {
                            resultList.add(row)
                            Log.d("result", "$resultList")

                        }
                    }
                }
                val filterResults = FilterResults()
                filterResults.values = resultList
                return filterResults
            }

            override fun publishResults(constraint: CharSequence?, results: FilterResults?) {

                /*  filterList.clear()
                  filterList.addAll(results?.values as List<VideoLibraryData>)*/
                Log.d("Publish", "${results?.values}")
                submitList(results?.values as MutableList<VideoLibraryData>)
            }

        }
    }
}

class DiffUtilVideoCallBack : DiffUtil.ItemCallback<VideoLibraryData>() {
    override fun areItemsTheSame(oldItem: VideoLibraryData, newItem: VideoLibraryData): Boolean {
        return oldItem.id == newItem.id
    }

    override fun areContentsTheSame(oldItem: VideoLibraryData, newItem: VideoLibraryData): Boolean {
        return areItemsTheSame(oldItem, newItem)
    }

}