package com.example.strengthstudio.selectexercise

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import com.example.strengthstudio.R
import com.example.strengthstudio.databinding.ActivitySelectExerciseBinding
import com.example.strengthstudio.listeners.ItemClickListener
import com.example.strengthstudio.programlibrary.ProgramLibraryDetailActivity
import com.example.strengthstudio.selectexercise.adapter.SelectExerciseAdapter
import com.example.strengthstudio.selectexercise.data.SelectExerciseData
import com.google.android.material.bottomsheet.BottomSheetDialog

class SelectExerciseActivity : AppCompatActivity(), ItemClickListener {
    private val binding: ActivitySelectExerciseBinding by lazy {
        ActivitySelectExerciseBinding.inflate(layoutInflater)
    }
    private var exerciseList = listOf<SelectExerciseData>()
    private lateinit var adapter: SelectExerciseAdapter
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        setClickListener()
    }

    private fun setClickListener() {
        binding.apply {
            adapter = SelectExerciseAdapter(this@SelectExerciseActivity)

            rvSwitchExercise.adapter = adapter
            exerciseList = listOf(SelectExerciseData(1, "High Bar Squat"), SelectExerciseData(2, "Paused Squat"), SelectExerciseData(3, "Pin Squat"), SelectExerciseData(4, "Sab Squat"), SelectExerciseData(5, "Tempo Squat"))
            adapter.submitList(exerciseList)
            adapter.onItemClick = {
                showBottomSheetDialog()
            }
            toolbarSelectExercise.arrowImageViewBack.setOnClickListener {
                finish()
            }
        }
    }

    private fun showBottomSheetDialog() {
        val bottomSheetDialog = BottomSheetDialog(this)
        val view = layoutInflater.inflate(R.layout.bottomsheet_resetpop, null)
        val buttonYes: Button = view.findViewById(R.id.btnYes)
        val buttonClose: Button = view.findViewById(R.id.btnNo)
        buttonYes.setOnClickListener {
            startActivity(Intent(this, ProgramLibraryDetailActivity::class.java))
            //  intent.putExtra("Flag",true)
            finish()
        }
        buttonClose.setOnClickListener {
            bottomSheetDialog.dismiss()
            finish()
        }
        bottomSheetDialog.setContentView(view)
        bottomSheetDialog.show()
    }

    override fun onItemClick(position: Int) {

    }
}