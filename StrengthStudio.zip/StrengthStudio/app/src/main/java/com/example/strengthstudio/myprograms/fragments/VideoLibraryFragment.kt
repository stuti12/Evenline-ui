package com.example.strengthstudio.myprograms.fragments

import android.os.Bundle
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.fragment.app.Fragment
import com.example.strengthstudio.R
import com.example.strengthstudio.databinding.FragmentVideoLibraryBinding
import com.example.strengthstudio.myprograms.adapter.VideoLibraryAdapter
import com.example.strengthstudio.myprograms.data.VideoLibraryData

class VideoLibraryFragment : Fragment() {

    private val binding: FragmentVideoLibraryBinding by lazy {
        FragmentVideoLibraryBinding.inflate(layoutInflater)
    }
    private var videoList = mutableListOf<VideoLibraryData>()
    private lateinit var videoLibraryAdapter: VideoLibraryAdapter

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        setAdapter()
        setClickListener()
    }

    private fun setClickListener() {
        binding.apply {
            toolbarVideoLibrary.arrowImageViewBack.visibility = View.GONE
            toolbarVideoLibrary.tvTitle.text = "Video Library"
            toolbarVideoLibrary.tvTitle.visibility = View.VISIBLE
            toolbarVideoLibrary.searchView.visibility = View.VISIBLE
            toolbarVideoLibrary.searchView.setOnSearchClickListener {
                toolbarVideoLibrary.searchView.layoutParams.width = ConstraintLayout.LayoutParams.MATCH_PARENT
                toolbarVideoLibrary.tvTitle.visibility = View.GONE
            }
            toolbarVideoLibrary.searchView.setOnCloseListener {
                videoLibraryAdapter.submitList(mutableListOf<VideoLibraryData>().apply {
                    clear()
                    addAll(videoList)
                })
                toolbarVideoLibrary.searchView.visibility = View.VISIBLE
                toolbarVideoLibrary.searchView.layoutParams.width = ConstraintLayout.LayoutParams.WRAP_CONTENT
                toolbarVideoLibrary.searchView.gravity = Gravity.END
                toolbarVideoLibrary.tvTitle.visibility = View.VISIBLE
                false
            }
            toolbarVideoLibrary.searchView.setOnQueryTextListener(object : androidx.appcompat.widget.SearchView.OnQueryTextListener {
                override fun onQueryTextSubmit(query: String?): Boolean {
                    //      videoLibraryAdapter.notifyDataSetChanged()
                    return true
                }

                override fun onQueryTextChange(newText: String?): Boolean {
                    videoLibraryAdapter.filter?.filter(newText)
                    return false
                }

            })

        }

    }

    private fun setAdapter() {
        binding.apply {
            videoList.apply {
                add(
                    VideoLibraryData(
                        1,
                        R.drawable.ic_program_detail_banner,
                        "Stuti",
                        getString(R.string.lorem_ipsum_is_simply_dummy_text_of_the_printing_and_typesetting_industry_lorem_ipsum_has_been_the_industry_s_standard_dummy_text_ever_since_the_1500s_when_an_unknown_printer_took_a_galley_of_type_and_scrambled_it_to_make_a_type_specimen_book_it_has_survived_not_only_five_centuries_but_also_the_leap_into_electronic_typesetting_remaining_essentially_unchanged_it_was_popularised_in_the_1960s_with_the_release_of_letraset_sheets_containing_lorem_ipsum_passages_and_more_recently_with_desktop_publishing_software_like_aldus_pagemaker_including_versions_of_lorem_ipsum),
                        getString(R.string._10m_ago),
                        getString(R.string.duration_10_15)
                    )
                )
                add(
                    VideoLibraryData(
                        2,
                        R.drawable.ic_program_detail_banner,
                        getString(R.string.jamal_browner_s_12_week),
                        getString(R.string.lorem_ipsum_is_simply_dummy_text_of_the_printing_and_typesetting_industry_lorem_ipsum_has_been_the_industry_s_standard_dummy_text_ever_since_the_1500s_when_an_unknown_printer_took_a_galley_of_type_and_scrambled_it_to_make_a_type_specimen_book_it_has_survived_not_only_five_centuries_but_also_the_leap_into_electronic_typesetting_remaining_essentially_unchanged_it_was_popularised_in_the_1960s_with_the_release_of_letraset_sheets_containing_lorem_ipsum_passages_and_more_recently_with_desktop_publishing_software_like_aldus_pagemaker_including_versions_of_lorem_ipsum),
                        getString(R.string._10m_ago),
                        getString(R.string.duration_10_15)
                    )
                )
                add(
                    VideoLibraryData(
                        3, R.drawable.ic_program_detail_banner,
                        "Mansi",
                        getString(R.string.lorem_ipsum_is_simply_dummy_text_of_the_printing_and_typesetting_industry_lorem_ipsum_has_been_the_industry_s_standard_dummy_text_ever_since_the_1500s_when_an_unknown_printer_took_a_galley_of_type_and_scrambled_it_to_make_a_type_specimen_book_it_has_survived_not_only_five_centuries_but_also_the_leap_into_electronic_typesetting_remaining_essentially_unchanged_it_was_popularised_in_the_1960s_with_the_release_of_letraset_sheets_containing_lorem_ipsum_passages_and_more_recently_with_desktop_publishing_software_like_aldus_pagemaker_including_versions_of_lorem_ipsum),
                        getString(R.string._10m_ago),
                        getString(R.string.duration_10_15)
                    )
                )
                add(
                    VideoLibraryData(4, R.drawable.ic_program_detail_banner, "abc", getString(R.string.lorem_ipsum_is_simply_dummy_text_of_the_printing_and_typesetting_industry_lorem_ipsum_has_been_the_industry_s_standard_dummy_text_ever_more), getString(R.string._10m_ago), getString(R.string.duration_10_15))
                )
            }

            videoLibraryAdapter = VideoLibraryAdapter(requireActivity())
            videoLibraryAdapter.submitList(mutableListOf<VideoLibraryData>().apply {
                clear()
                addAll(videoList)
            })
            rvVideoLibrary.adapter = videoLibraryAdapter

            val adapter = ArrayAdapter.createFromResource(requireActivity(), R.array.feeds, android.R.layout.simple_spinner_item)
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            filledExposedDropdown.setAdapter(adapter)

        }
    }

}