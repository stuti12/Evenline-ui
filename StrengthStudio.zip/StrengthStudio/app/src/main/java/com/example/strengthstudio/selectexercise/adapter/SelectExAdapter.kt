package com.example.strengthstudio.selectexercise.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.strengthstudio.databinding.ItemSelectExerciseBinding
import com.example.strengthstudio.selectexercise.data.SelectExerciseData

class SelectExerciseAdapter(private val context: Context) : ListAdapter<SelectExerciseData, SelectExerciseAdapter.MyViewHolder>(DiffUtilCallBack()) {
    var onItemClick: ((SelectExerciseData) -> Unit)? = null

    inner class MyViewHolder(private val binding: ItemSelectExerciseBinding) : RecyclerView.ViewHolder(binding.root) {
        val cardRow = binding.itemViewExercise
        fun bind(dataModel: SelectExerciseData) {
            binding.apply {
                textExercise.text = dataModel.exercise
            }

        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val binding = ItemSelectExerciseBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return MyViewHolder(binding)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val currentItem = getItem(position)
        holder.bind(currentItem)
        holder.cardRow.setOnClickListener {
            onItemClick?.invoke(currentItem)
        }
    }


}

class DiffUtilCallBack : DiffUtil.ItemCallback<SelectExerciseData>() {
    override fun areItemsTheSame(oldItem: SelectExerciseData, newItem: SelectExerciseData): Boolean {
        return oldItem.id == newItem.id
    }

    override fun areContentsTheSame(oldItem: SelectExerciseData, newItem: SelectExerciseData): Boolean {
        return areItemsTheSame(oldItem, newItem)
    }

}