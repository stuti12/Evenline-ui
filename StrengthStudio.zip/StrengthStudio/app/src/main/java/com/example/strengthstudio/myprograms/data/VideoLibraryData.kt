package com.example.strengthstudio.myprograms.data

data class VideoLibraryData(val id: Int, val videoImage: Int, val videoName: String, val description: String, val videoTime: String, val duration: String)