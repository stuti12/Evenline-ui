package com.example.strengthstudio.myprograms.fragments

import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.fragment.app.Fragment
import com.example.strengthstudio.R
import com.example.strengthstudio.databinding.BottomsheetDaysPlanningBinding
import com.example.strengthstudio.databinding.BottomsheetSelectPlanBinding
import com.example.strengthstudio.databinding.FragmentMyProgramBinding
import com.example.strengthstudio.myprograms.adapter.ActiveProgramAdapter
import com.example.strengthstudio.myprograms.data.ActiveProgramData
import com.example.strengthstudio.programlibrary.ProgramLibraryDetailActivity
import com.example.strengthstudio.questionaries.QuestionariesActivity
import com.google.android.material.bottomsheet.BottomSheetDialog


class MyProgramFragment : Fragment() {
    private val binding: FragmentMyProgramBinding by lazy {
        FragmentMyProgramBinding.inflate(layoutInflater)
    }
    private lateinit var bottomSheetView: BottomsheetSelectPlanBinding
    private lateinit var bottomSheetViewDaysPlanning: BottomsheetDaysPlanningBinding

    private var activeList = listOf<ActiveProgramData>()
    private lateinit var activeProgramAdapter: ActiveProgramAdapter
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        setAdapter()
        setData()

        setClickListener()
    }

    private fun setClickListener() {
        binding.apply {
            toolbarPrograms.arrowImageViewBack.visibility = View.GONE
            toolbarPrograms.tvTitle.text = "My Programs"
            toolbarPrograms.tvTitle.visibility = View.VISIBLE
            toolbarPrograms.searchView.visibility = View.VISIBLE
            toolbarPrograms.searchView.setOnSearchClickListener {
                toolbarPrograms.searchView.layoutParams.width = ConstraintLayout.LayoutParams.MATCH_PARENT
                toolbarPrograms.tvTitle.visibility = View.GONE

            }
            /*     toolbarPograms.root.visibility = View.GONE
                    toolbarSearch.root.visibility = View.VISIBLE
    */
            toolbarPrograms.searchView.setOnCloseListener {
                activeProgramAdapter.submitList(mutableListOf<ActiveProgramData>().apply {
                    clear()
                    addAll(activeList)
                })
                toolbarPrograms.searchView.visibility = View.VISIBLE
                toolbarPrograms.searchView.layoutParams.width = ConstraintLayout.LayoutParams.WRAP_CONTENT
                toolbarPrograms.searchView.gravity = Gravity.END
                toolbarPrograms.tvTitle.visibility = View.VISIBLE
                false
            }
            /*
             toolbarSearch.setOnCloseListener {
             toolbarSearch.visibility = View.GONE
             toolbarPrograms.visibility = View.Visible
             */

            toolbarPrograms.searchView.setOnQueryTextListener(object : androidx.appcompat.widget.SearchView.OnQueryTextListener {
                override fun onQueryTextSubmit(query: String?): Boolean {
                    //      videoLibraryAdapter.notifyDataSetChanged()
                    return true
                }

                override fun onQueryTextChange(newText: String?): Boolean {
                    activeProgramAdapter.filter?.filter(newText)
                    return false
                }

            })

        }
    }

    private fun setData() {
        activeList = listOf(
            ActiveProgramData(R.drawable.ic_active1, "Jamal Browner’s 12 Week Intermediate Vol. 4", "12 Weeks"),
            ActiveProgramData(R.drawable.ic_active2, "The Godfather Program Bundle (LIMITED)", "12 weeks"),
            ActiveProgramData(R.drawable.ic_active3, "SSTT’s Strength Focused Push Pull Legs", "12 weeks"),
            ActiveProgramData(R.drawable.ic_active3, "SSTT’s Strength Focused Push Pull Legs", "12 weeks"),
            ActiveProgramData(R.drawable.ic_active3, "SSTT’s Strength Focused Push Pull Legs", "12 weeks"),
            ActiveProgramData(R.drawable.ic_active3, "SSTT’s Strength Focused Push Pull Legs", "12 weeks")
        )
        activeProgramAdapter.submitList(mutableListOf<ActiveProgramData>().apply {
            clear()
            addAll(activeList)
        })
        if (activeList.isEmpty()) {
            binding.rvActiveProgram.visibility = View.GONE
            binding.viewNoData.visibility = View.VISIBLE
        } else {
            binding.rvActiveProgram.visibility = View.VISIBLE
            binding.viewNoData.visibility = View.GONE
        }

    }

    private fun setAdapter() {
        binding.apply {
            activeProgramAdapter = ActiveProgramAdapter(requireActivity())
            activeProgramAdapter.onItemClick = {
                showDayPlanningBottomSheetDialog()
            }
            rvActiveProgram.adapter = activeProgramAdapter

        }
    }

    private fun showDayPlanningBottomSheetDialog() {
        val bottomSheetDialog = BottomSheetDialog(requireActivity())
        bottomSheetViewDaysPlanning = BottomsheetDaysPlanningBinding.inflate(layoutInflater)
        bottomSheetDialog.setContentView(bottomSheetViewDaysPlanning.root)
        bottomSheetViewDaysPlanning.stepView.done(false)
        bottomSheetViewDaysPlanning.stepView.go(bottomSheetViewDaysPlanning.stepView.currentStep, true)
        bottomSheetViewDaysPlanning.btnYes.setOnClickListener {
            bottomSheetViewDaysPlanning.stepView.go(bottomSheetViewDaysPlanning.stepView.currentStep, true)
            bottomSheetViewDaysPlanning.stepView.done(true)
            bottomSheetDialog.dismiss()
            showSelectPlanBottomSheetDialog()
        }
        bottomSheetViewDaysPlanning.btnClose.setOnClickListener {
            bottomSheetDialog.dismiss()
        }
        bottomSheetDialog.show()
    }

    private fun showSelectPlanBottomSheetDialog() {
        val bottomSheetDialog = BottomSheetDialog(requireActivity())
        bottomSheetView = BottomsheetSelectPlanBinding.inflate(layoutInflater)
        bottomSheetDialog.setContentView(bottomSheetView.root)
        bottomSheetView.stepView.done(false)
        bottomSheetView.stepView.go(bottomSheetView.stepView.currentStep + 1, true)

        bottomSheetView.btnUseDefaultPlan.setOnClickListener {
            bottomSheetView.stepView.done(true)
            bottomSheetDialog.dismiss()
            startActivity(Intent(requireActivity(), ProgramLibraryDetailActivity::class.java))
        }

        bottomSheetView.btnCustomizePlan.setOnClickListener {
            bottomSheetDialog.dismiss()
            startActivity(Intent(requireActivity(), QuestionariesActivity::class.java))
        }

        bottomSheetView.btnClose.setOnClickListener {
            bottomSheetDialog.dismiss()
        }
        bottomSheetDialog.show()

    }


}