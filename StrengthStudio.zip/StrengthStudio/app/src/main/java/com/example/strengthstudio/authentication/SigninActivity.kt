package com.example.strengthstudio.authentication

import android.content.Intent
import android.os.Bundle
import android.view.MotionEvent
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.addTextChangedListener
import com.example.strengthstudio.R
import com.example.strengthstudio.databinding.ActivitySigninBinding
import com.example.strengthstudio.myprograms.MyProgramsActivity
import com.example.strengthstudio.utils.SessionManager
import com.example.strengthstudio.utils.hideKeyboard
import com.example.strengthstudio.utils.makeLinks
import com.example.strengthstudio.utils.toast

class SigninActivity : AppCompatActivity() {
    private val binding: ActivitySigninBinding by lazy {
        ActivitySigninBinding.inflate(layoutInflater)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        spannableTextSet()
        setClickListener()

    }

    override fun dispatchTouchEvent(ev: MotionEvent?): Boolean {
        if (currentFocus != null) {
            binding.signInParent.hideKeyboard()
        }
        return super.dispatchTouchEvent(ev)
    }

    private fun spannableTextSet() {
        binding.textDontHaveAccount.makeLinks(Pair(getString(R.string.signup), View.OnClickListener {
            val intent = Intent(applicationContext, SignUpActivity::class.java)
            startActivity(intent)
        }))
    }

    private fun validation(): Boolean {
        binding.apply {
            when {
                etEmail.text.isNullOrEmpty() -> {
                    textLayoutEmail.error = "Required Email ID"
                    return false
                }
                else -> {
                    textLayoutEmail.error = null
                }
            }
            when {
                etPassword.text.isNullOrEmpty() -> {
                    textLayoutPassword.error = getString(R.string.error_require_password)
                    return false
                }
                else -> {
                    textLayoutPassword.error = null
                    return true
                }
            }
            /*if(!Patterns.EMAIL_ADDRESS.matcher(etEmail.text).matches()) {
                textLayoutEmail.error = "Invalid Email ID"
                return false
            }*/
        }
    }

    override fun onBackPressed() {
        finishAffinity()
    }

    private fun setClickListener() {
        var token: String
        binding.apply {
            btnSignin.setOnClickListener {
                if (validation()) {
                    this@SigninActivity.toast(getString(R.string.text_signin_success))
                    token = etEmail.text.toString()
                    SessionManager.saveAuthToken(this@SigninActivity, token)
                    startActivity(Intent(this@SigninActivity, MyProgramsActivity::class.java))
                    //  finish()
                } else {
                    this@SigninActivity.toast("Login Fail")
                }
            }

            textForgetPassword.setOnClickListener {
                startActivity(Intent(this@SigninActivity, ForgetPasswordActivity::class.java))
            }

            etEmail.addTextChangedListener {
                textLayoutEmail.error = null
            }

            etPassword.addTextChangedListener {
                textLayoutPassword.error = null
            }

        }
    }
}