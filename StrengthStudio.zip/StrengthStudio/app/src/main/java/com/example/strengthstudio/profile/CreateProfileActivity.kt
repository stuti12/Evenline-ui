package com.example.strengthstudio.profile

import android.app.DatePickerDialog
import android.content.Intent
import android.os.Bundle
import android.view.MotionEvent
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.addTextChangedListener
import com.example.strengthstudio.R
import com.example.strengthstudio.databinding.ActivityCreateProfileBinding
import com.example.strengthstudio.myprograms.MyProgramsActivity
import com.example.strengthstudio.utils.hideKeyboard
import com.example.strengthstudio.utils.toast
import java.util.*

class CreateProfileActivity : AppCompatActivity(), View.OnClickListener {
    private val binding: ActivityCreateProfileBinding by lazy {
        ActivityCreateProfileBinding.inflate(layoutInflater)
    }
    private var position = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        binding.etDateOfBirth.setOnClickListener(this)
        setClickListener()
        binding.toolbar.tvTitle.visibility = View.VISIBLE
        binding.toolbar.tvTitle.text = "Create Profile"
    }

    override fun onBackPressed() {
        binding.apply {
            when (position) {
                0 -> {
                    // finishAffinity()
                    super.onBackPressed()
                }
                1 -> {
                    cardViewRecord.visibility = View.GONE
                    cardViewPersonalInfo.visibility = View.VISIBLE
                    position = stepView.currentStep - 1
                    binding.stepView.done(false)
                    binding.stepView.go(position, true)
                    btnNextRecord.text = getString(R.string.text_next)
                }
                else -> {
                    cardViewGoal.visibility = View.GONE
                    cardViewRecord.visibility = View.VISIBLE
                    position = stepView.currentStep - 1
                    binding.stepView.done(false)
                    binding.stepView.go(position, true)
                    btnNextGoal.text = getString(R.string.text_submit)
                }
            }
        }
    }

    override fun dispatchTouchEvent(ev: MotionEvent?): Boolean {
        if (currentFocus != null) {
            binding.viewCreateProfile.hideKeyboard()
        }
        return super.dispatchTouchEvent(ev)
    }

    private fun validation(): Boolean {
        binding.apply {
            if (etFirstName.text.isNullOrEmpty() || etLastName.text.isNullOrEmpty() || etUserName.text.isNullOrEmpty() || etDateOfBirth.text.isNullOrEmpty()) {
                textLayoutFirstName.error = getString(R.string.txt_firstname_required)
                textLayoutLastName.error = getString(R.string.txt_lastname_required)
                textLayoutUserName.error = getString(R.string.txt_username_required)
                textLayoutDOB.error = getString(R.string.txt_dateofbirth)
                return if (etSquat.text.isNullOrEmpty() || etBenchPressMax.text.isNullOrEmpty() || etDeadlift.text.isNullOrEmpty() || etWeight.text.isNullOrEmpty() || etHeight.text.isNullOrEmpty()) {
                    textLayoutSquat.error = getString(R.string.txt_squt_required)
                    textLayoutBenchPressMax.error = getString(R.string.txt_benchpress_required)
                    textLayoutDeadlift.error = getString(R.string.txt_deadlift_require)
                    etWeight.error = getString(R.string.txt_weight_required)
                    textLayoutHeight.error = "Height Required"
                    false
                } else {
                    textLayoutSquat.error = null
                    textLayoutBenchPressMax.error = null
                    textLayoutDeadlift.error = null
                    textLayoutWeight.error = null
                    textLayoutHeight.error = null
                    true
                }
                return false
            } else {
                textLayoutFirstName.error = null
                textLayoutLastName.error = null
                textLayoutUserName.error = null
                textLayoutDOB.error = null
                return true
            }

        }
    }

    private fun setClickListener() {
        binding.apply {
            stepView.done(false)
            toolbar.arrowImageViewBack.setOnClickListener {
                finish()
            }
            btnNext.setOnClickListener {
                if (validation()) {
                    when (position) {
                        0 -> {
                            cardViewPersonalInfo.visibility = View.GONE
                            cardViewRecord.visibility = View.VISIBLE
                            position = stepView.currentStep + 1
                            stepView.done(false)
                            stepView.go(position, true)
                            btnNext.text = getString(R.string.text_next)
                        }
                        1 -> {
                            cardViewRecord.visibility = View.GONE
                            cardViewGoal.visibility = View.VISIBLE
                            position = stepView.currentStep + 1
                            stepView.done(false)
                            stepView.go(position, true)
                            btnNext.text = getString(R.string.text_submit)
                        }
                        else -> {
                            position = 0
                            stepView.done(true)
                            stepView.go(3, true)
                        }
                    }

                }
            }
            btnNextRecord.setOnClickListener {
                when (position) {
                    1 -> {
                        cardViewRecord.visibility = View.GONE
                        cardViewGoal.visibility = View.VISIBLE
                        position = 2
                        stepView.done(false)
                        stepView.go(position, true)
                        btnNextGoal.text = getString(R.string.text_submit)
                    }
                    else -> {
                        position = 0
                        stepView.done(true)
                        stepView.go(3, true)
                    }
                }
            }
            stepView.state
                .nextStepCircleEnabled(true)
                .commit()
            btnNextGoal.setOnClickListener {
                this@CreateProfileActivity.toast("Profile Created")
                startActivity(Intent(this@CreateProfileActivity, MyProgramsActivity::class.java))
            }
            imgCamera.setOnClickListener {
                /*  if (checkPermission(Manifest.permission.READ_EXTERNAL_STORAGE)) {
                      imagePicker()
                  } else {
                    this@CreateProfileActivity.toast("Needs permission")
                  }*/
            }


            etFirstName.addTextChangedListener {
                textLayoutFirstName.error = null
            }
            etLastName.addTextChangedListener {
                textLayoutLastName.error = null
            }
            etUserName.addTextChangedListener {
                textLayoutUserName.error = null
            }
            etDateOfBirth.addTextChangedListener {
                textLayoutDOB.error = null
            }
            etSquat.addTextChangedListener {
                textLayoutSquat.error = null
            }
            etBenchPressMax.addTextChangedListener {
                textLayoutBenchPressMax.error = null
            }
            etDeadlift.addTextChangedListener {
                textLayoutDeadlift.error = null
            }
            etHeight.addTextChangedListener {
                textLayoutHeight.error = null
            }
            etWeight.addTextChangedListener {
                textLayoutWeight.error = null
            }
        }
    }

    override fun onClick(v: View?) {
        val mYear: Int
        val mMonth: Int
        val mDay: Int
        if (v == binding.etDateOfBirth) {
            val calendar: Calendar = Calendar.getInstance()

            mYear = calendar.get(Calendar.YEAR)
            mMonth = calendar.get(Calendar.MONTH)
            mDay = calendar.get(Calendar.DAY_OF_MONTH)
            val datePickerDialog = DatePickerDialog(
                this, { _, year, month, dayOfMonth -> binding.etDateOfBirth.setText(dayOfMonth.toString() + "/" + (month + 1) + "/" + year) },
                mYear, mMonth, mDay
            )
            datePickerDialog.datePicker.maxDate = System.currentTimeMillis()
            datePickerDialog.show()

        }
    }
}



