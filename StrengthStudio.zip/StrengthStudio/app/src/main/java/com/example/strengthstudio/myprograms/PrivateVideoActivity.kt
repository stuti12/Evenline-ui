package com.example.strengthstudio.myprograms

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputMethodManager
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.constraintlayout.widget.ConstraintLayout
import com.example.strengthstudio.R
import com.example.strengthstudio.databinding.ActivityPrivateVideoBinding
import com.example.strengthstudio.databinding.BottomsheetAddPrivateVideoBinding
import com.example.strengthstudio.myprograms.adapter.AddPrivateVideoAdapter
import com.example.strengthstudio.myprograms.adapter.PrivateVideoAdapter
import com.example.strengthstudio.myprograms.data.PrivateVideoData
import com.example.strengthstudio.utils.toast
import com.google.android.material.bottomsheet.BottomSheetDialog


class PrivateVideoActivity : AppCompatActivity() {
    private val binding: ActivityPrivateVideoBinding by lazy {
        ActivityPrivateVideoBinding.inflate(layoutInflater)
    }
    lateinit var bottomSheetView: BottomsheetAddPrivateVideoBinding
    private var privateVideoList = mutableListOf<PrivateVideoData>()
    private lateinit var addPrivateVideoAdapter: AddPrivateVideoAdapter
    private lateinit var addPhotoVideoList: MutableList<Uri?>
    private lateinit var privateVideoAdapter: PrivateVideoAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)

        setAdapter()
        setClickListeners()
    }

    private fun setClickListeners() {
        binding.apply {
            toolbarPrivateVideo.arrowImageViewBack.setOnClickListener {
                finish()
            }
            floatingAdd.setOnClickListener {
                showBottomSheetDialog()
            }
            toolbarPrivateVideo.tvTitle.visibility = View.VISIBLE
            binding.toolbarPrivateVideo.tvTitle.text = "Private Video"
            toolbarPrivateVideo.searchView.visibility = View.VISIBLE
            toolbarPrivateVideo.searchView.setOnSearchClickListener {
                toolbarPrivateVideo.searchView.layoutParams.width = ConstraintLayout.LayoutParams.MATCH_PARENT
                toolbarPrivateVideo.tvTitle.visibility = View.GONE
            }
            toolbarPrivateVideo.searchView.setOnCloseListener {
                toolbarPrivateVideo.searchView.visibility = View.VISIBLE
                toolbarPrivateVideo.searchView.layoutParams.width = ConstraintLayout.LayoutParams.WRAP_CONTENT
                toolbarPrivateVideo.searchView.gravity = Gravity.END
                toolbarPrivateVideo.tvTitle.visibility = View.VISIBLE
                false
            }
        }
    }

    private fun setAdapter() {
        binding.apply {
            privateVideoAdapter = PrivateVideoAdapter(this@PrivateVideoActivity)
            addPrivateVideoAdapter = AddPrivateVideoAdapter(this@PrivateVideoActivity)

            rvPrivateVideo.adapter = privateVideoAdapter

            privateVideoList.add(PrivateVideoData(R.drawable.ic_program_detail_banner, getString(R.string.jamal_browner_s_12_week_intermediate_vol_4), getString(R.string.lorem_ipsum_is_simply_dummy_text_of_the_printing_and_typesetting_industry_lorem_ipsum_has_been_the_industry_s_standard_dummy_text_ever_more), getString(R.string._10m_ago)))
            privateVideoList.add(PrivateVideoData(null, getString(R.string.jamal_browner_s_12_week_intermediate_vol_4), getString(R.string.lorem_ipsum_is_simply_dummy_text_of_the_printing_and_typesetting_industry_lorem_ipsum_has_been_the_industry_s_standard_dummy_text_ever_more), getString(R.string._10m_ago)))
            privateVideoList.add(
                PrivateVideoData(R.drawable.ic_program_detail_banner, getString(R.string.jamal_browner_s_12_week_intermediate_vol_4), getString(R.string.lorem_ipsum_is_simply_dummy_text_of_the_printing_and_typesetting_industry_lorem_ipsum_has_been_the_industry_s_standard_dummy_text_ever_more), getString(R.string._10m_ago))
            )

            privateVideoAdapter.submitList(privateVideoList)
            privateVideoAdapter.notifyDataSetChanged()


        }

    }

    fun imageChooser() {
        val intent = Intent(Intent.ACTION_PICK, MediaStore.Video.Media.EXTERNAL_CONTENT_URI)
        intent.type = "image/* video/*"
        resultLauncher.launch(intent)
    }

    private var resultLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val selectedMediaUri: Uri? = result?.data?.data
            addPhotoVideoList.add(selectedMediaUri)
            addPrivateVideoAdapter.notifyItemInserted(addPhotoVideoList.size - 1)


        } else {
            this.toast(getString(R.string.text_picture_not_found))
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun showBottomSheetDialog() {
        val bottomSheetDialog = BottomSheetDialog(this)
        bottomSheetView = BottomsheetAddPrivateVideoBinding.inflate(layoutInflater)
        addPhotoVideoList = mutableListOf()
        addPrivateVideoAdapter.submitList(addPhotoVideoList)

        bottomSheetView.rvPhotoVideo.adapter = addPrivateVideoAdapter


        bottomSheetView.imgAddPhoto.setOnClickListener {
            imageChooser()
        }
        bottomSheetView.mainViewAddPrivateVideo.setOnTouchListener { _, _ ->
            val imm: InputMethodManager = this.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.hideSoftInputFromWindow(bottomSheetView.mainViewAddPrivateVideo.windowToken, 0)

        }
        bottomSheetDialog.setContentView(bottomSheetView.root)
        bottomSheetDialog.show()

        bottomSheetView.btnCreateVideo.setOnClickListener {
            privateVideoList.add(PrivateVideoData(R.drawable.ic_program_detail_banner, bottomSheetView.etVideoTitle.text.toString(), bottomSheetView.etDescription.text.toString(), getString(R.string._10m_ago)))
            privateVideoAdapter.submitList(privateVideoList)
            privateVideoAdapter.notifyItemInserted(privateVideoList.size - 1)

        }

        bottomSheetView.btnClose.setOnClickListener {

            bottomSheetDialog.dismiss()
        }

    }
}