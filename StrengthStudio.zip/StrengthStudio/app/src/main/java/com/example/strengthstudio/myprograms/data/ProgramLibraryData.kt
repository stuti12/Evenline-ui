package com.example.strengthstudio.myprograms.data

data class ProgramLibraryData(val id: Int, val imageLibrary: Int, val title: String, val rating: String)