package com.example.strengthstudio.myprograms.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.strengthstudio.databinding.ItemCommunityReplyBinding
import com.example.strengthstudio.myprograms.data.CommentReplyData

class CommentReplyAdapter(private val context: Context) : ListAdapter<CommentReplyData, CommentReplyAdapter.MyViewHolder>(DiffUtilCommentReplyCallBack()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val binding = ItemCommunityReplyBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return MyViewHolder(binding)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val currentItem = getItem(position)
        holder.bind(currentItem, position)

    }

    inner class MyViewHolder(private val binding: ItemCommunityReplyBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(dataModel: CommentReplyData, position: Int) {
            binding.apply {
                dataModel.profileImage?.let { imgUser.setImageResource(it) }
                textCaden.text = dataModel.name
                textComment.text = dataModel.description
                textJustNow.text = dataModel.time
            }
        }


    }

}

class DiffUtilCommentReplyCallBack : DiffUtil.ItemCallback<CommentReplyData>() {
    override fun areItemsTheSame(oldItem: CommentReplyData, newItem: CommentReplyData): Boolean {
        return oldItem.id == newItem.id
    }

    override fun areContentsTheSame(oldItem: CommentReplyData, newItem: CommentReplyData): Boolean {
        return areItemsTheSame(oldItem, newItem)
    }

}