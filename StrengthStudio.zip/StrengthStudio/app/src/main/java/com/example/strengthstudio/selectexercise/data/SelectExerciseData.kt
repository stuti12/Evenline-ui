package com.example.strengthstudio.selectexercise.data

data class SelectExerciseData(val id: Int, val exercise: String?)