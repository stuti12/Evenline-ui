package com.example.strengthstudio.programlibrary.adapter

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.recyclerview.widget.RecyclerView
import com.example.strengthstudio.R
import com.example.strengthstudio.completexercise.CompleteExerciseActivity
import com.example.strengthstudio.day1.DayOneActivity
import com.example.strengthstudio.programlibrary.data.Constants
import com.example.strengthstudio.programlibrary.data.RecycleChildData
import com.example.strengthstudio.programlibrary.data.RecycleParentData
import com.example.strengthstudio.selectexercise.SelectExerciseActivity

class ProgramLibraryDetailAdapter(var mContext: Context, val list: MutableList<RecycleParentData>) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {

        return if (viewType == Constants.PARENT) {
            val rowView: View = LayoutInflater.from(parent.context).inflate(R.layout.item_program_library_parent, parent, false)
            GroupViewHolder(rowView)
        } else {
            val rowView: View = LayoutInflater.from(parent.context).inflate(R.layout.item_program_library_child, parent, false)
            ChildViewHolder(rowView)
        }
    }

    override fun getItemCount(): Int = list.size

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {

        val dataList = list[position]

        if (dataList.type == Constants.PARENT) {
            holder as GroupViewHolder
            holder.apply {
                dayTitle.text = dataList.parentTitle
                imgParent.setOnClickListener {
                    if (holder.adapterPosition == 0) {
                        val intent = Intent(mContext, DayOneActivity::class.java)
                        mContext.startActivity(intent)
                    }
                }

                if (position % 2 == 0) {
                    imgParent.setImageResource(R.drawable.ic_imogi)
                }
                imgDown.setOnClickListener {
                    if (position % 2 == 1) {
                        expandOrCollapseParentItem(dataList, position)
                    }

                }

            }
            val isExpandable: Boolean = dataList.isExpanded
            holder.apply {
                if (isExpandable) {
                    parentView.setBackgroundColor(Color.parseColor("#696969"))
                    imgDown.setImageResource(R.drawable.ic_downarrow)
                    imgComplete.setImageResource(R.drawable.ic_complete)
                    imgComplete.visibility = View.VISIBLE
                } else {
                    parentView.setBackgroundColor(Color.parseColor("#252525"))
                    imgDown.setImageResource(R.drawable.ic_uparrow)
                }
            }
        } else {
            holder as ChildViewHolder
            holder.apply {
                val singleService = dataList.subList.first()
                textTitleProgramDetail.text = singleService.title
                textStatus.text = singleService.status

                if (textStatus.text.toString() == "Completed") {
                    textStatus.setTextColor(Color.GREEN)
                    imgRefresh.visibility = View.GONE
                } else {
                    textStatus.setTextColor(Color.RED)
                    imgRefresh.visibility = View.VISIBLE
                }
                imgProgramLibrary.setImageResource(singleService.img)
                imgSide.setOnClickListener {
                    val intent = Intent(mContext, CompleteExerciseActivity::class.java)
                    mContext.startActivity(intent)
                }

                imgRefresh.setOnClickListener {
                    val intent = Intent(mContext, SelectExerciseActivity::class.java)
                    // intent.putExtra("Flag",false)
                    mContext.startActivity(intent)

                }
            }
        }

    }

    private fun expandOrCollapseParentItem(singleBoarding: RecycleParentData, position: Int) {
        if (singleBoarding.isExpanded) {
            collapseParentRow(position)
        } else {
            expandParentRow(position)
        }

    }

    private fun expandParentRow(position: Int) {
        val currentBoardingRow = list[position]
        val services = currentBoardingRow.subList
        currentBoardingRow.isExpanded = true
        var nextPosition = position
        if (currentBoardingRow.type == Constants.PARENT) {

            services.forEach { service ->
                val parentModel = RecycleParentData()
                parentModel.type = Constants.CHILD
                val subList: ArrayList<RecycleChildData> = ArrayList()
                subList.add(service)
                parentModel.subList = subList
                list.add(++nextPosition, parentModel)
            }
            notifyDataSetChanged()
        }
    }

    private fun collapseParentRow(position: Int) {
        val currentBoardingRow = list[position]
        val services = currentBoardingRow.subList
        list[position].isExpanded = false
        if (list[position].type == Constants.PARENT) {
            services.forEach { _ ->
                list.removeAt(position + 1)
            }
            notifyDataSetChanged()
        }

    }

    override fun getItemViewType(position: Int): Int = list[position].type

    override fun getItemId(position: Int): Long {
        return position.toLong()
    }

    inner class GroupViewHolder(row: View) : RecyclerView.ViewHolder(row) {
        val parentView = row.findViewById<ConstraintLayout>(R.id.itemViewParent)
        val imgDown = row.findViewById(R.id.imgDown) as ImageView
        val imgComplete = row.findViewById(R.id.imgComplete) as ImageView
        val imgParent = row.findViewById<ImageView>(R.id.imgParent)
        val dayTitle = row.findViewById(R.id.textParentTitle) as TextView
    }

    inner class ChildViewHolder(row: View) : RecyclerView.ViewHolder(row) {
        val imgProgramLibrary = row.findViewById(R.id.imgProgramLibrary) as ImageView
        val textTitleProgramDetail = row.findViewById(R.id.textTitleProgramDetail) as TextView
        val textStatus = row.findViewById(R.id.textStatus) as TextView
        val imgSide = row.findViewById(R.id.imgSide) as ImageView
        val imgRefresh = row.findViewById<ImageView>(R.id.imgRefresh)
    }
}
