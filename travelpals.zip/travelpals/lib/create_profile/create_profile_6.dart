import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:travelpals/bottom_tabbar_page.dart';

import '../component/decorated_radio_button.dart';
import '../custom/custom_button.dart';
import '../utils/colors.dart';
import '../utils/strings.dart';

class CreateProfile6 extends StatefulWidget {
  const CreateProfile6({Key? key}) : super(key: key);

  @override
  State<CreateProfile6> createState() => _CreateProfile6State();
}

class _CreateProfile6State extends State<CreateProfile6> {
  var isSelectYes = false;
  var isSelectNo = false;
  var isSelectSocially = false;
  int selectedGenderVar = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(titleSpacing: 0,
          backgroundColor: AppColors.whiteColor,
          title: Expanded(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                 Text(
                  Strings.createProfile,
                  style: TextStyle(
                      fontFamily: 'Museo Sans',
                      fontWeight: FontWeight.w700,
                      color: AppColors.colorText,
                      fontSize: ScreenUtil().setSp(20)),
                ),
                GestureDetector(
                  onTap: () {
                    Get.to(const TabbarPage());
                  },
                  child:  Align(
                    alignment: Alignment.topRight,
                    child: Text(
                      Strings.skip,
                      style: TextStyle(
                          fontFamily: 'Museo Sans',
                          color: AppColors.cancelColor,
                          fontSize: ScreenUtil().setSp(18)),
                    ),
                  ),
                ),
              ],
            ),
          ),
          leading: IconButton(
            icon: const Icon(
              Icons.arrow_back,
              color: AppColors.arrowColor,
            ),
            onPressed: () {
              Get.back();
            },
          ),
        ),
        body: Column(children: [
          Expanded(
            child: SingleChildScrollView(
              child: Container(
                  padding:  EdgeInsets.only(left: 30.h, top: 20.h, right: 30),
                  width: double.infinity,
                  child: Column(
                    children: [
                       Align(
                        alignment: Alignment.topLeft,
                        child: Text(
                          Strings.doYouHavePassport,
                          style: TextStyle(
                              fontFamily: 'Museo Sans',
                              fontWeight: FontWeight.bold,
                              fontSize: ScreenUtil().setSp(24),
                              color: AppColors.colorText),
                        ),
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      DecoratedRadioButton(
                        isSelected: 1 == selectedGenderVar,
                        text: Strings.yes,
                        onTap: () {
                          setState(() {
                            selectedGenderVar = 1;
                          });
                        },
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      DecoratedRadioButton(
                        isSelected: 2 == selectedGenderVar,
                        text: Strings.no,
                        onTap: () {
                          setState(() {
                            selectedGenderVar = 2;
                          });
                        },
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                       Align(
                        alignment: Alignment.topLeft,
                        child: Text(
                          Strings.covid19,
                          style: TextStyle(
                              fontFamily: 'Museo Sans',
                              fontWeight: FontWeight.bold,
                              fontSize: ScreenUtil().setSp(24),
                              color: AppColors.colorText),
                        ),
                      ),
                      DecoratedRadioButton(
                        isSelected: 1 == selectedGenderVar,
                        text: Strings.yes,
                        onTap: () {
                          setState(() {
                            selectedGenderVar = 1;
                          });
                        },
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      DecoratedRadioButton(
                        isSelected: 3 == selectedGenderVar,
                        text: Strings.socially,
                        onTap: () {
                          setState(() {
                            selectedGenderVar = 3;
                          });
                        },
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                       Align(
                        alignment: Alignment.topLeft,
                        child: Text(
                          Strings.doYouSmoke,
                          style: TextStyle(
                              fontFamily: 'Museo Sans',
                              fontWeight: FontWeight.bold,
                              fontSize: ScreenUtil().setSp(24),
                              color: AppColors.colorText),
                        ),
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      DecoratedRadioButton(
                        isSelected: 1 == selectedGenderVar,
                        text: Strings.yes,
                        onTap: () {
                          setState(() {
                            selectedGenderVar = 1;
                          });
                        },
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      DecoratedRadioButton(
                        isSelected: 2 == selectedGenderVar,
                        text: Strings.no,
                        onTap: () {
                          setState(() {
                            selectedGenderVar = 2;
                          });
                        },
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      DecoratedRadioButton(
                        isSelected: 3 == selectedGenderVar,
                        text: Strings.socially,
                        onTap: () {
                          setState(() {
                            selectedGenderVar = 3;
                          });
                        },
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                       Align(
                        alignment: Alignment.topLeft,
                        child: Text(
                          Strings.doYouDrink,
                          style: TextStyle(
                              fontFamily: 'Museo Sans',
                              fontWeight: FontWeight.bold,
                              fontSize: ScreenUtil().setSp(24),
                              color: AppColors.colorText),
                        ),
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      DecoratedRadioButton(
                        isSelected: 1 == selectedGenderVar,
                        text: Strings.yes,
                        onTap: () {
                          setState(() {
                            selectedGenderVar = 1;
                          });
                        },
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      DecoratedRadioButton(
                        isSelected: 2 == selectedGenderVar,
                        text: Strings.no,
                        onTap: () {
                          setState(() {
                            selectedGenderVar = 2;
                          });
                        },
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      DecoratedRadioButton(
                        isSelected: 3 == selectedGenderVar,
                        text: Strings.socially,
                        onTap: () {
                          setState(() {
                            selectedGenderVar = 3;
                          });
                        },
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                    ],
                  )),
            ),
          ),

          //bottom
          Padding(
            padding: const EdgeInsets.only(bottom: 8.0, left: 10, right: 10),
            child: CustomButton(
              title: Strings.done,
              onTap: () {
                Get.to(const TabbarPage());
              },
              bgColor: AppColors.buttonColor,
            ),
          ),
        ]));
  }
}

enum BestTutorSite { getStrong, build, power, recomposition }
