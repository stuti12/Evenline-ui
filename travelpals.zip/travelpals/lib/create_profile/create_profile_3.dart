import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:travelpals/component/decorated_checkbox.dart';
import 'package:travelpals/create_profile/profile_shared_pref.dart';

import '../custom/custom_button.dart';
import '../utils/colors.dart';
import '../utils/strings.dart';
import 'create_profile_4.dart';

class CreateProfile3 extends StatefulWidget {
  const CreateProfile3({Key? key}) : super(key: key);

  @override
  State<CreateProfile3> createState() => _CreateProfile3State();
}

class _CreateProfile3State extends State<CreateProfile3> {
  int isSelected = 0;
  bool checkSelectedWomen = false;
  bool checkSelectedMen = false;
  bool checkSelectedEveryOne = false;
  bool checkSelectedLarge = false;
  bool checkSelectedFriends = false;
  bool checkSelectedSolo = false;
  double start = 30.0;
  double end = 50.0;
  final ProfilePrefService _prefService = ProfilePrefService();

  List<String> partner = [Strings.women,Strings.men,Strings.everyone,Strings.largeGroup,Strings.friendsOnly,Strings.soloTravel];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: AppColors.bottomSheet,
        appBar: AppBar(titleSpacing: 0,
          backgroundColor: AppColors.whiteColor,
          title:  Text(
            Strings.createProfile,
            style: TextStyle(
                fontFamily: 'Museo Sans',
                color: AppColors.colorText,
                fontWeight: FontWeight.w700,
                fontSize: ScreenUtil().setSp(24)),
          ),
          leading: IconButton(
            icon: const Icon(
              Icons.arrow_back,
              color: AppColors.arrowColor,
            ),
            onPressed: () {
              Get.back();
            },
          ),
        ),
        body: Column(children: [
          Expanded(
            child: SingleChildScrollView(
              child: Container(
                  padding:  EdgeInsets.only(left: 30.h, top: 20.h, right: 30),
                  width: double.infinity,
                  child: Column(
                    children: [
                      Align(
                        alignment: Alignment.topLeft,
                        child: Text(
                          Strings.whoAreYouInterested,
                          style: TextStyle(
                              fontFamily: 'Museo Sans',
                              fontWeight: FontWeight.bold,
                              fontSize: ScreenUtil().setSp(24),
                              color: AppColors.colorText),
                        ),
                      ),
                      const SizedBox(
                        height: 10,
                      ),

                      //gender
                      DecoratedCheckbox(
                        isSelected: checkSelectedWomen,
                        text: partner[0],
                        onTap: () {
                          setState(() {
                            checkSelectedWomen = !checkSelectedWomen;
                          });
                        },
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      DecoratedCheckbox(
                        isSelected: checkSelectedMen,
                        text: partner[1],
                        onTap: () {
                          setState(() {
                            checkSelectedMen = !checkSelectedMen;
                          });
                        },
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      DecoratedCheckbox(
                        isSelected: checkSelectedEveryOne,
                        text: partner[2],
                        onTap: () {
                          setState(() {
                            checkSelectedEveryOne = !checkSelectedEveryOne;
                          });
                        },
                      ),
                      const SizedBox(
                        height: 20,
                      ),
                      DecoratedCheckbox(
                        isSelected: checkSelectedLarge,
                        text: partner[3],
                        onTap: () {
                          setState(() {
                            checkSelectedLarge = !checkSelectedLarge;
                          });
                        },
                      ),
                      const SizedBox(
                        height: 20,
                      ),
                      DecoratedCheckbox(
                        isSelected: checkSelectedFriends,
                        text: partner[4],
                        onTap: () {
                          setState(() {
                            checkSelectedFriends = !checkSelectedFriends;
                          });
                        },
                      ),

                      const SizedBox(
                        height: 20,
                      ),

                      DecoratedCheckbox(
                        isSelected: checkSelectedSolo,
                        text: partner[5],
                        onTap: () {
                          setState(() {
                            checkSelectedSolo = !checkSelectedSolo;
                          });
                        },
                      ),
                      const SizedBox(
                        height: 20,
                      ),
                    ],
                  )),
            ),
          ),

          //bottom
          Padding(
            padding: const EdgeInsets.only(bottom: 8.0, left: 10, right: 10),
            child: CustomButton(
              title: Strings.next,
              onTap: () {
                _prefService
                    .createCache('${start.toStringAsFixed(0)}-${end.toStringAsFixed(0)}')
                    .whenComplete(() {});
                Get.to(const CreateProfile4());
              },
              bgColor: AppColors.buttonColor,
            ),
          ),
        ]));
  }
}

enum BestTutorSite { women, men, everyone, largegroup, friends, solo }
