import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:travelpals/create_profile/create_profile_2.dart';

import '../custom/custom_button.dart';
import '../utils/colors.dart';
import '../utils/strings.dart';

class CreateProfile extends StatefulWidget {
  const CreateProfile({Key? key}) : super(key: key);

  @override
  State<CreateProfile> createState() => _CreateProfileState();
}

class _CreateProfileState extends State<CreateProfile> {
  static final TextEditingController _email = TextEditingController();
  static final _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return ScreenUtilInit(
        builder: (_, child) {
          return Scaffold(
              backgroundColor: AppColors.bottomSheet,
              appBar: AppBar(
                backgroundColor: AppColors.whiteColor,
                title:  Text(
                  Strings.createProfile,
                  style: TextStyle(
                      fontFamily: 'Museo Sans',
                      color: AppColors.colorText,
                      fontSize: ScreenUtil().setSp(22)),
                ),
                leading: IconButton(
                  icon: const Icon(
                    Icons.arrow_back,
                    color: AppColors.arrowColor,
                  ),
                  onPressed: () {
                    Get.back();
                  },
                ),
              ),
              body: Column(children: [
                Expanded(
                  child: SingleChildScrollView(
                    child: Center(
                      child: Container(
                          padding:
                           EdgeInsets.only(left: 30.h, top: 20.h, right: 30),
                          width: double.infinity,
                          child: Column(
                            children: [
                               Align(
                                alignment: Alignment.topLeft,
                                child: Text(
                                  Strings.personalInfo,
                                  style: TextStyle(
                                      fontFamily: 'Museo Sans',
                                      fontWeight: FontWeight.bold,
                                      fontSize: ScreenUtil().setSp(26),
                                      color: AppColors.colorText),
                                ),
                              ),
                              const SizedBox(
                                height: 10,
                              ),
                              Text(
                                Strings.profileName,
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                    fontFamily: 'Museo Sans',
                                    fontWeight: FontWeight.bold,
                                    fontSize: ScreenUtil().setSp(26),
                                    color: AppColors.blackC),
                              ),
                              const Text(
                                'johnathan@gmail.com',
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                    fontFamily: 'Museo Sans Bold',
                                    fontSize: 16,
                                    color: AppColors.cancelColor),
                              ),
                              CircleAvatar(
                                  maxRadius: 70,
                                  minRadius: 70,
                                  backgroundColor: AppColors.inputColor,
                                  child: IconButton(
                                      onPressed: () {
                                        Get.snackbar("title", "message");
                                      },
                                      icon: const Icon(
                                        Icons.camera_alt_outlined,
                                        color: AppColors.cancelColor,
                                        size: 44,
                                      ))),
                               Padding(
                                padding: EdgeInsets.only(left: 18.h, right: 18.h),
                                child: Text(
                                  Strings.addProfilePhoto,
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                      fontFamily: 'Museo Sans Bold',
                                      fontSize: ScreenUtil().setSp(16),
                                      color: AppColors.cancelColor),
                                ),
                              ),
                              const SizedBox(
                                height: 50,
                              ),
                              Align(
                                alignment: Alignment.topLeft,
                                child: Text(
                                  Strings.bio,
                                  style: TextStyle(
                                      fontFamily: 'Museo Sans Bold',
                                      fontSize: ScreenUtil().setSp(18),
                                      fontWeight: FontWeight.bold,
                                      color: AppColors.blackC),
                                ),
                              ),
                              const SizedBox(
                                height: 10,
                              ),
                              Form(
                                key: _formKey,
                                child: TextFormField(
                                  validator: (value) {
                                    if (value?.isEmpty ?? true) {
                                      return 'Please Enter biography';
                                    }
                                    return null;
                                  },
                                  controller: _email,
                                  maxLines: 5,
                                  textInputAction: TextInputAction.done,
                                  style: const TextStyle(
                                      color: Colors.black, fontFamily: 'Museo Sans'),
                                  keyboardType: TextInputType.emailAddress,
                                  cursorColor: Colors.white,
                                  decoration:  InputDecoration(
                                    filled: true,
                                    fillColor: AppColors.inputColor,
                                    enabledBorder: InputBorder.none,
                                    errorBorder: const OutlineInputBorder(
                                        borderSide:
                                        BorderSide(color: AppColors.buttonColor),
                                        borderRadius:
                                        BorderRadius.all(Radius.circular(20.0))),
                                    contentPadding:
                                    EdgeInsets.only(left: 25.h, top: 50.h),
                                    focusedBorder: OutlineInputBorder(
                                        borderSide:
                                        const BorderSide(color: AppColors.buttonColor),
                                        borderRadius:
                                        BorderRadius.all(Radius.circular(20.h))),
                                    labelStyle:
                                    TextStyle(color: AppColors.colorVaarient),
                                    hintStyle: const TextStyle(
                                        fontFamily: 'Museo Sans',
                                        color: AppColors.cancelColor),
                                    hintText: Strings.enterBio,
                                  ),
                                ),
                              ),
                            ],
                          )),
                    ),
                  ),
                ),

                //bottom
                Padding(
                  padding:  EdgeInsets.only(bottom: 8.h, left: 10.h, right: 10.h),
                  child: CustomButton(
                    title: Strings.next,
                    onTap: () {
                      Get.to(const CreateProfile2());
                    },
                    bgColor: AppColors.buttonColor,
                  ),
                ),
              ]));
        });
  }

}
