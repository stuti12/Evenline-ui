import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';

import '../component/decorated_checkbox.dart';
import '../custom/custom_button.dart';
import '../utils/colors.dart';
import '../utils/strings.dart';
import 'create_profile_5.dart';

class CreateProfile4 extends StatefulWidget {
  const CreateProfile4({Key? key}) : super(key: key);

  @override
  State<CreateProfile4> createState() => _CreateProfile4State();
}

class _CreateProfile4State extends State<CreateProfile4> {
  var isSelectDifferent = false;
  var isSelectSameCountry = false;
  var isSelectSameState = false;
  var isSelectFamily = false;
  var isSelectPets = false;
  var isSelectSolo = false;
  double start = 30.0;
  double end = 50.0;

  List<String> values = [
    Strings.differentCountry,
    Strings.sameCountry,
    Strings.sameState,
    Strings.soloTravel,
    Strings.travelWithFamily,
    Strings.travelOrMeetPets
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: AppColors.bottomSheet,
        appBar: AppBar(titleSpacing: 0,
          backgroundColor: AppColors.whiteColor,
          title:  Text(
            Strings.createProfile,
            style: TextStyle(
                fontFamily: 'Museo Sans',
                color: AppColors.colorText,
                fontSize: ScreenUtil().setSp(20)),
          ),
          leading: IconButton(
            icon: const Icon(
              Icons.arrow_back,
              color: AppColors.arrowColor,
            ),
            onPressed: () {
              Get.back();
            },
          ),
        ),
        body: Column(children: [
          Expanded(
            child: SingleChildScrollView(
              child: Container(
                  padding:  EdgeInsets.only(left: 30.h, top: 20.h, right: 30),
                  width: double.infinity,
                  child: Column(
                    children: [
                      Align(
                        alignment: Alignment.topLeft,
                        child: Text(
                          Strings.whatTypeOfTravelInterested,
                          style: TextStyle(
                              fontFamily: 'Museo Sans',
                              fontWeight: FontWeight.bold,
                              fontSize: ScreenUtil().setSp(24),
                              color: AppColors.colorText),
                        ),
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      const SizedBox(
                        height: 10,
                      ),

                      //gender
                      DecoratedCheckbox(
                        isSelected: isSelectDifferent,
                        text: values[0],
                        onTap: () {
                          setState(() {
                            isSelectDifferent = !isSelectDifferent;
                          });
                        },
                      ),
                      const SizedBox(
                        height: 20,
                      ),
                      DecoratedCheckbox(
                        isSelected: isSelectSameCountry,
                        text: values[1],
                        onTap: () {
                          setState(() {
                            isSelectSameCountry = !isSelectSameCountry;
                          });
                        },
                      ),
                      const SizedBox(
                        height: 20,
                      ),
                      DecoratedCheckbox(
                        isSelected: isSelectSameState,
                        text: values[2],
                        onTap: () {
                          setState(() {
                            isSelectSameState = !isSelectSameState;
                          });
                        },
                      ),
                      const SizedBox(
                        height: 20,
                      ),

                      DecoratedCheckbox(
                        isSelected: isSelectSolo,
                        text: values[3],
                        onTap: () {
                          setState(() {
                            isSelectSolo = !isSelectSolo;
                          });
                        },
                      ),

                      const SizedBox(
                        height: 20,
                      ),

                      DecoratedCheckbox(
                        isSelected: isSelectFamily,
                        text: values[4],
                        onTap: () {
                          setState(() {
                            isSelectFamily = !isSelectFamily;
                          });
                        },
                      ),
                      const SizedBox(
                        height: 20,
                      ),

                      DecoratedCheckbox(
                        isSelected: isSelectPets,
                        text: values[5],
                        onTap: () {
                          setState(() {
                            isSelectPets = !isSelectPets;
                          });
                        },
                      ),
                    ],
                  )),
            ),
          ),

          //bottom
          Padding(
            padding: const EdgeInsets.only(bottom: 8.0, left: 10, right: 10),
            child: CustomButton(
              title: Strings.next,
              onTap: () {
                Get.to(const CreateProfile5());
              },
              bgColor: AppColors.buttonColor,
            ),
          ),
        ]));
  }
}
