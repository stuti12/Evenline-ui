import 'package:flutter/material.dart';
import 'package:flutter_multi_select_items/flutter_multi_select_items.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';

import '../custom/custom_button.dart';
import '../utils/colors.dart';
import '../utils/strings.dart';
import 'create_profile_6.dart';

class CreateProfile5 extends StatefulWidget {
  const CreateProfile5({Key? key}) : super(key: key);

  @override
  State<CreateProfile5> createState() => _CreateProfile5State();
}

class _CreateProfile5State extends State<CreateProfile5> {
  BestTutorSite _site = BestTutorSite.getStrong;
  var isSelectMale = false;
  var isSelectFemale = false;
  var isSelectNonBinary = false;
  double start = 30.0;
  double end = 50.0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: AppColors.bottomSheet,
        appBar: AppBar(
          backgroundColor: AppColors.whiteColor,
          title:  Text(
            Strings.createProfile,
            style: TextStyle(
                fontFamily: 'Museo Sans',
                color: AppColors.colorText,
                fontSize: ScreenUtil().setSp(20)),
          ),
          leading: IconButton(
            icon: const Icon(
              Icons.arrow_back,
              color: AppColors.arrowColor,
            ),
            onPressed: () {
              Get.back();
            },
          ),
        ),
        body: Column(children: [
          Expanded(
            child: SingleChildScrollView(
              child: Container(
                  padding: EdgeInsets.only(left: 30.h, top: 20.h, right: 30),
                  width: double.infinity,
                  child: Column(
                    children: [
                       Align(
                        alignment: Alignment.topLeft,
                        child: Text(
                          Strings.chooseYourIntrest,
                          style: TextStyle(
                              fontFamily: 'Museo Sans',
                              fontWeight: FontWeight.bold,
                              fontSize: ScreenUtil().setSp(24),
                              color: AppColors.colorText),
                        ),
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      MultiSelectContainer(
                          itemsDecoration: MultiSelectDecorations(
                              selectedDecoration: BoxDecoration(
                                  color: AppColors.buttonColor,
                                  border: Border.all(
                                      width: 2, color: AppColors.buttonColor),
                                  borderRadius: BorderRadius.circular(30))),
                          items: [
                            MultiSelectCard(
                                value: 'Water sports', label: 'Water sports'),
                            MultiSelectCard(
                                value: 'Scuba diving', label: 'Scuba diving'),
                            MultiSelectCard(value: 'Boating', label: 'Boating'),
                            MultiSelectCard(
                                value: 'Winter Sports', label: 'Winter Sports'),
                            MultiSelectCard(value: 'Hiking', label: 'Hiking'),
                            MultiSelectCard(
                                value: 'Clubbing', label: 'Clubbing'),
                            MultiSelectCard(value: 'Food', label: 'Food'),
                            MultiSelectCard(value: 'Cafe', label: 'Cafe'),
                            MultiSelectCard(
                                value: 'Exploring', label: 'Exploring'),
                            MultiSelectCard(value: 'Museums', label: 'Museums'),
                            MultiSelectCard(
                                value: 'Water sports', label: 'Water sports'),
                            MultiSelectCard(
                                value: 'Scuba diving', label: 'Scuba diving'),
                            MultiSelectCard(value: 'Boating', label: 'Boating'),
                            MultiSelectCard(
                                value: 'Winter Sports', label: 'Winter Sports'),
                            MultiSelectCard(value: 'Hiking', label: 'Hiking'),
                            MultiSelectCard(
                                value: 'Clubbing', label: 'Clubbing'),
                            MultiSelectCard(value: 'Food', label: 'Food'),
                            MultiSelectCard(value: 'Cafe', label: 'Cafe'),
                            MultiSelectCard(
                                value: 'Exploring', label: 'Exploring'),
                            MultiSelectCard(value: 'Museums', label: 'Museums')
                          ],
                          onChange: (allSelectedItems, selectedItem) {})
                    ],
                  )),
            ),
          ),

          //bottom
          Padding(
            padding: const EdgeInsets.only(bottom: 8.0, left: 10, right: 10),
            child: CustomButton(
              title: Strings.next,
              onTap: () {
                Get.to(const CreateProfile6());
              },
              bgColor: AppColors.buttonColor,
            ),
          ),
        ]));
  }
}

enum BestTutorSite { getStrong, build, power, recomposition }
