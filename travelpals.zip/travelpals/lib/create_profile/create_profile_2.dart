import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:travelpals/create_profile/profile_shared_pref.dart';

import '../component/decorated_radio_button.dart';
import '../custom/custom_button.dart';
import '../utils/colors.dart';
import '../utils/strings.dart';
import 'create_profile_3.dart';
import 'create_profile_4.dart';

class CreateProfile2 extends StatefulWidget {
  const CreateProfile2({Key? key}) : super(key: key);

  @override
  State<CreateProfile2> createState() => _CreateProfile2State();
}

class _CreateProfile2State extends State<CreateProfile2> {
  var isSelectMale = false;
  var isSelectFemale = false;
  var isSelectNonBinary = false;

  int selectedGenderVar = 0;
  double start = 30.0;
  double end = 50.0;

  final ProfilePrefService _prefService = ProfilePrefService();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: AppColors.bottomSheet,
        appBar: AppBar(titleSpacing: 0,
          backgroundColor: AppColors.whiteColor,
          title:  Text(
            Strings.createProfile,
            style: TextStyle(
                fontFamily: 'Museo Sans',
                color: AppColors.colorText,
                fontSize: ScreenUtil().setSp(20)),
          ),
          leading: IconButton(
            icon: const Icon(
              Icons.arrow_back,
              color: AppColors.arrowColor,
            ),
            onPressed: () {
              Get.back();
            },
          ),
        ),
        body: Column(children: [
          Expanded(
            child: SingleChildScrollView(
              child: Container(
                  padding:  EdgeInsets.only(left: 30.h, top: 20.h, right: 30),
                  width: double.infinity,
                  child: Column(
                    children: [
                       Align(
                        alignment: Alignment.topLeft,
                        child: Text(
                          Strings.howDoYouIdentify,
                          style: TextStyle(
                              fontFamily: 'Museo Sans',
                              fontWeight: FontWeight.w700,
                              fontSize: ScreenUtil().setSp(24),
                              color: AppColors.colorText),
                        ),
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                       Align(
                        alignment: Alignment.topLeft,
                        child: Text(
                          Strings.selectYourGender,
                          style: TextStyle(
                              fontFamily: 'Museo Sans',
                              fontSize: ScreenUtil().setSp(16),
                              fontWeight: FontWeight.w500,
                              color: AppColors.colorText),
                        ),
                      ),
                      const SizedBox(
                        height: 10,
                      ),

                      //gender
                      selectGender(),

                       Align(
                        alignment: Alignment.topLeft,
                        child: Text(
                          Strings.ageGroup,
                          style: TextStyle(
                              fontFamily: 'Museo Sans',
                              fontWeight: FontWeight.w700,
                              fontSize: ScreenUtil().setSp(24),
                              color: AppColors.colorText),
                        ),
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      Container(
                        height: 130,
                        width: double.infinity,
                        decoration: BoxDecoration(
                            border: Border.all(
                                color: AppColors.colorBorder, width: 2),
                            borderRadius:
                                const BorderRadius.all(Radius.circular(30))),
                        child: Column(
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Padding(
                                  padding:
                                      const EdgeInsets.only(left: 18, top: 8.0),
                                  child: Text(
                                    Strings.age,
                                    style: TextStyle(
                                        fontFamily: 'Museo Sans',
                                        fontWeight: FontWeight.bold,
                                        fontSize: 20,
                                        color: AppColors.blackC),
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(
                                      top: 8.0, right: 18),
                                  child: RichText(
                                    text: TextSpan(
                                        text:
                                            '${start.toStringAsFixed(0)}-${end.toStringAsFixed(0)}\n',
                                        style: TextStyle(
                                            fontFamily: 'Museo Sans',
                                            fontSize: ScreenUtil().setSp(24),
                                            fontWeight: FontWeight.w700,
                                            color: AppColors.blackC),
                                        children:  <TextSpan>[
                                          TextSpan(
                                            text: Strings.years,
                                            style: TextStyle(
                                                fontFamily: 'Museo Sans',fontWeight: FontWeight.w500,
                                                fontSize: ScreenUtil().setSp(16),
                                                color: AppColors.colorVaarient),
                                          ),
                                        ]),
                                  ),
                                ),
                              ],
                            ),
                            RangeSlider(
                              activeColor: AppColors.buttonColor,
                              values: RangeValues(start, end),
                              labels:
                                  RangeLabels(start.toString(), end.toString()),
                              onChanged: (value) {
                                setState(() {
                                  start = value.start;
                                  end = value.end;

                                });
                              },
                              min: 10.0,
                              max: 80.0,
                            ),
                          ],
                        ),
                      ),
                    ],
                  )),
            ),
          ),

          //bottom
          Padding(
            padding: const EdgeInsets.only(bottom: 8.0, left: 10, right: 10),
            child: CustomButton(
              title: Strings.next,
              onTap: () {
                _prefService
                    .createCache('${start.toStringAsFixed(0)}-${end.toStringAsFixed(0)}')
                    .whenComplete(() {});
               /* print("shared pref ${ _prefService
                    .createCache('${start.toStringAsFixed(0)}-${end.toStringAsFixed(0)}')
                    .whenComplete(() {})}");*/
                Get.to(const CreateProfile3());
              },
              bgColor: AppColors.buttonColor,
            ),
          ),
        ]));
  }

  Widget selectGender() {
    return Column(
      children: [
        DecoratedRadioButton(
          isSelected: 1 == selectedGenderVar,
          text: Strings.male,
          onTap: () {
            setState(() {
              selectedGenderVar = 1;
            });
          },
        ),
        // selectedGender(Strings.male, 1, selectedGenderVar),
        const SizedBox(
          height: 5,
        ),
        DecoratedRadioButton(
          isSelected: 2 == selectedGenderVar,
          text: Strings.female,
          onTap: () {
            setState(() {
              selectedGenderVar = 2;
            });
          },
        ),

        // selectedGender(Strings.female, 2, selectedGenderVar),
        const SizedBox(
          height: 5,
        ),
        DecoratedRadioButton(
          isSelected: 3 == selectedGenderVar,
          text: Strings.nonBinary,
          onTap: () {
            setState(() {
              selectedGenderVar = 3;
            });
          },
        ),

        // selectedGender(Strings.nonBinary, 3, selectedGenderVar)
      ],
    );
  }
}


