import 'package:shared_preferences/shared_preferences.dart';

class ProfilePrefService {
  Future createCache(String age) async {
    SharedPreferences _preferences = await SharedPreferences.getInstance();
    _preferences.setString("age", age);
  }

  Future createPartnerListCache(List<String> partner) async {
    SharedPreferences _preferences = await SharedPreferences.getInstance();
    _preferences.setStringList("partner", partner);
  }

  Future createTravelInterestListCache(List<String> partner) async {
    SharedPreferences _preferences = await SharedPreferences.getInstance();
    _preferences.setStringList("travelintrest", partner);
  }

  Future createActivityInterestListCache(List<String> partner) async {
    SharedPreferences _preferences = await SharedPreferences.getInstance();
    _preferences.setStringList("activityintrest", partner);
  }

  Future<String?> readCache(String age) async {
    SharedPreferences _preferences = await SharedPreferences.getInstance();
    var cache = _preferences.getString("age");
    return cache;
  }

  Future readPartnerListCache(List<String> partner) async {
    SharedPreferences _preferences = await SharedPreferences.getInstance();
    var cache = _preferences.getStringList("partner");
    return cache;
  }

  Future readTravelInterestListCache(List<String> partner) async {
    SharedPreferences _preferences = await SharedPreferences.getInstance();
    var cache = _preferences.getStringList("travelintrest");
    return cache;
  }

  Future readActivityInterestListCache(List<String> partner) async {
    SharedPreferences _preferences = await SharedPreferences.getInstance();
    var cache = _preferences.getStringList("activityintrest");
    return cache;
  }


  Future removeCache(String age) async {
    SharedPreferences _preferences = await SharedPreferences.getInstance();
    _preferences.remove("age");
  }
}
