import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_multi_select_items/flutter_multi_select_items.dart';
import 'package:get/get.dart';

import '../authentication/login/signup.dart';
import '../bottom_tab/trip/trips.dart';
import '../custom/custom_button.dart';
import '../custom/text_style.dart';
import '../utils/colors.dart';
import '../utils/strings.dart';

class OtherUserProfile extends StatefulWidget {
  const OtherUserProfile({Key? key}) : super(key: key);

  @override
  State<OtherUserProfile> createState() => _OtherUserProfileState();
}

class _OtherUserProfileState extends State<OtherUserProfile> {
  List<String> images = [
    "https://static.javatpoint.com/tutorial/flutter/images/flutter-logo.png",
    "https://static.javatpoint.com/tutorial/flutter/images/flutter-logo.png",
    "https://static.javatpoint.com/tutorial/flutter/images/flutter-logo.png",
    "https://static.javatpoint.com/tutorial/flutter/images/flutter-logo.png",
    "https://static.javatpoint.com/tutorial/flutter/images/flutter-logo.png",
    "https://static.javatpoint.com/tutorial/flutter/images/flutter-logo.png",
    "https://static.javatpoint.com/tutorial/flutter/images/flutter-logo.png",
    "https://static.javatpoint.com/tutorial/flutter/images/flutter-logo.png",
    "https://static.javatpoint.com/tutorial/flutter/images/flutter-logo.png",
    "https://static.javatpoint.com/tutorial/flutter/images/flutter-logo.png",
    "https://static.javatpoint.com/tutorial/flutter/images/flutter-logo.png",
    "https://static.javatpoint.com/tutorial/flutter/images/flutter-logo.png",
    "https://static.javatpoint.com/tutorial/flutter/images/flutter-logo.png",
  ];

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: CustomScrollView(slivers: <Widget>[
      SliverAppBar(
        backgroundColor: Colors.transparent,
        snap: false,
        pinned: true,
        floating: false,

        expandedHeight: 230,
        //IconButton
        actions: <Widget>[
          //IconButton
          Padding(
            padding: const EdgeInsets.only(top: 16.0, right: 8.0),
            child: Text(
              Strings.reportText,
              style: TextStyle(
                  fontFamily: 'Museo Sans',
                  color: AppColors.whiteColor,
                  fontSize: 18),
            ),
          ), //IconButton
        ],
        flexibleSpace: LayoutBuilder(builder: (context, cons) {
          return FlexibleSpaceBar(
            centerTitle: true,
            title: Row(children: [
              const SizedBox(
                width: 50,
                height: 12,
              ),
              Visibility(
                visible: cons.biggest.height <= 130,
                child: const CircleAvatar(
                  backgroundImage: AssetImage('assets/profilematch.png'),
                ),
              ),
              const SizedBox(width: 12),
              Visibility(
                visible: cons.biggest.height <= 130,
                child: RichText(
                  text: TextSpan(
                    text: "Namita Singh",
                    style: UITextStyle.regularTextStyle(
                      color: AppColors.colorText,
                      fontSize: 20,
                    ),
                  ),
                ),
              ),
              const Spacer(),
            ]),
            background:
                Image.asset('assets/profilematch.png', fit: BoxFit.cover),
          );
        }),
        //<Widget>[]
      ),
      SliverToBoxAdapter(
        child: Padding(
          padding: const EdgeInsets.only(left: 12.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              const Text(
                'Namita Singh',
                style: TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'Museo Sans',
                    color: AppColors.colorText),
              ),
              const SizedBox(
                height: 10,
              ),
              Row(
                children: const [
                  Icon(
                    Icons.person_outline_rounded,
                    color: AppColors.colorText,
                  ),
                  Expanded(
                      child: Text(
                    Strings.matchNotDesc,
                    style: TextStyle(
                        fontSize: 16,
                        fontFamily: 'Museo Sans',
                        color: AppColors.colorText),
                  )),
                ],
              ),
              const SizedBox(
                height: 10,
              ),
              Row(
                children: const [
                  Icon(
                    Icons.location_on_outlined,
                    color: AppColors.colorText,
                  ),
                  Expanded(
                      child: Text(
                    'Boston, MI, USA',
                    style: TextStyle(
                        fontSize: 16,
                        fontFamily: 'Museo Sans',
                        color: AppColors.colorText),
                  )),
                ],
              ),
              const SizedBox(
                height: 10,
              ),
              const Text(
                Strings.iHaveInterested,
                style: TextStyle(
                    fontSize: 22,
                    fontFamily: 'Museo Sans',
                    color: AppColors.colorText),
              ),
              const SizedBox(
                height: 10,
              ),
              MultiSelectContainer(
                  maxSelectableCount: 0,
                  textStyles: const MultiSelectTextStyles(
                      textStyle: TextStyle(
                    fontFamily: 'Museo Sans',
                    fontSize: 13,
                  )),
                  itemsDecoration: MultiSelectDecorations(
                      selectedDecoration: BoxDecoration(
                          color: AppColors.buttonColor,
                          border: Border.all(
                              width: 2, color: AppColors.buttonColor),
                          borderRadius: BorderRadius.circular(30))),
                  items: [
                    MultiSelectCard(
                        value: 'Water sports', label: Strings.waterSports),
                    MultiSelectCard(value: 'Food', label: Strings.food),
                    MultiSelectCard(value: 'Exercise', label: Strings.exercise),
                    MultiSelectCard(
                        value: 'Background Check',
                        label: Strings.backgroundCheck),
                  ],
                  onChange: (allSelectedItems, selectedItem) {}),
              const SizedBox(
                height: 10,
              ),

              Row(
                children: const [
                  Text(
                    Strings.trips,
                    style: TextStyle(
                        fontFamily: 'Museo Sans',
                        fontWeight: FontWeight.bold,
                        fontSize: 20,
                        color: AppColors.colorText),
                  ),
                  Expanded(
                      child: Padding(
                    padding: EdgeInsets.only(right: 8.0),
                    child: Align(
                        alignment: Alignment.topRight,
                        child: Text(
                          Strings.viewAll,
                          style: TextStyle(
                              fontSize: 16,
                              fontFamily: 'Museo Sans',
                              color: AppColors.colorText),
                          textAlign: TextAlign.end,
                        )),
                  )),
                ],
              ),

              //horizontal
              Container(
                height: 200,
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  children: <Widget>[
                    Card(
                      semanticContainer: true,
                      clipBehavior: Clip.antiAliasWithSaveLayer,
                      elevation: 10,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10)),
                      child: Container(
                          constraints: const BoxConstraints(
                              maxHeight: double.minPositive),
                          width: 200.0,
                          height: 80,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Carousel(),
                              Row(
                                children: [
                                  Padding(
                                    padding: const EdgeInsets.only(left: 8.0),
                                    child: Image.asset(
                                      "assets/picture.png",
                                      width: 50,
                                      height: 50,
                                    ),
                                  ),
                                  const Padding(
                                    padding: EdgeInsets.only(left: 8.0),
                                    child: Text(
                                      'Adam',
                                      style: TextStyle(
                                          fontFamily: 'Museo Sans',
                                          fontSize: 20,
                                          color: AppColors.colorText),
                                      textAlign: TextAlign.start,
                                    ),
                                  ),
                                ],
                              ),
                              const Text(
                                'At vero eos et accusamus et iusto odio dignissimos  ...',
                                style: TextStyle(
                                    fontFamily: 'Museo Sans',
                                    fontSize: 13,
                                    color: AppColors.cancelColor),
                                textAlign: TextAlign.start,
                              ),
                            ],
                          )),
                    ),
                    Container(
                        constraints:
                            const BoxConstraints(maxHeight: double.minPositive),
                        width: 200.0,
                        height: 80,
                        child: Card(
                          semanticContainer: true,
                          clipBehavior: Clip.antiAliasWithSaveLayer,
                          elevation: 10,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10)),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Carousel(),
                              Row(
                                children: [
                                  Padding(
                                    padding: const EdgeInsets.only(left: 8.0),
                                    child: Image.asset(
                                      "assets/picture.png",
                                      width: 50,
                                      height: 50,
                                    ),
                                  ),
                                  const Padding(
                                    padding: EdgeInsets.only(left: 8.0),
                                    child: Text(
                                      'Adam',
                                      style: TextStyle(
                                          fontFamily: 'Museo Sans',
                                          fontSize: 20,
                                          color: AppColors.colorText),
                                      textAlign: TextAlign.start,
                                    ),
                                  ),
                                ],
                              ),
                              const Text(
                                'At vero eos et accusamus et iusto odio dignissimos  ...',
                                style: TextStyle(
                                    fontFamily: 'Museo Sans',
                                    fontSize: 13,
                                    color: AppColors.cancelColor),
                                textAlign: TextAlign.start,
                              ),
                            ],
                          ),
                        )),
                  ],
                ),
              ),
              const SizedBox(
                height: 40,
              ),
              const Text(
                Strings.photosAndVideos,
                style: TextStyle(
                    fontFamily: 'Museo Sans',
                    fontWeight: FontWeight.bold,
                    fontSize: 20,
                    color: AppColors.colorText),
              ),
              const SizedBox(
                height: 10,
              ),
              GridView.count(
                  shrinkWrap: true,
                  crossAxisCount: 4,
                  crossAxisSpacing: 0,
                  children: List.generate(images.length, (index) {
                    return Center(
                      child: Card(
                          semanticContainer: true,
                          clipBehavior: Clip.antiAliasWithSaveLayer,
                          elevation: 2,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(15)),
                          shadowColor: AppColors.blackC.withOpacity(0.7),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Stack(
                                alignment: AlignmentDirectional.topCenter,
                                fit: StackFit.loose,
                                children: [
                                  Image.network(images[index], fit: BoxFit.fill)
                                ],
                              )
                            ],
                          )),
                    );
                  }))
            ],
          ),
        ),
      )
    ]));
  }

  //bottomsheet function
  Future<void> showBottomSheets() async {
    OS? _os = OS.windows;

    await Get.bottomSheet(ClipRRect(
      borderRadius: const BorderRadius.only(
          topRight: Radius.circular(30), topLeft: Radius.circular(30)),
      child: StatefulBuilder(
        builder: (context, setState) => Container(
          padding: const EdgeInsets.only(left: 20, right: 20),
          height: 276,
          color: AppColors.bottomSheet,
          child: Column(
            children: [
              Column(
                children: [
                  const SizedBox(
                    height: 20,
                  ),
                  const Text(
                    Strings.performBackground,
                    style: TextStyle(
                        fontFamily: 'Museo Sans',
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                        color: AppColors.colorText),
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                  const Text(
                    Strings.loreumText,
                    style: TextStyle(
                        fontFamily: 'Museo Sans',
                        fontSize: 20,
                        color: AppColors.colorText),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  Row(
                    children: [
                      Radio<OS>(
                        activeColor: AppColors.cancelColor,
                        toggleable: true,
                        value: OS.mac,
                        groupValue: _os,
                        onChanged: (OS? value) {
                          setState(() {
                            _os = value;
                          });
                        },
                      ),
                      RichText(
                        text: TextSpan(
                            text: Strings.agree,
                            style: const TextStyle(
                                fontFamily: 'Museo Sans',
                                fontSize: 18.0,
                                color: AppColors.colorVaarient),
                            children: <TextSpan>[
                              TextSpan(
                                text: Strings.terms,
                                style: TextStyle(
                                    fontFamily: 'Museo Sans',
                                    fontSize: 18.0,
                                    color: AppColors.blackC),
                              ),
                            ]),
                      ),
                    ],
                  ),
                ],
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Expanded(
                    child: CustomButton(
                      title: Strings.cancel,
                      onTap: () {
                        Get.back();
                      },
                      textColor: AppColors.buttonColor,
                      bgColor: AppColors.whiteColor,
                    ),
                  ),
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: CustomButton(
                        title: Strings.check,
                        onTap: () {},
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    ));
  }
}

class Carousel extends StatefulWidget {
  const Carousel({
    Key? key,
  }) : super(key: key);

  @override
  State<Carousel> createState() => _CarouselState();
}

class _CarouselState extends State<Carousel> {
  late PageController _pageController;

  List<String> images = [
    "https://images.wallpapersden.com/image/download/purple-sunrise-4k-vaporwave_bGplZmiUmZqaraWkpJRmbmdlrWZlbWU.jpg",
    "https://wallpaperaccess.com/full/2637581.jpg",
    "https://uhdwallpapers.org/uploads/converted/20/01/14/the-mandalorian-5k-1920x1080_477555-mm-90.jpg"
  ];

  int activePage = 1;

  @override
  void initState() {
    super.initState();

    _pageController = PageController(initialPage: 1);
  }

  bool onTap = false;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        SizedBox(
          height: 110,
          child: Stack(children: [
            PageView.builder(
                itemCount: images.length,
                pageSnapping: true,
                controller: _pageController,
                onPageChanged: (page) {
                  setState(() {
                    activePage = page;
                  });
                },
                itemBuilder: (context, pagePosition) {
                  bool active = pagePosition == activePage;
                  return slider(images, pagePosition, active);
                }),
            Positioned(
                bottom: 0,
                left: 0,
                right: 0,
                child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: indicators(images.length, activePage))),
          ]),
        ),
      ],
    );
  }
}

Card slider(images, pagePosition, active) {
  double margin = active ? 1 : 1;

  return Card(
    semanticContainer: true,
    clipBehavior: Clip.antiAliasWithSaveLayer,
    elevation: 10,
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
    child: AnimatedContainer(
      duration: const Duration(milliseconds: 50),
      curve: Curves.easeInOutCubic,
      margin: EdgeInsets.all(margin),
      decoration: BoxDecoration(
          image: DecorationImage(
              image: NetworkImage(images[pagePosition]), fit: BoxFit.fitWidth)),
    ),
  );
}
