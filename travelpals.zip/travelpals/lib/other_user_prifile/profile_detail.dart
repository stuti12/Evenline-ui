import 'package:flutter/material.dart';
import 'package:flutter_multi_select_items/flutter_multi_select_items.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';

import '../custom/text_style.dart';
import '../utils/colors.dart';

class ProfileDetailPage extends StatelessWidget {
  // final ProfileDetailController profileDetailController =
  // Get.put(ProfileDetailController());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: CustomScrollView(slivers: [
        SliverAppBar(
          pinned: true,
          expandedHeight: 250,
          backgroundColor: AppColors.whiteColor,
          leading: IconButton(
            icon: const Icon(
              Icons.arrow_back,
              color: AppColors.arrowColor,
            ),
            onPressed: () {
              Get.back();
            },
          ),
          actions: [
            Padding(
              padding: EdgeInsets.only(right: 10),
              child: TextButton(
                style: TextButton.styleFrom(
                  textStyle: UITextStyle.regularTextStyle(
                    fontSize: 18,
                  ),
                ),
                onPressed: () {},
                child: Text('Report'),
              ),
            ),
          ],
          flexibleSpace: LayoutBuilder(builder: (context, cons) {
            return FlexibleSpaceBar(
              centerTitle: true,
              title: Row(children: [
                SizedBox(width: 15),
                Visibility(
                  visible: cons.biggest.height <= 130,
                  child: InkWell(
                      splashColor: AppColors.whiteColor,
                      onTap: () {
                        FocusScope.of(context).unfocus();
                        if (Navigator.of(context).canPop()) {
                          Navigator.of(context).pop();
                        }
                      },
                      child: Image.asset('')),
                ),
                SizedBox(width: 12),
                Visibility(
                  visible: cons.biggest.height <= 130,
                  child: CircleAvatar(
                    backgroundImage: AssetImage(''),
                  ),
                ),
                SizedBox(width: 12),
                Visibility(
                  visible: cons.biggest.height <= 130,
                  child: RichText(
                    text: TextSpan(
                      text: "Namita Singh",
                      style: UITextStyle.regularTextStyle(
                        color: AppColors.colorText,
                        fontSize: 20,
                      ),
                    ),
                  ),
                ),
                Spacer(),
                Visibility(
                  visible: cons.biggest.height <= 130,
                  child: Padding(
                    padding: EdgeInsets.only(right: 10),
                    child: TextButton(
                      style: TextButton.styleFrom(
                        textStyle: UITextStyle.regularTextStyle(
                          fontSize: 18,
                        ),
                      ),
                      onPressed: () {},
                      child: Text('Report'),
                    ),
                  ),
                )
              ]),
              background: Image.asset('', fit: BoxFit.cover),
            );
          }),
        ),
        SliverToBoxAdapter(
            child: Column(
          children: [
            Container(
              decoration: BoxDecoration(
                color: Colors.white,
                // borderRadius: BorderRadius.circular(35)
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Padding(
                    padding: const EdgeInsets.only(
                      left: 20.0,
                      right: 20.0,
                      top: 20.0,
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        RichText(
                          text: TextSpan(
                            text: "Namita Singh",
                            style: UITextStyle.regularTextStyle(
                              color: AppColors.colorText,
                              fontSize: 22,
                            ),
                          ),
                        ),
                        SizedBox(
                          height: 10,
                        ),
                        Row(
                          children: [
                            Icon(Icons.person_outline_rounded),
                            SizedBox(
                              width: 8,
                            ),
                            Expanded(
                              child: SizedBox(
                                child: RichText(
                                  textAlign: TextAlign.left,
                                  overflow: TextOverflow.clip,
                                  // maxLines: 2,
                                  text: TextSpan(
                                    text:
                                        "At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium ",
                                    style: UITextStyle.regularTextStyle(
                                      color: AppColors.colorText,
                                      fontSize: 12,
                                    ),
                                  ),
                                ),
                              ),
                            )
                          ],
                        ),
                        SizedBox(
                          height: 10,
                        ),
                        Row(
                          children: [
                            SizedBox(
                              width: 8,
                            ),
                            Expanded(
                              child: SizedBox(
                                child: RichText(
                                  textAlign: TextAlign.left,
                                  overflow: TextOverflow.clip,
                                  // maxLines: 2,
                                  text: TextSpan(
                                    text: "Boston, MI, USA",
                                    style: UITextStyle.regularTextStyle(
                                      color: AppColors.whiteColor,
                                      fontSize: 12,
                                    ),
                                  ),
                                ),
                              ),
                            )
                          ],
                        ),
                        SizedBox(
                          height: 24.h,
                        ),
                        RichText(
                          text: TextSpan(
                            text: "I have Interest in,",
                            style: UITextStyle.regularTextStyle(
                              color: AppColors.colorText,
                              fontSize: 16,
                            ),
                          ),
                        ),
                        SizedBox(
                          height: 12,
                        ),
                        MultiSelectContainer(
                            maxSelectableCount: 0,
                            textStyles: MultiSelectTextStyles(
                                textStyle: UITextStyle.regularTextStyle(
                              color: AppColors.colorText,
                              fontSize: 12,
                            )),
                            itemsDecoration: MultiSelectDecorations(
                              decoration: BoxDecoration(
                                color: AppColors.colorText.withAlpha(20),
                                borderRadius: BorderRadius.circular(20),
                              ),
                            ),
                            items: [
                              MultiSelectCard(
                                  value: 'Water sports', label: 'Water sports'),
                              MultiSelectCard(
                                  value: 'Scuba diving', label: 'Scuba diving'),
                              MultiSelectCard(
                                value: 'Boating',
                                label: 'Boating',
                              ),
                            ],
                            onChange: (allSelectedItems, selectedItem) {}),
                        SizedBox(
                          height: 18,
                        ),
                        MultiSelectContainer(
                            maxSelectableCount: 0,
                            textStyles: MultiSelectTextStyles(
                                textStyle: UITextStyle.regularTextStyle(
                              color: AppColors.whiteColor,
                              fontSize: 14,
                            )),
                            itemsDecoration: MultiSelectDecorations(
                              decoration: BoxDecoration(
                                color: AppColors.buttonColor,
                                borderRadius: BorderRadius.circular(20),
                              ),
                            ),
                            items: [
                              MultiSelectCard(
                                  value: 'Background Check',
                                  label: 'Background Check'),
                            ],
                            onChange: (allSelectedItems, selectedItem) {}),
                        SizedBox(
                          height: 18,
                        ),
                      ],
                    ),
                  ),
                  Container(
                    decoration: BoxDecoration(
                        border:
                            Border.all(color: Color.fromRGBO(204, 249, 251, 1)),
                        color: AppColors.inputColor),
                    height: 300,
                    width: double.infinity,
                    child: Padding(
                      padding: const EdgeInsets.all(20.0),
                      child: Column(
                        children: [
                          Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              Expanded(
                                child: Text("Trips",
                                    style: UITextStyle.regularTextStyle(
                                      color: AppColors.colorText,
                                      fontSize: 20,
                                    )),
                              ),
                              SizedBox(
                                height: 25.h,
                                child: TextButton(
                                  style: TextButton.styleFrom(
                                    // backgroundColor: Colors.red,

                                    textStyle: UITextStyle.regularTextStyle(
                                      fontSize: 12,
                                      // txtAlignment: TextAlign.right
                                    ),
                                  ),
                                  onPressed: () {},
                                  child: Text('View All'),
                                ),
                              )
                            ],
                          ),
                          Flexible(
                            child: GridView.builder(
                              scrollDirection: Axis.horizontal,
                              gridDelegate:
                                  new SliverGridDelegateWithFixedCrossAxisCount(
                                      crossAxisCount: 1,
                                      childAspectRatio:
                                          (double.infinity / 0.6) /
                                              (double.infinity / 1.4),
                                      crossAxisSpacing: 2.0,
                                      mainAxisSpacing: 12.0),
                              itemCount: 5,
                              itemBuilder: (BuildContext context, int index) {
                                return Container(
                                  child: Column(children: [
                                    Card(
                                        color: Colors.white,
                                        shape: RoundedRectangleBorder(
                                          borderRadius:
                                              BorderRadius.circular(15),
                                        ),
                                        elevation: 2.0,
                                        shadowColor:
                                            AppColors.blackC.withOpacity(0.7),
                                        child: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            Stack(
                                              alignment: AlignmentDirectional
                                                  .topCenter,
                                              fit: StackFit.loose,
                                              children: <Widget>[
                                                SizedBox(
                                                  child: Image.asset(
                                                    '',
                                                    fit: BoxFit.fill,
                                                  ),
                                                ),
                                                Align(
                                                    alignment:
                                                        Alignment.topRight,
                                                    child: InkWell(
                                                        splashColor:
                                                            Colors.transparent,
                                                        onTap: () {},
                                                        child: Padding(
                                                            padding:
                                                                const EdgeInsets
                                                                    .all(8.0),
                                                            child: Image.asset(
                                                              '',
                                                              height: 15,
                                                              width: 15,
                                                            ))))
                                              ],
                                            ),
                                            SizedBox(
                                              height: 15,
                                            ),
                                            Padding(
                                              padding: const EdgeInsets.only(
                                                left: 10.0,
                                                right: 10.0,
                                              ),
                                              child: Row(
                                                children: [
                                                  CircleAvatar(
                                                    radius: 12.0,
                                                    backgroundImage: NetworkImage(
                                                        "https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=1600"),
                                                    backgroundColor:
                                                        Colors.transparent,
                                                  ),
                                                  SizedBox(
                                                    width: 5,
                                                  ),
                                                  Text(
                                                    "Adam Jane",
                                                    style: UITextStyle
                                                        .regularTextStyle(
                                                      color:
                                                          AppColors.colorText,
                                                      fontSize: 16,
                                                    ),
                                                  )
                                                ],
                                              ),
                                            ),
                                            Padding(
                                              padding:
                                                  const EdgeInsets.all(10.0),
                                              child: Text(
                                                "At vero eos et accusamus et iusto odio dignissimos  ...",
                                                style: UITextStyle
                                                    .regularTextStyle(
                                                  color: AppColors.colorText,
                                                  fontSize: 12,
                                                ),
                                              ),
                                            ),
                                          ],
                                        ))
                                  ]),
                                );
                              },
                            ),
                          )
                        ],
                      ),
                    ),
                  ),
                  SizedBox(height: 24),
                  Container(
                    height: 300,
                    width: double.infinity,
                    child: Padding(
                      padding: const EdgeInsets.all(20.0),
                      child: Column(
                        children: [
                          Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              Expanded(
                                child: Text("Blogs",
                                    style: UITextStyle.regularTextStyle(
                                      color: AppColors.colorText,
                                      fontSize: 20,
                                    )),
                              ),
                              SizedBox(
                                height: 25,
                                child: TextButton(
                                  style: TextButton.styleFrom(
                                    // backgroundColor: Colors.red,
                                    primary: AppColors.colorText,
                                    textStyle: UITextStyle.regularTextStyle(
                                      fontSize: 12,

                                      // txtAlignment: TextAlign.right
                                    ),
                                  ),
                                  onPressed: () {},
                                  child: Text('View All'),
                                ),
                              )
                            ],
                          ),
                          Flexible(
                            child: GridView.builder(
                              scrollDirection: Axis.horizontal,
                              gridDelegate:
                                  new SliverGridDelegateWithFixedCrossAxisCount(
                                      crossAxisCount: 1,
                                      childAspectRatio:
                                          (double.infinity / 0.6) /
                                              (double.infinity / 1.4),
                                      crossAxisSpacing: 2.0,
                                      mainAxisSpacing: 12.0),
                              itemCount: 5,
                              itemBuilder: (BuildContext context, int index) {
                                return Container(
                                  child: Column(children: [
                                    Card(
                                        color: Colors.white,
                                        shape: RoundedRectangleBorder(
                                          borderRadius:
                                              BorderRadius.circular(15),
                                        ),
                                        elevation: 2.0,
                                        shadowColor:
                                            AppColors.blackC.withOpacity(0.7),
                                        child: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            Stack(
                                              alignment: AlignmentDirectional
                                                  .topCenter,
                                              fit: StackFit.loose,
                                              children: <Widget>[
                                                SizedBox(
                                                  child: Image.asset(
                                                    '',
                                                    fit: BoxFit.fill,
                                                  ),
                                                ),
                                                Align(
                                                    alignment:
                                                        Alignment.topRight,
                                                    child: InkWell(
                                                        splashColor:
                                                            Colors.transparent,
                                                        onTap: () {},
                                                        child: Padding(
                                                            padding:
                                                                const EdgeInsets
                                                                    .all(8.0),
                                                            child: Image.asset(
                                                              index % 2 == 0
                                                                  ? ''
                                                                  : '',
                                                              height: 15,
                                                              width: 15,
                                                            ))))
                                              ],
                                            ),
                                            SizedBox(
                                              height: 15,
                                            ),
                                            Padding(
                                              padding: const EdgeInsets.only(
                                                left: 10.0,
                                                right: 10.0,
                                              ),
                                              child: Row(
                                                children: [
                                                  CircleAvatar(
                                                    radius: 12.0,
                                                    backgroundImage: NetworkImage(
                                                        "https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=1600"),
                                                    backgroundColor:
                                                        Colors.transparent,
                                                  ),
                                                  SizedBox(
                                                    width: 5,
                                                  ),
                                                  Text(
                                                    "Adam Jane",
                                                    style: UITextStyle
                                                        .regularTextStyle(
                                                      color:
                                                          AppColors.colorText,
                                                      fontSize: 16,
                                                    ),
                                                  )
                                                ],
                                              ),
                                            ),
                                            Padding(
                                              padding:
                                                  const EdgeInsets.all(10.0),
                                              child: Text(
                                                "At vero eos et accusamus et iusto odio dignissimos  ...",
                                                style: UITextStyle
                                                    .regularTextStyle(
                                                  color: AppColors.colorText,
                                                  fontSize: 12,
                                                ),
                                              ),
                                            ),
                                          ],
                                        ))
                                  ]),
                                );
                              },
                            ),
                          )
                        ],
                      ),
                    ),
                  ),
                  Container(
                    height: 200.h,
                    width: double.infinity,
                    child: Padding(
                      padding: EdgeInsets.only(left: 20.0, right: 20.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text("Photos & Videos",
                              style: UITextStyle.regularTextStyle(
                                color: AppColors.colorText,
                                fontSize: 20,
                              )),
                          SizedBox(
                            height: 15,
                          ),
                          Expanded(
                            child: GridView.builder(
                              padding: EdgeInsets.zero,
                              physics: NeverScrollableScrollPhysics(),
                              shrinkWrap: true,
                              scrollDirection: Axis.vertical,
                              gridDelegate:
                                  new SliverGridDelegateWithFixedCrossAxisCount(
                                crossAxisCount: 4,
                                crossAxisSpacing: 0,
                              ),
                              itemCount: 5,
                              primary: false,
                              itemBuilder: (BuildContext context, int index) {
                                return Container(
                                  child: Column(children: [
                                    Card(
                                        color: Colors.white,
                                        shape: RoundedRectangleBorder(
                                          borderRadius:
                                              BorderRadius.circular(15),
                                        ),
                                        elevation: 2.0,
                                        shadowColor:
                                            AppColors.blackC.withOpacity(0.7),
                                        child: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            Stack(
                                              alignment: AlignmentDirectional
                                                  .topCenter,
                                              fit: StackFit.loose,
                                              children: <Widget>[
                                                SizedBox(
                                                  child: Image.asset(
                                                    '',
                                                    fit: BoxFit.fill,
                                                  ),
                                                ),
                                                // Align(
                                                //     alignment:
                                                //         Alignment.center,
                                                //     child: InkWell(
                                                //         splashColor: AppColor
                                                //             .transparentColor,
                                                //         onTap: () {},
                                                //         child: Padding(
                                                //             padding:
                                                //                 const EdgeInsets
                                                //                     .all(8.0),
                                                //             child:
                                                //                 Image.asset(
                                                //               index % 2 == 0
                                                //                   ? AppImage
                                                //                       .temp1
                                                //                   : AppImage
                                                //                       .icnFavourite,
                                                //               height: 15.h,
                                                //               width: 15.h,
                                                //             ))))
                                              ],
                                            ),
                                          ],
                                        ))
                                  ]),
                                );
                              },
                            ),
                          )
                        ],
                      ),
                    ),
                  )
                ],
              ),
            ),
          ],
        ))
      ]),
    );
  }
}
