import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:travelpals/bottom_tab/post/create_post.dart';

import '../../utils/colors.dart';
import '../../utils/strings.dart';
import '../notifications/notifications.dart';
import '../trip/trips.dart';

class PostsScreen extends StatefulWidget {
  const PostsScreen({Key? key}) : super(key: key);

  @override
  State<PostsScreen> createState() => _PostsScreenState();
}

class _PostsScreenState extends State<PostsScreen> {
  final TextEditingController _search = TextEditingController();
  final TextEditingController _post = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        leadingWidth: 130,
        centerTitle: false,
        titleSpacing: 0,
        backgroundColor: Colors.white,
        leading: const Padding(
          padding: EdgeInsets.only(top: 18.0, left: 10),
          child: Text(
            Strings.travelPals,
            style: TextStyle(
                fontFamily: 'Museo Sans',
                fontWeight: FontWeight.bold,
                color: AppColors.buttonColor,
                fontSize: 20),
          ),
        ),
        actions: [
          IconButton(
            icon: const Icon(
              Icons.favorite_border,
              color: AppColors.colorText,
            ),
            onPressed: () {},
          ),
          IconButton(
            icon: const Icon(
              Icons.notifications_none,
              color: AppColors.colorText,
            ),
            onPressed: () {
              Get.to(const Notifications());
            },
          )
        ],
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 8.0),
          child: Column(
            children: [
              const SizedBox(
                height: 10,
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8.0),
                child: TextFormField(
                  controller: _search,
                  textInputAction: TextInputAction.next,
                  style: const TextStyle(
                      color: Colors.black, fontFamily: 'Museo Sans'),
                  keyboardType: TextInputType.emailAddress,
                  cursorColor: Colors.white,
                  decoration: const InputDecoration(
                    prefixIcon: Icon(
                      Icons.search,
                      color: AppColors.colorText,
                    ),
                    filled: true,
                    fillColor: AppColors.colorSearch,
                    enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: AppColors.colorSearch),
                        borderRadius: BorderRadius.all(Radius.circular(15.0))),
                    errorBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: AppColors.buttonColor),
                        borderRadius: BorderRadius.all(Radius.circular(35.0))),
                    contentPadding: EdgeInsets.only(left: 15, top: 5),
                    focusedBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: AppColors.colorSearch),
                        borderRadius: BorderRadius.all(Radius.circular(15.0))),
                    hintStyle: TextStyle(
                      color: AppColors.colorBottomNavText,
                      fontFamily: 'Museo Sans',
                    ),
                    hintText: Strings.searchHere,
                  ),
                ),
              ),
              const SizedBox(
                height: 10,
              ),
              Row(
                children: [
                  Expanded(
                    child: TextFormField(
                      controller: _post,
                      textInputAction: TextInputAction.next,
                      style: const TextStyle(
                          color: Colors.black, fontFamily: 'Museo Sans'),
                      keyboardType: TextInputType.emailAddress,
                      cursorColor: Colors.white,
                      decoration: const InputDecoration(
                        fillColor: AppColors.colorSearch,
                        enabledBorder: OutlineInputBorder(
                            borderSide: BorderSide(
                                color: AppColors.counterPostButtonBgColor),
                            borderRadius:
                                BorderRadius.all(Radius.circular(15.0))),
                        errorBorder: OutlineInputBorder(
                            borderSide:
                                BorderSide(color: AppColors.buttonColor),
                            borderRadius:
                                BorderRadius.all(Radius.circular(35.0))),
                        contentPadding: EdgeInsets.only(left: 15, top: 5),
                        focusedBorder: OutlineInputBorder(
                            borderSide: BorderSide(
                                color: AppColors.counterPostButtonBgColor),
                            borderRadius:
                                BorderRadius.all(Radius.circular(15.0))),
                        hintStyle: TextStyle(
                          color: AppColors.colorBottomNavText,
                          fontFamily: 'Museo Sans',
                        ),
                        hintText: Strings.whatsInYourMind,
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: GestureDetector(
                        onTap: () {
                          Get.to(CreatePost());
                        },
                        child: Image.asset(
                          'assets/temp.png',
                          width: 30,
                        )),
                  )
                ],
              ),
              const ListBox(
                name: 'Adam Jane',
                description: Strings.description,
                duration: Strings.date,
                image: 'picture.png',
              ),
              const ListBox(
                name: 'Adam Jane',
                description: Strings.description,
                duration: Strings.date,
                image: 'picture.png',
              )
            ],
          ),
        ),
      ),
    );
  }
}

class Carousel extends StatefulWidget {
  const Carousel({
    Key? key,
  }) : super(key: key);

  @override
  State<Carousel> createState() => _CarouselState();
}

class _CarouselState extends State<Carousel> {
  late PageController _pageController;

  List<String> images = [
    "https://images.wallpapersden.com/image/download/purple-sunrise-4k-vaporwave_bGplZmiUmZqaraWkpJRmbmdlrWZlbWU.jpg",
    "https://wallpaperaccess.com/full/2637581.jpg",
    "https://uhdwallpapers.org/uploads/converted/20/01/14/the-mandalorian-5k-1920x1080_477555-mm-90.jpg"
  ];

  int activePage = 1;

  @override
  void initState() {
    super.initState();

    _pageController = PageController(initialPage: 1);
  }

  bool onTap = false;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        SizedBox(
          height: 300,
          child: Stack(children: [
            PageView.builder(
                itemCount: images.length,
                pageSnapping: true,
                controller: _pageController,
                onPageChanged: (page) {
                  setState(() {
                    activePage = page;
                  });
                },
                itemBuilder: (context, pagePosition) {
                  bool active = pagePosition == activePage;
                  return slider(images, pagePosition, active);
                }),
            Positioned(
                bottom: 0,
                top: 170,
                left: 0,
                right: 0,
                child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: indicators(images.length, activePage))),
          ]),
        ),
      ],
    );
  }
}

class ListBox extends StatefulWidget {
  const ListBox(
      {Key? key, this.name, this.description, this.image, this.duration})
      : super(key: key);
  final String? name;
  final String? description;
  final String? image;
  final String? duration;

  @override
  State<StatefulWidget> createState() => _ListBoxState();
}

class _ListBoxState extends State<ListBox> {
  int like = 0;
  bool onTap = false;
  bool onTapLike = false;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(2),
      width: double.infinity,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Carousel(),
          (widget.image != null)
              ? Container(
                  color: AppColors.whiteColor,
                  child: Row(
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(left: 8.0),
                        child: Image.asset(
                          "assets/${widget.image}",
                          width: 50,
                          height: 50,
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(left: 8.0),
                        child: Text(
                          widget.name ?? "not found",
                          style: const TextStyle(
                              fontFamily: 'Museo Sans',
                              fontSize: 20,
                              color: AppColors.colorText),
                          textAlign: TextAlign.start,
                        ),
                      ),
                    ],
                  ),
                )
              :
              //no image
              Container(),
          const SizedBox(
            height: 10,
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 15.0),
            child: Text(
              widget.description ?? "not found",
              style: const TextStyle(
                  fontFamily: 'Museo Sans', fontSize: 16, color: Colors.grey),
              textAlign: TextAlign.start,
            ),
          ),
          const SizedBox(
            height: 10,
          ),
          const SizedBox(
            height: 10,
          ),
          Row(
            children: [
              Row(
                children: [
                  IconButton(
                    icon: Icon(
                      onTap ? Icons.thumb_up_outlined : Icons.thumb_up,
                      color: AppColors.colorText,
                    ),
                    onPressed: () {
                      setState(() {
                        onTap = !onTap;
                        like++;
                      });
                    },
                  ),
                  Text(
                    like.toString(),
                    style: const TextStyle(
                        fontFamily: 'Museo Sans',
                        fontSize: 16,
                        color: Colors.grey),
                    textAlign: TextAlign.start,
                  ),
                ],
              ),
              Row(
                children: [
                  IconButton(
                    icon: const Icon(
                      Icons.messenger_outline,
                      color: AppColors.colorText,
                    ),
                    onPressed: () {},
                  ),
                  const Text(
                    '1',
                    style: TextStyle(
                        fontFamily: 'Museo Sans',
                        fontSize: 16,
                        color: Colors.grey),
                    textAlign: TextAlign.start,
                  ),
                ],
              ),
            ],
          )
        ],
      ),
    );
  }
}
