import 'dart:io';
import 'dart:math';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';
import 'package:video_player/video_player.dart';

import '../../custom/custom_button.dart';
import '../../utils/colors.dart';
import '../../utils/strings.dart';

class CreatePost extends StatefulWidget {
  const CreatePost({Key? key}) : super(key: key);

  @override
  State<CreatePost> createState() => _CreatePostState();
}

class _CreatePostState extends State<CreatePost> {
  @override
  void initState() {
    super.initState();
    debugPrint(Get.arguments);
  }

  var arg = Get.arguments;
  TextEditingController _post = TextEditingController();
  TextEditingController _location = TextEditingController();
  File? image;
  final ImagePicker imgpicker = ImagePicker();
  List<XFile>? imagefiles;
  File? _video;
  int count = 0;
  VideoPlayerController videoPlayerController = VideoPlayerController.file(File(''));
  bool isVideo = false;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        titleSpacing: 0,
        backgroundColor: AppColors.whiteColor,
        title: const Text(
          Strings.createPost,
          style: TextStyle(
              fontFamily: 'Museo Sans',
              color: AppColors.colorText,
              fontSize: 22),
        ),
        leading: IconButton(
          icon: const Icon(
            Icons.arrow_back,
            color: AppColors.arrowColor,
          ),
          onPressed: () {
            Get.back();
          },
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 8.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(
                height: 10,
              ),
              Row(
                children: [
                  Image.asset(
                    'assets/picture.png',
                    width: 50,
                  ),
                  const Text(
                    'Adam jane',
                    style: TextStyle(
                        fontFamily: 'Museo Sans',
                        color: AppColors.colorText,
                        fontWeight: FontWeight.w700,
                        fontSize: 16),
                  )
                ],
              ),
              const SizedBox(
                height: 10,
              ),
              TextFormField(
                controller: _post,
                maxLines: 8,
                textInputAction: TextInputAction.next,
                style: const TextStyle(
                    color: Colors.black, fontFamily: 'Museo Sans'),
                keyboardType: TextInputType.emailAddress,
                cursorColor: Colors.white,
                decoration: const InputDecoration(
                  fillColor: AppColors.colorSearch,
                  enabledBorder: OutlineInputBorder(
                      borderSide:
                          BorderSide(color: AppColors.counterPostButtonBgColor),
                      borderRadius: BorderRadius.all(Radius.circular(15.0))),
                  errorBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: AppColors.buttonColor),
                      borderRadius: BorderRadius.all(Radius.circular(35.0))),
                  contentPadding: EdgeInsets.only(left: 15, top: 5),
                  focusedBorder: OutlineInputBorder(
                      borderSide:
                          BorderSide(color: AppColors.counterPostButtonBgColor),
                      borderRadius: BorderRadius.all(Radius.circular(15.0))),
                  hintStyle: TextStyle(
                    color: AppColors.colorBottomNavText,
                    fontFamily: 'Museo Sans',
                  ),
                  hintText: Strings.whatsInYourMind,
                ),
              ),

              //addphoto
              const Text(
                Strings.addPhoto,
                style: TextStyle(
                    fontFamily: 'Museo Sans',
                    color: AppColors.colorText,
                    fontSize: 18,
                    fontWeight: FontWeight.w500),
              ),
              //photogrid

              Container(
                decoration: const BoxDecoration(
                    borderRadius: BorderRadius.all(
                      Radius.circular(10),
                    ),
                    color: AppColors.colorPostInput),
                height: 80,
                width: 80,
                child: IconButton(
                    onPressed: () {
                      alert();
                    },
                    icon: const Icon(
                      Icons.add_box_outlined,
                      size: 30,
                      color: AppColors.cancelColor,
                    )),
              ),
              imagefiles != null && !isVideo
                  ? Container(
                      height: 100,
                      child: GridView.builder(
                          itemCount: imagefiles!.length,
                          gridDelegate:
                              const SliverGridDelegateWithFixedCrossAxisCount(
                                  crossAxisCount: 3),
                          itemBuilder: (BuildContext context, int index) {
                            return ClipRRect(
                              borderRadius: BorderRadius.circular(8.0),
                              child: Padding(
                                padding: const EdgeInsets.only(top: 8.0),
                                child: Image.file(
                                  File(
                                    imagefiles![index].path,
                                  ),
                                ),
                              ),
                            );
                          }),
                    )

              //for videos
                  : ClipRRect(borderRadius: BorderRadius.circular(8.0),
                child: SizedBox(
                    height: 100,width: 100,
                    child: VideoPlayer(videoPlayerController)),
              ),

              const SizedBox(
                height: 10,
              ),
              const Text(
                Strings.addLocation,
                style: TextStyle(
                    fontFamily: 'Museo Sans',
                    color: AppColors.colorText,
                    fontSize: 18,
                    fontWeight: FontWeight.w500),
              ),

              const SizedBox(
                height: 10,
              ),
              TextFormField(
                controller: _location,
                textInputAction: TextInputAction.next,
                style: const TextStyle(
                    color: Colors.black, fontFamily: 'Museo Sans'),
                keyboardType: TextInputType.emailAddress,
                cursorColor: Colors.white,
                decoration: const InputDecoration(
                  prefixIcon: Icon(
                    Icons.location_on_outlined,
                    color: AppColors.colorText,
                  ),
                  filled: true,
                  fillColor: AppColors.colorSearch,
                  enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: AppColors.colorSearch),
                      borderRadius: BorderRadius.all(Radius.circular(15.0))),
                  errorBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: AppColors.buttonColor),
                      borderRadius: BorderRadius.all(Radius.circular(35.0))),
                  contentPadding: EdgeInsets.only(left: 15, top: 5),
                  focusedBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: AppColors.colorSearch),
                      borderRadius: BorderRadius.all(Radius.circular(15.0))),
                ),
              ),
              const SizedBox(
                height: 10,
              ),
              CustomButton(
                title: Strings.post,
                onTap: () {},
              ),
            ],
          ),
        ),
      ),
    );
  }

  openImages() async {
    isVideo = false;
    try {
      var pickedfiles = await imgpicker.pickMultiImage();
      //  var videos = await imgpicker.pickVideo(source: ImageSource.gallery);

      if (pickedfiles != null /*|| videos != null*/) {
        imagefiles = pickedfiles;
        //    video = videos;
        setState(() {
/*
          VideoPlayerController _videoPlayerController = VideoPlayerController.file(video as File);
          _videoPlayerController.play();*/
        });
      } else {
        if (kDebugMode) {
          print("No image is selected.");
        }
      }
    } catch (e) {
      if (kDebugMode) {
        print("error while picking file.");
      }
    }
  }

  void alert() async {
    await Get.dialog(AlertDialog(
      titleTextStyle:
          TextStyle(fontFamily: 'Museo Sans', color: AppColors.blackC),
      elevation: 5,
      title: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: const [
          Padding(
            padding: EdgeInsets.only(top: 8.0, bottom: 8.0),
            child: Text(
              'TravelPals',
              style: TextStyle(
                  fontFamily: 'Museo Sans',
                  fontSize: 16,
                  fontWeight: FontWeight.bold),
            ),
          ),
          Text(
            'Choose media type you want to upload',
            style: TextStyle(fontFamily: 'Museo Sans'),
          ),
        ],
      ),
      actions: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            TextButton(
                onPressed: () {
                  Navigator.of(Get.overlayContext!, rootNavigator: true).pop();
                },
                child: Text('Cancel')),
            TextButton(
                onPressed: () {
                  Navigator.of(Get.overlayContext!, rootNavigator: true).pop();

                  openImages();
                },
                child: Text('Image')),
            TextButton(
                onPressed: () {
                  Navigator.of(Get.overlayContext!, rootNavigator: true).pop();

                  pickVideo();
                },
                child: Text('Video')),
          ],
        )
      ],
    ));
  }

  //video pick
  Future pickVideo() async {
    isVideo = true;
    final video = await imgpicker.pickVideo(source: ImageSource.gallery);
    _video = File(video!.path);
    videoPlayerController = VideoPlayerController.file(_video! )
      ..initialize().then((value) => {setState(() {
        videoPlayerController.play();

      })});
  }

}
