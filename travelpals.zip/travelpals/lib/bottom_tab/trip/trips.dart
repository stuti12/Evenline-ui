import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:travelpals/bottom_tab/notifications/notifications.dart';
import 'package:travelpals/custom/custom_button.dart';
import 'package:travelpals/post_trip/post_trip.dart';

import '../../utils/colors.dart';
import '../../utils/strings.dart';
import 'favourite_trips.dart';

class TripsScreen extends StatefulWidget {
  const TripsScreen({Key? key}) : super(key: key);

  @override
  State<TripsScreen> createState() => _TripsScreenState();
}

class _TripsScreenState extends State<TripsScreen> {
  bool isTap = false;

  @override
  Widget build(BuildContext context) {
    return ScreenUtilInit(builder: (_, child) {
      return DefaultTabController(
        length: 2,
        child: Scaffold(
            resizeToAvoidBottomInset: false,
            backgroundColor: AppColors.bottomSheet,
            appBar: AppBar(
              elevation: 0,
              bottom: const TabBar(
                labelColor: AppColors.buttonColor,
                unselectedLabelColor: AppColors.colorTabUnselected,
                tabs: [
                  Tab(text: Strings.everywhere),
                  Tab(
                    text: Strings.local,
                  )
                ],
                indicatorColor: AppColors.buttonColor,
              ),
              leadingWidth: 130,
              centerTitle: false,
              titleSpacing: 0,
              backgroundColor: Colors.white,
              leading: Padding(
                padding: EdgeInsets.only(top: 18.h, left: 10.h),
                child: Text(
                  Strings.travelPals,
                  style: TextStyle(
                      fontFamily: 'Museo Sans',
                      fontWeight: FontWeight.w700,
                      color: AppColors.buttonColor,
                      fontSize: ScreenUtil().setSp(20)),
                ),
              ),
              actions: [
                IconButton(
                  icon: const Icon(
                    Icons.favorite_border,
                    color: AppColors.colorText,
                  ),
                  onPressed: () {
                    Get.to(const FavouriteTripsScreen());
                  },
                ),
                IconButton(
                  icon: const Icon(
                    Icons.notifications_none,
                    color: AppColors.colorText,
                  ),
                  onPressed: () {
                    Get.to(const Notifications());
                  },
                )
              ],
            ),
            body: const TabBarView(
              children: [
                FirstScreen(),
                SecondScreen(),
              ],
            ),
            floatingActionButton: FloatingActionButton(
              backgroundColor: AppColors.buttonColor,
              elevation: 10,
              foregroundColor: AppColors.whiteColor,
              onPressed: () {
                Get.to(const PostTripScreen());
              },
              child: const Icon(
                Icons.add,
                color: Colors.white,
                size: 30,
              ),
            )),
      );
    });
  }
}

class FirstScreen extends StatefulWidget {
  const FirstScreen({Key? key}) : super(key: key);

  @override
  State<FirstScreen> createState() => _FirstScreenState();
}

class _FirstScreenState extends State<FirstScreen> {
  final TextEditingController _search = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return ListView(children: [
      Column(
        children: [
          SizedBox(
            height: 10.h,
          ),
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 8.h),
            child: TextFormField(
              controller: _search,
              textInputAction: TextInputAction.next,
              style: const TextStyle(
                  color: Colors.black, fontFamily: 'Museo Sans'),
              keyboardType: TextInputType.emailAddress,
              cursorColor: Colors.white,
              decoration: const InputDecoration(
                prefixIcon: Icon(
                  Icons.search,
                  color: AppColors.colorText,
                ),
                filled: true,
                fillColor: AppColors.colorSearch,
                enabledBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: AppColors.colorSearch),
                    borderRadius: BorderRadius.all(Radius.circular(15.0))),
                errorBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: AppColors.buttonColor),
                    borderRadius: BorderRadius.all(Radius.circular(35.0))),
                contentPadding: EdgeInsets.only(left: 15, top: 5),
                focusedBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: AppColors.colorSearch),
                    borderRadius: BorderRadius.all(Radius.circular(35.0))),
                hintStyle: TextStyle(
                  color: AppColors.colorBottomNavText,
                  fontFamily: 'Museo Sans',
                ),
                hintText: Strings.searchHere,
              ),
            ),
          ),
          const Carousel(),
          const ListBox(
            name: 'Adam Jane',
            description: Strings.description,
            duration: Strings.date,
            image: 'picture.png',
          ),
          const ListBox(
            name: 'Adam Jane',
            description: Strings.description,
            duration: Strings.date,
            image: 'picture.png',
          )
        ],
      ),
    ]);
  }
}

class SecondScreen extends StatefulWidget {
  const SecondScreen({Key? key}) : super(key: key);

  @override
  State<SecondScreen> createState() => _SecondScreenState();
}

class _SecondScreenState extends State<SecondScreen> {
  @override
  Widget build(BuildContext context) {
    return ListView(children: [
      Column(
        children: const [
          Carousel(),
          ListBox(
            name: 'Adam Jane',
            description: Strings.description,
            duration: Strings.date,
            image: 'picture.png',
          ),
          ListBox(
            name: 'Adam Jane',
            description: Strings.description,
            duration: Strings.date,
            image: 'picture.png',
          )
        ],
      ),
    ]);
  }
}

class Carousel extends StatefulWidget {
  const Carousel({
    Key? key,
  }) : super(key: key);

  @override
  State<Carousel> createState() => _CarouselState();
}

class _CarouselState extends State<Carousel> {
  late PageController _pageController;

  List<String> images = [
    "https://images.wallpapersden.com/image/download/purple-sunrise-4k-vaporwave_bGplZmiUmZqaraWkpJRmbmdlrWZlbWU.jpg",
    "https://wallpaperaccess.com/full/2637581.jpg",
    "https://uhdwallpapers.org/uploads/converted/20/01/14/the-mandalorian-5k-1920x1080_477555-mm-90.jpg"
  ];

  int activePage = 1;

  @override
  void initState() {
    super.initState();

    _pageController = PageController(initialPage: 1);
  }

  bool onTap = false;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        SizedBox(
          height: 300,
          child: Stack(children: [
            PageView.builder(
                itemCount: images.length,
                pageSnapping: true,
                controller: _pageController,
                onPageChanged: (page) {
                  setState(() {
                    activePage = page;
                  });
                },
                itemBuilder: (context, pagePosition) {
                  bool active = pagePosition == activePage;
                  return slider(images, pagePosition, active);
                }),
            Positioned(
                bottom: 0,
                top: 170,
                left: 0,
                right: 0,
                child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: indicators(images.length, activePage))),
            Positioned(
                top: 50,
                right: 10,
                child: CircleAvatar(
                  backgroundColor: const Color(0xff33000000),
                  child: IconButton(
                      onPressed: () {
                        setState(() {
                          onTap = !onTap;
                        });
                      },
                      icon: Icon(
                        onTap ? Icons.favorite_border : Icons.favorite,
                        color: AppColors.colorBorder,
                      )),
                ))
          ]),
        ),
      ],
    );
  }
}

AnimatedContainer slider(images, pagePosition, active) {
  double margin = active ? 1 : 1;

  return AnimatedContainer(
    duration: const Duration(milliseconds: 50),
    curve: Curves.easeInOutCubic,
    margin: EdgeInsets.all(margin),
    decoration: BoxDecoration(
        image: DecorationImage(
            image: NetworkImage(
              images[pagePosition],
            ),
            fit: BoxFit.fitWidth)),
  );
}

imageAnimation(PageController animation, images, pagePosition) {
  return AnimatedBuilder(
    animation: animation,
    builder: (context, widget) {
      debugPrint(pagePosition);

      return const SizedBox();
    },
    child: Image.network(images[pagePosition], fit: BoxFit.fitWidth),
  );
}

List<Widget> indicators(imagesLength, currentIndex) {
  return List<Widget>.generate(imagesLength, (index) {
    return Container(
      margin: const EdgeInsets.all(3),
      width: 10,
      height: 10,
      decoration: BoxDecoration(
          color: currentIndex == index ? Colors.white : Colors.white54,
          shape: BoxShape.circle),
    );
  });
}

class ListBox extends StatefulWidget {
  const ListBox(
      {Key? key, this.name, this.description, this.image, this.duration})
      : super(key: key);
  final String? name;
  final String? description;
  final String? image;
  final String? duration;

  @override
  State<StatefulWidget> createState() => _ListBoxState();
}

class _ListBoxState extends State<ListBox> {
  int like = 0;
  int group = 10;
  bool onTap = false;
  bool onTapLike = false;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(2),
      width: double.infinity,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          (widget.image != null)
              ? Container(
                  color: AppColors.whiteColor,
                  child: Row(
                    children: [
                      Padding(
                        padding: EdgeInsets.only(left: 8.h),
                        child: Image.asset(
                          "assets/${widget.image}",
                          width: 50,
                          height: 50,
                        ),
                      ),
                      Padding(
                        padding: EdgeInsets.only(left: 8.h),
                        child: Text(
                          widget.name ?? "not found",
                          style: TextStyle(
                              fontFamily: 'Museo Sans',
                              fontWeight: FontWeight.w500,
                              fontSize: ScreenUtil().setSp(16),
                              color: AppColors.colorText),
                          textAlign: TextAlign.start,
                        ),
                      ),
                      Expanded(
                        child: Padding(
                          padding: const EdgeInsets.only(right: 8.0),
                          child: Align(
                            alignment: Alignment.topRight,
                            child: GestureDetector(
                              onTap: () {
                                setState(() {
                                  onTapLike = !onTapLike;
                                });
                              },
                              child: Icon(
                                onTapLike
                                    ? Icons.favorite_border
                                    : Icons.favorite,
                                color: AppColors.colorBorder,
                              ),
                            ),
                          ),
                        ),
                      )
                    ],
                  ),
                )
              :
              //no image
              Container(),
          const SizedBox(
            height: 10,
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 15.0),
            child: Text(
              widget.description ?? "not found",
              style: TextStyle(
                  fontFamily: 'Museo Sans',
                  color: AppColors.counterPostButtonColor,
                  fontSize: ScreenUtil().setSp(13),

                  fontWeight: FontWeight.w400),
              textAlign: TextAlign.start,
            ),
          ),
          const SizedBox(
            height: 10,
          ),
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 8.h),
            child: Row(
              children: [
                const Icon(Icons.calendar_today),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 8.0),
                  child: Text(
                    widget.duration ?? "not found",
                    style: TextStyle(
                        fontFamily: 'Museo Sans',
                        fontWeight: FontWeight.w400,
                        fontSize: ScreenUtil().setSp(13),
                        color: AppColors.colorText),
                    textAlign: TextAlign.start,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(
            height: 10,
          ),
          Row(
            children: [
              Expanded(
                child: Row(
                  children: [
                    IconButton(
                      icon: Icon(
                        onTap ? Icons.thumb_up_outlined : Icons.thumb_up,
                        color: AppColors.colorText,
                      ),
                      onPressed: () {
                        setState(() {
                          onTap = !onTap;
                          like++;
                        });
                      },
                    ),
                    Text(
                      like.toString(),
                      style: TextStyle(
                          fontFamily: 'Museo Sans',
                          fontWeight: FontWeight.w400,
                          fontSize: ScreenUtil().setSp(12),
                          color: AppColors.colorText),
                      textAlign: TextAlign.start,
                    ),
                  ],
                ),
              ),
              Row(
                children: [
                  IconButton(
                    icon: const Icon(
                      Icons.group,
                      color: AppColors.colorText,
                    ),
                    onPressed: () {},
                  ),
                  Text(
                    group.toString(),
                    style:  TextStyle(
                        fontFamily: 'Museo Sans',
                        fontWeight: FontWeight.w400,
                        fontSize: ScreenUtil().setSp(12),
                        color: AppColors.colorText),
                    textAlign: TextAlign.start,
                  ),
                  Padding(
                      padding: const EdgeInsets.only(left: 8, right: 8),
                      child: CustomButton(
                        width: 120,
                        height: 42,
                        title: Strings.askToJoin,
                        onTap: () {
                          showBottomSheets();
                        },
                        bgColor: AppColors.buttonColor,
                      )),
                ],
              ),
            ],
          )
        ],
      ),
    );
  }

  Future<void> showBottomSheets() async {
    await Get.bottomSheet(ClipRRect(
      borderRadius: const BorderRadius.only(
          topRight: Radius.circular(30), topLeft: Radius.circular(30)),
      child: Container(
        padding: EdgeInsets.only(left: 20.h, right: 20),
        height: 290,
        color: AppColors.bottomSheet,
        child: Column(
          children: [
            Container(
                transform: Matrix4.translationValues(
                    0.0, -MediaQuery.of(context).size.height * 0.05, 0.5),
                child: Image.asset('assets/subscribe.png')),
            Column(
              children: [
                SizedBox(
                  height: 20,
                ),
                Text(
                  Strings.subscribe,
                  style: TextStyle(
                      fontFamily: 'Museo Sans',
                      fontSize: ScreenUtil().setSp(24),
                      fontWeight: FontWeight.bold,
                      color: AppColors.colorText),
                ),
                SizedBox(
                  height: 20.h,
                ),
                Text(
                  Strings.inOrderTo,
                  style: TextStyle(
                      fontFamily: 'Museo Sans',
                      fontSize: ScreenUtil().setSp(20),
                      color: AppColors.colorText),
                  textAlign: TextAlign.center,
                ),
                SizedBox(
                  height: 10.h,
                ),
              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: CustomButton(
                      title: Strings.explore,
                      onTap: () {},
                    ),
                  ),
                ),
                Expanded(
                  child: CustomButton(
                    title: Strings.cancel,
                    onTap: () {
                      Get.back();
                    },
                    textColor: AppColors.buttonColor,
                    bgColor: AppColors.whiteColor,
                  ),
                )
              ],
            ),
          ],
        ),
      ),
    ));
  }
}
