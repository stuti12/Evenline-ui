import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:travelpals/bottom_tab/messages/chat_detail.dart';

import '../../utils/colors.dart';
import '../../utils/strings.dart';
import '../notifications/notifications.dart';

class MessagesScreen extends StatefulWidget {
  const MessagesScreen({Key? key}) : super(key: key);

  @override
  State<MessagesScreen> createState() => _MessagesScreenState();
}

class _MessagesScreenState extends State<MessagesScreen> {
  var data = [
    {
      "name": Strings.parisADream,
      "desc": Strings.atVero,
      "image": "paris.png",
      "duration": Strings.tenMinutes
    },
    {
      "name": Strings.greeceLand,
      "desc": Strings.atVero,
      "image": "greece.png",
      "duration": Strings.tenMinutes
    },
    {
      "name": Strings.beachLove,
      "desc": Strings.atVero,
      "image": "beach.png",
      "duration": Strings.tenMinutes
    },
    {
      "name": Strings.parisADream,
      "desc": Strings.atVero,
      "image": "paris.png",
      "duration": Strings.tenMinutes
    },
    {
      "name": Strings.greeceLand,
      "desc": Strings.atVero,
      "image": "greece.png",
      "duration": Strings.tenMinutes
    },
    {
      "name": Strings.beachLove,
      "desc": Strings.atVero,
      "image": "beach.png",
      "duration": Strings.tenMinutes
    }
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          elevation: 0,
          leadingWidth: 130,
          centerTitle: false,
          titleSpacing: 0,
          backgroundColor: Colors.white,
          leading:  Padding(
            padding: EdgeInsets.only(top: 18.h, left: 10),
            child: Text(
              Strings.travelPals,
              style: TextStyle(
                  fontFamily: 'Museo Sans',
                  fontWeight: FontWeight.w700,
                  color: AppColors.buttonColor,
                  fontSize: ScreenUtil().setSp(20)),
            ),
          ),
          actions: [
            IconButton(
              icon: const Icon(
                Icons.favorite_border,
                color: AppColors.colorText,
              ),
              onPressed: () {},
            ),
            IconButton(
              icon: const Icon(
                Icons.notifications_none,
                color: AppColors.colorText,
              ),
              onPressed: () {
                Get.to(const Notifications());
              },
            )
          ],
        ),
        body: ListView.builder(
          itemCount: data.length,
          itemBuilder: (BuildContext context, int index) {
            return Padding(
              padding: const EdgeInsets.all(8.0),
              child: ListTile(
                leading:
                    Image.asset('assets/${data[index]["image"]}', width: 50),
                subtitle: Text(
                  data[index]["desc"] ?? "no Data",
                  style:  TextStyle(
                      fontWeight: FontWeight.w400,
                      fontFamily: 'Museo Sans',
                      color: AppColors.counterPostButtonColor,
                      fontSize: ScreenUtil().setSp(12)),
                ),
                title: Text(
                  data[index]["name"] ?? "no Data",
                  style: TextStyle(
                      fontWeight: FontWeight.w500,
                      fontFamily: 'Museo Sans',
                      color: AppColors.blackC,
                      fontSize: ScreenUtil().setSp(16)),
                ),
                onTap: () {
                  Get.to(const ChatDetail(), arguments: data[index]);
                },
                trailing: Text(
                  data[index]["duration"] ?? "",
                  style: TextStyle(
                      fontSize: ScreenUtil().setSp(12),
                      fontFamily: 'Museo Sans',
                      color: AppColors.colorBottomNavText),
                ),
              ),
            );
          },
        ));
  }
}
