import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../utils/colors.dart';
import '../../../utils/strings.dart';

class AddMember extends StatefulWidget {
  const AddMember({Key? key}) : super(key: key);

  @override
  State<AddMember> createState() => _AddMemberState();
}

class _AddMemberState extends State<AddMember> {
  var data = [
    {"name": 'Krish J', "desc": Strings.atVero, "image": "picture1.png"},
    {"name": 'Kritika Shah', "desc": Strings.atVero, "image": "picture2.png"},
    {"name": 'Bibek Jahn', "desc": Strings.atVero, "image": "picture3.png"},
    {"name": 'Melissa John', "desc": Strings.atVero, "image": "picture4.png"},
    {"name": 'Jobon Gosh', "desc": Strings.atVero, "image": "picture5.png"},
    {"name": 'Krish J', "desc": Strings.atVero, "image": "picture1.png"}
  ];
  var selectedData = [];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        titleSpacing: 0,
        backgroundColor: AppColors.whiteColor,
        title: const Text(
          Strings.addMember,
          style: TextStyle(
              fontFamily: 'Museo Sans',
              color: AppColors.colorText,
              fontSize: 22),
        ),
        leading: IconButton(
          icon: const Icon(
            Icons.arrow_back,
            color: AppColors.arrowColor,
          ),
          onPressed: () {
            Get.back();
          },
        ),
        actions: [
          IconButton(
            icon: const Icon(
              Icons.search,
              color: AppColors.colorText,
            ),
            onPressed: () {},
          ),
        ],
      ),
      body: Column(
        children: [
          SizedBox(
            height: 100,
            child: Visibility(
              visible: selectedData.isNotEmpty,
              child: ListView.builder(
                  itemCount: selectedData.length,
                  scrollDirection: Axis.horizontal,
                  itemBuilder: (BuildContext context, int index) {
                    return Column(
                      children: [
                        Image.asset('assets/${selectedData[index]["image"]}',
                            width: 50),
                        Text(
                          selectedData[index]["name"] ?? "no Data",
                          style: TextStyle(
                              fontWeight: FontWeight.w500,
                              fontFamily: 'Museo Sans',
                              color: AppColors.blackC,
                              fontSize: 17),
                        ),
                        const SizedBox(
                          width: 70,
                        ),
                      ],
                    );
                  }),
            ),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: data.length,
              itemBuilder: (BuildContext context, int index) {
                return Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: ListTile(
                    leading: Image.asset('assets/${data[index]["image"]}',
                        width: 50),
                    subtitle: Text(
                      data[index]["desc"] ?? "no Data",
                      style: const TextStyle(
                          fontWeight: FontWeight.w400,
                          fontFamily: 'Museo Sans',
                          color: AppColors.counterPostButtonColor,
                          fontSize: 14),
                    ),
                    title: Text(
                      data[index]["name"] ?? "no Data",
                      style: TextStyle(
                          fontWeight: FontWeight.w500,
                          fontFamily: 'Museo Sans',
                          color: AppColors.blackC,
                          fontSize: 17),
                    ),
                    onTap: () {
                      setState(() {
                        selectedData.add(data[index]);
                      });
                    },
                    trailing: const Text(
                      Strings.tenMinutes,
                      style: TextStyle(
                          fontFamily: 'Museo Sans',
                          color: AppColors.colorBottomNavText),
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
      floatingActionButton: /*FloatingActionButton(
          backgroundColor: AppColors.colorGreen,
          elevation: 10,
          foregroundColor: AppColors.whiteColor,
          onPressed: () {},
          child: Container(
            child: const Icon(
              Icons.check,
              color: Colors.white,
              size: 30,
            ),
          ),
        )*/
          FloatingActionButton(
        onPressed: () {},
        backgroundColor: AppColors.colorGreen,
        elevation: 0,
        child: Container(
          decoration: BoxDecoration(
            color: AppColors.colorGreen,
            borderRadius: const BorderRadius.all(
              Radius.circular(100),
            ),
            boxShadow: [
              BoxShadow(
                color: AppColors.colorGreen.withOpacity(0.3),
                spreadRadius: 7,
                blurRadius: 7,
                offset: Offset(3, 5),
              ),
            ],
          ),
          child: const Padding(
            padding: EdgeInsets.all(8.0),
            child: Icon(
              Icons.check,
              color: Colors.white,
              size: 30,
            ),
          ),
        ),
      ),
    );
  }
}
