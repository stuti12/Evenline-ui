import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';
import 'package:travelpals/bottom_tab/messages/add_member/add_member.dart';
import 'package:travelpals/bottom_tab/messages/remove_member/remove_member.dart';

import '../../custom/custom_button.dart';
import '../../utils/colors.dart';
import '../../utils/strings.dart';

class ChatDetail extends StatefulWidget {
  const ChatDetail({Key? key}) : super(key: key);

  @override
  State<ChatDetail> createState() => _ChatDetailState();
}

class _ChatDetailState extends State<ChatDetail> {
  var name = Get.arguments["name"];
  var img = Get.arguments["image"];
  var isSender = true;
  List<SendMessage> sendMessage = [
    SendMessage('hii', 'sender', '', 'text'),
    SendMessage('hiii', 'receiver', '', 'text'),
    SendMessage(Strings.atVero, 'sender', '', 'text'),
    SendMessage(' accusamus et iusto odio .', 'receiver', '', 'text'),
  ];
  File? image;
  final ImagePicker imgpicker = ImagePicker();
  File? imagefiles;
  TextEditingController chat = TextEditingController();

  @override
  void initState() {
    super.initState();

    debugPrint(img);
    debugPrint(name);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        titleSpacing: 0,
        backgroundColor: AppColors.whiteColor,
        leading: IconButton(
          icon: const Icon(
            Icons.arrow_back,
            color: AppColors.arrowColor,
          ),
          onPressed: () {
            Get.back();
          },
        ),
        title: Row(
          children: [
            Image.asset(
              'assets/${img}',
              width: 40,
            ),
            const SizedBox(
              width: 10,
            ),
            Expanded(
                child: Text(
              name,
              style: const TextStyle(
                  fontFamily: 'Museo Sans',
                  color: AppColors.colorText,
                  fontSize: 16),
            ))
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(
              Icons.video_camera_back_outlined,
              color: AppColors.colorBottomNavText,
            ),
            onPressed: () {},
          ),
          IconButton(
            icon: const Icon(
              Icons.phone_outlined,
              color: AppColors.colorBottomNavText,
            ),
            onPressed: () {},
          ),
          PopupMenuButton<int>(
              color: AppColors.colorBottomNavText,
              icon: const Icon(
                Icons.more_vert,
                color: AppColors.colorBottomNavText,
              ),
              itemBuilder: (context) => [
                    PopupMenuItem(
                      value: 1,
                      child: TextButton(
                          onPressed: () {
                            Get.to(const AddMember());
                          },
                          child: const Text(
                            Strings.addMember,
                            style: TextStyle(
                                fontSize: 13,
                                color: AppColors.colorText,
                                fontFamily: 'Museo Sans'),
                          )),
                    ),
                    PopupMenuItem(
                      value: 2,
                      child: TextButton(
                          onPressed: () {
                            Get.to(const RemoveMember());
                          },
                          child: const Text(
                            Strings.removeMember,
                            style: TextStyle(
                                fontSize: 13,
                                color: AppColors.colorText,
                                fontFamily: 'Museo Sans'),
                          )),
                    ),
                    PopupMenuItem(
                      value: 3,
                      child: TextButton(
                          onPressed: () {
                            showReportBottomSheets();
                          },
                          child: const Text(
                            Strings.reportText,
                            style: TextStyle(
                                fontSize: 13,
                                color: AppColors.colorText,
                                fontFamily: 'Museo Sans'),
                          )),
                    ),
                    PopupMenuItem(
                      value: 4,
                      child: TextButton(
                          onPressed: () {
                            showDeleteBottomSheets();
                          },
                          child: const Text(
                            Strings.delete,
                            style: TextStyle(
                                fontSize: 13,
                                color: AppColors.colorText,
                                fontFamily: 'Museo Sans'),
                          )),
                    ),
                    PopupMenuItem(
                      value: 5,
                      child: TextButton(
                          onPressed: () {
                            showLeaveBottomSheets();
                          },
                          child: const Text(
                            Strings.leave,
                            style: TextStyle(
                                fontSize: 13,
                                color: AppColors.colorText,
                                fontFamily: 'Museo Sans'),
                          )),
                    ),
                  ])
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              itemCount: sendMessage.length,
              itemBuilder: (BuildContext context, int index) {
                return Align(
                    alignment: sendMessage[index].userType == 'sender'
                        ? Alignment.topLeft
                        : Alignment.topRight,
                    child: Container(
                        padding: const EdgeInsets.all(10),
                        margin:
                            const EdgeInsets.only(top: 10, left: 10, right: 10),
                        decoration: BoxDecoration(
                            color: sendMessage[index].userType != 'sender'
                                ? AppColors.colorMessage
                                : AppColors.colorPostInput,
                            borderRadius: const BorderRadius.only(
                                topRight: Radius.circular(10),
                                topLeft: Radius.circular(10),
                                bottomLeft: Radius.circular(10))),
                        child: sendMessage[index].messageTpe == 'text'
                            ? Text(
                                sendMessage[index].messageContent ?? "",
                                style: TextStyle(
                                    fontFamily: 'Museo Sans',
                                    color: AppColors.blackC,
                                    fontSize: 14),
                              )
                            : ClipRRect(
                                borderRadius: BorderRadius.circular(8),
                                child: Image.file(
                                  File(sendMessage[index].img ?? ""),
                                  height: 80,
                                ))));
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Container(
              decoration: BoxDecoration(
                  border: Border.all(
                    color: AppColors.counterPostButtonBgColor,
                  ),
                  borderRadius: BorderRadius.all(Radius.circular(35.0))),
              child: Row(
                children: [
                  Expanded(
                    child: TextFormField(
                      controller: chat,
                      textInputAction: TextInputAction.next,
                      cursorColor: Colors.white,
                      decoration: const InputDecoration(
                        fillColor: AppColors.colorSearch,
                        enabledBorder: InputBorder.none,
                        focusedBorder: InputBorder.none,
                        contentPadding: EdgeInsets.only(left: 15, top: 5),
                        hintStyle: TextStyle(
                          color: AppColors.colorBottomNavText,
                          fontFamily: 'Museo Sans',
                        ),
                        hintText: Strings.writeHere,
                      ),
                    ),
                  ),
                  IconButton(
                    onPressed: () {
                      openImages();
                    },
                    icon: const Icon(
                      Icons.image,
                      color: AppColors.colorBottomNavText,
                    ),
                  ),

                  //send message
                  IconButton(
                    color: AppColors.buttonColor,
                    onPressed: () {
                      if (chat.text.isNotEmpty) {
                        setState(() {
                          sendMessage.add(
                              SendMessage(chat.text, 'sender', '', 'text'));
                        });
                      } else {
                        debugPrint('Empty');
                      }
                    },
                    icon: const Icon(
                      Icons.arrow_circle_right,
                      color: AppColors.buttonColor,
                      size: 30,
                    ),
                  )
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  openImages() async {
    try {
      var pickedfiles = await imgpicker.pickImage(source: ImageSource.gallery);
      //  var videos = await imgpicker.pickVideo(source: ImageSource.gallery);

      if (pickedfiles != null /*|| videos != null*/) {
        debugPrint("path${pickedfiles.path}");
        setState(() {
          sendMessage.add(SendMessage('', 'sender', pickedfiles.path, 'image'));
        });
      } else {
        if (kDebugMode) {
          print("No image is selected.");
        }
      }
    } catch (e) {
      if (kDebugMode) {
        print("error while picking file.");
      }
    }
  }

  //bottomsheet function
  Future<void> showReportBottomSheets() async {
    await Get.bottomSheet(ClipRRect(
      borderRadius: const BorderRadius.only(
          topRight: Radius.circular(30), topLeft: Radius.circular(30)),
      child: StatefulBuilder(
        builder: (context, setState) => Container(
          padding: const EdgeInsets.only(left: 20, right: 20),
          height: 226,
          color: AppColors.bottomSheet,
          child: Column(
            children: [
              Column(
                children: const [
                  SizedBox(
                    height: 20,
                  ),
                  Text(
                    Strings.reportThisGroup,
                    style: TextStyle(
                        fontFamily: 'Museo Sans',
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                        color: AppColors.colorText),
                  ),
                  SizedBox(
                    height: 20,
                  ),
                  Text(
                    Strings.loreumText,
                    style: TextStyle(
                        fontFamily: 'Museo Sans',
                        fontSize: 20,
                        color: AppColors.colorText),
                    textAlign: TextAlign.center,
                  ),
                  SizedBox(
                    height: 10,
                  ),
                ],
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Expanded(
                    child: CustomButton(
                      title: Strings.cancel,
                      onTap: () {
                        Get.back();
                      },
                      textColor: AppColors.buttonColor,
                      bgColor: AppColors.whiteColor,
                    ),
                  ),
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: CustomButton(
                        title: Strings.reportText,
                        onTap: () {},
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    ));
  }

  Future<void> showDeleteBottomSheets() async {
    await Get.bottomSheet(ClipRRect(
      borderRadius: const BorderRadius.only(
          topRight: Radius.circular(30), topLeft: Radius.circular(30)),
      child: StatefulBuilder(
        builder: (context, setState) => Container(
          padding: const EdgeInsets.only(left: 20, right: 20),
          height: 226,
          color: AppColors.bottomSheet,
          child: Column(
            children: [
              Column(
                children: const [
                  SizedBox(
                    height: 20,
                  ),
                  Text(
                    Strings.deleteThisGroup,
                    style: TextStyle(
                        fontFamily: 'Museo Sans',
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                        color: AppColors.colorText),
                  ),
                  SizedBox(
                    height: 20,
                  ),
                  Text(
                    Strings.loreumText,
                    style: TextStyle(
                        fontFamily: 'Museo Sans',
                        fontSize: 20,
                        color: AppColors.colorText),
                    textAlign: TextAlign.center,
                  ),
                  SizedBox(
                    height: 10,
                  ),
                ],
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Expanded(
                    child: CustomButton(
                      title: Strings.cancel,
                      onTap: () {
                        Get.back();
                      },
                      textColor: AppColors.buttonColor,
                      bgColor: AppColors.whiteColor,
                    ),
                  ),
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: CustomButton(
                        title: Strings.delete,
                        onTap: () {},
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    ));
  }

  Future<void> showLeaveBottomSheets() async {
    await Get.bottomSheet(ClipRRect(
      borderRadius: const BorderRadius.only(
          topRight: Radius.circular(30), topLeft: Radius.circular(30)),
      child: StatefulBuilder(
        builder: (context, setState) => Container(
          padding: const EdgeInsets.only(left: 20, right: 20),
          height: 226,
          color: AppColors.bottomSheet,
          child: Column(
            children: [
              Column(
                children: const [
                  SizedBox(
                    height: 20,
                  ),
                  Text(
                    Strings.leaveThisGroup,
                    style: TextStyle(
                        fontFamily: 'Museo Sans',
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                        color: AppColors.colorText),
                  ),
                  SizedBox(
                    height: 20,
                  ),
                  Text(
                    Strings.loreumText,
                    style: TextStyle(
                        fontFamily: 'Museo Sans',
                        fontSize: 20,
                        color: AppColors.colorText),
                    textAlign: TextAlign.center,
                  ),
                  SizedBox(
                    height: 10,
                  ),
                ],
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Expanded(
                    child: CustomButton(
                      title: Strings.cancel,
                      onTap: () {
                        Get.back();
                      },
                      textColor: AppColors.buttonColor,
                      bgColor: AppColors.whiteColor,
                    ),
                  ),
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: CustomButton(
                        title: Strings.leave,
                        onTap: () {},
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    ));
  }
}

class SendMessage {
  String? messageContent;
  String? userType;
  String? img;
  String? messageTpe;

  SendMessage(this.messageContent, this.userType, this.img, this.messageTpe);
}
