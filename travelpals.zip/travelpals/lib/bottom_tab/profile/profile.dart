import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:travelpals/bottom_tab/profile/settings/settings.dart';

import '../../utils/colors.dart';
import '../../utils/strings.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({Key? key}) : super(key: key);

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  List<String> images = [
    'assets/temp.png',
    'assets/temp.png',
    'assets/temp.png',
    'assets/temp.png',
    'assets/temp.png',
    'assets/temp.png',
    'assets/temp.png',
    'assets/temp.png',
    'assets/temp.png',
    'assets/temp.png',
    'assets/temp.png',
    'assets/temp.png',
    'assets/temp.png',
    'assets/temp.png',
    'assets/temp.png',
    'assets/temp.png',
    'assets/temp.png',
    'assets/temp.png',
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        backgroundColor: AppColors.bottomSheet,
        actions: [
          IconButton(
            icon: const Icon(
              Icons.settings,
              color: AppColors.colorText,
            ),
            onPressed: () {
              Get.to(const Settings());
            },
          ),
        ],
      ),
      backgroundColor: AppColors.bottomSheet,
      body: Container(
        padding: EdgeInsets.only(left: 20, right: 14),
        child: SingleChildScrollView(
          child: Column(
            children: [
              Center(child: Image.asset('assets/picture.png')),
              const SizedBox(height: 10),
              const Center(
                  child: Text(
                Strings.profileNames,
                style: TextStyle(
                    fontFamily: 'Museo Sans',
                    fontSize: 20,
                    color: AppColors.colorText,
                    fontWeight: FontWeight.w700),
              )),
              const SizedBox(height: 10),
              const Center(
                  child: Text(
                Strings.profileEmail,
                style: TextStyle(
                    fontFamily: 'Museo Sans',
                    fontSize: 14,
                    color: AppColors.colorText,
                    fontWeight: FontWeight.w400),
              )),
              const SizedBox(height: 10),
              const Center(
                  child: Text(
                Strings.profileContact,
                style: TextStyle(
                    fontFamily: 'Museo Sans',
                    fontSize: 14,
                    color: AppColors.colorText,
                    fontWeight: FontWeight.w400),
              )),
              const SizedBox(height: 10),

              Row(
                children: [
                  const Text(
                    Strings.bio,
                    style: TextStyle(
                        fontFamily: 'Museo Sans',
                        fontSize: 18,
                        color: AppColors.colorText,
                        fontWeight: FontWeight.w700),
                  ),
                  Expanded(
                    child: Align(
                      alignment: Alignment.topRight,
                      child: GestureDetector(
                          onTap: () {
                            setState(() {
                              //set output date to TextField value.
                            });
                          },
                          child: Container(
                            padding: const EdgeInsets.all(2),
                            decoration: const BoxDecoration(
                              borderRadius:
                                  BorderRadius.all(Radius.elliptical(7, 7)),
                              color: AppColors.colorBottomNavText,
                            ),
                            child: Icon(
                              Icons.edit,
                              color: AppColors.whiteColor,
                              size: 18,
                            ),
                          )),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 10),

              const Text(
                Strings.description,
                style: TextStyle(
                    fontFamily: 'Museo Sans', fontSize: 16, color: Colors.grey),
                textAlign: TextAlign.start,
              ),
              const SizedBox(height: 10),

              //photos Grid
              Row(
                children: [
                  const Text(
                    Strings.photosAndVideos,
                    style: TextStyle(
                        fontFamily: 'Museo Sans',
                        fontSize: 20,
                        color: AppColors.colorText,
                        fontWeight: FontWeight.w700),
                  ),
                  Expanded(
                    child: Align(
                      alignment: Alignment.topRight,
                      child: GestureDetector(
                          onTap: () {
                            setState(() {
                              //set output date to TextField value.
                            });
                          },
                          child: Container(
                            padding: const EdgeInsets.all(2),
                            decoration: const BoxDecoration(
                              borderRadius:
                                  BorderRadius.all(Radius.elliptical(7, 7)),
                              color: AppColors.colorBottomNavText,
                            ),
                            child: Icon(
                              Icons.edit,
                              color: AppColors.whiteColor,
                              size: 18,
                            ),
                          )),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 10),

              GridView.count(
                  shrinkWrap: true,
                  crossAxisCount: 4,
                  crossAxisSpacing: 0,
                  children: List.generate(images.length, (index) {
                    return Center(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Stack(
                            alignment: AlignmentDirectional.topCenter,
                            fit: StackFit.loose,
                            children: [
                              Image.asset(images[index], fit: BoxFit.fill)
                            ],
                          )
                        ],
                      ),
                    );
                  })),
              const SizedBox(height: 10),

            ],
          ),
        ),
      ),
    );
  }
}
