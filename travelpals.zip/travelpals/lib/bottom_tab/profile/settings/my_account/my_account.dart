import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';

import '../../../../component/decorated_radio_btn2.dart';
import '../../../../create_profile/profile_shared_pref.dart';
import '../../../../custom/custom_button.dart';
import '../../../../utils/colors.dart';
import '../../../../utils/strings.dart';

class MyAccount extends StatefulWidget {
  const MyAccount({Key? key}) : super(key: key);

  @override
  State<MyAccount> createState() => _MyAccountState();
}

class _MyAccountState extends State<MyAccount> {
  var isSelectYes = false;
  var isSelectNo = false;
  var isSelectSocially = false;
  int selectedGenderVar = 0;
  final ProfilePrefService _prefService = ProfilePrefService();
  String age = '';

  @override
  void initState() {
 
    super.initState();
    //read sharedpref value
    _prefService.readCache("age").then((value) {
      print("Age${value}");
        if (value == null) {
          return null;
        }
        else {
          setState(() {
            age = value;
          });
        }
    });
  }
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        title: Text(
          Strings.myAccount,
          style: TextStyle(
              fontFamily: 'Museo Sans',
              color: AppColors.colorText,
              fontSize: ScreenUtil().setSp(20)),
        ),
        centerTitle: false,
        titleSpacing: 0,
        backgroundColor: Colors.white,
        leading: IconButton(
          icon: const Icon(
            Icons.arrow_back,
            color: AppColors.arrowColor,
          ),
          onPressed: () {
            Get.back();
          },
        ),
      ),
      body: SingleChildScrollView(
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
               Text(
                Strings.birthdate,
                style: TextStyle(
                    fontFamily: 'Museo Sans',
                    color: AppColors.colorText,
                    fontSize: ScreenUtil().setSp(16),
                    fontWeight: FontWeight.w700),
              ),
              const SizedBox(
                height: 10,
              ),
               Text(
                '5/June/1992',
                style: TextStyle(
                    fontFamily: 'Museo Sans',
                    color: AppColors.counterPostButtonColor,
                    fontSize: ScreenUtil().setSp(12),
                    fontWeight: FontWeight.w400),
              ),
              const SizedBox(
                height: 10,
              ),

               Text(
                Strings.language,
                style: TextStyle(
                    fontFamily: 'Museo Sans',
                    color: AppColors.colorText,
                    fontSize: ScreenUtil().setSp(16),
                    fontWeight: FontWeight.w700),
              ),
              const SizedBox(
                height: 10,
              ),
               Text(
                'English',
                style: TextStyle(
                    fontFamily: 'Museo Sans',
                    color: AppColors.counterPostButtonColor,
                    fontSize: ScreenUtil().setSp(12),
                    fontWeight: FontWeight.w400),
              ),

              //interest age
              const SizedBox(
                height: 10,
              ),

              Row(
                children: [
                   Text(
                    Strings.interestedAge,
                    style: TextStyle(
                        fontFamily: 'Museo Sans',
                        color: AppColors.colorText,
                        fontSize: ScreenUtil().setSp(16),
                        fontWeight: FontWeight.w700),
                  ),
                  Expanded(
                    child: Align(
                      alignment: Alignment.topRight,
                      child: GestureDetector(
                          onTap: () {
                            setState(() {
                              //set output date to TextField value.
                            });
                          },
                          child: Container(
                            padding: const EdgeInsets.all(2),
                            decoration: const BoxDecoration(
                              borderRadius:
                                  BorderRadius.all(Radius.elliptical(7, 7)),
                              color: AppColors.colorBottomNavText,
                            ),
                            child: Icon(
                              Icons.edit,
                              color: AppColors.whiteColor,
                              size: 18,
                            ),
                          )),
                    ),
                  ),
                ],
              ),
              const SizedBox(
                height: 10,
              ),
              Text(
                'Age: $age',
                style: TextStyle(
                    fontFamily: 'Museo Sans',
                    color: AppColors.counterPostButtonColor,
                    fontSize: ScreenUtil().setSp(12),
                    fontWeight: FontWeight.w400),
              ),

               SizedBox(
                height: 25.h,
              ),
              //travel partner
              Row(
                children: [
                   Text(
                    Strings.yourTravelPartner,
                    style: TextStyle(
                        fontFamily: 'Museo Sans',
                        color: AppColors.colorText,
                        fontSize: ScreenUtil().setSp(16),
                        fontWeight: FontWeight.w700),
                  ),
                  Expanded(
                    child: Align(
                      alignment: Alignment.topRight,
                      child: GestureDetector(
                          onTap: () {
                            setState(() {
                              //set output date to TextField value.
                            });
                          },
                          child: Container(
                            padding: const EdgeInsets.all(2),
                            decoration: const BoxDecoration(
                              borderRadius:
                                  BorderRadius.all(Radius.elliptical(7, 7)),
                              color: AppColors.colorBottomNavText,
                            ),
                            child: Icon(
                              Icons.edit,
                              color: AppColors.whiteColor,
                              size: 18,
                            ),
                          )),
                    ),
                  ),
                ],
              ),
              SizedBox(
                height: 25.h,
              ),

              //travel interest
              Row(
                children: [
                   Text(
                    Strings.yourInterest,
                    style: TextStyle(
                        fontFamily: 'Museo Sans',
                        color: AppColors.colorText,
                        fontSize: ScreenUtil().setSp(16),
                        fontWeight: FontWeight.w700),
                  ),
                  Expanded(
                    child: Align(
                      alignment: Alignment.topRight,
                      child: GestureDetector(
                          onTap: () {
                            setState(() {
                              //set output date to TextField value.
                            });
                          },
                          child: Container(
                            padding: const EdgeInsets.all(2),
                            decoration: const BoxDecoration(
                              borderRadius:
                                  BorderRadius.all(Radius.elliptical(7, 7)),
                              color: AppColors.colorBottomNavText,
                            ),
                            child: Icon(
                              Icons.edit,
                              color: AppColors.whiteColor,
                              size: 18,
                            ),
                          )),
                    ),
                  ),
                ],
              ),
              const SizedBox(
                height: 10,
              ),

              //activity interest
              Row(
                children: [
                   Text(
                    Strings.yourActivityInterest,
                    style: TextStyle(
                        fontFamily: 'Museo Sans',
                        color: AppColors.colorText,
                        fontSize: ScreenUtil().setSp(16),
                        fontWeight: FontWeight.w700),
                  ),
                  Expanded(
                    child: Align(
                      alignment: Alignment.topRight,
                      child: GestureDetector(
                          onTap: () {
                            setState(() {
                              //set output date to TextField value.
                            });
                          },
                          child: Container(
                            padding: const EdgeInsets.all(2),
                            decoration: const BoxDecoration(
                              borderRadius:
                                  BorderRadius.all(Radius.elliptical(7, 7)),
                              color: AppColors.colorBottomNavText,
                            ),
                            child: Icon(
                              Icons.edit,
                              color: AppColors.whiteColor,
                              size: 18,
                            ),
                          )),
                    ),
                  ),
                ],
              ),
              const SizedBox(
                height: 10,
              ),

              //preference
               Text(
                Strings.yourPreference,
                style: TextStyle(
                    fontFamily: 'Museo Sans',
                    color: AppColors.colorText,
                    fontSize: ScreenUtil().setSp(16),
                    fontWeight: FontWeight.w700),
              ),
              Row(
                children: [
                   Expanded(
                      child: Text(
                    Strings.doYouHavePassport,
                    style: TextStyle(
                        fontFamily: 'Museo Sans',
                        color: AppColors.counterPostButtonColor,
                        fontSize: ScreenUtil().setSp(13),
                        fontWeight: FontWeight.w400),
                  )),
                  //switch
                  Switch(
                      activeColor: AppColors.buttonColor,
                      value: true,
                      onChanged: (value) {
                        setState(() {
                          value = !value;
                        });
                      })
                ],
              ),

              //vaccinated
              Row(
                children: [
                   Expanded(
                      child: Text(
                    Strings.vaccinated,
                    style: TextStyle(
                        fontFamily: 'Museo Sans',
                        color: AppColors.counterPostButtonColor,
                        fontSize: ScreenUtil().setSp(13),
                        fontWeight: FontWeight.w400),
                  )),
                  //switch
                  Switch(
                      activeColor: AppColors.buttonColor,
                      value: true,
                      onChanged: (value) {
                        setState(() {
                          value = !value;
                        });
                      })
                ],
              ),

              //smoke
              const SizedBox(
                height: 10,
              ),
               Text(
                Strings.doYouSmoke,
                style: TextStyle(
                    fontFamily: 'Museo Sans',
                    color: AppColors.counterPostButtonColor,
                    fontSize: ScreenUtil().setSp(14),
                    fontWeight: FontWeight.w700),
              ),
              const SizedBox(
                height: 10,
              ),
              DecoratedRadioButton2(
                isSelected: 1 == selectedGenderVar,
                text: Strings.yes,
                onTap: () {
                  setState(() {
                    selectedGenderVar = 1;
                  });
                },
              ),
              const SizedBox(
                height: 10,
              ),
              DecoratedRadioButton2(
                isSelected: 2 == selectedGenderVar,
                text: Strings.no,
                onTap: () {
                  setState(() {
                    selectedGenderVar = 2;
                  });
                },
              ),
              const SizedBox(
                height: 10,
              ),
              DecoratedRadioButton2(
                isSelected: 3 == selectedGenderVar,
                text: Strings.socially,
                onTap: () {
                  setState(() {
                    selectedGenderVar = 3;
                  });
                },
              ),
              const SizedBox(
                height: 10,
              ),

              const SizedBox(
                height: 10,
              ),
               Text(
                Strings.doYouDrink,
                style: TextStyle(
                    fontFamily: 'Museo Sans',
                    color: AppColors.counterPostButtonColor,
                    fontSize: ScreenUtil().setSp(14),
                    fontWeight: FontWeight.w700),
              ),
              const SizedBox(
                height: 10,
              ),
              DecoratedRadioButton2(
                isSelected: 1 == selectedGenderVar,
                text: Strings.yes,
                onTap: () {
                  setState(() {
                    selectedGenderVar = 1;
                  });
                },
              ),
              const SizedBox(
                height: 10,
              ),
              DecoratedRadioButton2(
                isSelected: 2 == selectedGenderVar,
                text: Strings.no,
                onTap: () {
                  setState(() {
                    selectedGenderVar = 2;
                  });
                },
              ),
              const SizedBox(
                height: 10,
              ),
              DecoratedRadioButton2(
                isSelected: 3 == selectedGenderVar,
                text: Strings.socially,
                onTap: () {
                  setState(() {
                    selectedGenderVar = 3;
                  });
                },
                borderColor: AppColors.whiteColor,
              ),
              const SizedBox(
                height: 10,
              ),

              //cancel
              const SizedBox(
                height: 10,
              ),
              CustomButton(
                title: Strings.cancelMembership,
                onTap: () {},
                bgColor: AppColors.bottomSheet,
                borderColor: AppColors.cancelColor,
                textColor: AppColors.cancelColor,
              ),

              const SizedBox(
                height: 10,
              ),
              CustomButton(
                title: Strings.deactivateAccount,
                onTap: () {
                  showDeactivateAccountBottomSheets();
                },
                bgColor: AppColors.cancelColor,
                borderColor: AppColors.cancelColor,
                textColor: AppColors.whiteColor,
              ),
              const SizedBox(
                height: 10,
              )
            ],
          ),
        ),
      ),
    );
  }

  Future<void> showDeactivateAccountBottomSheets() async {
    await Get.bottomSheet(ClipRRect(
      borderRadius: const BorderRadius.only(
          topRight: Radius.circular(30), topLeft: Radius.circular(30)),
      child: StatefulBuilder(
        builder: (context, setState) => Container(
          padding: const EdgeInsets.only(left: 20, right: 20),
          height: 226,
          color: AppColors.bottomSheet,
          child: Column(
            children: [
              Column(
                children: const [
                  SizedBox(
                    height: 20,
                  ),
                  Text(
                    Strings.leaveThisGroup,
                    style: TextStyle(
                        fontFamily: 'Museo Sans',
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                        color: AppColors.colorText),
                  ),
                  SizedBox(
                    height: 20,
                  ),
                  Text(
                    Strings.loreumText,
                    style: TextStyle(
                        fontFamily: 'Museo Sans',
                        fontSize: 20,
                        color: AppColors.colorText),
                    textAlign: TextAlign.center,
                  ),
                  SizedBox(
                    height: 10,
                  ),
                ],
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Expanded(
                    child: CustomButton(
                      title: Strings.cancel,
                      onTap: () {
                        //close bottomsheet
                        Get.back();
                      },
                      textColor: AppColors.buttonColor,
                      bgColor: AppColors.whiteColor,
                    ),
                  ),
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: CustomButton(
                        title: Strings.deactivate,
                        onTap: () async {},
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    ));
  }
}
