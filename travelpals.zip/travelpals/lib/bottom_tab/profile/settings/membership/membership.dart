import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';

import '../../../../custom/custom_button.dart';
import '../../../../utils/colors.dart';
import '../../../../utils/strings.dart';

class Membership extends StatefulWidget {
  const Membership({Key? key}) : super(key: key);

  @override
  State<Membership> createState() => _MembershipState();
}

class _MembershipState extends State<Membership> {
  @override
  Widget build(BuildContext context) {
    return ScreenUtilInit(builder: (_, child) {
      return Scaffold(
        appBar: AppBar(
          elevation: 0,
          title: const Text(
            Strings.manageYourMembership,
            style: TextStyle(
                fontFamily: 'Museo Sans',
                color: AppColors.colorText,
                fontSize: 22),
          ),
          centerTitle: false,
          titleSpacing: 0,
          backgroundColor: Colors.white,
          leading: IconButton(
            icon: const Icon(
              Icons.arrow_back,
              color: AppColors.arrowColor,
            ),
            onPressed: () {
              Get.back();
            },
          ),
        ),
        body: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.all(20.0),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(8),
                  child: Container(
                    height: 130,
                    width: ScreenUtil().screenWidth,
                    decoration: const BoxDecoration(
                        gradient: LinearGradient(
                            begin: Alignment.topRight,
                            end: Alignment.bottomLeft,
                            colors: [
                          AppColors.buttonColor,
                          AppColors.colorMembershipGradient2
                        ])),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(height: 10.h),
                        Row(
                          children: [
                            Padding(
                              padding: EdgeInsets.only(left: 16.h),
                              child: Text(
                                Strings.currentSubscription,
                                style: TextStyle(
                                    fontFamily: 'Museo Sans',
                                    color: AppColors.colorMembershipTitleText,
                                    fontSize: ScreenUtil().setSp(18),
                                    fontWeight: FontWeight.w700),
                              ),
                            ),
                            Expanded(
                                child: Align(
                              alignment: Alignment.topRight,
                              child: Padding(
                                padding: const EdgeInsets.only(right: 8.0),
                                child: Icon(
                                  Icons.check_circle,
                                  color: AppColors.whiteColor,
                                  size: 32,
                                ),
                              ),
                            ))
                          ],
                        ),
                        SizedBox(height: 10.h),
                        Padding(
                          padding: EdgeInsets.only(left: 16.h),
                          child: Text(
                            Strings.oneMonthPackage,
                            style: TextStyle(
                                fontFamily: 'Museo Sans',
                                color: AppColors.whiteColor,
                                fontSize: ScreenUtil().setSp(16),
                                fontWeight: FontWeight.w700),
                          ),
                        ),
                        SizedBox(height: 10.h),
                        Padding(
                          padding: EdgeInsets.only(left: 16.h),
                          child: Text(
                            Strings.expires,
                            style: TextStyle(
                                fontFamily: 'Museo Sans',
                                color: AppColors.whiteColor,
                                fontSize: ScreenUtil().setSp(12),
                                fontWeight: FontWeight.w400),
                          ),
                        )
                      ],
                    ),
                  ),
                ),
              ),
              Padding(
                padding: EdgeInsets.only(left: 16.h),
                child: Text(
                  Strings.allPlans,
                  style: TextStyle(
                      fontFamily: 'Museo Sans',
                      color: AppColors.colorText,
                      fontSize: ScreenUtil().setSp(20),
                      fontWeight: FontWeight.w700),
                ),
              ),
              Carousel(),
              Center(
                child: CustomButton(
                  width: 200,
                  title: Strings.upgradePlans,
                  onTap: () {},
                  bgColor: AppColors.buttonColor,
                ),
              ),
            ],
          ),
        ),
      );
    });
  }
}

class Carousel extends StatefulWidget {
  const Carousel({
    Key? key,
  }) : super(key: key);

  @override
  State<Carousel> createState() => _CarouselState();
}

class _CarouselState extends State<Carousel> {
  late PageController _pageController;

  List<Widget> colums = [
    Column(
      children: [
        ClipRRect(
          borderRadius: const BorderRadius.only(
              topLeft: Radius.circular(10), topRight: Radius.circular(10)),
          child: Container(
            color: AppColors.colorVerifyGradient,
            child: Padding(
              padding: EdgeInsets.all(8.h),
              child: Text(
                Strings.threeMonthPackage,
                style: TextStyle(
                    fontFamily: 'Museo Sans',
                    color: AppColors.colorText,
                    fontSize: ScreenUtil().setSp(16),
                    fontWeight: FontWeight.w500),
              ),
            ),
          ),
        ),
        Text(textAlign: TextAlign.center,
          '\$15 / Month',
          style: TextStyle(
              fontFamily: 'Museo Sans',
              color: AppColors.colorMembershiptext,
              fontSize: ScreenUtil().setSp(16),
              fontWeight: FontWeight.w700),
        ),
        SizedBox(
          height: 10.h,
        ),
        Row(
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    Strings.backgroundCheck,
                    style: TextStyle(
                        fontFamily: 'Museo Sans',
                        color: AppColors.colorText,
                        fontSize: ScreenUtil().setSp(12),
                        fontWeight: FontWeight.w500),
                  ),
                  SizedBox(
                    height: 10.h,
                  ),
                  Text(
                    Strings.likes,
                    style: TextStyle(
                        fontFamily: 'Museo Sans',
                        color: AppColors.colorText,
                        fontSize: ScreenUtil().setSp(12),
                        fontWeight: FontWeight.w500),
                  ),
                  SizedBox(
                    height: 10.h,
                  ),
                  Text(
                    Strings.comments,
                    style: TextStyle(
                        fontFamily: 'Museo Sans',
                        color: AppColors.colorText,
                        fontSize: ScreenUtil().setSp(12),
                        fontWeight: FontWeight.w500),
                  ),
                  SizedBox(
                    height: 10.h,
                  ),
                  Text(
                    Strings.joinTrips,
                    style: TextStyle(
                        fontFamily: 'Museo Sans',
                        color: AppColors.colorText,
                        fontSize: ScreenUtil().setSp(12),
                        fontWeight: FontWeight.w500),
                  ),
                  SizedBox(
                    height: 10.h,
                  ),
                  Text(
                    Strings.videoCall,
                    style: TextStyle(
                        fontFamily: 'Museo Sans',
                        color: AppColors.colorText,
                        fontSize: ScreenUtil().setSp(12),
                        fontWeight: FontWeight.w500),
                  ),
                  SizedBox(
                    height: 10.h,
                  ),
                  Text(
                    Strings.profileSwipe,
                    style: TextStyle(
                        fontFamily: 'Museo Sans',
                        color: AppColors.colorText,
                        fontSize: ScreenUtil().setSp(12),
                        fontWeight: FontWeight.w500),
                  ),
                ],
              ),
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text(
                  '3',
                  style: TextStyle(
                      fontFamily: 'Museo Sans',
                      color: AppColors.colorText,
                      fontSize: ScreenUtil().setSp(12),
                      fontWeight: FontWeight.w500),
                ),
                SizedBox(
                  height: 10.h,
                ),
                Text(
                  Strings.unlimited,
                  style: TextStyle(
                      fontFamily: 'Museo Sans',
                      color: AppColors.colorText,
                      fontSize: ScreenUtil().setSp(12),
                      fontWeight: FontWeight.w500),
                ),
                SizedBox(
                  height: 10.h,
                ),
                Text(
                  Strings.unlimited,
                  style: TextStyle(
                      fontFamily: 'Museo Sans',
                      color: AppColors.colorText,
                      fontSize: ScreenUtil().setSp(12),
                      fontWeight: FontWeight.w500),
                ),
                SizedBox(
                  height: 10.h,
                ),
                Text(
                  Strings.unlimited,
                  style: TextStyle(
                      fontFamily: 'Museo Sans',
                      color: AppColors.colorText,
                      fontSize: ScreenUtil().setSp(12),
                      fontWeight: FontWeight.w500),
                ),
                SizedBox(
                  height: 10.h,
                ),
                Text(
                  Strings.unlimited,
                  style: TextStyle(
                      fontFamily: 'Museo Sans',
                      color: AppColors.colorText,
                      fontSize: ScreenUtil().setSp(12),
                      fontWeight: FontWeight.w500),
                ),
                SizedBox(
                  height: 10.h,
                ),
                Text(
                  Strings.unlimited,
                  style: TextStyle(
                      fontFamily: 'Museo Sans',
                      color: AppColors.colorText,
                      fontSize: ScreenUtil().setSp(12),
                      fontWeight: FontWeight.w500),
                ),
              ],
            )
          ],
        ),
      ],
    ),
    Column(
      children: [
        ClipRRect(
          borderRadius: const BorderRadius.only(
              topLeft: Radius.circular(10), topRight: Radius.circular(10)),
          child: Container(
            color: AppColors.colorVerifyGradient,
            child: Padding(
              padding: EdgeInsets.all(8.h),
              child: Text(
                Strings.sixMonthPackage,
                style: TextStyle(
                    fontFamily: 'Museo Sans',
                    color: AppColors.colorText,
                    fontSize: ScreenUtil().setSp(16),
                    fontWeight: FontWeight.w500),
              ),
            ),
          ),
        ),
        Text(
          '\$15 / Month',
          style: TextStyle(
              fontFamily: 'Museo Sans',
              color: AppColors.colorMembershiptext,
              fontSize: ScreenUtil().setSp(16),
              fontWeight: FontWeight.w700),
        ),
        SizedBox(
          height: 10.h,
        ),
        Row(
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    Strings.backgroundCheck,
                    style: TextStyle(
                        fontFamily: 'Museo Sans',
                        color: AppColors.colorText,
                        fontSize: ScreenUtil().setSp(12),
                        fontWeight: FontWeight.w500),
                  ),
                  SizedBox(
                    height: 10.h,
                  ),
                  Text(
                    Strings.likes,
                    style: TextStyle(
                        fontFamily: 'Museo Sans',
                        color: AppColors.colorText,
                        fontSize: ScreenUtil().setSp(12),
                        fontWeight: FontWeight.w500),
                  ),
                  SizedBox(
                    height: 10.h,
                  ),
                  Text(
                    Strings.comments,
                    style: TextStyle(
                        fontFamily: 'Museo Sans',
                        color: AppColors.colorText,
                        fontSize: ScreenUtil().setSp(12),
                        fontWeight: FontWeight.w500),
                  ),
                  SizedBox(
                    height: 10.h,
                  ),
                  Text(
                    Strings.joinTrips,
                    style: TextStyle(
                        fontFamily: 'Museo Sans',
                        color: AppColors.colorText,
                        fontSize: ScreenUtil().setSp(12),
                        fontWeight: FontWeight.w500),
                  ),
                  SizedBox(
                    height: 10.h,
                  ),
                  Text(
                    Strings.videoCall,
                    style: TextStyle(
                        fontFamily: 'Museo Sans',
                        color: AppColors.colorText,
                        fontSize: ScreenUtil().setSp(12),
                        fontWeight: FontWeight.w500),
                  ),
                  SizedBox(
                    height: 10.h,
                  ),
                  Text(
                    Strings.profileSwipe,
                    style: TextStyle(
                        fontFamily: 'Museo Sans',
                        color: AppColors.colorText,
                        fontSize: ScreenUtil().setSp(12),
                        fontWeight: FontWeight.w500),
                  ),
                ],
              ),
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text(
                  '3',
                  style: TextStyle(
                      fontFamily: 'Museo Sans',
                      color: AppColors.colorText,
                      fontSize: ScreenUtil().setSp(12),
                      fontWeight: FontWeight.w500),
                ),
                SizedBox(
                  height: 10.h,
                ),
                Text(
                  Strings.unlimited,
                  style: TextStyle(
                      fontFamily: 'Museo Sans',
                      color: AppColors.colorText,
                      fontSize: ScreenUtil().setSp(12),
                      fontWeight: FontWeight.w500),
                ),
                SizedBox(
                  height: 10.h,
                ),
                Text(
                  Strings.unlimited,
                  style: TextStyle(
                      fontFamily: 'Museo Sans',
                      color: AppColors.colorText,
                      fontSize: ScreenUtil().setSp(12),
                      fontWeight: FontWeight.w500),
                ),
                SizedBox(
                  height: 10.h,
                ),
                Text(
                  Strings.unlimited,
                  style: TextStyle(
                      fontFamily: 'Museo Sans',
                      color: AppColors.colorText,
                      fontSize: ScreenUtil().setSp(12),
                      fontWeight: FontWeight.w500),
                ),
                SizedBox(
                  height: 10.h,
                ),
                Text(
                  Strings.unlimited,
                  style: TextStyle(
                      fontFamily: 'Museo Sans',
                      color: AppColors.colorText,
                      fontSize: ScreenUtil().setSp(12),
                      fontWeight: FontWeight.w500),
                ),
                SizedBox(
                  height: 10.h,
                ),
                Text(
                  Strings.unlimited,
                  style: TextStyle(
                      fontFamily: 'Museo Sans',
                      color: AppColors.colorText,
                      fontSize: ScreenUtil().setSp(12),
                      fontWeight: FontWeight.w500),
                ),
              ],
            )
          ],
        ),
      ],
    ),
    Column(
      children: [
        ClipRRect(
          borderRadius: const BorderRadius.only(
              topLeft: Radius.circular(10), topRight: Radius.circular(10)),
          child: Container(
            color: AppColors.colorVerifyGradient,
            child: Padding(
              padding: EdgeInsets.all(8.h),
              child: Text(
                Strings.foreverPlan,
                style: TextStyle(
                    fontFamily: 'Museo Sans',
                    color: AppColors.colorText,
                    fontSize: ScreenUtil().setSp(16),
                    fontWeight: FontWeight.w500),
              ),
            ),
          ),
        ),
        Text(
          '\$15 / Month',
          style: TextStyle(
              fontFamily: 'Museo Sans',
              color: AppColors.colorMembershiptext,
              fontSize: ScreenUtil().setSp(16),
              fontWeight: FontWeight.w700),
        ),
        SizedBox(
          height: 10.h,
        ),
        Row(
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    Strings.backgroundCheck,
                    style: TextStyle(
                        fontFamily: 'Museo Sans',
                        color: AppColors.colorText,
                        fontSize: ScreenUtil().setSp(12),
                        fontWeight: FontWeight.w500),
                  ),
                  SizedBox(
                    height: 10.h,
                  ),
                  Text(
                    Strings.likes,
                    style: TextStyle(
                        fontFamily: 'Museo Sans',
                        color: AppColors.colorText,
                        fontSize: ScreenUtil().setSp(12),
                        fontWeight: FontWeight.w500),
                  ),
                  SizedBox(
                    height: 10.h,
                  ),
                  Text(
                    Strings.comments,
                    style: TextStyle(
                        fontFamily: 'Museo Sans',
                        color: AppColors.colorText,
                        fontSize: ScreenUtil().setSp(12),
                        fontWeight: FontWeight.w500),
                  ),
                  SizedBox(
                    height: 10.h,
                  ),
                  Text(
                    Strings.joinTrips,
                    style: TextStyle(
                        fontFamily: 'Museo Sans',
                        color: AppColors.colorText,
                        fontSize: ScreenUtil().setSp(12),
                        fontWeight: FontWeight.w500),
                  ),
                  SizedBox(
                    height: 10.h,
                  ),
                  Text(
                    Strings.videoCall,
                    style: TextStyle(
                        fontFamily: 'Museo Sans',
                        color: AppColors.colorText,
                        fontSize: ScreenUtil().setSp(12),
                        fontWeight: FontWeight.w500),
                  ),
                  SizedBox(
                    height: 10.h,
                  ),
                  Text(
                    Strings.profileSwipe,
                    style: TextStyle(
                        fontFamily: 'Museo Sans',
                        color: AppColors.colorText,
                        fontSize: ScreenUtil().setSp(12),
                        fontWeight: FontWeight.w500),
                  ),
                ],
              ),
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text(
                  '3',
                  style: TextStyle(
                      fontFamily: 'Museo Sans',
                      color: AppColors.colorText,
                      fontSize: ScreenUtil().setSp(12),
                      fontWeight: FontWeight.w500),
                ),
                SizedBox(
                  height: 10.h,
                ),
                Text(
                  Strings.unlimited,
                  style: TextStyle(
                      fontFamily: 'Museo Sans',
                      color: AppColors.colorText,
                      fontSize: ScreenUtil().setSp(12),
                      fontWeight: FontWeight.w500),
                ),
                SizedBox(
                  height: 10.h,
                ),
                Text(
                  Strings.unlimited,
                  style: TextStyle(
                      fontFamily: 'Museo Sans',
                      color: AppColors.colorText,
                      fontSize: ScreenUtil().setSp(12),
                      fontWeight: FontWeight.w500),
                ),
                SizedBox(
                  height: 10.h,
                ),
                Text(
                  Strings.unlimited,
                  style: TextStyle(
                      fontFamily: 'Museo Sans',
                      color: AppColors.colorText,
                      fontSize: ScreenUtil().setSp(12),
                      fontWeight: FontWeight.w500),
                ),
                SizedBox(
                  height: 10.h,
                ),
                Text(
                  Strings.unlimited,
                  style: TextStyle(
                      fontFamily: 'Museo Sans',
                      color: AppColors.colorText,
                      fontSize: ScreenUtil().setSp(12),
                      fontWeight: FontWeight.w500),
                ),
                SizedBox(
                  height: 10.h,
                ),
                Text(
                  Strings.unlimited,
                  style: TextStyle(
                      fontFamily: 'Museo Sans',
                      color: AppColors.colorText,
                      fontSize: ScreenUtil().setSp(12),
                      fontWeight: FontWeight.w500),
                ),
              ],
            )
          ],
        ),
      ],
    ),
  ];

  int activePage = 1;

  @override
  void initState() {
    super.initState();

    _pageController = PageController(initialPage: 1, viewportFraction: 0.6);
  }

  bool onTap = false;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        SizedBox(
          height: 260,
          child: Stack(children: [
            PageView.builder(
                pageSnapping: true,
                itemCount: colums.length,
                controller: _pageController,
                onPageChanged: (page) {
                  setState(() {
                    activePage = page;
                  });
                },
                itemBuilder: (context, pagePosition) {
                  bool active = pagePosition == activePage;
                  return colums[pagePosition];
                }),
          ]),
        ),
      ],
    );
  }
}
