import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:travelpals/bottom_tab/profile/settings/change/controller/change_pswd_controller.dart';
import 'package:travelpals/bottom_tab/profile/settings/settings.dart';

import '../../../../custom/custom_button.dart';
import '../../../../utils/colors.dart';
import '../../../../utils/strings.dart';

class ChangePassword extends StatefulWidget {
  const ChangePassword({Key? key}) : super(key: key);

  @override
  State<ChangePassword> createState() => _ChangePasswordState();
}

class _ChangePasswordState extends State<ChangePassword> {
  ChangePasswordController controller = ChangePasswordController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        title: const Text(
          Strings.changePassword,
          style: TextStyle(
              fontFamily: 'Museo Sans',
              color: AppColors.colorText,
              fontSize: 22),
        ),
        centerTitle: false,
        titleSpacing: 0,
        backgroundColor: Colors.white,
        leading: IconButton(
          icon: const Icon(
            Icons.arrow_back,
            color: AppColors.arrowColor,
          ),
          onPressed: () {
            Get.back();
          },
        ),
      ),
      body: SingleChildScrollView(
        child: Form(
          key: controller.loginKey,
            autovalidateMode: AutovalidateMode.onUserInteraction,
            child: Container(
              padding: EdgeInsets.symmetric(horizontal: 20),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  const SizedBox(
                    height: 10,
                  ),
                  Obx(
                    () => TextFormField(
                      controller: controller.passwordController,
                      obscureText: controller.isPasswordHidden.value,
                      textInputAction: TextInputAction.done,
                      style: const TextStyle(
                          color: Colors.black, fontFamily: 'Museo Sans'),
                      keyboardType: TextInputType.emailAddress,
                      cursorColor: Colors.white,
                      decoration: InputDecoration(
                          contentPadding: const EdgeInsets.only(left: 10),
                          filled: true,
                          fillColor: AppColors.colorPostInput,
                          enabledBorder: const OutlineInputBorder(
                              borderSide:
                                  BorderSide(color: AppColors.colorPostInput),
                              borderRadius:
                                  BorderRadius.all(Radius.circular(15.0))),
                          errorBorder: const OutlineInputBorder(
                              borderSide:
                                  BorderSide(color: AppColors.buttonColor),
                              borderRadius:
                                  BorderRadius.all(Radius.circular(15.0))),
                          focusedBorder: const OutlineInputBorder(
                              borderSide:
                                  BorderSide(color: AppColors.colorPostInput),
                              borderRadius:
                                  BorderRadius.all(Radius.circular(15.0))),
                          suffixIcon: IconButton(
                            onPressed: () {
                              controller.isPasswordHidden.value =
                                  !controller.isPasswordHidden.value;
                            },
                            icon: Icon(
                              controller.isPasswordHidden.value
                                  ? Icons.visibility
                                  : Icons.visibility_off,
                            ),
                            color: Colors.grey,
                          ),
                          hintText: Strings.currentPassword,
                          hintStyle: const TextStyle(
                              fontFamily: 'Museo Sans',
                              color: AppColors.colorVaarient)),
                      onSaved: (value) {
                        controller.pswd = value!;
                      },
                      validator: (value) {
                        return controller.validatePassword(value!);
                      },
                    ),
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  Obx(
                    () => TextFormField(
                      controller: controller.newPasswordController,
                      obscureText: controller.isNewPasswordHidden.value,
                      textInputAction: TextInputAction.done,
                      style: const TextStyle(
                          color: Colors.black, fontFamily: 'Museo Sans'),
                      keyboardType: TextInputType.emailAddress,
                      cursorColor: Colors.white,
                      decoration: InputDecoration(
                          contentPadding: const EdgeInsets.only(left: 10),
                          filled: true,
                          fillColor: AppColors.colorPostInput,
                          enabledBorder: const OutlineInputBorder(
                              borderSide:
                                  BorderSide(color: AppColors.colorPostInput),
                              borderRadius:
                                  BorderRadius.all(Radius.circular(15.0))),
                          errorBorder: const OutlineInputBorder(
                              borderSide:
                                  BorderSide(color: AppColors.buttonColor),
                              borderRadius:
                                  BorderRadius.all(Radius.circular(15.0))),
                          focusedBorder: const OutlineInputBorder(
                              borderSide:
                                  BorderSide(color: AppColors.colorPostInput),
                              borderRadius:
                                  BorderRadius.all(Radius.circular(15.0))),
                          suffixIcon: IconButton(
                            onPressed: () {
                              controller.isNewPasswordHidden.value =
                                  !controller.isNewPasswordHidden.value;
                            },
                            icon: Icon(
                              controller.isNewPasswordHidden.value
                                  ? Icons.visibility
                                  : Icons.visibility_off,
                            ),
                            color: Colors.grey,
                          ),
                          hintText: Strings.newPassword,
                          hintStyle: const TextStyle(
                              fontFamily: 'Museo Sans',
                              color: AppColors.colorVaarient)),
                      onSaved: (value) {
                        controller.newPswd = value!;
                      },
                      validator: (value) {
                        return controller.validatePassword(value!);
                      },
                    ),
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  Obx(
                    () => TextFormField(
                      controller: controller.confirmNewPasswordController,
                      obscureText: controller.isConfirmNewPasswordHidden.value,
                      textInputAction: TextInputAction.done,
                      style: const TextStyle(
                          color: Colors.black, fontFamily: 'Museo Sans'),
                      keyboardType: TextInputType.emailAddress,
                      cursorColor: Colors.white,
                      decoration: InputDecoration(
                          contentPadding: const EdgeInsets.only(left: 10),
                          filled: true,
                          fillColor: AppColors.colorPostInput,
                          enabledBorder: const OutlineInputBorder(
                              borderSide:
                                  BorderSide(color: AppColors.colorPostInput),
                              borderRadius:
                                  BorderRadius.all(Radius.circular(15.0))),
                          errorBorder: const OutlineInputBorder(
                              borderSide:
                                  BorderSide(color: AppColors.buttonColor),
                              borderRadius:
                                  BorderRadius.all(Radius.circular(15.0))),
                          focusedBorder: const OutlineInputBorder(
                              borderSide:
                                  BorderSide(color: AppColors.colorPostInput),
                              borderRadius:
                                  BorderRadius.all(Radius.circular(15.0))),
                          suffixIcon: IconButton(
                            onPressed: () {
                              controller.isConfirmNewPasswordHidden.value =
                                  !controller.isConfirmNewPasswordHidden.value;
                            },
                            icon: Icon(
                              controller.isConfirmNewPasswordHidden.value
                                  ? Icons.visibility
                                  : Icons.visibility_off,
                            ),
                            color: Colors.grey,
                          ),
                          hintText: Strings.confirmNewPassword,
                          hintStyle: const TextStyle(
                              fontFamily: 'Museo Sans',
                              color: AppColors.colorVaarient)),
                      onSaved: (value) {
                        controller.confirmNewPswd = value!;
                      },
                      validator: (value) {
                        return controller.matchPassword(value!);
                      },
                    ),
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  CustomButton(
                    title: Strings.done,
                    onTap: () {
                      if(controller.checkLogin()) {

                      }else {
                        Get.snackbar('', 'Password Changed');
                      }
                    },
                  ),
                ],
              ),
            )),
      ),
    );
  }
}
