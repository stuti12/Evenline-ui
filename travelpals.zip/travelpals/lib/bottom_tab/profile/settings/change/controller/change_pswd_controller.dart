import 'package:flutter/material.dart';
import 'package:get/get.dart';

class ChangePasswordController extends GetxController {
  final GlobalKey<FormState> loginKey = GlobalKey<FormState>();

  TextEditingController confirmNewPasswordController = TextEditingController();
  TextEditingController newPasswordController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  var newPswd = '';
  var confirmNewPswd = '';
  var pswd = '';
  var isPasswordHidden = true.obs;
  var isNewPasswordHidden = true.obs;
  var isConfirmNewPasswordHidden = true.obs;

  @override
  void onInit() {
    super.onInit();
    print("controller init");
  }

  @override
  void onClose() {
    super.onClose();
    confirmNewPasswordController.dispose();
    newPasswordController.dispose();
    passwordController.dispose();
  }

  String? validatePassword(String value) {
    if (value.length <= 6) {
      return "Please enter valid Password";
    }
    return null;
  }

  String? matchPassword(String value) {
    if (value.length <= 6) {
      return "Please enter valid Password";
    }
    if (value != newPasswordController.text) {
      return "Password not match";
    }
    return null;
  }

  bool checkLogin() {
    final isValid = loginKey.currentState!.validate();
    if (!isValid) {
      return false;
    }
    Get.snackbar("title", "login success");

    loginKey.currentState?.save();
    return true;
  }
}
