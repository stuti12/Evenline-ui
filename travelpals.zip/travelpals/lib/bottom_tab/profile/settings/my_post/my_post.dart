import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../../utils/colors.dart';
import '../../../../utils/strings.dart';
import '../../../trip/favourite_trips.dart';

class MyPosts extends StatefulWidget {
  const MyPosts({Key? key}) : super(key: key);

  @override
  State<MyPosts> createState() => _MyPostsState();
}

class _MyPostsState extends State<MyPosts> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        title: const Text(
          Strings.myPosts,
          style: TextStyle(
              fontFamily: 'Museo Sans',
              color: AppColors.colorText,
              fontSize: 22),
        ),
        centerTitle: false,
        titleSpacing: 0,
        backgroundColor: Colors.white,
        leading: IconButton(
          icon: const Icon(
            Icons.arrow_back,
            color: AppColors.arrowColor,
          ),
          onPressed: () {
            Get.back();
          },
        ),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: const [
            ListBox(
              name: 'Adam Jane',
              description: Strings.description,
              duration: Strings.date,
              image: 'picture.png',
            ),
            ListBox(
              name: 'Adam Jane',
              description: Strings.description,
              duration: Strings.date,
              image: 'picture.png',
            )
          ],
        ),
      ),
    );
  }
}

class ListBox extends StatefulWidget {
  const ListBox(
      {Key? key, this.name, this.description, this.image, this.duration})
      : super(key: key);
  final String? name;
  final String? description;
  final String? image;
  final String? duration;

  @override
  State<StatefulWidget> createState() => _ListBoxState();
}

class _ListBoxState extends State<ListBox> {
  int like = 0;
  bool onTap = false;
  bool onTapLike = false;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(2),
      width: double.infinity,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Carousel(),
          (widget.image != null)
              ? Container(
                  color: AppColors.whiteColor,
                  child: Row(
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(left: 8.0),
                        child: Image.asset(
                          "assets/${widget.image}",
                          width: 50,
                          height: 50,
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(left: 8.0),
                        child: Text(
                          widget.name ?? "not found",
                          style: const TextStyle(
                              fontFamily: 'Museo Sans',
                              fontSize: 20,
                              color: AppColors.colorText),
                          textAlign: TextAlign.start,
                        ),
                      ),
                    ],
                  ),
                )
              :
              //no image
              Container(),
          const SizedBox(
            height: 10,
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 15.0),
            child: Text(
              widget.description ?? "not found",
              style: const TextStyle(
                  fontFamily: 'Museo Sans', fontSize: 16, color: Colors.grey),
              textAlign: TextAlign.start,
            ),
          ),
          const SizedBox(
            height: 10,
          ),
          const SizedBox(
            height: 10,
          ),
          Row(
            children: [
              Row(
                children: [
                  IconButton(
                    icon: Icon(
                      onTap ? Icons.thumb_up_outlined : Icons.thumb_up,
                      color: AppColors.colorText,
                    ),
                    onPressed: () {
                      setState(() {
                        onTap = !onTap;
                        like++;
                      });
                    },
                  ),
                  Text(
                    like.toString(),
                    style: const TextStyle(
                        fontFamily: 'Museo Sans',
                        fontSize: 16,
                        color: Colors.grey),
                    textAlign: TextAlign.start,
                  ),
                ],
              ),
              Row(
                children: [
                  IconButton(
                    icon: const Icon(
                      Icons.messenger_outline,
                      color: AppColors.colorText,
                    ),
                    onPressed: () {},
                  ),
                  const Text(
                    '1',
                    style: TextStyle(
                        fontFamily: 'Museo Sans',
                        fontSize: 16,
                        color: Colors.grey),
                    textAlign: TextAlign.start,
                  ),
                ],
              ),
            ],
          )
        ],
      ),
    );
  }
}
