import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:travelpals/authentication/login/login.dart';
import 'package:travelpals/bottom_tab/profile/settings/advertisement/advertisement.dart';
import 'package:travelpals/bottom_tab/profile/settings/change/change_password.dart';
import 'package:travelpals/bottom_tab/profile/settings/membership/membership.dart';
import 'package:travelpals/bottom_tab/profile/settings/my_account/my_account.dart';
import 'package:travelpals/bottom_tab/profile/settings/my_post/my_post.dart';
import 'package:travelpals/bottom_tab/profile/settings/my_trips/my_trips.dart';
import 'package:travelpals/bottom_tab/profile/settings/terms/terms_conditions.dart';

import '../../../utils/colors.dart';
import '../../../utils/shared_pref.dart';
import '../../../utils/strings.dart';

class Settings extends StatefulWidget {
  const Settings({Key? key}) : super(key: key);

  @override
  State<Settings> createState() => _SettingsState();
}

class _SettingsState extends State<Settings> {
  List<String> data = [
    Strings.myAccount,
    Strings.myPosts,
    Strings.myTrips,
    Strings.advertisement,
    Strings.termsConditions,
    Strings.membership,
    Strings.changePassword,
    Strings.privacyPolicy,
    Strings.help,
    Strings.logOut
  ];
  final PrefService _prefService = PrefService();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        title: const Text(
          Strings.settings,
          style: TextStyle(
              fontFamily: 'Museo Sans',
              color: AppColors.colorText,
              fontSize: 22),
        ),
        centerTitle: false,
        titleSpacing: 0,
        backgroundColor: Colors.white,
        leading: IconButton(
          icon: const Icon(
            Icons.arrow_back,
            color: AppColors.arrowColor,
          ),
          onPressed: () {
            Get.back();
          },
        ),
      ),
      body: ListView.builder(
        itemCount: data.length,
        itemBuilder: (BuildContext context, int index) {
          return ListTile(
            title: Text(
              data[index],
              style: const TextStyle(
                  fontWeight: FontWeight.w500,
                  fontFamily: 'Museo Sans',
                  color: AppColors.colorText,
                  fontSize: 17),
            ),
            onTap: () {
              if (index == 0) {
                Get.to(const MyAccount());
              }
              if (index == 1) {
                Get.to(const MyPosts());
              }
              if (index == 2) {
                Get.to(const MyTrips());
              }
              if (index == 3) {
                Get.to(const Advertisement());
              }
              if (index == 4) {
                Get.to(const TermsConditions());
              }
              if (index == 5) {
                Get.to(const Membership());
              }
              if (index == 6) {
                Get.to(const ChangePassword());
              }
              if (index == 7) {
                Get.to(const TermsConditions());
              }
              if (index == 9)  {
                //  showDeactivateAccountBottomSheets();
                //logout
                 _prefService.removeCache("email").whenComplete(() {
                  Get.off(const LoginScreen());
                });
              }
            },
            trailing: IconButton(
              onPressed: () {},
              icon: Icon(Icons.keyboard_arrow_right),
            ),
          );
        },
      ),
    );
  }
}
