import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../../custom/custom_button.dart';
import '../../../../utils/colors.dart';
import '../../../../utils/strings.dart';

class MyTrips extends StatefulWidget {
  const MyTrips({Key? key}) : super(key: key);

  @override
  State<MyTrips> createState() => _MyTripsState();
}

class _MyTripsState extends State<MyTrips> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        title: const Text(
          Strings.myTrips,
          style: TextStyle(
              fontFamily: 'Museo Sans',
              color: AppColors.colorText,
              fontSize: 22),
        ),
        centerTitle: false,
        titleSpacing: 0,
        backgroundColor: Colors.white,
        leading: IconButton(
          icon: const Icon(
            Icons.arrow_back,
            color: AppColors.arrowColor,
          ),
          onPressed: () {
            Get.back();
          },
        ),
      ),
      body: const FirstScreen(),
    );
  }
}

class FirstScreen extends StatefulWidget {
  const FirstScreen({Key? key}) : super(key: key);

  @override
  State<FirstScreen> createState() => _FirstScreenState();
}

class _FirstScreenState extends State<FirstScreen> {
  @override
  Widget build(BuildContext context) {
    return ListView(children: [
      Column(
        children: const [
          Carousel(),
          ListBox(
            name: 'Adam Jane',
            description: Strings.description,
            duration: Strings.date,
            image: 'picture.png',
          ),
          ListBox(
            name: 'Adam Jane',
            description: Strings.description,
            duration: Strings.date,
            image: 'picture.png',
          )
        ],
      ),
    ]);
  }
}

class Carousel extends StatefulWidget {
  const Carousel({
    Key? key,
  }) : super(key: key);

  @override
  State<Carousel> createState() => _CarouselState();
}

class _CarouselState extends State<Carousel> {
  late PageController _pageController;

  List<String> images = [
    "https://images.wallpapersden.com/image/download/purple-sunrise-4k-vaporwave_bGplZmiUmZqaraWkpJRmbmdlrWZlbWU.jpg",
    "https://wallpaperaccess.com/full/2637581.jpg",
    "https://uhdwallpapers.org/uploads/converted/20/01/14/the-mandalorian-5k-1920x1080_477555-mm-90.jpg"
  ];

  int activePage = 1;

  @override
  void initState() {
    super.initState();

    _pageController = PageController(initialPage: 1);
  }

  bool onTap = false;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        SizedBox(
          height: 300,
          child: Stack(children: [
            PageView.builder(
                itemCount: images.length,
                pageSnapping: true,
                controller: _pageController,
                onPageChanged: (page) {
                  setState(() {
                    activePage = page;
                  });
                },
                itemBuilder: (context, pagePosition) {
                  bool active = pagePosition == activePage;
                  return slider(images, pagePosition, active);
                }),
            Positioned(
                bottom: 0,
                top: 170,
                left: 0,
                right: 0,
                child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: indicators(images.length, activePage))),
            Positioned(
                top: 40,
                right: 10,
                child: CircleAvatar(
                  backgroundColor: AppColors.cancelColor,
                  child: IconButton(
                      onPressed: () {
                        setState(() {
                          onTap = !onTap;
                        });
                      },
                      icon: Icon(
                        onTap ? Icons.favorite : Icons.favorite_border,
                        color: AppColors.colorBorder,
                      )),
                )),
            Positioned(
                top: 40,
                right: 60,
                child: CircleAvatar(
                  backgroundColor: AppColors.cancelColor,
                  child: IconButton(
                      onPressed: () {},
                      icon: Icon(
                        Icons.lock_open_outlined,
                        color: AppColors.colorBorder,
                      )),
                )),
          ]),
        ),
      ],
    );
  }
}

AnimatedContainer slider(images, pagePosition, active) {
  double margin = active ? 1 : 1;

  return AnimatedContainer(
    duration: const Duration(milliseconds: 50),
    curve: Curves.easeInOutCubic,
    margin: EdgeInsets.all(margin),
    decoration: BoxDecoration(
        image: DecorationImage(
            image: NetworkImage(
              images[pagePosition],
            ),
            fit: BoxFit.fitWidth)),
  );
}

imageAnimation(PageController animation, images, pagePosition) {
  return AnimatedBuilder(
    animation: animation,
    builder: (context, widget) {
      debugPrint(pagePosition);

      return const SizedBox();
    },
    child: Image.network(images[pagePosition], fit: BoxFit.fitWidth),
  );
}

List<Widget> indicators(imagesLength, currentIndex) {
  return List<Widget>.generate(imagesLength, (index) {
    return Container(
      margin: const EdgeInsets.all(3),
      width: 10,
      height: 10,
      decoration: BoxDecoration(
          color: currentIndex == index ? Colors.white : Colors.white54,
          shape: BoxShape.circle),
    );
  });
}

class ListBox extends StatefulWidget {
  const ListBox(
      {Key? key, this.name, this.description, this.image, this.duration})
      : super(key: key);
  final String? name;
  final String? description;
  final String? image;
  final String? duration;

  @override
  State<StatefulWidget> createState() => _ListBoxState();
}

class _ListBoxState extends State<ListBox> {
  int like = 0;
  bool onTap = false;
  bool onTapLike = false;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(2),
      width: double.infinity,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          (widget.image != null)
              ? Container(
                  color: AppColors.whiteColor,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        children: [
                          Padding(
                            padding: const EdgeInsets.only(left: 8.0),
                            child: Image.asset(
                              "assets/${widget.image}",
                              width: 50,
                              height: 50,
                            ),
                          ),
                          //name
                          Padding(
                            padding: const EdgeInsets.only(left: 8.0),
                            child: Text(
                              widget.name ?? "not found",
                              style: const TextStyle(
                                  fontFamily: 'Museo Sans',
                                  fontSize: 20,
                                  color: AppColors.colorText),
                              textAlign: TextAlign.start,
                            ),
                          ),
                        ],
                      ),
                      Align(
                        alignment: Alignment.topRight,
                        child: Row(
                          children: [
                            Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: CircleAvatar(
                                backgroundColor: AppColors.cancelColor,
                                child: IconButton(
                                  icon: const Icon(
                                    Icons.lock_open_outlined,
                                    color: AppColors.colorBorder,
                                  ),
                                  onPressed: () {
                                    setState(() {});
                                  },
                                ),
                              ),
                            ),
                            CircleAvatar(
                              backgroundColor: AppColors.cancelColor,
                              child: IconButton(
                                icon: Icon(
                                  onTapLike
                                      ? Icons.favorite_rounded
                                      : Icons.favorite,
                                  color: AppColors.colorBorder,
                                ),
                                onPressed: () {
                                  setState(() {
                                    onTapLike = !onTapLike;
                                  });
                                },
                              ),
                            ),
                          ],
                        ),
                      )
                    ],
                  ),
                )
              :
              //no image
              Container(),
          const SizedBox(
            height: 10,
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 15.0),
            child: Text(
              widget.description ?? "not found",
              style: const TextStyle(
                  fontFamily: 'Museo Sans', fontSize: 16, color: Colors.grey),
              textAlign: TextAlign.start,
            ),
          ),
          const SizedBox(
            height: 10,
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8.0),
            child: Row(
              children: [
                const Icon(Icons.calendar_today),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 8.0),
                  child: Text(
                    widget.duration ?? "not found",
                    style: const TextStyle(
                        fontFamily: 'Museo Sans',
                        fontSize: 16,
                        color: AppColors.colorText),
                    textAlign: TextAlign.start,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(
            height: 10,
          ),
          Row(
            children: [
              Expanded(
                child: Row(
                  children: [
                    IconButton(
                      icon: Icon(
                        onTap ? Icons.thumb_up_outlined : Icons.thumb_up,
                        color: AppColors.colorText,
                      ),
                      onPressed: () {
                        setState(() {
                          onTap = !onTap;
                          like++;
                        });
                      },
                    ),
                    Text(
                      like.toString(),
                      style: const TextStyle(
                          fontFamily: 'Museo Sans',
                          fontSize: 16,
                          color: Colors.grey),
                      textAlign: TextAlign.start,
                    ),
                  ],
                ),
              ),
              Row(
                children: [
                  IconButton(
                    icon: const Icon(
                      Icons.group,
                      color: AppColors.colorText,
                    ),
                    onPressed: () {},
                  ),
                  Text(
                    like.toString(),
                    style: const TextStyle(
                        fontFamily: 'Museo Sans',
                        fontSize: 16,
                        color: Colors.grey),
                    textAlign: TextAlign.start,
                  ),
                  Padding(
                      padding: const EdgeInsets.only(left: 8, right: 8),
                      child: CustomButton(
                        width: 120,
                        height: 42,
                        title: Strings.addFriend,
                        onTap: () {},
                        bgColor: AppColors.buttonColor,
                      )),
                ],
              ),
            ],
          )
        ],
      ),
    );
  }
}
