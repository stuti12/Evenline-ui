import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:travelpals/custom/custom_button.dart';

import '../../utils/colors.dart';
import '../../utils/strings.dart';

class Notifications extends StatefulWidget {
  const Notifications({Key? key}) : super(key: key);

  @override
  State<Notifications> createState() => _NotificationsState();
}

class _NotificationsState extends State<Notifications> {
  var data = [
    {
      "name": Strings.adamJaneWantsToJoin,
      "image": "picture.png",
      "duration": Strings.tenMinutes
    },
    {
      "name": Strings.adamJaneWantsToJoin,
      "image": "picture.png",
      "duration": Strings.yesterday
    },
    {"name": Strings.commentText, "image": "picture.png"},
    {
      "name": Strings.commentText,
      "image": "picture.png",
      "duration": Strings.tenMinutes
    },
    {"name": Strings.commentText, "image": "picture.png"},
    {
      "name": Strings.commentText,
      "image": "picture.png",
      "duration": Strings.tenMinutes
    }
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        titleSpacing: 0,
        backgroundColor: AppColors.whiteColor,
        title: const Text(
          Strings.notifications,
          style: TextStyle(
              fontFamily: 'Museo Sans',
              color: AppColors.colorText,
              fontSize: 22),
        ),
        leading: IconButton(
          icon: const Icon(
            Icons.arrow_back,
            color: AppColors.arrowColor,
          ),
          onPressed: () {
            Get.back();
          },
        ),
      ),
      body: ListView.separated(
        itemCount: data.length,
        itemBuilder: (BuildContext context, int index) {
          return Padding(
            padding: const EdgeInsets.all(8.0),
            child: ListTile(
              leading: Expanded(
                  child:
                      Image.asset('assets/${data[index]["image"]}', width: 50)),
              title: Padding(
                padding: const EdgeInsets.symmetric(vertical: 8.0),
                child: Text(
                  data[index]["name"] ?? "no Data",
                  style: const TextStyle(
                      fontWeight: FontWeight.w500,
                      fontFamily: 'Museo Sans',
                      color: AppColors.colorText,
                      fontSize: 17),
                ),
              ),
              onTap: () {},
              subtitle: (index == 2 || index == 0)
                  ? Row(
                      children: [
                        const SizedBox(
                          height: 10,
                        ),
                        Expanded(
                            child: CustomButton(
                                title: Strings.accept, onTap: () {})),
                        const SizedBox(
                          width: 10,
                        ),
                        Expanded(
                            child: CustomButton(
                          title: Strings.delete,
                          onTap: () {},
                          bgColor: AppColors.whiteColor,
                          textColor: AppColors.buttonColor,
                        )),
                      ],
                    )
                  : Container(),
              trailing: const Padding(
                padding: EdgeInsets.only(top: 25.0),
                child: Text(
                  Strings.tenMinutes,
                  style: TextStyle(
                      fontFamily: 'Museo Sans',
                      color: AppColors.colorBottomNavText),
                ),
              ),
            ),
          );
        },
        separatorBuilder: (BuildContext context, int index) {
          return const Padding(
            padding: EdgeInsets.all(8.0),
            child: Divider(
              thickness: 1.5,
              color: AppColors.colorBorder,
            ),
          );
        },
      ),
    );
  }
}
