import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:travelpals/custom/custom_button.dart';
import 'package:travelpals/other_user_prifile/other_user_profile.dart';

import '../../utils/colors.dart';
import '../../utils/strings.dart';

class MatchScreen extends StatefulWidget {
  const MatchScreen({Key? key}) : super(key: key);

  @override
  State<MatchScreen> createState() => _MatchScreenState();
}

class _MatchScreenState extends State<MatchScreen> {
  bool isMatch = true;

  @override
  Widget build(BuildContext context) {
    return ScreenUtilInit(
        builder: (_, child) {
          return Scaffold(
            backgroundColor: AppColors.bottomSheet,
            appBar: AppBar(
              elevation: 0,
              leadingWidth: 130,
              centerTitle: false,
              titleSpacing: 0,
              backgroundColor: Colors.white,
              leading: const Padding(
                padding: EdgeInsets.only(top: 18.0, left: 10),
                child: Text(
                  Strings.travelPals,
                  style: TextStyle(
                      fontFamily: 'Museo Sans',
                      fontWeight: FontWeight.bold,
                      color: AppColors.buttonColor,
                      fontSize: 20),
                ),
              ),
              actions: [
                IconButton(
                  icon: const Icon(
                    Icons.favorite_border,
                    color: AppColors.colorText,
                  ),
                  onPressed: () {},
                ),
                IconButton(
                  icon: const Icon(
                    Icons.notifications_none,
                    color: AppColors.colorText,
                  ),
                  onPressed: () {},
                )
              ],
            ),
            body: Center(
              child: !isMatch

              //no match data
                  ? Container(
                color: AppColors.bottomSheet,
                child: Column(
                  children: [
                    Image.asset('assets/Frame.png'),
                    const SizedBox(
                      height: 20,
                    ),
                    const Text(
                      Strings.matchNot,
                      style: TextStyle(
                          fontFamily: 'Museo Sans',
                          fontWeight: FontWeight.bold,
                          fontSize: 24,
                          color: AppColors.colorText),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(
                      height: 10,
                    ),
                    const Text(
                      Strings.matchNotDesc,
                      style: TextStyle(
                          fontFamily: 'Museo Sans',
                          fontSize: 16,
                          color: AppColors.colorBottomNavText),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(
                      height: 10,
                    ),
                    CustomButton(
                      title: Strings.updateYourProfile,
                      onTap: () {},
                      width: 200,
                      height: 40,
                    )
                  ],
                ),
              )

              //view with data
                  : GestureDetector(
                onTap: () {
                  Get.to(const OtherUserProfile());
                },
                child: Container(
                  color: AppColors.bottomSheet,
                  child: SingleChildScrollView(
                    child: Column(
                      children: [
                        const SizedBox(
                          height: 20,
                        ),
                        Card(
                            color: AppColors.whiteColor,
                            shape: const RoundedRectangleBorder(
                                borderRadius:
                                BorderRadius.all(Radius.circular(10))),
                            child: Stack(children: [
                              Image.asset('assets/profilematch.png'),
                              Positioned(
                                  left: 20,
                                  bottom: 100,
                                  child: Text(
                                    'Namita Singh',
                                    style: TextStyle(
                                        fontSize: 22,
                                        fontWeight: FontWeight.bold,
                                        fontFamily: 'Museo Sans',
                                        color: AppColors.whiteColor),
                                  )),
                              Positioned(
                                  right: 20,
                                  left: 20,
                                  bottom: 60,
                                  child: Row(
                                    children: [
                                      Icon(
                                        Icons.person_outline_rounded,
                                        color: AppColors.whiteColor,
                                      ),
                                      Expanded(
                                          child: Text(
                                            Strings.matchNotDesc,
                                            style: TextStyle(
                                                fontSize: 16,
                                                fontFamily: 'Museo Sans',
                                                color: AppColors.whiteColor),
                                          )),
                                    ],
                                  )),
                              const SizedBox(
                                height: 5,
                              ),
                              Positioned(
                                  right: 20,
                                  left: 40,
                                  bottom: 30,
                                  child: Text(
                                    'Boston, MI, USA',
                                    style: TextStyle(
                                        fontSize: 16,
                                        fontFamily: 'Museo Sans',
                                        color: AppColors.whiteColor),
                                  )),
                            ])),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Padding(
                              padding:
                              const EdgeInsets.symmetric(horizontal: 8.0),
                              child: Container(
                                decoration: BoxDecoration(
                                    borderRadius: const BorderRadius.all(
                                        Radius.circular(16)),
                                    color: AppColors.whiteColor),
                                child: GestureDetector(
                                    onTap: () {
                                      setState(() {
                                        //set output date to TextField value.
                                      });
                                    },
                                    child: const Icon(
                                      Icons.cancel_rounded,
                                      color: AppColors.colorBorderRed,
                                      size: 36,
                                    )),
                              ),
                            ),
                            Container(
                              decoration: const BoxDecoration(
                                  borderRadius:
                                  BorderRadius.all(Radius.circular(16)),
                                  color: AppColors.buttonColor),
                              child: GestureDetector(
                                  onTap: () {
                                    setState(() {
                                      //set output date to TextField value.
                                    });
                                  },
                                  child: Icon(
                                    Icons.check,
                                    color: AppColors.whiteColor,
                                    size: 30,
                                  )),
                            ),
                          ],
                        ),
                        const SizedBox(
                          height: 10,
                        ),
                        const Text(
                          Strings.note,
                          style: TextStyle(
                              fontFamily: 'Museo Sans',
                              fontSize: 14,
                              color: AppColors.colorBottomNavText),
                          textAlign: TextAlign.center,
                        ),
                        const SizedBox(
                          height: 30,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          );
        });
  }

}
