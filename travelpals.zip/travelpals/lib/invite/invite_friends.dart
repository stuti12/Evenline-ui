import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:travelpals/utils/colors.dart';
import 'package:travelpals/utils/strings.dart';

import '../custom/custom_button.dart';

class InviteFriends extends StatefulWidget {
  const InviteFriends({Key? key}) : super(key: key);

  @override
  State<InviteFriends> createState() => _InviteFriendsState();
}

class _InviteFriendsState extends State<InviteFriends> {
  bool onTap = false;

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        backgroundColor: AppColors.bottomSheet,
        appBar: AppBar(
          titleSpacing: 0,
          backgroundColor: AppColors.whiteColor,
          title: const Text(
            Strings.inviteFriends,
            style: TextStyle(
                fontFamily: 'Museo Sans',
                color: AppColors.colorText,
                fontSize: 22),
          ),
          leading: IconButton(
            icon: const Icon(
              Icons.arrow_back,
              color: AppColors.arrowColor,
            ),
            onPressed: () {
              Get.back();
            },
          ),
          bottom: const TabBar(
            labelColor: AppColors.buttonColor,
            unselectedLabelColor: AppColors.colorTabUnselected,
            tabs: [
              Tab(text: Strings.travelFriends),
              Tab(
                text: Strings.myContacts,
              )
            ],
            indicatorColor: AppColors.buttonColor,
          ),
        ),
        body: const TabBarView(
          children: [
            FirstScreen(),
            SecondScreen(),
          ],
        ),
      ),
    );
  }
}

class FirstScreen extends StatefulWidget {
  const FirstScreen({Key? key}) : super(key: key);

  @override
  State<FirstScreen> createState() => _FirstScreenState();
}

class _FirstScreenState extends State<FirstScreen> {
  List<String> names = [
    'Krish J.',
    'Kritika Shah',
    'Bibek Jahn',
    'Mellissa John',
    'Jobon Gosh',
    'Krish J.',
    'Kritika Shah',
    'Bibek Jahn',
    'Mellissa John',
    'Jobon Gosh'
  ];

  List<String> images = [
    'picture.png',
    'picture.png',
    'picture.png',
    'picture.png',
    'picture.png',
    'picture.png',
    'picture.png',
    'picture.png',
    'picture.png',
    'picture.png'
  ];

  bool isTap = true;

  List<int> id = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
  List<String> name = [
    'Krish J.',
    'Kritika Shah',
    'Bibek Jahn',
    'Mellissa John',
    'Jobon Gosh',
    'Krish J.',
    'Kritika Shah',
    'Bibek Jahn',
    'Mellissa John',
    'Jobon Gosh'
  ];
  List<bool> flag = [
    true,
    true,
    true,
    true,
    true,
    true,
    true,
    true,
    false,
    false
  ];

  // var data = [{"id":1,"name":'Krish J.',"flag":true,"image":"picture.png"},{"id":2,"name":'Kritika Shah.',"flag":true,"image":"picture.png"},{"id":3,"name":'Bibek Jahn.',"flag":true,"image":"picture.png"},{"id":4,"name":'Mellissa John',"flag":true,"image":"picture.png"},{"id":5,"name":'John John',"flag":true},{"id":6,"name":'Krish J',"flag":true,"image":"picture.png"},{"id":7,"name":'Mellissa John',"flag":true,"image":"picture.png"}];

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      itemCount: name.length,
      itemBuilder: (BuildContext context, int index) {
        return Padding(
          padding: const EdgeInsets.all(8.0),
          child: ListTile(
            leading: Image.asset('assets/${images[index]}', width: 50),
            trailing: CustomButton(
              title: flag[index] ? Strings.invite : Strings.remove,
              onTap: () {
                setState(() {
                  flag[index] = !flag[index];
                });
              },
              width: 100,
              height: 45,
              borderColor:
                  (flag[index]) ? AppColors.buttonColor : AppColors.cancelColor,
              bgColor:
                  (flag[index]) ? AppColors.buttonColor : AppColors.cancelColor,
              textColor:
                  flag[index] ? AppColors.whiteColor : AppColors.colorText,
            ),
            title: Text(
              name[index],
              style: TextStyle(
                  fontWeight: FontWeight.w400,
                  fontFamily: 'Museo Sans',
                  color: AppColors.blackC,
                  fontSize: 16),
            ),
            onTap: () {},
          ),
        );
      },
    );
  }
}

class SecondScreen extends StatefulWidget {
  const SecondScreen({Key? key}) : super(key: key);

  @override
  State<SecondScreen> createState() => _SecondScreenState();
}

class _SecondScreenState extends State<SecondScreen> {
  @override
  Widget build(BuildContext context) {
    return Center(
        child: Container(
      color: AppColors.bottomSheet,
      child: const Text(Strings.defaultPhoneBook,
          style: TextStyle(
              fontFamily: 'Museo Sans', color: AppColors.colorBottomNavText),
          textAlign: TextAlign.center),
    ));
  }
}
