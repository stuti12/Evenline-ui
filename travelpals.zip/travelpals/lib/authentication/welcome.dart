import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:travelpals/authentication/login/login.dart';
import 'package:travelpals/bottom_tabbar_page.dart';
import 'package:travelpals/utils/colors.dart';

import '../utils/shared_pref.dart';
import '../utils/strings.dart';

class WelcomeScreen extends StatefulWidget {
  const WelcomeScreen({Key? key}) : super(key: key);

  @override
  State<WelcomeScreen> createState() => _WelcomeScreenState();
}

class _WelcomeScreenState extends State<WelcomeScreen> {
  final PrefService _prefService = PrefService();

  @override
  void initState() {
    super.initState();
    _prefService.readCache("email").then((value) {
      if (value == null) {
        return Timer(const Duration(seconds: 2), () => Get.off(const LoginScreen()));
      } else {
        return Timer(
            const Duration(seconds: 2), () => Get.off(const TabbarPage()));
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(debugShowCheckedModeBanner: false,
      home: ScreenUtilInit(
          builder: (_, child) {
         return   Scaffold(
              body: SingleChildScrollView(
                child: Column(
                  children: [
                    Image.asset('assets/welcome.png'),
                     Padding(
                      padding: EdgeInsets.all(8.h),
                      child: Text(
                        Strings.welcomeTitle,
                        style: TextStyle(
                            fontFamily: 'Museo Sans',
                            fontWeight: FontWeight.bold,
                            fontSize: ScreenUtil().setSp(26),
                            color: AppColors.colorText),
                        textAlign: TextAlign.center,
                      ),
                    ),
                     Padding(
                      padding: EdgeInsets.only(left: 20.h, right: 20.h),
                      child: Text(
                        Strings.welcomeSubtitle,
                        style: TextStyle(
                            fontFamily: 'Museo Sans',
                            fontSize: ScreenUtil().setSp(16),
                            color: AppColors.colorGrey),
                        textAlign: TextAlign.center,
                      ),
                    ),
                     SizedBox(height: 20.h),
                    /* CustomButton(title: Strings.next.toUpperCase(), onTap: (){
                  Get.off(() => LoginScreen());

                },bgColor: AppColors.buttonColor,width: 110,height: 40,),
                */
                    Directionality(
                      textDirection: TextDirection.rtl,
                      child: SizedBox(
                        height: 40.r,
                        child: ElevatedButton.icon(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: AppColors.buttonColor,
                            shape: RoundedRectangleBorder(
                                borderRadius:
                                BorderRadius.circular(24.0)), // Background color
                          ),
                          onPressed: () {
                            _prefService.readCache("email").then((value) {
                              if (value == null) {
                                return Timer(const Duration(seconds: 2),
                                        () => Get.off(LoginScreen()));
                              } else {
                                return Timer(const Duration(seconds: 2),
                                        () => Get.off(const TabbarPage()));
                              }
                            });
                          },
                          icon: const Icon(Icons.arrow_right_alt),
                          label:  Text(
                            Strings.next,
                            style: TextStyle(
                              fontSize: ScreenUtil().setSp(16),
                              color: Colors.white,
                              fontFamily: 'Museo Sans',
                            ),
                          ),
                        ),
                      ),
                    ),
                     SizedBox(height: 20.h),
                  ],
                ),
              ),
            );
          }),
    );
  }
}
