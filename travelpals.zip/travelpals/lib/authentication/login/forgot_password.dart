import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:travelpals/authentication/controllers/forget_password_controller.dart';

import '../../custom/custom_button.dart';
import '../../utils/colors.dart';
import '../../utils/strings.dart';

class ForgotPasswordScreen extends StatefulWidget {
  const ForgotPasswordScreen({Key? key}) : super(key: key);

  @override
  State<ForgotPasswordScreen> createState() => _ForgotPasswordScreenState();
}

class _ForgotPasswordScreenState extends State<ForgotPasswordScreen> {
/*
  static final _formKey = GlobalKey<FormState>();
  static final TextEditingController _email = TextEditingController();
*/
  ForgetController controller = ForgetController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: AppColors.whiteColor,
        title: Expanded(
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: const [
              Text(
                Strings.forgotPswd,
                style: TextStyle(
                    fontFamily: 'Museo Sans',
                    color: AppColors.colorText,
                    fontSize: 22),
              ),
              Align(
                alignment: Alignment.topRight,
                child: Text(
                  Strings.cancel,
                  style: TextStyle(
                      fontFamily: 'Museo Sans',
                      color: AppColors.cancelColor,
                      fontSize: 22),
                ),
              ),
            ],
          ),
        ),
        leading: IconButton(
          icon: const Icon(
            Icons.arrow_back,
            color: AppColors.arrowColor,
          ),
          onPressed: () {
            Get.back();
          },
        ),
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Padding(
            padding: EdgeInsets.only(left: 30.0, top: 24),
            child: Text(
              Strings.forgetTitle,
              style: TextStyle(
                  fontFamily: 'Museo Sans',
                  fontSize: 18,
                  color: AppColors.colorText),
            ),
          ),
          Form(
              key: controller.forgetKey,
              autovalidateMode: AutovalidateMode.onUserInteraction,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Container(
                    width: double.infinity,
                    margin: const EdgeInsets.symmetric(
                        horizontal: 30.0, vertical: 12.0),
                    child: TextFormField(
                      controller: controller.emailController,
                      textInputAction: TextInputAction.next,
                      style: const TextStyle(
                          color: Colors.black, fontFamily: 'Museo Sans'),
                      keyboardType: TextInputType.emailAddress,
                      cursorColor: Colors.white,
                      decoration: InputDecoration(
                        filled: true,
                        fillColor: AppColors.inputColor,
                        enabledBorder: const OutlineInputBorder(
                            borderSide: BorderSide(color: AppColors.inputColor),
                            borderRadius:
                                BorderRadius.all(Radius.circular(35.0))),
                        labelStyle:
                            const TextStyle(color: AppColors.colorVaarient),
                        focusedBorder: OutlineInputBorder(
                            borderSide: BorderSide(color: AppColors.whiteColor),
                            borderRadius:
                                const BorderRadius.all(Radius.circular(35.0))),
                        labelText: Strings.email,
                        hintText: Strings.email,
                      ),
                      validator: (value) {
                        return controller.validateEmail(value!);
                      },
                    ),
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  CustomButton(
                      title: Strings.okay.toUpperCase(),
                      onTap: () {
                        setState(() {
                          // GetUtils.isLengthEqualTo(_email.text??"",0)?:debugPrint('dfd')
                        });
                      },
                      bgColor: AppColors.buttonColor,
                      margin: const EdgeInsets.symmetric(horizontal: 20)),
                ],
              ))
        ],
      ),
    );
  }
}
