import 'dart:convert';

import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:travelpals/authentication/controllers/sign_up_controller.dart';
import 'package:travelpals/authentication/login/verify_account.dart';
import 'package:travelpals/bottom_tab/profile/profile.dart';
import 'package:travelpals/create_profile/create_profile.dart';

import '../../component/decorated_radio_button.dart';
import '../../custom/custom_button.dart';
import '../../utils/colors.dart';
import '../../utils/strings.dart';
import 'login.dart';

class SignUpScreen extends StatefulWidget {
  const SignUpScreen({Key? key}) : super(key: key);

  @override
  State<SignUpScreen> createState() => _SignUpScreenState();
}

class _SignUpScreenState extends State<SignUpScreen> {
/*  static final _formKey = GlobalKey<FormState>();

  static final TextEditingController _email = TextEditingController();
  static final TextEditingController _fname = TextEditingController();
  static final TextEditingController _lname = TextEditingController();
  static final TextEditingController _phone = TextEditingController();
  static final TextEditingController _dob = TextEditingController();
  static final TextEditingController _password = TextEditingController();
  static final TextEditingController _cpassword = TextEditingController();*/
  SignUpController controller = SignUpController();

  var itemsList = [];
  var itemsListLanguage = [];
  var isSelectPhone = false;
  var isSelectEmail = false;

  int selectedGenderVar = 0;

  Future<void> readJson() async {
    final String response =
        await rootBundle.loadString("assets/country/country.json");
    final data = await json.decode(response);
    setState(() {
      for (var i in data as List) {
        /* print('json data is:-->${i}');*/
        itemsList.add(i['name'] as String);
      }
      debugPrint('CountryName:->$itemsList ');
    });
  }

  Future<void> readLangJson() async {
    final String response =
        await rootBundle.loadString("assets/language/language.json");
    final data = await json.decode(response);
    setState(() {
      for (var i in data as List) {
        /* print('json data is:-->${i}');*/
        itemsListLanguage.add(i['name'] as String);
      }
      debugPrint('CountryName:->$itemsListLanguage ');
    });
  }

  double start = 30.0;
  double end = 50.0;

  @override
  void initState() {
    super.initState();
    readJson();
    readLangJson();
  }

  @override
  Widget build(BuildContext context) {
    return ScreenUtilInit(builder: (_, child) {
      return Scaffold(
        resizeToAvoidBottomInset: false,
        appBar: AppBar(
          backgroundColor: AppColors.whiteColor,
          title: Text(
            Strings.createAccount,
            style: TextStyle(
                fontFamily: 'Museo Sans',
                color: AppColors.colorText,
                fontWeight: FontWeight.w700,
                fontSize: ScreenUtil().setSp(20)),
          ),
          leading: IconButton(
            icon: const Icon(
              Icons.arrow_back,
              color: AppColors.arrowColor,
            ),
            onPressed: () {
              Get.back();
            },
          ),
        ),
        body: Column(
          children: [
            Expanded(
              child: SingleChildScrollView(
                child: Container(
                  padding: EdgeInsets.only(left: 30.h, top: 20.h, right: 30.h),
                  width: double.infinity,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        Strings.enterPersonalinfo,
                        style: TextStyle(
                            fontFamily: 'Museo Sans',
                            fontSize: ScreenUtil().setSp(16),
                            color: AppColors.colorText),
                      ),
                      Form(
                          autovalidateMode: AutovalidateMode.onUserInteraction,
                          key: controller.signUpKey,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              const SizedBox(
                                height: 15,
                              ),
                              TextFormField(
                                controller: controller.fnameController,
                                textInputAction: TextInputAction.next,
                                style: const TextStyle(
                                    color: AppColors.colorText,
                                    fontFamily: 'Museo Sans'),
                                keyboardType: TextInputType.name,
                                cursorColor: Colors.white,
                                decoration: const InputDecoration(
                                  contentPadding: EdgeInsets.only(left: 10),
                                  filled: true,
                                  fillColor: AppColors.inputColor,
                                  enabledBorder: OutlineInputBorder(
                                      borderSide: BorderSide(
                                          color: AppColors.inputColor),
                                      borderRadius: BorderRadius.all(
                                          Radius.circular(26.0))),
                                  focusedBorder: OutlineInputBorder(
                                      borderSide: BorderSide(
                                          color: AppColors.inputColor),
                                      borderRadius: BorderRadius.all(
                                          Radius.circular(26.0))),
                                  errorBorder: OutlineInputBorder(
                                      borderSide: BorderSide(
                                          color: AppColors.buttonColor),
                                      borderRadius: BorderRadius.all(
                                          Radius.circular(26.0))),
                                  hintStyle: TextStyle(
                                      fontFamily: 'Museo Sans',
                                      color: AppColors.colorVaarient,
                                      fontSize: 16,
                                      fontWeight: FontWeight.w500),
                                  hintText: Strings.firstName,
                                ),
                                validator: (value) {
                                  return controller.validateFirstName(value!);
                                },
                                onSaved: (value) {
                                  controller.fname = value!;
                                },
                              ),
                              const SizedBox(
                                height: 10,
                              ),

                              //lname
                              TextFormField(
                                controller: controller.lnameController,
                                textInputAction: TextInputAction.next,
                                style: const TextStyle(
                                    color: AppColors.colorText,
                                    fontFamily: 'Museo Sans'),
                                keyboardType: TextInputType.name,
                                cursorColor: Colors.white,
                                decoration: const InputDecoration(
                                  contentPadding: EdgeInsets.only(left: 10),
                                  filled: true,
                                  fillColor: AppColors.inputColor,
                                  enabledBorder: OutlineInputBorder(
                                      borderSide: BorderSide(
                                          color: AppColors.inputColor),
                                      borderRadius: BorderRadius.all(
                                          Radius.circular(26.0))),
                                  focusedBorder: OutlineInputBorder(
                                      borderSide: BorderSide(
                                          color: AppColors.inputColor),
                                      borderRadius: BorderRadius.all(
                                          Radius.circular(26.0))),
                                  errorBorder: OutlineInputBorder(
                                      borderSide: BorderSide(
                                          color: AppColors.buttonColor),
                                      borderRadius: BorderRadius.all(
                                          Radius.circular(35.0))),
                                  hintStyle: TextStyle(
                                      fontFamily: 'Museo Sans',
                                      color: AppColors.colorVaarient,
                                      fontSize: 16,
                                      fontWeight: FontWeight.w500),
                                  hintText: Strings.lastName,
                                ),
                                validator: (value) {
                                  return controller.validateLastName(value!);
                                },
                                onSaved: (value) {
                                  controller.lname = value!;
                                },
                              ),
                              const SizedBox(
                                height: 10,
                              ),

                              //email
                              TextFormField(
                                controller: controller.emailController,
                                textInputAction: TextInputAction.next,
                                style: const TextStyle(
                                    color: AppColors.colorText,
                                    fontFamily: 'Museo Sans'),
                                keyboardType: TextInputType.emailAddress,
                                cursorColor: Colors.white,
                                decoration: InputDecoration(
                                  contentPadding: EdgeInsets.only(left: 10.h),
                                  filled: true,
                                  fillColor: AppColors.inputColor,
                                  enabledBorder: const OutlineInputBorder(
                                      borderSide: BorderSide(
                                          color: AppColors.inputColor),
                                      borderRadius: BorderRadius.all(
                                          Radius.circular(26.0))),
                                  focusedBorder: const OutlineInputBorder(
                                      borderSide: BorderSide(
                                          color: AppColors.inputColor),
                                      borderRadius: BorderRadius.all(
                                          Radius.circular(26.0))),
                                  errorBorder: const OutlineInputBorder(
                                      borderSide: BorderSide(
                                          color: AppColors.buttonColor),
                                      borderRadius: BorderRadius.all(
                                          Radius.circular(26.0))),
                                  hintStyle: const TextStyle(
                                      fontFamily: 'Museo Sans',
                                      color: AppColors.colorVaarient,
                                      fontSize: 16,
                                      fontWeight: FontWeight.w500),
                                  hintText: Strings.email,
                                ),
                                validator: (value) {

                                  return controller.validateEmail(value!);
                                },
                                onSaved: (value) {
                                  controller.email = value!;
                                },
                              ),
                              const SizedBox(
                                height: 10,
                              ),

                              //country
                              DropdownButtonFormField(
                                isExpanded: true,
                                decoration: InputDecoration(
                                  filled: true,
                                  contentPadding: EdgeInsets.only(left: 10.h),
                                  fillColor: AppColors.inputColor,
                                  enabledBorder: const OutlineInputBorder(
                                      borderSide: BorderSide(
                                          color: AppColors.inputColor),
                                      borderRadius: BorderRadius.all(
                                          Radius.circular(26.0))),
                                  focusedBorder: const OutlineInputBorder(
                                      borderSide: BorderSide(
                                          color: AppColors.inputColor),
                                      borderRadius: BorderRadius.all(
                                          Radius.circular(26.0))),
                                  errorBorder: const OutlineInputBorder(
                                      borderSide: BorderSide(
                                          color: AppColors.buttonColor),
                                      borderRadius: BorderRadius.all(
                                          Radius.circular(35.0))),
                                ),
                                icon: const Icon(
                                  Icons.keyboard_arrow_down,
                                  color: Colors.grey,
                                ),
                                value: itemsList[0],
                                items: itemsList
                                    .map((e) => DropdownMenuItem(
                                        value: e, child: Text(e)))
                                    .toList(),
                                onChanged: (Object? value) {
                                  setState(() {
                                    if (value == 'Afghanistan') {
                                      showBottom();
                                    }
                                  });
                                },
                              ),

                              //phone
                              TextFormField(
                                controller: controller.phoneController,
                                textInputAction: TextInputAction.next,
                                style: const TextStyle(
                                    color: AppColors.colorText,
                                    fontFamily: 'Museo Sans'),
                                keyboardType: TextInputType.phone,
                                cursorColor: Colors.white,
                                decoration: const InputDecoration(
                                  contentPadding: EdgeInsets.only(left: 10),
                                  filled: true,
                                  fillColor: AppColors.inputColor,
                                  enabledBorder: OutlineInputBorder(
                                      borderSide: BorderSide(
                                          color: AppColors.inputColor),
                                      borderRadius: BorderRadius.all(
                                          Radius.circular(26.0))),
                                  focusedBorder: OutlineInputBorder(
                                      borderSide: BorderSide(
                                          color: AppColors.inputColor),
                                      borderRadius: BorderRadius.all(
                                          Radius.circular(26.0))),
                                  errorBorder: OutlineInputBorder(
                                      borderSide: BorderSide(
                                          color: AppColors.buttonColor),
                                      borderRadius: BorderRadius.all(
                                          Radius.circular(35.0))),
                                  hintText: Strings.phoneNumber,
                                  hintStyle: TextStyle(
                                      fontFamily: 'Museo Sans',
                                      color: AppColors.colorVaarient,
                                      fontSize: 16,
                                      fontWeight: FontWeight.w500),
                                ),
                                onSaved: (value) {
                                  controller.phone = value!;
                                },
                                validator: (value) {
                                 return controller.validatePhone(value!);
                                },
                              ),
                              const SizedBox(
                                height: 10,
                              ),

                              //dob
                              TextFormField(
                                onTap: () async {
                                  selectDate();
                                },
                                controller: controller.dobController,
                                textInputAction: TextInputAction.next,
                                style: const TextStyle(
                                    color: AppColors.colorText,
                                    fontFamily: 'Museo Sans'),
                                keyboardType: TextInputType.datetime,
                                cursorColor: Colors.white,
                                decoration: InputDecoration(
                                  contentPadding: EdgeInsets.only(left: 10.h),
                                  filled: true,
                                  fillColor: AppColors.inputColor,
                                  enabledBorder: const OutlineInputBorder(
                                      borderSide: BorderSide(
                                          color: AppColors.inputColor),
                                      borderRadius: BorderRadius.all(
                                          Radius.circular(26.0))),
                                  focusedBorder: const OutlineInputBorder(
                                      borderSide: BorderSide(
                                          color: AppColors.inputColor),
                                      borderRadius: BorderRadius.all(
                                          Radius.circular(26.0))),
                                  errorBorder: const OutlineInputBorder(
                                      borderSide: BorderSide(
                                          color: AppColors.buttonColor),
                                      borderRadius: BorderRadius.all(
                                          Radius.circular(35.0))),
                                  hintStyle: const TextStyle(
                                      fontFamily: 'Museo Sans',
                                      color: AppColors.colorVaarient,
                                      fontSize: 16,
                                      fontWeight: FontWeight.w500),
                                  hintText: Strings.dateofBirth,
                                ),
                                validator: (value) {
                                  return controller.validateDob(value!);
                                },
                                onSaved: (value){
                                  controller.dob = value!;
                                },
                              ),
                              const SizedBox(
                                height: 10,
                              ),

                              const SizedBox(
                                height: 5,
                              ),

                              TextFormField(
                                controller: controller.passwordController,
                                obscureText: true,
                                textInputAction: TextInputAction.next,
                                style: const TextStyle(
                                    color: AppColors.colorText,
                                    fontFamily: 'Museo Sans'),
                                keyboardType: TextInputType.emailAddress,
                                cursorColor: Colors.white,
                                decoration: const InputDecoration(
                                  filled: true,
                                  contentPadding: EdgeInsets.only(left: 10),
                                  fillColor: AppColors.inputColor,
                                  enabledBorder: OutlineInputBorder(
                                      borderSide: BorderSide(
                                          color: AppColors.inputColor),
                                      borderRadius: BorderRadius.all(
                                          Radius.circular(26.0))),
                                  focusedBorder: OutlineInputBorder(
                                      borderSide: BorderSide(
                                          color: AppColors.inputColor),
                                      borderRadius: BorderRadius.all(
                                          Radius.circular(26.0))),
                                  errorBorder: OutlineInputBorder(
                                      borderSide: BorderSide(
                                          color: AppColors.buttonColor),
                                      borderRadius: BorderRadius.all(
                                          Radius.circular(26.0))),
                                  hintStyle: TextStyle(
                                      fontFamily: 'Museo Sans',
                                      color: AppColors.colorVaarient,
                                      fontSize: 16,
                                      fontWeight: FontWeight.w500),
                                  hintText: Strings.password,
                                ),
                                onSaved: (value) {
                                  controller.password = value!;
                                },
                                validator: (value) {
                                  return controller.validatePassword(value!);
                                },
                              ),
                              const SizedBox(
                                height: 5,
                              ),

                              TextFormField(
                                controller: controller.cPasswordController,
                                obscureText: true,
                                textInputAction: TextInputAction.done,
                                style: const TextStyle(
                                    color: AppColors.colorText,
                                    fontFamily: 'Museo Sans'),
                                keyboardType: TextInputType.visiblePassword,
                                cursorColor: Colors.white,
                                decoration: const InputDecoration(
                                  filled: true,
                                  contentPadding: EdgeInsets.only(left: 10),
                                  enabledBorder: OutlineInputBorder(
                                      borderSide: BorderSide(
                                          color: AppColors.inputColor),
                                      borderRadius: BorderRadius.all(
                                          Radius.circular(26.0))),
                                  focusColor: AppColors.inputColor,
                                  fillColor: AppColors.inputColor,
                                  focusedBorder: OutlineInputBorder(
                                      borderSide: BorderSide(
                                          color: AppColors.inputColor),
                                      borderRadius: BorderRadius.all(
                                          Radius.circular(26.0))),
                                  errorBorder: OutlineInputBorder(
                                      borderSide: BorderSide(
                                          color: AppColors.buttonColor),
                                      borderRadius: BorderRadius.all(
                                          Radius.circular(25.0))),
                                  hintStyle: TextStyle(
                                      fontFamily: 'Museo Sans',
                                      color: AppColors.colorVaarient,
                                      fontSize: 16,
                                      fontWeight: FontWeight.w500),
                                  hintText: Strings.confirmPassword,
                                ),
                                validator: (value) {
                             
                                  return controller.validateConfPassword(value!);
                                },
                              ),
                              const SizedBox(
                                height: 5,
                              ),

                              //language
                              DropdownButtonFormField(
                                isExpanded: true,
                                decoration: InputDecoration(
                                  filled: true,
                                  contentPadding: EdgeInsets.only(left: 10.h),
                                  fillColor: AppColors.inputColor,
                                  enabledBorder: const OutlineInputBorder(
                                      borderSide: BorderSide(
                                          color: AppColors.inputColor),
                                      borderRadius: BorderRadius.all(
                                          Radius.circular(26.0))),
                                  focusedBorder: const OutlineInputBorder(
                                      borderSide: BorderSide(
                                          color: AppColors.inputColor),
                                      borderRadius: BorderRadius.all(
                                          Radius.circular(26.0))),
                                  errorBorder: const OutlineInputBorder(
                                      borderSide: BorderSide(
                                          color: AppColors.buttonColor),
                                      borderRadius: BorderRadius.all(
                                          Radius.circular(26.0))),
                                ),
                                focusColor: AppColors.inputColor,
                                icon: const Icon(
                                  Icons.keyboard_arrow_down,
                                  color: Colors.grey,
                                ),
                                value: itemsListLanguage[0],
                                items: itemsListLanguage
                                    .map((e) => DropdownMenuItem(
                                        value: e, child: Text(e)))
                                    .toList(),
                                onChanged: (Object? value) {},
                              ),
                              SizedBox(
                                height: 10.h,
                              ),

                              Text(
                                Strings.selectDistance,
                                style: TextStyle(
                                    fontFamily: 'Museo Sans',
                                    fontSize: ScreenUtil().setSp(16),
                                    color: AppColors.colorVaarient),
                              ),
                              //range

                              RangeSlider(
                                values: RangeValues(start, end),
                                labels: RangeLabels(
                                    start.toString(), end.toString()),
                                onChanged: (value) {
                                  setState(() {
                                    start = value.start;
                                    end = value.end;
                                  });
                                },
                                min: 10.0,
                                max: 80.0,
                              ),
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceAround,
                                children: [
                                  Text(
                                    '0 Miles',
                                    style: TextStyle(
                                        fontFamily: 'Museo Sans',
                                        fontSize: ScreenUtil().setSp(12),
                                        color: AppColors.colorVaarient),
                                  ),
                                  Text(
                                    '50 Miles',
                                    style: TextStyle(
                                        fontFamily: 'Museo Sans',
                                        fontSize: ScreenUtil().setSp(12),
                                        color: AppColors.colorVaarient),
                                  ),
                                  Text(
                                    '100 Miles',
                                    style: TextStyle(
                                        fontFamily: 'Museo Sans',
                                        fontSize: ScreenUtil().setSp(12),
                                        color: AppColors.colorVaarient),
                                  ),
                                ],
                              ),
                              const SizedBox(
                                height: 10,
                              ),

                              Row(
                                children: [
                                  Radio<OS>(
                                    toggleable: true,
                                    value: OS.mac,
                                    groupValue: _os,
                                    onChanged: (OS? value) {
                                      setState(() {
                                        _os = value;
                                      });
                                    },
                                  ),
                                  RichText(
                                    text: TextSpan(
                                        text: Strings.agree,
                                        style: TextStyle(
                                            fontFamily: 'Museo Sans',
                                            fontSize: ScreenUtil().setSp(16),
                                            color: AppColors.colorVaarient),
                                        children: <TextSpan>[
                                          TextSpan(
                                            text: Strings.terms,
                                            style: TextStyle(
                                                fontFamily: 'Museo Sans',
                                                fontSize:
                                                    ScreenUtil().setSp(16),
                                                color: AppColors.colorText),
                                          ),
                                        ]),
                                  ),
                                ],
                              ),
                              SizedBox(
                                height: 10.h,
                              ),
                              CustomButton(
                                title: Strings.signUpText,
                                onTap: () {
                                  if (controller.checkSignUp()) {
                                    Get.off(const CreateProfile());
                                  } else {
                                    Get.snackbar('', 'SignUp Fail');
                                  }
                                },
                                bgColor: AppColors.buttonColor,
                              ),
                              SizedBox(
                                height: 10.h,
                              ),
                            ],
                          ))
                    ],
                  ),
                ),
              ),
            ),

            //bottom
            Padding(
              padding: EdgeInsets.only(bottom: 8.h),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  RichText(
                    text: TextSpan(
                        text: Strings.alreadyMember,
                        style: TextStyle(
                            fontFamily: 'Museo Sans',
                            fontWeight: FontWeight.bold,
                            fontSize: ScreenUtil().setSp(14),
                            color: AppColors.colorVaarient),
                        children: <TextSpan>[
                          TextSpan(
                            recognizer: TapGestureRecognizer()
                              ..onTap = () => {Get.to(const LoginScreen())},
                            text: Strings.signInText,
                            style: TextStyle(
                                fontFamily: 'Museo Sans',
                                fontWeight: FontWeight.bold,
                                fontSize: ScreenUtil().setSp(14),
                                color: AppColors.colorText),
                          ),
                        ]),
                  ),
                ],
              ),
            ),
          ],
        ),
      );
    });
  }

  Future<void> showBottom() async {
    await Get.bottomSheet(ClipRRect(
      borderRadius: const BorderRadius.only(
          topRight: Radius.circular(30), topLeft: Radius.circular(30)),
      child: Container(
          padding: const EdgeInsets.only(left: 20, right: 20),
          height: 180,
          color: AppColors.bottomSheet,
          child: Column(
            children: [
              const SizedBox(
                height: 15,
              ),
              const Text(
                Strings.addSocialSecurity,
                style: TextStyle(
                    fontFamily: 'Museo Snas',
                    fontWeight: FontWeight.bold,
                    fontSize: 24),
              ),
              const SizedBox(
                height: 15,
              ),
              TextFormField(
                validator: (value) {
                  return controller.validateEmail(value!);
                },
                textInputAction: TextInputAction.done,
                style: const TextStyle(
                    color: AppColors.colorText, fontFamily: 'Museo Sans'),
                keyboardType: TextInputType.emailAddress,
                cursorColor: Colors.white,
                decoration: const InputDecoration(
                  hintText: 'Enter Code',
                  hintStyle: TextStyle(fontFamily: 'Museo Sans'),
                  filled: true,
                  fillColor: AppColors.colorBottomInput,
                  enabledBorder: OutlineInputBorder(
                      borderSide:
                          BorderSide(color: AppColors.inputColor, width: 4),
                      borderRadius: BorderRadius.all(Radius.circular(35.0))),
                  errorBorder: OutlineInputBorder(
                      borderSide:
                          BorderSide(color: AppColors.buttonColor, width: 2),
                      borderRadius: BorderRadius.all(Radius.circular(35.0))),
                  contentPadding: EdgeInsets.only(left: 15),
                  focusedBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: AppColors.buttonColor),
                      borderRadius: BorderRadius.all(Radius.circular(35.0))),
                  labelStyle: TextStyle(color: AppColors.colorVaarient),
                ),
              ),
              const SizedBox(
                height: 15,
              ),
              CustomButton(
                title: Strings.done,
                bgColor: AppColors.buttonColor,
                onTap: () {
                  getBottomSheet();
                },
              ),
            ],
          )),
    ));
  }

  Future<void> selectDate() async {
    DateTime? pickedDate = await showDatePicker(
        context: context,
        initialDate: DateTime.now(),
        firstDate: DateTime(2000),
        //DateTime.now() - not to allow to choose before today.
        lastDate: DateTime(2101));

    if (pickedDate != null) {
      String formattedDate = DateFormat('yyyy-MM-dd').format(pickedDate);
      setState(() {
        controller.dobController.text =
            formattedDate; //set output date to TextField value.
      });
    } else {
      debugPrint("Date is not selected");
    }
  }

  Future getBottomSheet() async {
    await Get.bottomSheet(StatefulBuilder(builder:
        (BuildContext context, StateSetter setState /*You can rename this!*/) {
      return ClipRRect(
        borderRadius: const BorderRadius.only(
            topRight: Radius.circular(30), topLeft: Radius.circular(30)),
        child: Container(
            padding: const EdgeInsets.only(left: 30, right: 30),
            height: 240,
            color: AppColors.inputColor,
            child: Column(
              children: [
                const SizedBox(
                  height: 15,
                ),
                const Text(
                  Strings.verifyAccount,
                  style: TextStyle(
                      fontFamily: 'Museo Sans',
                      fontWeight: FontWeight.bold,
                      fontSize: 24),
                ),
                const SizedBox(
                  height: 10,
                ),
                //radio
                DecoratedRadioButton(
                  isSelected: 1 == selectedGenderVar,
                  text: Strings.verifyViaEmail,
                  onTap: () {
                    setState(() {
                      selectedGenderVar = 1;
                    });
                  },
                ),
                const SizedBox(
                  height: 5,
                ),

                DecoratedRadioButton(
                  isSelected: 2 == selectedGenderVar,
                  text: Strings.verifyViaPhone,
                  onTap: () {
                    setState(() {
                      selectedGenderVar = 2;
                    });
                  },
                ),
                const SizedBox(
                  height: 10,
                ),

                CustomButton(
                  title: Strings.sendVerificationCode,
                  onTap: () {
                    Get.to(const VerifyAccountScreen());
                  },
                ),
              ],
            )),
      );
    }));
  }
}

enum OS { mac, windows, linux }

OS? _os = OS.windows;

enum BestTutorSite2 { email, phone }
