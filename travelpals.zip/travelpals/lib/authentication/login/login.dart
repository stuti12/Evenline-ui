import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:travelpals/authentication/controllers/login_controller.dart';
import 'package:travelpals/authentication/login/forgot_password.dart';
import 'package:travelpals/authentication/login/signup.dart';
import 'package:travelpals/bottom_tabbar_page.dart';
import 'package:travelpals/utils/colors.dart';

import '../../custom/custom_button.dart';
import '../../utils/shared_pref.dart';
import '../../utils/strings.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({Key? key}) : super(key: key);

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  LoginController controller = LoginController();
  final PrefService _prefService = PrefService();

  @override
  Widget build(BuildContext context) {

    return ScreenUtilInit(
      builder: (_, child) {
        return Scaffold(
          resizeToAvoidBottomInset: false,
          body: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: SingleChildScrollView(
                  child: Container(
                    padding:  EdgeInsets.only(
                        left: 30.h, top: 50.h, right: 30.h),
                    width: double.infinity,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                         Text(
                          Strings.letsSignIn,
                          style: TextStyle(
                              fontFamily: 'Museo Sans',
                              fontWeight: FontWeight.bold,
                              fontSize: ScreenUtil().setSp(26),
                              color: AppColors.colorText),
                        ),
                        const SizedBox(
                          height: 8,
                        ),
                         Text(Strings.welcomeText,
                            style: TextStyle(
                                fontFamily: 'Museo Sans Bold',
                                fontSize: ScreenUtil().setSp(22),
                                color: AppColors.colorText)),
                        Form(
                            autovalidateMode: AutovalidateMode
                                .onUserInteraction,
                            key: controller.loginKey,
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                 SizedBox(
                                  height: 10.h,
                                ),
                                SizedBox(width: ScreenUtil().screenWidth,
                                  child: TextFormField(
                                    controller: controller.emailController,
                                    textInputAction: TextInputAction.next,
                                    style: const TextStyle(
                                        color: Colors.black,
                                        fontFamily: 'Museo Sans'),
                                    keyboardType: TextInputType.emailAddress,
                                    cursorColor: Colors.white,
                                    decoration: const InputDecoration(
                                      filled: true,
                                      fillColor: AppColors.inputColor,
                                      enabledBorder: OutlineInputBorder(
                                          borderSide:
                                          BorderSide(color: AppColors.inputColor),
                                          borderRadius: BorderRadius.all(
                                              Radius.circular(26.0))),
                                      errorBorder: OutlineInputBorder(
                                          borderSide: BorderSide(
                                              color: AppColors.buttonColor),
                                          borderRadius: BorderRadius.all(
                                              Radius.circular(26.0))),
                                      contentPadding: EdgeInsets.only(left: 10),
                                      focusedBorder: OutlineInputBorder(
                                          borderSide:
                                          BorderSide(color: AppColors.inputColor),
                                          borderRadius: BorderRadius.all(
                                              Radius.circular(26.0))),
                                      hintStyle:  TextStyle(fontFamily: 'Museo Sans',color: AppColors.colorVaarient,fontSize: 16,fontWeight: FontWeight.w500),
                                      hintText: Strings.email,
                                    ),
                                    onSaved: (value) {
                                      controller.email = value!;
                                    },
                                    validator: (value) {
                                      return controller.validateEmail(value!);
                                    },
                                  ),
                                ),
                                 SizedBox(
                                  height: 15.h,
                                ),

                                Obx(
                                      () =>
                                      SizedBox(width: ScreenUtil().screenWidth,
                                        child: TextFormField(
                                          controller: controller
                                              .passwordController,
                                          obscureText: controller.isPasswordHidden
                                              .value,
                                          textInputAction: TextInputAction.done,
                                          style: const TextStyle(
                                              color: Colors.black,
                                              fontFamily: 'Museo Sans'),
                                          keyboardType: TextInputType
                                              .emailAddress,
                                          cursorColor: Colors.white,
                                          decoration: InputDecoration(
                                            contentPadding:
                                             EdgeInsets.only(left: 10.h),
                                            filled: true,
                                            fillColor: AppColors.inputColor,
                                            enabledBorder:  OutlineInputBorder(
                                                borderSide: const BorderSide(
                                                    color: AppColors.inputColor),
                                                borderRadius: BorderRadius.all(
                                                    Radius.circular(26.h))),
                                            errorBorder:  OutlineInputBorder(
                                                borderSide: const BorderSide(
                                                    color: AppColors.buttonColor),
                                                borderRadius: BorderRadius.all(
                                                    Radius.circular(26.h))),
                                            focusedBorder:  OutlineInputBorder(
                                                borderSide: const BorderSide(
                                                    color: AppColors.inputColor),
                                                borderRadius: BorderRadius.all(
                                                    Radius.circular(26.h))),
                                            suffixIcon: IconButton(
                                              onPressed: () {
                                                controller.isPasswordHidden
                                                    .value =
                                                !controller.isPasswordHidden
                                                    .value;
                                              },
                                              icon: Icon(
                                                controller.isPasswordHidden.value
                                                    ? Icons.visibility
                                                    : Icons.visibility_off,
                                              ),
                                              color: Colors.grey,
                                            ),

                                            hintText: Strings.password,
                                            hintStyle:  const TextStyle(fontFamily: 'Museo Sans',color: AppColors.colorVaarient,fontSize: 16,fontWeight: FontWeight.w500),

                                          ),
                                          onSaved: (value) {
                                            controller.pswd = value!;
                                          },
                                          validator: (value) {
                                            return controller.validatePassword(
                                                value!);
                                          },
                                        ),
                                      ),
                                ),
                                 SizedBox(
                                  height: 10.h,
                                ),

                                //forget password
                                Align(
                                  alignment: Alignment.topRight,
                                  child: Padding(
                                    padding: EdgeInsets.all(20.h),
                                    child: InkWell(
                                      onTap: () {
                                        Get.to(const ForgotPasswordScreen());
                                      },
                                      child: RichText(
                                        text: TextSpan(
                                            text: Strings.forgotPswd,
                                            style:  TextStyle(
                                                fontFamily: 'Museo Sans',
                                                fontWeight: FontWeight.w400,
                                                fontSize: ScreenUtil().setSp(16),
                                                color: AppColors.colorVaarient),
                                            children: <TextSpan>[
                                              TextSpan(
                                                recognizer: TapGestureRecognizer()
                                                  ..onTap = () =>
                                                  {
                                                    Get.to(
                                                        const ForgotPasswordScreen())
                                                  },
                                              ),
                                            ]),
                                      ),
                                    ),
                                  ),
                                ),
                                CustomButton(
                                  title: Strings.signinText,
                                  onTap: () {
                                    _prefService
                                        .createCache(controller.emailController.text)
                                        .whenComplete(() {
                                      if (controller.checkLogin()) {
                                        Get.off(const TabbarPage());
                                      } else {
                                        Get.snackbar('', 'Login Fail');
                                      }
                                    });
                                  },
                                ),
                                 Padding(
                                  padding: EdgeInsets.all(20.h),
                                  child: Text(
                                    Strings.orContinue,
                                    style: TextStyle(
                                        fontFamily: 'Museo Sans',
                                        fontWeight: FontWeight.w400,
                                        fontSize: ScreenUtil().setSp(16),
                                        color: AppColors.colorVaarient),
                                    textAlign: TextAlign.right,
                                  ),
                                ),

                                //social login
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Image.asset(
                                      'assets/google.png',
                                      height: 70.h,
                                      width: 70.h,
                                    ),
                                    Image.asset(
                                      'assets/apple.png',
                                      height: 70.h,
                                      width: 70.h,
                                    ),
                                    Image.asset(
                                      'assets/facebook.png',
                                      height: 70.h,
                                      width: 70.h,
                                    )
                                  ],
                                )
                              ],
                            ))
                      ],
                    ),
                  ),
                ),
              ),
              Padding(
                padding:  EdgeInsets.only(bottom: 8.h),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    RichText(
                      text: TextSpan(
                          text: Strings.notMember,
                          style:  TextStyle(
                              fontFamily: 'Museo Sans',
                              fontSize:ScreenUtil().setSp(14),
                              color: AppColors.colorVaarient),
                          children: <TextSpan>[
                            TextSpan(
                              recognizer: TapGestureRecognizer()
                                ..onTap = () => {Get.to(const SignUpScreen())},
                              text: Strings.signUp,
                              style:  TextStyle(
                                  fontFamily: 'Museo Sans Bold',
                                  fontWeight: FontWeight.bold,
                                  fontSize: ScreenUtil().setSp(14),
                                  color: AppColors.colorText),
                            ),
                          ]),
                    ),
                  ],
                ),
              ),
            ],
          ),
        );
      });
  }
}
