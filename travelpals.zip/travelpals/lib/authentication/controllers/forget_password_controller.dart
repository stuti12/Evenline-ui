
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:get/get_state_manager/src/simple/get_controllers.dart';
import 'package:get/get_utils/src/get_utils/get_utils.dart';

class ForgetController extends GetxController {
  final GlobalKey<FormState> forgetKey = GlobalKey<FormState>();

  // late TextEditingController emailController,passwordController;
   TextEditingController emailController = TextEditingController();
  var email = '';
  var pswd = '';

  @override
  void onInit() {
    super.onInit();
  }

  @override
  void onClose() {
    super.onClose();
    emailController.dispose();

  }

  String? validateEmail(String value) {
    if(value == null) {
      return "Please enter Email";
    }
    if (!GetUtils.isEmail(value)) {
      return "Please enter valid Email";
    }
    return null;
  }



  bool checkLogin() {
    final isValid = forgetKey.currentState!.validate();
    if (!isValid) {
      return false;
    }
    Get.snackbar("title", "password successfully sent");

    forgetKey.currentState?.save();
    return true;
  }
}