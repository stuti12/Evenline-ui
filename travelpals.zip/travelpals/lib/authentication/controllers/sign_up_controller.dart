
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:get/get_state_manager/src/simple/get_controllers.dart';
import 'package:get/get_utils/src/get_utils/get_utils.dart';

class SignUpController extends GetxController {
  final GlobalKey<FormState> signUpKey = GlobalKey<FormState>();

  // late TextEditingController emailController,passwordController;

  TextEditingController emailController = TextEditingController();
  TextEditingController fnameController = TextEditingController();
  TextEditingController lnameController = TextEditingController();
  TextEditingController phoneController = TextEditingController();
  TextEditingController dobController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  TextEditingController cPasswordController = TextEditingController();
  var email = '';
  var fname = '';
  var lname = '';
  var phone = '';
  var dob = '';
  var password = '';

  @override
  void onInit() {
    super.onInit();
  }

  @override
  void onClose() {
    super.onClose();
    emailController.dispose();

  }

  String? validateEmail(String value) {
    if(emailController.text.isEmpty) {
      return 'Please Enter Email';
    }

    if (!GetUtils.isEmail(value)) {
      return "Please enter valid Email";
    }
    return null;
  }

  String? validatePassword(String value) {
    if(passwordController.text.isEmpty) {
      return 'Please Enter Password';
    }
    if (value.length <= 6) {
      return "Please enter valid Password";
    }
    return null;
  }

  String? validatePhone(String value) {
    if(phoneController.text.isEmpty) {
      print("Phone validator");

      return 'Please Enter Phone number';
    }
    if (value.length != 10) {
      return "Please enter valid Phone number";
    }
    return null;
  }

  String? validateFirstName(String value) {
    if(fnameController.text.isEmpty) {
      return 'Please Enter First Name';
    }
    return null;
  }

  String? validateLastName(String value) {
    if(lnameController.text.isEmpty) {
      return 'Please Enter Last Name';
    }
    return null;
  }

  String? validateDob(String value) {
    if(dobController.text.isEmpty) {
      return 'Please Enter Date of birth';
    }
    return null;
  }

  String? validateConfPassword(String value) {
    if(cPasswordController.text.isEmpty) {
      return 'Please Enter Password';
    }
    if (value.length <= 6) {
      return "Please enter valid Password";
    }
    if(value!=passwordController.text) {
      return 'Password not match';
    }

    return null;
  }

  bool checkSignUp() {
    final isValid = signUpKey.currentState!.validate();
    if (!isValid) {
      return false;
    }
    Get.snackbar("title", "login success");

    signUpKey.currentState?.save();
    return true;
  }
}