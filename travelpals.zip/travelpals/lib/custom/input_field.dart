import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../utils/colors.dart';

class AppWidgets {
  static Widget inputField(BuildContext context, String hint,
      {TextInputAction textInputAction = TextInputAction.next,
      String initialValue = "",
      TextEditingController? controller,
      FocusNode? focusNode,
      bool obscureText = true,
      int maxLines = 1,
      int? maxLength,
      bool enabled = true,
      bool readOnly = false,
      TextInputType? keyboardType,
      Function? onClick,
      dynamic suffixIcon}) {
    return TextFormField(
        controller: controller,
        focusNode: focusNode,
        initialValue: controller == null ? initialValue : null,
        obscureText: obscureText,
        textInputAction: textInputAction,
        inputFormatters: [
          FilteringTextInputFormatter.deny(RegExp(
              '(\u00a9|\u00ae|[\u2000-\u3300]|\ud83c[\ud000-\udfff]|\ud83d[\ud000-\udfff]|\ud83e[\ud000-\udfff])')),
        ],
        enabled: enabled,
        readOnly: readOnly,
        keyboardType: keyboardType,
        onFieldSubmitted: (v) {
          if (textInputAction == TextInputAction.next)
            FocusScope.of(context).nextFocus();
        },
        maxLines: maxLines,
        maxLength: maxLength,
        decoration: InputDecoration(
          enabledBorder: InputBorder.none,
          suffixIcon: suffixIcon,
          contentPadding: EdgeInsets.only(top: 15, bottom: 15),
          labelText: hint,
          focusedBorder: const OutlineInputBorder(
              borderSide: BorderSide(color: AppColors.colorTheme),
              borderRadius: BorderRadius.all(Radius.circular(35.0))),
          counterText: '',
        ));
  }
}
