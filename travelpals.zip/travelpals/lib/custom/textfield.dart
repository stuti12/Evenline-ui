import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../utils/colors.dart';

class CustomWidgets {
  static Widget textField(
      {bool isPassword = false,
      bool isNumber = false,
      int? length,
      Color? cursorColors,
      final FormFieldValidator? validator,
      TextInputAction? textInputActiosn,
      TextEditingController? textController,
      int lines = 1}) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 2),
      child: TextFormField(
        style: const TextStyle(
            color: AppColors.colorText, fontFamily: 'Museo Sans'),
        textInputAction: textInputActiosn,
        validator: validator,
        maxLines: lines,
        cursorColor: cursorColors,
        controller: textController,
        maxLength: length,
        inputFormatters: [
          LengthLimitingTextInputFormatter(length),
        ],
        obscureText: isPassword,
        keyboardType: isNumber ? TextInputType.number : TextInputType.text,
        decoration: const InputDecoration(
          counterText: '',
          contentPadding: EdgeInsets.only(left: 5),
          filled: true,
          fillColor: AppColors.inputColor,
          enabledBorder: OutlineInputBorder(
              borderSide: BorderSide(color: AppColors.buttonColor),
              borderRadius: BorderRadius.all(Radius.circular(35.0))),
          errorBorder: OutlineInputBorder(
              borderSide: BorderSide(color: AppColors.buttonColor),
              borderRadius: BorderRadius.all(Radius.circular(35.0))),
          focusedBorder: OutlineInputBorder(
              borderSide: BorderSide(color: AppColors.buttonColor),
              borderRadius: BorderRadius.all(Radius.circular(35.0))),
        ),
      ),
    );
  }
}
