import 'package:flutter/material.dart';

import '../utils/colors.dart';

class DecoratedRadioButton2 extends StatelessWidget {
  const DecoratedRadioButton2(
      {Key? key,
      required this.isSelected,
      required this.text,
      this.onTap,
      this.borderColor})
      : super(key: key);
  final bool isSelected;
  final String text;
  final Color? borderColor;

  final GestureTapCallback? onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Container(
        width: double.infinity,
        height: 50,
        decoration: BoxDecoration(
            color: AppColors.inputColor,
            border: Border.all(color: borderColor ?? Colors.white, width: 2),
            borderRadius: const BorderRadius.all(Radius.circular(30))),
        child: Padding(
          padding: const EdgeInsets.only(
            left: 20,
          ),
          child: Row(
            children: [
              Text(
                text,
                style: TextStyle(
                    color: isSelected
                        ? AppColors.cancelColor
                        : AppColors.cancelColor,
                    fontFamily: 'Museo Sans'),
              ),
              Expanded(
                  child: Padding(
                padding: const EdgeInsets.only(right: 10),
                child: Align(
                    alignment: Alignment.centerRight,
                    child: Radio(
                      value: isSelected,
                      groupValue: true,
                      onChanged: (bool? value) {
                        value = !value!;
                      },
                      activeColor: AppColors.buttonColor,
                    )
                    /*Container(
                      width: 25,
                      decoration: BoxDecoration(
                          color: isSelected
                              ? AppColors.colorVerifyGradient
                              : AppColors.inputColor,
                          border: Border.all(
                              color: isSelected
                                  ? AppColors.colorTheme
                                  : AppColors.colorBorder,
                              width: 2),
                          borderRadius:
                              const BorderRadius.all(Radius.circular(30))),
                      child: Image.asset(isSelected
                          ? 'assets/selected.png'
                          : 'assets/unselected.png'),
                    )*/
                    ),
              ))
            ],
          ),
        ),
      ),
    );
  }
}
