import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import 'package:travelpals/invite/invite_friends.dart';
import 'package:video_player/video_player.dart';

import '../custom/custom_button.dart';
import '../utils/colors.dart';
import '../utils/strings.dart';

class PostTripScreen extends StatefulWidget {
  const PostTripScreen({Key? key}) : super(key: key);

  @override
  State<PostTripScreen> createState() => _PostTripScreenState();
}

class _PostTripScreenState extends State<PostTripScreen> {
  static final _formKey = GlobalKey<FormState>();
  final ImagePicker imgpicker = ImagePicker();
  List<XFile>? imagefiles;
  File? _video;

  VideoPlayerController videoPlayerController =
      VideoPlayerController.file(File(''));
  bool isVideo = false;
  int count = 0;

  static final TextEditingController _startDate = TextEditingController();
  static final TextEditingController _endDate = TextEditingController();
  static final TextEditingController _tripname = TextEditingController();
  static final TextEditingController _tripDetail = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bottomSheet,
      appBar: AppBar(
        titleSpacing: 0,
        backgroundColor: AppColors.whiteColor,
        title: const Text(
          Strings.postTrip,
          style: TextStyle(
              fontFamily: 'Museo Sans',
              color: AppColors.colorText,
              fontSize: 22),
        ),
        leading: IconButton(
          icon: const Icon(
            Icons.arrow_back,
            color: AppColors.arrowColor,
          ),
          onPressed: () {
            Get.back();
          },
        ),
      ),
      body: SingleChildScrollView(
        child: Container(
          margin: const EdgeInsets.only(left: 20, right: 20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(
                height: 30,
              ),
              Form(
                  key: _formKey,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      //tripname
                      const Text(
                        Strings.tripName,
                        style: TextStyle(
                            fontFamily: 'Museo Sans',
                            color: AppColors.colorText,
                            fontSize: 18),
                      ),
                      const SizedBox(
                        height: 5,
                      ),
                      TextFormField(
                        controller: _tripname,
                        textInputAction: TextInputAction.next,
                        style: const TextStyle(
                            color: AppColors.colorText,
                            fontFamily: 'Museo Sans'),
                        keyboardType: TextInputType.name,
                        cursorColor: Colors.white,
                        decoration: const InputDecoration(
                          contentPadding: EdgeInsets.only(left: 15),
                          filled: true,
                          fillColor: AppColors.colorPostInput,
                          enabledBorder: OutlineInputBorder(
                              borderSide:
                                  BorderSide(color: AppColors.colorPostInput),
                              borderRadius:
                                  BorderRadius.all(Radius.circular(15.0))),
                          focusedBorder: OutlineInputBorder(
                              borderSide:
                                  BorderSide(color: AppColors.colorPostInput),
                              borderRadius:
                                  BorderRadius.all(Radius.circular(15.0))),
                          errorBorder: OutlineInputBorder(
                              borderSide:
                                  BorderSide(color: AppColors.buttonColor),
                              borderRadius:
                                  BorderRadius.all(Radius.circular(15.0))),
                          hintText: Strings.tripName,
                        ),
                        validator: (value) {
                          if (value?.isEmpty ?? true) {
                            return 'Please Enter trip Name';
                          }
                          return null;
                        },
                      ),
                      const SizedBox(
                        height: 10,
                      ),

                      //detail
                      const Text(
                        Strings.tripDetail,
                        style: TextStyle(
                            fontFamily: 'Museo Sans',
                            color: AppColors.colorText,
                            fontSize: 18),
                      ),
                      const SizedBox(
                        height: 5,
                      ),

                      TextFormField(
                        maxLines: 6,
                        controller: _tripDetail,
                        textInputAction: TextInputAction.next,
                        style: const TextStyle(
                            color: AppColors.colorText,
                            fontFamily: 'Museo Sans'),
                        keyboardType: TextInputType.name,
                        cursorColor: Colors.white,
                        decoration: const InputDecoration(
                          contentPadding: EdgeInsets.only(left: 15),
                          filled: true,
                          fillColor: AppColors.colorPostInput,
                          enabledBorder: OutlineInputBorder(
                              borderSide:
                                  BorderSide(color: AppColors.colorPostInput),
                              borderRadius:
                                  BorderRadius.all(Radius.circular(15.0))),
                          focusedBorder: OutlineInputBorder(
                              borderSide:
                                  BorderSide(color: AppColors.colorPostInput),
                              borderRadius:
                                  BorderRadius.all(Radius.circular(15.0))),
                          errorBorder: OutlineInputBorder(
                              borderSide:
                                  BorderSide(color: AppColors.buttonColor),
                              borderRadius:
                                  BorderRadius.all(Radius.circular(15.0))),
                        ),
                        validator: (value) {
                          if (value?.isEmpty ?? true) {
                            return 'Please Enter Details';
                          }
                          return null;
                        },
                      ),
                      const SizedBox(
                        height: 10,
                      ),

                      //addphoto
                      const Text(
                        Strings.addPhoto,
                        style: TextStyle(
                            fontFamily: 'Museo Sans',
                            color: AppColors.colorText,
                            fontSize: 18),
                      ),

                      const SizedBox(
                        height: 10,
                      ),

                      //photogrid

                      Container(
                        decoration: const BoxDecoration(
                            borderRadius: BorderRadius.all(
                              Radius.circular(10),
                            ),
                            color: AppColors.colorPostInput),
                        height: 80,
                        width: 80,
                        child: IconButton(
                            onPressed: () {
                              alert();
                            },
                            icon: const Icon(
                              Icons.add_box_outlined,
                              size: 30,
                              color: AppColors.cancelColor,
                            )),
                      ),
                      (imagefiles != null && !isVideo)
                          ? Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: SizedBox(
                                height: 100,
                                child: GridView.builder(
                                    itemCount: imagefiles!.length,
                                    gridDelegate:
                                        const SliverGridDelegateWithFixedCrossAxisCount(
                                            crossAxisCount: 3),
                                    itemBuilder:
                                        (BuildContext context, int index) {
                                      return (imagefiles!.isNotEmpty &&
                                              !isVideo)
                                          ? ClipRRect( borderRadius: BorderRadius.circular(8.0),
                                        child: Image.file(
                                              File(
                                                imagefiles![index].path,
                                              ),
                                             height: 100,width: 100,
                                            ),
                                          )
                                          : Container();
                                    }),
                              ),
                            )
                          : ClipRRect(borderRadius: BorderRadius.circular(8.0),
                            child: SizedBox(
                                height: 100,width: 100,
                                child: VideoPlayer(videoPlayerController)),
                          ),

                      const SizedBox(
                        height: 10,
                      ),

                      //startdate
                      const Text(
                        Strings.tripStartDate,
                        style: TextStyle(
                            fontFamily: 'Museo Sans',
                            color: AppColors.colorText,
                            fontSize: 18),
                      ),
                      const SizedBox(
                        height: 5,
                      ),
                      TextFormField(
                        controller: _startDate,
                        textInputAction: TextInputAction.next,
                        style: const TextStyle(
                            color: AppColors.colorText,
                            fontFamily: 'Museo Sans'),
                        keyboardType: TextInputType.name,
                        cursorColor: Colors.white,
                        decoration: InputDecoration(
                          contentPadding: const EdgeInsets.only(left: 15),
                          filled: true,
                          fillColor: AppColors.colorPostInput,
                          enabledBorder: const OutlineInputBorder(
                              borderSide:
                                  BorderSide(color: AppColors.colorPostInput),
                              borderRadius:
                                  BorderRadius.all(Radius.circular(15.0))),
                          focusedBorder: const OutlineInputBorder(
                              borderSide:
                                  BorderSide(color: AppColors.colorPostInput),
                              borderRadius:
                                  BorderRadius.all(Radius.circular(15.0))),
                          errorBorder: const OutlineInputBorder(
                              borderSide:
                                  BorderSide(color: AppColors.buttonColor),
                              borderRadius:
                                  BorderRadius.all(Radius.circular(15.0))),
                          suffixIcon: IconButton(
                            onPressed: () async {
                              selectDate();
                            },
                            icon: const Icon(Icons.calendar_today),
                            color: Colors.grey,
                          ),
                        ),
                        validator: (value) {
                          if (value?.isEmpty ?? true) {
                            return 'Please Enter StartDate';
                          }
                          return null;
                        },
                      ),
                      const SizedBox(
                        height: 10,
                      ),

                      //enddate
                      const Text(
                        Strings.tripEndDate,
                        style: TextStyle(
                            fontFamily: 'Museo Sans',
                            color: AppColors.colorText,
                            fontSize: 18),
                      ),
                      const SizedBox(
                        height: 5,
                      ),
                      TextFormField(
                        controller: _endDate,
                        textInputAction: TextInputAction.next,
                        style: const TextStyle(
                            color: AppColors.colorText,
                            fontFamily: 'Museo Sans'),
                        keyboardType: TextInputType.name,
                        cursorColor: Colors.white,
                        decoration: InputDecoration(
                          contentPadding: const EdgeInsets.only(left: 15),
                          filled: true,
                          fillColor: AppColors.colorPostInput,
                          enabledBorder: const OutlineInputBorder(
                              borderSide:
                                  BorderSide(color: AppColors.colorPostInput),
                              borderRadius:
                                  BorderRadius.all(Radius.circular(15.0))),
                          focusedBorder: const OutlineInputBorder(
                              borderSide:
                                  BorderSide(color: AppColors.colorPostInput),
                              borderRadius:
                                  BorderRadius.all(Radius.circular(15.0))),
                          errorBorder: const OutlineInputBorder(
                              borderSide:
                                  BorderSide(color: AppColors.buttonColor),
                              borderRadius:
                                  BorderRadius.all(Radius.circular(15.0))),
                          suffixIcon: IconButton(
                            onPressed: () async {
                              selectDate();
                            },
                            icon: const Icon(Icons.calendar_today),
                            color: Colors.grey,
                          ),
                        ),
                        validator: (value) {
                          if (value?.isEmpty ?? true) {
                            return 'Please Enter EndDate';
                          }
                          return null;
                        },
                      ),
                      const SizedBox(
                        height: 10,
                      ),

                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          const Expanded(
                              child: Text(
                            Strings.howmanyPeople,
                            style: TextStyle(
                                fontFamily: 'Museo Sans',
                                color: AppColors.colorText,
                                fontSize: 18),
                          )),
                          Row(
                            children: [
                              Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Container(
                                  decoration: const BoxDecoration(
                                      borderRadius:
                                          BorderRadius.all(Radius.circular(26)),
                                      color:
                                          AppColors.counterPostButtonBgColor),
                                  child: Padding(
                                    padding: const EdgeInsets.all(4.0),
                                    child: GestureDetector(
                                        onTap: () {
                                          setState(() {
                                            count++;
                                            //set output date to TextField value.
                                          });
                                        },
                                        child: const Icon(
                                          Icons.add,
                                          color:
                                              AppColors.counterPostButtonColor,
                                        )),
                                  ),
                                ),
                              ),
                              Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Text(
                                  count.toString(),
                                  style: const TextStyle(
                                      fontFamily: 'Museo Sans',
                                      color: AppColors.counterPostButtonColor),
                                ),
                              ),
                              Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Container(
                                  decoration: const BoxDecoration(
                                      borderRadius:
                                          BorderRadius.all(Radius.circular(26)),
                                      color:
                                          AppColors.counterPostButtonBgColor),
                                  child: Padding(
                                    padding: const EdgeInsets.all(4.0),
                                    child: GestureDetector(
                                      onTap: () {
                                        setState(() {
                                          if (count == 0) {
                                            count = count;
                                          } else {
                                            count--;
                                          }
                                          //set output date to TextField value.
                                        });
                                      },
                                      child: const Icon(
                                        Icons.remove,
                                        color: AppColors.counterPostButtonColor,
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          )
                        ],
                      ),
                      const SizedBox(
                        height: 15,
                      ),

                      //make private
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Expanded(
                              child: Text(
                            Strings.makeThisTripPrivate,
                            style: TextStyle(
                                fontFamily: 'Museo Sans',
                                color: AppColors.colorText,
                                fontSize: 18),
                          )),

                          //switch
                          Switch(
                              activeColor: AppColors.buttonColor,
                              value: true,
                              onChanged: (value) {
                                setState(() {
                                  value = !value;
                                });
                              })
                        ],
                      ),
                      const SizedBox(
                        height: 15,
                      ),
                      Row(
                        children: [
                          const Expanded(
                              child: Text(
                            Strings.inviteFriends,
                            style: TextStyle(
                                fontFamily: 'Museo Sans',
                                color: AppColors.colorText,
                                fontSize: 18),
                          )),
                          CustomButton(
                            onTap: () {
                              Get.to(const InviteFriends());
                            },
                            title: Strings.invite,
                            width: 90,
                          )
                        ],
                      ),
                      const SizedBox(
                        height: 15,
                      ),

                      CustomButton(
                        title: Strings.posts,
                        onTap: () {
                          if (_formKey.currentState!.validate()) {
                          } else {
                            Get.snackbar("", "Logged In UnSuccess");
                          }
                        },
                        bgColor: AppColors.buttonColor,
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                    ],
                  ))
            ],
          ),
        ),
      ),
    );
  }

  Future<void> selectDate() async {
    DateTime? pickedDate = await showDatePicker(
        context: context,
        initialDate: DateTime.now(),
        firstDate: DateTime(2000),
        //DateTime.now() - not to allow to choose before today.
        lastDate: DateTime(2101));

    DateTime? pickedEndDate = await showDatePicker(
        context: context,
        initialDate: DateTime.now(),
        firstDate: DateTime(2000),
        //DateTime.now() - not to allow to choose before today.
        lastDate: DateTime(2101));

    if (pickedDate != null) {
      String formattedDate = DateFormat('yyyy-MM-dd').format(pickedDate);
      setState(() {
        _startDate.text = formattedDate;
        //set output date to TextField value.
      });
    } else {
      debugPrint("Date is not selected");
    }
    if (pickedEndDate != null) {
      String formattedDate = DateFormat('yyyy-MM-dd').format(pickedEndDate);
      setState(() {
        _endDate.text = formattedDate;

        //set output date to TextField value.
      });
    } else {
      debugPrint("Date is not selected");
    }
  }

  openImages() async {
    isVideo = false;
    try {
      var pickedfiles = await imgpicker.pickMultiImage();
      //  var videos = await imgpicker.pickVideo(source: ImageSource.gallery);

      if (pickedfiles != null /*|| videos != null*/) {
        imagefiles = pickedfiles;
        //    video = videos;
        setState(() {});
      } else {
        if (kDebugMode) {
          print("No image is selected.");
        }
      }
    } catch (e) {
      if (kDebugMode) {
        print("error while picking file.");
      }
    }
  }

  //video pick
  Future pickVideo() async {
    isVideo = true;
    final video = await imgpicker.pickVideo(source: ImageSource.gallery);
    _video = File(video!.path);
    videoPlayerController = VideoPlayerController.file(_video! )
      ..initialize().then((value) => {setState(() {
        videoPlayerController.play();

      })});
  }

  void alert() async {
    await Get.dialog(AlertDialog(
      titleTextStyle:
          TextStyle(fontFamily: 'Museo Sans', color: AppColors.blackC),
      elevation: 5,
      title: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: const [
          Padding(
            padding: EdgeInsets.only(top: 8.0, bottom: 8.0),
            child: Text(
              'TravelPals',
              style: TextStyle(
                  fontFamily: 'Museo Sans',
                  fontSize: 16,
                  fontWeight: FontWeight.bold),
            ),
          ),
          Text(
            'Choose media type you want to upload',
            style: TextStyle(fontFamily: 'Museo Sans'),
          ),
        ],
      ),
      actions: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            TextButton(
                onPressed: () {
                  Navigator.of(Get.overlayContext!, rootNavigator: true).pop();
                },
                child: const Text('Cancel')),
            TextButton(
                onPressed: () {
                  Navigator.of(Get.overlayContext!, rootNavigator: true).pop();

                  openImages();
                },
                child: Text('Image')),
            TextButton(
                onPressed: () {
                  Navigator.of(Get.overlayContext!, rootNavigator: true).pop();
                  pickVideo();
                },
                child: Text('Video')),
          ],
        )
      ],
    ));
  }
}
