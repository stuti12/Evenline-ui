class Strings {
  static const String welcomeTitle =
      'A community for travelers around the World';
  static const String welcomeSubtitle =
      'At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum.';
  static const String next = 'Next';
  static const String letsSignIn = 'Let’s sign you in';
  static const String welcomeText = 'Welcome back';
  static const String email = 'Email';
  static const String password = 'Password';
  static const String forgotPswd = 'Forgot Password?';
  static const String signinText = 'Sign In';
  static const String orContinue = 'Or continue with';
  static const String notMember = 'Not a member?';
  static const String signUp = 'Signup';

  static const String createAccount = 'Create your account';
  static const String enterPersonalinfo =
      'Enter your personal Information to connect with us';
  static const String firstName = 'First Name';
  static const String lastName = 'Last Name';
  static const String country = 'Country';
  static const String phoneNumber = 'Phone Number';
  static const String dateofBirth = 'Date Of Birth';
  static const String confirmPassword = 'Confirm Password';
  static const String selectDistance = 'Select Distance Range';
  static const String agree = 'I agree to the';
  static const String terms = ' terms and condition';
  static const String signUpText = 'Sign Up';
  static const String alreadyMember = 'Already a member?';
  static const String signInText = ' Sign In';

  static const String cancel = 'Cancel';
  static const String forgetTitle =
      'We will send password reset link to your email ID to reset your password. please enter your register email ID';
  static const String okay = 'Okay';

  static const String addSocialSecurity = 'Add Social Security Number';
  static const String done = 'Done';

  static const String verifyAccount = 'Verify your account';
  static const String sendVerificationCode = 'Send Verification Code';
  static const String verifyViaEmail = 'Verify Via Email';
  static const String verifyViaPhone = 'Verify Via Phone';
  static const String proceedToCreate = 'Proceed to create Profile';

  static const String createProfile = 'Create Profile';
  static const String personalInfo = 'Personal information';
  static const String profileName = 'Johnathan Doe';
  static const String addProfilePhoto =
      'Add Profile Photo or Video(We recommended a video)';
  static const String bio = 'Bio';
  static const String enterBio = 'Enter your biography (Upto 400 characters)';
  static const String howDoYouIdentify = 'How do you identify?';
  static const String selectYourGender = 'Select your gender';

  static const String ageGroup = 'Age group range of people you want to meet';
  static const String age = 'Age Range';
  static const String male = 'Male';
  static const String female = 'Female';
  static const String nonBinary = 'Non-Binary';
  static const String years = 'Years';
  static const String women = 'Women';
  static const String men = 'Men';
  static const String everyone = 'Everyone';
  static const String largeGroup = 'Large Group';
  static const String friendsOnly = 'Friends Only';
  static const String soloTravel = 'Solo Travel';
  static const String differentCountry = 'Different countries/abroad';
  static const String sameCountry = 'In the same country you live in';
  static const String sameState = 'In same state';
  static const String travelWithFamily = 'Travel with family/kids';
  static const String travelOrMeetPets = 'Travel or meet others with pets';
  static const String whoAreYouInterested =
      'Who are you interested in traveling with?';
  static const String whatTypeOfTravelInterested =
      'What type of travel are you interested in?';
  static const String chooseYourIntrest =
      'Choose your interests and activities';
  static const String doYouHavePassport = 'Do you have a passport?';
  static const String doYouSmoke = 'Do you smoke?';
  static const String doYouDrink = 'Do you drink?';
  static const String covid19 =
      'Covid -19 – Do you prefer to travel with someone that’s vaccinated?';
  static const String yes = 'Yes';
  static const String no = 'No';
  static const String skip = 'Skip';
  static const String socially = 'Socially';

  static const String trips = 'Trips';
  static const String favouritetrips = 'Favourite Trips';
  static const String matches = 'Matches';
  static const String post = 'Post';
  static const String messages = 'Messages';
  static const String profile = 'Profile';
  static const String travelPals = 'TravelPals';
  static const String everywhere = 'Everywhere';
  static const String local = 'Local';
  static const String searchHere = 'Search Here...';
  static const String askToJoin = 'Ask to Join';
  static const String date = '5/10/2021 - 10/10/2021';
  static const String subscribe = 'Subscribe to TravelPals';
  static const String explore = 'Explore Plans';
  static const String inOrderTo =
      'In order to use the amazing features of TravelPals, you need to subsribe.';
  static const String description =
      'At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint...';

  static const String postTrip = 'Post a Trip';
  static const String tripName = 'Trip Name';
  static const String tripDetail = 'Trip Details';
  static const String addPhoto = 'Add Photos or Videos';
  static const String tripStartDate = 'Trip Start Date';
  static const String tripEndDate = 'Trip End Date';
  static const String howmanyPeople = 'How many people can join this trip?';
  static const String makeThisTripPrivate = 'Make this trip private';
  static const String inviteFriends = 'Invite Friends';
  static const String invite = 'Invite';
  static const String posts = 'Post';
  static const String remove = 'Remove';
  static const String travelFriends = 'Travel Pal Friends';
  static const String myContacts = 'My Contacts';
  static const String defaultPhoneBook =
      'default phonebook contact list will show here';

  static const String matchNot = 'Match Not found!';
  static const String updateYourProfile = 'Update Your Profile';
  static const String matchNotDesc =
      'At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium ';
  static const String note =
      'Note: Swipe right for match and swipe left for cancel.';

  static const String reportText = 'Report';
  static const String backgroundCheck = 'Background Check';
  static const String iHaveInterested = 'I have Interest in,';
  static const String viewAll = 'View All';
  static const String photosAndVideos = 'Photos & Videos';

  static const String performBackground = 'Perform Background Check';
  static const String loreumText =
      'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore e.';
  static const String check = 'Check';
  static const String waterSports = 'Water Sports';
  static const String food = 'Food';
  static const String exercise = 'Exercise';

  static const String whatsInYourMind = 'Whats on your mind?';
  static const String freshFashion = 'Fresh Fashion For You!';
  static const String shopNow = 'Shop Now!';
  static const String parisADream = 'Paris - a dream trip ';
  static const String atVero = 'At vero eos et accusamus et iusto odio .';
  static const String greeceLand = 'Greece - land';
  static const String beachLove = 'Beach Love';
  static const String monastreyVisit = 'Monastrey Visit';
  static const String tenMinutes = '10 min';

  static const String createPost = 'Create Post';
  static const String addLocation = 'Add Location';
  static const String addMember = 'Add Member';
  static const String removeMember = 'Remove Member';
  static const String delete = 'Delete';
  static const String leave = 'Leave';
  static const String deleteThisGroup = 'Delete this group';
  static const String reportThisGroup = 'Report this group';
  static const String leaveThisGroup = 'Leave this group';
  static const String writeHere = 'Write Here..';

  static const String notifications = 'Notifications';
  static const String accept = 'Accept';
  static const String commentText = 'Adam Jane Comment on your post.';
  static const String adamJaneWantsToJoin =
      'Adam Jane wants to join your Paris - a dream trip.';
  static const String yesterday = 'Yesterday';
  static const String twoDayAgo = '2 Days Ago';
  static const String profileNames = 'Adam Jane';
  static const String profileEmail = 'johnathan@gmail.com';
  static const String profileContact = '+1 562 562 5626';

  static const String settings = 'Settings';
  static const String myAccount = 'My Account';
  static const String myPosts = 'My Posts';
  static const String myTrips = 'My Trips';
  static const String advertisement = 'Advertisement ';
  static const String termsConditions = 'Terms & Conditions ';
  static const String membership = 'Membership';
  static const String changePassword = 'Change Password';
  static const String privacyPolicy = 'Privacy Policy';
  static const String help = 'Help';
  static const String logOut = 'Log Out';

  static const String termsDescription =
      'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam';
  static const String addFriend = 'Add Friend';
  static const String manageYourMembership = 'Manage your Membership';
  static const String currentSubscription = 'Current Subsription Plan';
  static const String oneMonthPackage = '1 Month Package';
  static const String threeMonthPackage = '3 Month Package';
  static const String sixMonthPackage = '6 Month Package';
  static const String foreverPlan = 'Forever Plan';
  static const String expires = 'Expires on: 25 July 2022';
  static const String allPlans = 'All Subscription Plans';
  static const String upgradePlans = 'Upgrade Your Plans';
  static const String likes = 'Likes';
  static const String comments = 'Comments';
  static const String joinTrips = 'Join Trips';
  static const String videoCall = 'Video Calls';
  static const String profileSwipe = 'Profile Swipes';
  static const String unlimited = 'Unlimited';

  static const String birthdate = 'Birthdate';
  static const String language = 'Language';
  static const String interestedAge = 'Intrested Age Group';
  static const String yourTravelPartner = 'Your Travel Partner Should Be';
  static const String yourInterest = 'Your Travel Intrestes';
  static const String yourActivityInterest = 'Your Activity Intrestes';
  static const String doYouHavePasport = 'Do you have passport?';
  static const String vaccinated =
      'Covid -19 – Do you prefer to travel with someone that’s vaccinated?';
  static const String yourPreference = 'Your Preference';
  static const String cancelMembership = 'Cancel Membership';
  static const String deactivateAccount = 'Deactivate Account';
  static const String deactivate = 'Deactivate';
  static const String deactivateDesc =
      'This account will tempororily deactivate. \nIt can be restored within 30 Days  ';

  static const String currentPassword = 'Current Password';
  static const String newPassword = 'New Password';
  static const String confirmNewPassword = 'Confirm New Password';
}
