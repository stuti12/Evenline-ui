import 'package:flutter/material.dart';

class AppColors extends Object {
  static const colorTheme = Color(0xFF5DD0D4);
  static const colorText = Color(0xFF334155);
  static const colorGrey = Color(0xFF787575);
  static const arrowColor = Color(0xFF182538);
  static const buttonColor = Color(0xFF01B5BB);
  static const cancelColor = Color(0xFFA9A7A7);
  static const inputColor = Color(0xFFF9F9F9);
  static const colorBottomInput = Color(0xFFF3F3F3);
  static const colorAccountInput = Color(0xFFF2F2F2);
  static const bottomSheet = Color(0xFFFBFBFB);
  static const colorRed = Color(0xFFFBFBFB);
  static const colorVerify = Color(0xFF41C8CD);
  static const colorVerifyGradient = Color(0xFFEDFFFF);
  static const colorPostInput = Color(0xFFF0F0F0);
  static const colorBorder = Color(0xFFD9D9D9);
  static const colorBorderRed = Color(0xFFFF1212);
  static const colorBottomNavText = Color(0xFFAFAFAF);
  static const colorTabUnselected = Color(0xFF9FC7C9);
  static const counterPostButtonColor = Color(0xFF787575);
  static const counterPostButtonBgColor = Color(0xFFD9D9D9);
  static const colorSearch = Color(0xFFF1F1F1);
  static const colorMessage = Color(0xFFD2E5E5);
  static const colorGreen = Color(0xFF34A853);
  static const colorMembershipTitleText = Color(0xFFC0FDFF);
  static const colorMembershipGradient2 = Color(0xFF227F82);
  static const colorMembershiptext = Color(0xFF049398);

  static Color whiteColor = Colors.white;
  static Color blackC = Colors.black;
  static const colorVaarient = Color(0xFF8F9C9C);
}
