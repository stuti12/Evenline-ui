import 'package:flutter/material.dart';
import 'package:travelpals/bottom_tab/match/match.dart';
import 'package:travelpals/bottom_tab/messages/messages.dart';
import 'package:travelpals/bottom_tab/post/posts.dart';
import 'package:travelpals/bottom_tab/profile/profile.dart';
import 'package:travelpals/bottom_tab/trip/trips.dart';
import 'package:travelpals/utils/colors.dart';
import 'package:travelpals/utils/strings.dart';

class TabbarPage extends StatefulWidget {
  const TabbarPage({Key? key}) : super(key: key);

  @override
  State<TabbarPage> createState() => _TabbarPageState();
}

class _TabbarPageState extends State<TabbarPage>
    with SingleTickerProviderStateMixin {
  int selectedIndex = 0;
  bool value = true;
  final _bucket = PageStorageBucket();
  final _key = GlobalKey<ScaffoldState>();
  final GlobalKey<NavigatorState> _navigatorKey = GlobalKey<NavigatorState>();
  List<Widget> pages = [
    const TripsScreen(),
    const MatchScreen(),
    const PostsScreen(),
    const MessagesScreen(),
    const ProfileScreen(),
  ];

  void onSelected(int index) {
    setState(() {
      selectedIndex = index;
    });
    print(selectedIndex);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _key,
      body: PageStorage(
        bucket: _bucket,
        child: pages[selectedIndex],
      ),
      bottomNavigationBar: BottomNavigationBar(
          items: <BottomNavigationBarItem>[
            BottomNavigationBarItem(
              icon: _getBottomBar(
                Icons.home_filled,
                selectedIndex == 0,
                Strings.trips,
              ),
              label: "",
            ),
            BottomNavigationBarItem(
              icon: _getBottomBar(
                Icons.grid_view_rounded,
                selectedIndex == 1,
                Strings.matches,
              ),
              label: "",
            ),
            BottomNavigationBarItem(
              icon: _getBottomBar(
                Icons.edit_note,
                selectedIndex == 2,
                Strings.post,
              ),
              label: "",
            ),
            BottomNavigationBarItem(
              icon: _getBottomBar(
                Icons.local_post_office,
                selectedIndex == 3,
                Strings.messages,
              ),
              label: "",
            ),
            BottomNavigationBarItem(
              icon: _getBottomBar(
                Icons.person,
                selectedIndex == 4,
                Strings.profile,
              ),
              label: "",
            )
          ],
          type: BottomNavigationBarType.fixed,
          unselectedItemColor: AppColors.inputColor,
          selectedItemColor: AppColors.buttonColor,
          selectedFontSize: 11,
          unselectedFontSize: 11,
          onTap: onSelected,
          iconSize: 30,
          elevation: 5),
    );
  }
}

Widget _getBottomBar(IconData icon, bool indicator, String label) {
  return Column(
    children: <Widget>[
      Icon(icon,
          color:
              indicator ? AppColors.buttonColor : AppColors.colorBottomNavText),
      Text(
        label,
        style: TextStyle(
            color:
                indicator ? AppColors.colorText : AppColors.colorBottomNavText,
            fontFamily: 'Amsi Pro Regular'),
      ),
    ],
  );
}
