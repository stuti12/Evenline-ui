package com.example.travelpals

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
